/*
 * CallibrationEditor.java
 * CREATED:    Jun 16, 2005 3:43:33 PM
 * AUTHOR:     Amit Bansil
 * PROJECT:    celest-brightness
 * 
 * Copyright 2005 The Center for Polymer Studies,
 * Boston University, all rights reserved.
 * */
package cps.jarch.simulation.graphics;

public class CalibrationEditor {
	//TODO implement
}
