/*
 * CREATED ON:    Aug 15, 2005 10:54:37 PM
 * CREATED BY:    Amit Bansil 
 */
package cps.jarch.simulation.graphics;

import java.awt.geom.Rectangle2D;

/**
 * TODO document IconEx<br>
 * @version $Id: IconEx.java 523 2005-08-30 21:31:54Z bansil $
 * @author Amit Bansil
 */
public interface IconEx {
	public void paint(GraphicsEx g, Rectangle2D bounds);
}
