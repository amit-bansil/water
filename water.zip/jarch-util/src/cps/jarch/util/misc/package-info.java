/**
 * Miscellaneous utility classes. Fills in gaps in java.lang and java.utils.
 */
package cps.jarch.util.misc;