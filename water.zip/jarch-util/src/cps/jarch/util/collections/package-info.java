/**
 * Utility classes for use with java's collections framework.
 */
package cps.jarch.util.collections;