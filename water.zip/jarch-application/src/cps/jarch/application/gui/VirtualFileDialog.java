/*
 * VirtualFileDialog.java
 * CREATED:    Mar 13, 2005 6:30:29 PM
 * AUTHOR:     Amit Bansil
 * PROJECT:    CELEST-Framework-application
 * 
 * Copyright 2005 The Center for Polymer Studies,
 * Boston University, all rights reserved.
 * */
package cps.jarch.application.gui;

/**
 * 
 * @version 0.0
 * @author Amit Bansil
 */
public class VirtualFileDialog {
	//tODO implement
}
