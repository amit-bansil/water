/*
 * MainFrame.java
 * CREATED:    Jan 8, 2005 8:13:13 PM
 * AUTHOR:     Amit Bansil
 * PROJECT:    CELESTFramework
 * 
 * Copyright 2005 The Center for Polymer Studies,
 * Boston University, all rights reserved.
 * */
package cps.jarch.application.gui;

/**
 * 
 * @version 0.0
 * @author Amit Bansil
 */
public class MainFrame {

	public MainFrame() {
		super();
	}

}
