/*
 * CREATED ON:    Aug 15, 2005 6:24:58 PM
 * CREATED BY:    Amit Bansil 
 */
package cps.jarch.gui.resources;

import cps.jarch.util.notes.Constant;

/**
 * @version $Id: DescribedProxy.java 529 2005-08-31 21:09:53Z bansil $
 * @author Amit Bansil
 */
public interface DescribedProxy {
	public @Constant Described getDescription();
}
