/*
 * ComponentProxy.java
 * CREATED:    Jun 22, 2005 6:45:34 PM
 * AUTHOR:     Amit Bansil
 * PROJECT:    celest-framework-gui
 * 
 * Copyright 2005 The Center for Polymer Studies,
 * Boston University, all rights reserved.
 * */
package cps.jarch.gui.util;

import cps.jarch.util.notes.Constant;

import javax.swing.JComponent;

/**
 * @author Amit Bansil
 * @version $Id: ComponentProxy.java 529 2005-08-31 21:09:53Z bansil $
 */
public interface ComponentProxy {
	public @Constant JComponent getComponent();
}
