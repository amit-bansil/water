/*
 * CREATED ON:    Jun 28, 2005 1:34:13 PM
 * CREATED BY:     Amit Bansil 
 */
package cps.jarch.gui.util;

import javax.swing.JMenu;

public interface MenuProxy {
	public JMenu getMenu();
}
