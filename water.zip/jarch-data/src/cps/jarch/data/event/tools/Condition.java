/*
 * Condition.java
 * CREATED:    Jun 19, 2005 11:28:31 AM
 * AUTHOR:     Amit Bansil
 * PROJECT:    celest-framework-data
 * 
 * Copyright 2005 The Center for Polymer Studies,
 * Boston University, all rights reserved.
 * */
package cps.jarch.data.event.tools;

public interface Condition {
	public boolean check();
}
