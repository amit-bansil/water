/**
 * Structure for connecting components using an {@link java.util.Observable} paradigm.
 * @version $Id$
 * */
package cps.jarch.data.event;