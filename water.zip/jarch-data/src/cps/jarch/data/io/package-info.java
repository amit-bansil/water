/**
 * Allows saving and loading of data. Unlike serialization, where the entire object
 * graph is created again wholesale when loading, this model works by taking an existing
 * object graph and saving/loading the state of those objects. 
 */
package cps.jarch.data.io;