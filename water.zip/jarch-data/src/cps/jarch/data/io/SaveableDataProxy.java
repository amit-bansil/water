/*
 * SaveableDataProxy.java
 * CREATED:    Jun 18, 2005 5:29:11 PM
 * AUTHOR:     Amit Bansil
 * PROJECT:    celest-framework-event
 * 
 * Copyright 2005 The Center for Polymer Studies,
 * Boston University, all rights reserved.
 * */
package cps.jarch.data.io;

public interface SaveableDataProxy {
	//constant
	public SaveableData getData();
}
