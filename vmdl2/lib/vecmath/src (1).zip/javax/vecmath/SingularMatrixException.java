/*
 * $RCSfile: SingularMatrixException.java,v $
 *
 * Copyright (c) 2004 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.1 $
 * $Date: 2004/06/09 02:52:31 $
 * $State: Exp $
 */

package javax.vecmath;

/**
 * Indicates that inverse of a matrix can not be computed.
 */
public class SingularMatrixException extends RuntimeException{

/**
 * Create the exception object with default values.
 */
  public SingularMatrixException(){
  }

/**
 * Create the exception object that outputs message.
 * @param str the message string to be output.
 */
  public SingularMatrixException(String str){

    super(str);
  }

}
