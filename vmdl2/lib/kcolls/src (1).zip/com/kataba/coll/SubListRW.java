//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** An implementation of ListRO which contains only a single element.
 *
 * @author Chris Thiessen
 */
public class SubListRW
    extends AbstractListRW
{
    protected ListRW list;
    protected int fromIndex;
    protected int toIndex;

    /** Constructs to be based on the specified element. */
    public SubListRW(ListRW _list, int _fromIndex, int _toIndex) {
	list = _list;
	fromIndex = _fromIndex;
	toIndex = _toIndex;
	if(fromIndex < 0)
	    throw new IndexOutOfBoundsException("fromIndex:"+fromIndex+", list.size:"+list.size());
	if(fromIndex > toIndex)
	    throw new IllegalArgumentException
		("fromIndex:"+_fromIndex+" > toIndex:"+_toIndex+"");
	if(toIndex > list.size())
	    throw new IndexOutOfBoundsException
		("toIndex:"+toIndex+", list.size:"+list.size());
    }


    //
    // implements CollectionRO
    //

    /** @throws UnsupportedOperationException always (TODO)
     * @see CollectionRO#addListener(CollectionRO.Listener,Object) */
    public void addListener(CollectionRO.Listener listener, Object stoIndexback) {
        throw new UnsupportedOperationException("No support for events on sublists");
    }

    /** @throws UnsupportedOperationException always (TODO)
     * @see CollectionRO#removeListener(CollectionRO.Listener) */
    public void removeListener(CollectionRO.Listener listener) {
        throw new UnsupportedOperationException("No support for events on sublists");
    }

    /** @see CollectionRO#size() */
    public int size() {
	return toIndex - fromIndex;
    }


    //
    // implements CollectionRW
    //

    /** @see CollectionRW#add(Object) */
    public boolean add(Object element) {
        return false;
    }

    /** @see CollectionRW#remove(Object) */
    public boolean remove(Object element) {
        return false;
    }


    //
    // implements ListRO
    //

    /** @see ListRO#addListener(ListRO.Listener,Object) */
    public void addListener(ListRO.Listener listener, Object sendback) {
    }

    /** @see ListRO#removeListener(ListRO.Listener) */
    public void removeListener(ListRO.Listener listener) {
    }

    /** @see ListRO#get(int) */
    public Object get(int index) {
	return list.get(index + fromIndex);
    }


    //
    // implements ListRW
    //

    /** @see ListRW#add(int,Object) */
    public void add(int index, Object element) {
    }

    /** @see ListRW#remove(int) */
    public Object remove(int index) {
        return null;
    }
}
