//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import com.kataba.util.*;

/** Represents a read-write, ordered collection of Objects.
 *
 * <p>The semantics of inherited Collection methods are changed to
 * respect the ordered nature of a List's contents.
 *
 * @author Chris Thiessen
 */
public interface ListRW
    extends ListRO, CollectionRW, java.util.List
{


    /** Swaps the element at 'indexA' with the element at 'indexB'.
     *
     * @exception IndexOutOfBoundsException if either of the specified
     *            indexes is out of bounds.
     */
    public void swap(int indexA, int indexB);

    /** Moves the element at 'fromIndex' to 'toIndex'.  'toIndex' is
     * an index into the list as it is <b>prior</b> to the move.  If
     * 'toIndex' is greater than 'fromIndex', the element will end up
     * at 'toIndex-1'.
     *
     * @exception IndexOutOfBoundsException if either of the specified
     *            indexes is out of bounds.  */
    public void move(int fromIndex, int toIndex);

    /** Removes the elements from index 'start', up to, but not
     * including the element at index 'end'.
     *
     * TODO: remove?
     *
     * @exception IndexOutOfBoundsException if either 'start' or 'end'
     *            is out of bounds
     * @exception IllegalArgumentException if 'end < start'
     */
    public void removeRange(int start, int end);

    /** Removes the elements at the specified indexes.  The contents
     * 'indexes' must be in ascending order, and may contain no
     * duplicates. */
    public void removeAll(ArrayRO_int indexes);

    /** Removes all elements at the indexes *NOT* in the specified
     * 'indexes'.  The contents 'indexes' must be in ascending order,
     * and may contain no duplicates. */
    public void retainAll(ArrayRO_int indexes);

    /** Returns a read-write list cursor initially positioned at the
     * beginning of the List. */
    public ListCursorRW listCursorRW();

    /** Returns a read-write list cursor initially positioned at the
     * specified 'index' into the list.
     *
     * @exception IndexOutOfBoundsException if the specified
     *            'index' is out of bounds
     */
    public ListCursorRW listCursorRW(int index);


    //
    // close equivalents to java.util.List methods
    //

    /** @see ListRW#addAll(int,java.util.Collection) */
    public boolean addAll(int index, CollectionRO collection);

    /** @see ListRW#subList(int,int) */
    public ListRW subListRW(int fromIndex, int toIndex);

    /** @see java.util.List#listIterator() */
    public ListIteratorRW listIteratorRW();

    /** @see java.util.List#listIterator(int) */
    public ListIteratorRW listIteratorRW(int index);


    //
    // implements part of java.util.List
    //

    /** @see java.util.List#add(int,Object) */
    public void add(int index, Object element);

    /** @see java.util.List#addAll(int,java.util.Collection) */
    public boolean addAll(int index, java.util.Collection collection);

    /** @see java.util.List#remove(int) */
    public Object remove(int index);

    /** @see java.util.List#set(int,Object) */
    public Object set(int index, Object newElement);

    /** Returns listIteratorRW()
     *
     * @see java.util.List#listIterator() */
    public java.util.ListIterator listIterator();

    /** Returns listIteratorRW(int)
     *
     * @see java.util.List#listIterator(int) */
    public java.util.ListIterator listIterator(int index);

    /** @see java.util.List#subList(int,int) */
    public java.util.List subList(int fromIndex, int toIndex);
}
