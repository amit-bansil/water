
package com.kataba.coll;

import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.util.NoSuchElementException;

/** This class provides a skeletal implementation of the List
 * interface to minimize the effort required to implement this
 * interface backed by a "random access" data store.
 *
 * <p>Subclasses of this class must define the following methods:
 * <ul>
 *   <li><code>get(int)</code>
 *   <li><code>size()</code>
 *   <li><code>add(int,Object)</code>
 *   <li><code>remove(int)</code>
 *   <li><code>set(int,Object)</code>
 * </ul>
 *
 * <p>Changes to a List can be vetoed, or other related action taken,
 * through the use of a List.PreListener.  A registered PreListener
 * will be called before any requested modification of the List
 * contents is performed.  If an exception is thrown, the action will
 * not take place, and the exception will be passed through to the
 * caller.  Subclasses should call preEvent(...) to have a pre-change
 * event sent.
 *
 * <p>Basic support for tracking Listeners and sending events to them
 * is built in.  Subclasses should call postEvent(...) to have a
 * post-change event sent.
 *
 * <p>Subclasses wishing to provide update notification should
 * increment 'eventDepth' before performing their action, decrement it
 * afterwards, and call postEvent(...).
 *
 * @author Chris Thiessen
 */
public abstract class AbstractListRW
    extends AbstractListRO
    implements ListRW
{
    /** If not 0, the current action is part of a larger action, and
     * events will not be sent. */
    protected int eventDepth = 0;

    /** The CollectionRO.Listener's, stored as a sparse array of
     * CollectionRO.Listener/sendback pairs */
    private Object[] collListeners;
    /** The number of registered CollectionRO.Listeners */
    private int numCollListeners;

    /** The ListRO.Listener's, stored as ListRO.Listener/sendback pairs */
    private Object[] listListeners;
    /** The number of registered ListRO.Listeners */
    private int numListListeners;
    /** The pre-listener to call before modifications are made to the contents of the list */
    private PreListener preListener;

    /** The number of times this List has been <i>structurally
     * modified</i>. Structural modifications are those that change the
     * size of the List, or otherwise perturb it in such a fashion
     * that iterations in progress may yield incorrect results.  This
     * field is used by the the Iterator and ListIterator
     * implementation returned by the iterator and listIterator
     * methods. If the value of this field changes unexpectedly, the
     * Iterator (or ListIterator) will throw a
     * java.util.ConcurrentModificationException in response to the
     * next, remove, previous, set or add operations. This provides
     * <i>fail-fast behavior</i>, rather than non-deterministic
     * behavior in the face of concurrent modification during
     * iteration.
     *
     * <strong>Use of this field by subclasses is optional.</strong>
     * If a subclass wishes to provide fail-fast Iterators (and
     * ListIterators), then it merely has to increment this field in
     * its add(int, Object) and remove(int) methods (and any other
     * methods that it overrides that result in structural
     * modifications to the List).  If an implementation does not
     * wish to provide fail-fast Iterators, this field may be ignored.
     */
    protected transient int modCount = 0;

    /** Implemented by classes which wish to see changes to the List
     * before they occur, to to validate or pre-process those
     * modifications. */
    public interface PreListener {
    /** A number of elements are about to be added.  'indexA' is
     * the index at which they will be added, and 'elements'
     * contains the elements to be added. */
    public static final int ADD = ListRO.Listener.ADD;

    /** A range of elements will be removed, from 'indexA', up to
     * but not including 'indexB'. */
    public static final int REMOVE_RANGE = ListRO.Listener.REMOVE_RANGE;

    /** Elements with disjoint indexes will be removed. 'indexes'
     * contains the indexes of the elements to be removed. */
    public static final int REMOVE_DISJOINT = ListRO.Listener.REMOVE_DISJOINT;

    /** A range of elements will be replaced, starting at
     * 'indexA'.  'elements' contains the elements that replace
     * the existing range of elements starting at 'indexA'. */
    public static final int REPLACE_RANGE = ListRO.Listener.REPLACE_RANGE;

    /** The element at 'indexA' will be moved to 'indexB' */
    public static final int MOVE = ListRO.Listener.MOVE;
 
    /** The element at 'indexA' will be swapped with the one at 'indexB' */
    public static final int SWAP = ListRO.Listener.SWAP;

    /** Called before content-changing actions are taken on the
     * listened-to AbstractListRW.  If a RuntimeException is
     * thrown, the action will be cancelled.
     *
     * @param event    the event ID, one of
         *       { ADD, REMOVE_RANGE, REPLACE_DISJOINT, REPLACE_RANGE, MOVE, SWAP }
     * @param indexA   see the event ID descriptions
     * @param indexB   see the event ID descriptions
     * @param elements see the event ID descriptions.
         *                 NOTE: the contents of this ListRO may
         *                 change after the event is handled.  Make a
         *                 copy if you want to keep it around.
     */
    public void preEvent(int event
                 , int indexA, int indexB, ArrayRO_int indexes
                 , ListRO elements);

    /* copy-paste for event switching
    switch(event) {
    case AbstractListRW.PreListener.ADD:
    case AbstractListRW.PreListener.REMOVE_RANGE:
    case AbstractListRW.PreListener.REMOVE_DISJOINT:
    case AbstractListRW.PreListener.REPLACE_RANGE:
    case AbstractListRW.PreListener.MOVE:
    case AbstractListRW.PreListener.SWAP:
    }
    //*/
    }

    /** Sets the pre-listener.  The pre-listener is called with
     * details of any list-modification operations BEFORE the changes
     * occur. */
    public void setPreListener(PreListener listener) {
        preListener = listener;
    }

    /** Called before an action is taken */
    protected void preEvent(int event
                            , int indexA, int indexB, ArrayRO_int indexes
                            , ListRO elements) {
        if(preListener != null)
            preListener.preEvent(event, indexA, indexB, indexes, elements);
    }

    /** Returns whether pre-events are enabled */
    protected boolean preEventEnabled() {
        if(eventDepth != 0)
            return false;
        return preListener != null;
    }


    /** Returns the current level of post-event nesting.  Based at 0. */
    protected int postEventDepth() {
        return eventDepth;
    }

    /** Returns whether or not there are any registered ListRO.Listeners */
    protected boolean postEventEnabled(int event) {
        if(eventDepth != 0)
            return false;
        switch(event) {
        case ListRO.Listener.ADD:
        case ListRO.Listener.REMOVE_RANGE:
        case ListRO.Listener.REMOVE_DISJOINT:
        case ListRO.Listener.REPLACE_RANGE:
            return numListListeners > 0 || numCollListeners > 0;
        case ListRO.Listener.MOVE:
        case ListRO.Listener.SWAP:
            return numListListeners > 0;
        default:
            throw new IllegalArgumentException("Unrecognized event ("+event+")");
        }
    }

    /** Fires a List event */
    protected void postEvent(int event, int indexA, int indexB, ArrayRO_int indexes
                             , ListRO elements) {
        if(numCollListeners > 0) {
            // convert the list event into a collection event
            int collEvent = -1;
            CollectionRO elementsA = null;
            CollectionRO elementsB = null;

            switch(collEvent) {
            case ListRO.Listener.ADD:
                collEvent = CollectionRO.Listener.ADD;
                elementsA = new SubListRO(this, indexA, indexB+1);
                break;
            case ListRO.Listener.REMOVE_RANGE:
            case ListRO.Listener.REMOVE_DISJOINT:
                collEvent = CollectionRO.Listener.REMOVE;
                elementsA = elements;
                break;
            case ListRO.Listener.REPLACE_RANGE:
                collEvent = CollectionRO.Listener.REPLACE;
                elementsA = elements;
                elementsB = new SubListRO(this, indexA, indexB);
                break;
            case ListRO.Listener.MOVE:
            case ListRO.Listener.SWAP:
                break;
            }

            // if there is a corresponding collection event, send it
            if(collEvent != -1) {
                for(int i=0; i<collListeners.length; i+=2) {
                    CollectionRO.Listener listener
                        = (CollectionRO.Listener)collListeners[i];
                    Object sendback = listListeners[i+1];
                    try {
                        if(listener != null)
                            listener.collectionEvent
                                (sendback, this, collEvent, elementsA, elementsB);
                    } catch(RuntimeException ex) {
                        onCollListenerEx(listener, sendback, ex);
                    }
                }
            }
        }

        // send the event to each list event listener
        if(listListeners != null) {
            for(int i=0; i<listListeners.length; i+=2) {
                ListRO.Listener listener = (ListRO.Listener)listListeners[i];
                Object sendback = listListeners[i+1];
                try {
                    if(listener != null)
                        listener.listEvent
                            (sendback, this, event, indexA, indexB, indexes, elements);
                } catch(RuntimeException ex) {
                    onListListenerEx(listener, sendback, ex);
                }
            }
        }
    }

    /** Called when an exception is thrown by a CollectionRO.Listener
     * when passed an event by this List.
     *
     * @param listener the listener which was threw the exception
     * @param sendback the sendback object the listener was registered with
     * @param ex the exception that was thrown
     */
    protected void onCollListenerEx(CollectionRO.Listener listener, Object sendback
                                    , RuntimeException ex) {
        Out.ln("Exception on handling of a collection event");
        ex.printStackTrace(Out.out);
    }

    /** Called when an exception is thrown by a ListRO.Listener
     * when passed an event by this List.
     *
     * @param listener the listener which was threw the exception
     * @param sendback the sendback object the listener was registered with
     * @param ex the exception that was thrown
     */
    protected void onListListenerEx(ListRO.Listener listener, Object sendback
                                    , RuntimeException ex) {
        Out.ln("Exception on handling of a list event");
        ex.printStackTrace(Out.out);
    }

    /*
    private EventElements_Single single = new EventElements_Single(null);
    private static class EventElements_Single extends SingleElementListRO {
        private EventElements_Single(Object _element) {
            super(_element);
        }
    }
    //*/
    protected ListRO single(Object element) {
        return new SingleElementListRO(element);
        //return new EventElements_Single(element);
        //return new DefaultListRO(element);
        /*
        if(single != null)
            single.element = element;
        else
            single = new EventElements_Single(element);
        return single;
        //*/
    }


    //
    // implements CollectionRO
    //

    /** @see CollectionRO#addListener */
    public void addListener(CollectionRO.Listener listener
                                      , Object sendback) {
        if(listener == null)
            return;
        collListeners = PairUtil.add(collListeners, numCollListeners++
                                     , listener, sendback);
    }

    /** @see CollectionRO#removeListener */
    public void removeListener(CollectionRO.Listener listener) {
        int pair = PairUtil.find(collListeners, numCollListeners, listener);
        if(pair != -1)
            PairUtil.swapRemove(collListeners, numCollListeners--, pair);
    }

    // abstract methods

    /** @see CollectionRO#size */
    public abstract int size();


    //
    // implements CollectionRW
    //

    /** @see CollectionRW#add(Object) */
    public boolean add(Object element) {
        add(size(), element);
        return true;
    }

    /** @see CollectionRW#addAll(CollectionRO) */
    public boolean addAll(CollectionRO collection) {
        addAll(size(), collection);
        return collection.size() > 0;
    }

    /** @see CollectionRW#addAll(java.util.Collection) */
    public boolean addAll(java.util.Collection collection) {
        return addAll((CollectionRO)new CollectionToCollectionRW(collection));
    }

    /** @see CollectionRW#clear() */
    public void clear() {
        if(size() != 0)
            removeRange(0, size());
    }

    /** @see CollectionRW#remove(Object) */
    public boolean remove(Object element) {
        int index = indexOf(element, 0, true);
        if(index == -1)
            return false;
        else {
            remove(index);
            return true;
        }
    }

    /** @see CollectionRW#removeAll(CollectionRO) */
    public boolean removeAll(CollectionRO collection) {
        ArrayRO_int indexes = indexesOf(collection);
        if(indexes.size() == 0)
            return false;
        removeAll(indexes);
        return true;
    }

    /** @see CollectionRW#removeAll(java.util.Collection) */
    public boolean removeAll(java.util.Collection collection) {
        return removeAll((CollectionRO)new CollectionToCollectionRW(collection));
    }

    /** @see CollectionRW#removeAll(CollectionRO) */
    public boolean retainAll(CollectionRO collection) {
        ArrayRO_int indexes = indexesOf(collection);
        if(indexes.size() == 0)
            return false;
        retainAll(indexes);
        return true;
    }

    /** @see CollectionRW#retainAll(java.util.Collection) */
    public boolean retainAll(java.util.Collection collection) {
        return retainAll((CollectionRO)new CollectionToCollectionRW(collection));
    }

    /** @see CollectionRW#iteratorRW() */
    public IteratorRW iteratorRW() {
        return new DefaultListIteratorRW(listCursorRW());
    }

    /** @see CollectionRW#iterator() */
    public java.util.Iterator iterator() {
        return iteratorRW();
    }


    // abstract methods


    //
    // implements ListRO
    //

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO() {
        return listCursorRW();
    }

    /** @see ListRO#addListener */
    public void addListener(ListRO.Listener listener, Object sendback) {
        if(listener == null)
            return;
        listListeners = PairUtil.add(listListeners, numListListeners++
                                     , listener, sendback);
    }

    /** @see ListRO#removeListener */
    public void removeListener(ListRO.Listener listener) {
        int pair = PairUtil.find(listListeners, numListListeners, listener);
        if(pair != -1)
            PairUtil.swapRemove(listListeners, numListListeners--, pair);
    }

    // abstract methods

    /** @see ListRO#get(int) */
    public abstract Object get(int index);


    //
    // implements ListRW
    //

    /** @see ListRW#subListRW(int,int) */
    public ListRW subListRW(int fromIndex, int toIndex) {
        return new SubListRW(this, fromIndex, toIndex);
    }

    /** @see ListRW#subList(int,int) */
    public java.util.List subList(int fromIndex, int toIndex) {
        return subListRW(fromIndex, toIndex);
    }

    /** @see ListRW#addAll(int,java.util.Collection) */
    public boolean addAll(int index, java.util.Collection coll) {
        return addAll(index, (CollectionRO)new CollectionToCollectionRW(coll));
    }

    /** @see ListRW#addAll(int,CollectionRO) */
    public boolean addAll(int index, CollectionRO collection) {
        if(collection == null)
            throw new NullPointerException("collection == null");
        if(collection.size() == 0)
            return false;
        if(index < 0 || index > size())
            throw new IndexOutOfBoundsException("index:"+index+", size:"+size());

        // fire the pre event
        if(preEventEnabled())
            preEvent(PreListener.ADD, index, -1, null, new DefaultListRO(collection));

        eventDepth++;
        int numAdded = 0;
        for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); )
            add(index + numAdded++, itr.next());
        eventDepth--;

        /*
        Out.ln();
        Out.ln("AbstractList.addAll("+index+", "+collection+")");
        Out.ln("  numListListeners: " + numListListeners);
        Out.ln("  eventDepth: " + eventDepth);
        Out.ln("  postEventEnabled(ListRO.Listener.ADD): "+postEventEnabled(ListRO.Listener.ADD));
        */

        // fire the post event
        if(postEventEnabled(ListRO.Listener.ADD)) {
            postEvent(ListRO.Listener.ADD, index, index+numAdded, null, null);
        }

        return true;
    }

    /** @see ListRW#set(int,Object) */
    public Object set(int index, Object element) {
        if(index < 0 || index >= size())
            throw new IndexOutOfBoundsException("index:"+index+", size:"+size());
        Object oldElement = get(index);

        // fire the pre event
        if(preEventEnabled())
            preEvent(PreListener.REPLACE_RANGE, index, index+1, null, single(element));

        eventDepth++;
        remove(index);
        add(index, element);
        eventDepth--;

        // fire the post event
        if(postEventEnabled(ListRO.Listener.REPLACE_RANGE))
            postEvent(ListRO.Listener.REPLACE_RANGE, index, index+1
                      , null, single(oldElement));

        return oldElement;
    }

    /** @see ListRW#swap(int,int) */
    public void swap(int indexA, int indexB) {
        if(indexA < 0 || indexA >= size())
            throw new IndexOutOfBoundsException("indexA:" + indexA + ", size:" + size());
        if(indexB < 0 || indexB >= size())
            throw new IndexOutOfBoundsException("indexB:" + indexB + ", size:" + size());

        // fire the pre event
        if(preEventEnabled())
            preEvent(PreListener.SWAP, indexA, indexB, null, null);

        // swap elements
        eventDepth++;
        Object temp = get(indexA);
        set(indexA, get(indexB));
        set(indexB, temp);
        eventDepth--;

        // fire the post event
        if(postEventEnabled(ListRO.Listener.SWAP))
            postEvent(ListRO.Listener.SWAP, indexA, indexB, null, null);
    }

    /** @see ListRW#move(int,int) */
    public void move(int fromIndex, int toIndex) {
        if(fromIndex < 0 || fromIndex >= size())
            throw new IndexOutOfBoundsException("fromIndex:"+fromIndex+", size:"+size());
        if(toIndex < 0 || toIndex > size())
            throw new IndexOutOfBoundsException("toIndex:"+toIndex+", size:"+size());

        // if the move isn't required
        if(toIndex == fromIndex || toIndex == fromIndex+1)
            return;

        // fire the pre event
        if(preEventEnabled())
            preEvent(PreListener.MOVE, fromIndex, toIndex, null, null);

        // do the move
        eventDepth++;
        add(toIndex, get(fromIndex));
        remove(fromIndex);
        eventDepth--;

        // fire the post event
        if(postEventEnabled(ListRO.Listener.MOVE))
            postEvent(ListRO.Listener.MOVE, fromIndex, toIndex, null, null);
    }

    /** @see ListRW#listCursorRW() */
    public ListCursorRW listCursorRW() {
        return listCursorRW(0);
    }

    /** @see ListRW#listCursorRW(int) */
    public ListCursorRW listCursorRW(int index) {
        return new Cursor();
    }

    /** @see ListRW#listIteratorRW() */
    public ListIteratorRW listIteratorRW() {
        return new DefaultListIteratorRW(listCursorRW());
    }

    /** @see ListRW#listIteratorRW(int) */
    public ListIteratorRW listIteratorRW(int index) {
        return new DefaultListIteratorRW(listCursorRW(index));
    }

    /** @see ListRW#listIterator() */
    public java.util.ListIterator listIterator() {
        return listIteratorRW();
    }

    /** @see ListRW#listIteratorRW(int) */
    public java.util.ListIterator listIterator(int index) {
        return listIteratorRW(index);
    }

    /** @see ListRW#removeRange(int,int) */
    public void removeRange(int start, int end) {
        if(start < 0)
            throw new IndexOutOfBoundsException("start:"+start+" < 0");
        if(start > end)
            throw new IllegalArgumentException
                ("start:"+start+" > end:"+end);
        if(end > size())
            throw new IndexOutOfBoundsException
                ("end:"+end+" > size:"+size());

        if(end - start == 0)
            return;

        // fire the pre event
        if(preEventEnabled())
            preEvent(PreListener.REMOVE_RANGE, start, end, null, null);

        // prepare to fire the change event
        ListRO oldElements = null;
        boolean postEventEnabled = postEventEnabled(ListRO.Listener.REMOVE_RANGE);
        if(postEventEnabled)
            oldElements = new DefaultListRO(toArray(start, end));

        // remove the range of elements
        eventDepth++;
        for(int i=end-1; i>=start; i--)
            remove(i);
        eventDepth--;

        // fire the collection and list events
        if(postEventEnabled)
            postEvent(ListRO.Listener.REMOVE_RANGE, start, end, null, oldElements);
    }

    /** @see ListRW#retainAll(ArrayRO_int) */
    public void retainAll(ArrayRO_int indexes) {
        validateIndexes(indexes);

        // invert the indexes
        int[] inverse = new int[size() - indexes.size()];
        int inverse_i = 0;
        int indexes_i = 0;
        for(int i=0; i<size(); i++) {
            if(i == indexes.get(indexes_i))
                indexes_i++;
            else
                inverse[inverse_i++] = i;
        }

        // remove
        removeAll_internal(new ArrayRO_int(inverse));
    }

    /** @see ListRW#removeAll(ArrayRO_int) */
    public void removeAll(ArrayRO_int indexes) {
        validateIndexes(indexes);
        removeAll_internal(indexes);
    }

    /** Validates that the specified 'indexes' contain ascending,
     * non-duplicating indexes */
    private void validateIndexes(ArrayRO_int indexes) {
        // validate the indexes
        int size = size();
        int lastIndex = -1;
        if(indexes.get(0) < 0)
            throw new IndexOutOfBoundsException
                ("indexes[0]:"+indexes.get(0)+", size:" + size);
        for(int i=0,ii=indexes.size(); i<ii; i++) {
            int index = indexes.get(i);
            if(index <= lastIndex)
                throw new IllegalArgumentException
                    ("indexes["+i+"]:"+index+" > indexes["+(i-1)+"]:"+lastIndex);
            if(index >= size)
                throw new IndexOutOfBoundsException
                    ("indexes["+i+"]:"+index+", size:" + size);
            lastIndex = index;
        }
    }

    /** Removes all elements at the specified 'indexes' from the
     * ListRW.  If 'invert' is true, removes all elements which are
     * *not* at the specified 'indexes' */
    private void removeAll_internal(ArrayRO_int indexes) {
        if(indexes.size() == 0)
            return;

        // fire the pre event
        if(preEventEnabled())
            preEvent(PreListener.REMOVE_DISJOINT, -1, -1, indexes, null);

        // do the removal
        boolean postEventEnabled = postEventEnabled(ListRO.Listener.REMOVE_DISJOINT);
        ListRW eventElements = null;
        eventDepth++;
        if(postEventEnabled) {
            eventElements = new GapListRW();
            for(int i=indexes.size()-1; i>=0; i--) {
                int index = indexes.get(i);
                eventElements.add(0, get(index));
                remove(index);
            }
        } else {
            for(int i=indexes.size()-1; i>=0; i--)
                remove(indexes.get(i));
        }
        eventDepth--;

        // fire the post event
        if(postEventEnabled)
            postEvent(ListRO.Listener.REMOVE_DISJOINT, -1, -1, indexes, eventElements);
    }


    // abstract methods

    /** @see ListRW#add(int,Object) */
    public abstract void add(int index, Object element);

    /** @see ListRW#remove(int) */
    public abstract Object remove(int index);


    //
    // inner classes
    //

    /** The cursor.  Subclasses DefaultListCursorRW to provide the
     * safety of fail-fast. */
    protected class Cursor
        extends DefaultListCursorRW
    {
        protected int expectedModCount;

        /** Constructs */
        public Cursor() {
            super(AbstractListRW.this, 0);
            updateModCount();
        }

        /** Throws a <code>java.util.ConcurrentModificationException</code>
         * exception if the list has been structurally modified since
         * this cursor was last used. */
        protected void checkModCount() {
            if(expectedModCount != AbstractListRW.this.modCount)
                throw new java.util.ConcurrentModificationException();
        }

        /** Updates the expected 'modCount' */
        protected void updateModCount() {
            expectedModCount = AbstractListRW.this.modCount;
        }

        //
        // ListCursorRO
        //

        /** @see ListCursorRO#lock() */
        public Object lock() {
            checkModCount();
            Object result = super.lock();
            updateModCount();
            return result;
        }

        /** @see ListCursorRO#size() */
        public int size() {
            checkModCount();
            int result = super.size();
            updateModCount();
            return result;
        }

        /** @see ListCursorRO#index() */
        public int index() {
            checkModCount();
            int result = super.index();
            updateModCount();
            return result;
        }

        /** @see ListCursorRO#canGet(int) */
        public boolean canGet(int offset) {
            checkModCount();
            boolean result = super.canGet(offset);
            updateModCount();
            return result;
        }

        /** @see ListCursorRO#get(int) */
        public Object get(int offset) {
            checkModCount();
            Object result = super.get(offset);
            updateModCount();
            return result;
        }

        /** @see ListCursorRO#canMove(int) */
        public boolean canMove(int offset) {
            checkModCount();
            boolean result = super.canMove(offset);
            updateModCount();
            return result;
        }

        /** @see ListCursorRO#move(int) */
        public void move(int offset) {
            checkModCount();
            super.move(offset);
            updateModCount();
        }


        //
        // implements ListCursor
        //

        /** @see ListCursorRW#add(int,Object) */
        public void add(int offset, Object element) {
            checkModCount();
            super.add(offset, element);
            updateModCount();
        }

        /** @see ListCursorRW#remove(int) */
        public void remove(int offset) {
            checkModCount();
            super.remove(offset);
            updateModCount();
        }

        /** @see ListCursorRW#set(int,Object) */
        public void set(int offset, Object element) {
            checkModCount();
            super.set(offset, element);
            updateModCount();
        }
    }
}
