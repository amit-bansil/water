
package com.kataba.coll;

import com.kataba.util.*;

/** A read-only ListIterator over the elements of some collection of
 * elements of type <code>Object</code>.  Clients should synchronize
 * on 'lock()' if they wish to thread-safe their access to this
 * ListIteratorRO.
 *
 * @author Chris Thiessen
 */
public interface ListIteratorRO
    extends IteratorRO
{
    //
    // implements the read-only portion of java.util.ListIterator
    //

    /** @see java.util.ListIterator#hasPrevious() */
    public boolean hasPrevious();

    /** @see java.util.ListIterator#previous() */
    public Object previous();

    /** @see java.util.ListIterator#nextIndex() */
    public int nextIndex();

    /** @see java.util.ListIterator#previousIndex() */
    public int previousIndex();
}
