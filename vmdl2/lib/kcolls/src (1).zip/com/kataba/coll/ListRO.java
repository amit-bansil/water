//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import com.kataba.util.*;

/** Represents a read-only, ordered collection of Objects.
 *
 * <p>While this interface provides no modification methods, there is
 * no guarantee that the contents of the ListRO will remain unchanged.
 * An implementation of ListRO.Listener which is registered with a
 * ListRO (@see addListener(Listener,Object) ) will receive
 * notifications of changes to the contents of the ListRO after they
 * occur.
 *
 * <p>The semantics of inherited CollectionRO methods are changed to
 * respect the order of the ListRO.
 *
 * <p>An implementation of this interface should document its rules of
 * object equivalence.
 *
 * @see java.util.List
 * @author Chris Thiessen
 */
public interface ListRO
    extends CollectionRO
{

    /** Implemented by classes which wish to be notified of changes to
     * the contents of a ListRO */
    public interface Listener {
	/** A range of elements were added, starting at 'indexA', up
         * to, but not including 'indexB' */
	public static final int ADD = 1;

	/** A range of elements were replaced, from 'indexA', up to
	 * but not including 'indexB'.  'elements' contains the
	 * removed elements. */
	public static final int REMOVE_RANGE = 2;

	/** Elements were removed. 'indexes' contains the indexes, in
	 * ascending order, of the removed elements before removal,
	 * and 'elements' contains those removed elements in the same
	 * order. */
	public static final int REMOVE_DISJOINT = 3;

	/** A range of elements were replaced, from 'indexA', up to
	 * but not including 'indexB'.  'elements' contains the
	 * replaced elements, in their original order. */
	public static final int REPLACE_RANGE = 4;

	/** The element at 'indexA' was moved to 'indexB', where
	 * 'indexB' is a valid location BEFORE the move.  If 'indexA'
	 * was less than 'indexB', the element will have ended up at
	 * 'indexB-1'. */
	public static final int MOVE = 5;

	/** The element at 'indexA' was swapped with the one at 'indexB' */
	public static final int SWAP = 6;

	/** Called when the content of the listened-to ListRO changes.
	 * Thrown exceptions will not prevent any other Listeners from
	 * being notified of the event.
	 *
	 * @param sendback the Object that this Listener was registered along with
	 * @param source   the ListRO which changed
	 * @param event    the event ID, one of
         *       { ADD, REMOVE_RANGE, REPLACE_DISJOINT, REPLACE_RANGE, MOVE, SWAP }
	 * @param indexA   see the event ID descriptions
	 * @param indexB   see the event ID descriptions
	 * @param elements see the event ID descriptions.
         *                 NOTE: the contents of this ListRO may
         *                 change after the event is handled.  Make a
         *                 copy if you want to keep it around.
	 */
	public void listEvent(Object sendback, ListRO source, int event
			      , int indexA, int indexB
                              , ArrayRO_int indexes, ListRO elements);

	/* copy-paste for event switching
	switch(event) {
	case ListRO.Listener.ADD:
	case ListRO.Listener.REMOVE_RANGE:
	case ListRO.Listener.REMOVE_DISJOINT:
	case ListRO.Listener.REPLACE_RANGE:
	case ListRO.Listener.MOVE:
	case ListRO.Listener.SWAP:
	}
	*/
    }

    /** Registers a listener to be triggered when the contents of this
     * ListRO change.  The 'sendback' is passed to the 'listener' with
     * each event, to provide context. */
    public void addListener(Listener listener, Object sendback);

    /** Deregisters a listener registered to be notified when the
     * contents of this ListRO change.  More specifically, deregisters
     * the listener which is == to the specified 'listener'. */
    public void removeListener(Listener listener);

    /** Searches the list for an element matching the specified
     * 'element' under the ListRO's rules of object equivalence.  The
     * search starts at specified index and searches in the specified
     * direction (true=forwards, false=backwards).  Returns the index
     * of the first matching element it finds, or <code>-1</code> if
     * no such element is found.
     *
     * @param object the match of the element to be found
     * @param startIndex the index at which to begin the search
     * @param direction <code>true</code> to move forward,
     *                  <code>false</code> to move backwards
     * @return the index of the matching element, or -1 if none is found
     * @exception IndexOutOfBoundsException if the startIndex is invalid.
     */
    public int indexOf(Object object, int startIndex, boolean direction);

    /** Returns an ArrayRO_int containing the indexes of each element
     * in the ListRO which is a match for an element in the specified
     * 'coll'.  The indexes will be returned in order. */
    public ArrayRO_int indexesOf(CollectionRO coll);

    /** Returns a read-only list cursor positioned at the beginning of
     * the ListRO. */
    public ListCursorRO listCursorRO();

    /** Returns a read-only list cursor positioned at the specified
     * 'index' into the ListRO
     *
     * @exception IndexOutOfBoundsException if the specified
     *            'index' is out of bounds
     */
    public ListCursorRO listCursorRO(int index);


    //
    // close equivalenst to java.util.List methods
    //

    /** @see java.util.List#subList(int,int) */
    public ListRO subListRO(int fromIndex, int toIndex);

    /** Returns a read-only ListIteratorRO over the contents of this
     * ListRO.
     *
     * @see java.util.List#listIterator() */
    public ListIteratorRO listIteratorRO();

    /** Returns a read-only ListIteratorRO over the contents of this
     * ListRO, starting at the specified 'index'.
     *
     * @see java.util.List#listIterator() */
    public ListIteratorRO listIteratorRO(int index);


    //
    // implements read-only part of java.util.List
    //

    /** @see java.util.List#get(int) */
    public Object get(int index);

    /** @see java.util.List#indexOf(Object) */
    public int indexOf(Object element);

    /** @see java.util.List#lastIndexOf(Object) */
    public int lastIndexOf(Object element);

    /** The same as <code>java.util.List.equals(Object)</code> except
     * that it treats ListRO in the same way.
     *
     * @see java.util.List#equals(Object)
     */
    public boolean equals(Object object);

    /** @see java.util.List#equals */
    public int hashCode();
}
