//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** A Collection in which no contained element may be equal to any
 * other contained element, according to the Set's rules of
 * equivalence.
 *
 * <p>An implementation of this interface should document its rules of
 * object equivalence.
 *
 *
 * @see java.util.Set
 * @author Chris Thiessen
 */
public interface SetRW
    extends CollectionRW, SetRO, java.util.Set
{
}
