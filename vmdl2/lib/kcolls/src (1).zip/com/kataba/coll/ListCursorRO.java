//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import com.kataba.util.*;

/** An interface which represents a read-only list cursor, a
 * representation of a position in a list.  A list cursor's position,
 * index(), can have values from 0 to the size of the list; that is,
 * from before the first element to just after the last element.
 *
 * <p>eg. to iterate forwards through a list:
 * <pre>
 * // print every other element of the list
 * ListCursorRO cursor = list.listCursorRO();
 * while(cursor.canGet(0)) {
 *     System.out.println("element: " + cursor.get(0));
 *     cursor.move(1);
 * }
 *
 * // a slightly more compressed idiom of the same
 * for(ListCursorRO cur=list.listCurRO(); cur.canGet(0); cur.move(1))
 *     System.out.println("element: " + cur.get(0));
 * </pre>
 *
 * <p>eg. to iterate backwards through every other element of a list
 * <pre>
 * // print every other element of the list
 * ListCursorRO cursor = list.listCursorRO(list.size());
 * while(cursor.canGet(-1)) {
 *     System.out.println("element: " + cursor.get(-1));
 *     cursor.moveCrop(-2);
 * }
 *
 * // a slightly more compressed idiom of the same
 * for(ListCursorRO cur=list.listCursorRO(list.size()); cur.canGet(-1); cur.moveCrop(-2))
 *     System.out.println("element: " + cur.get(-1));
 * </pre>
 *
 * @see ListRO#listCursorRO()
 * @see ListRO#listCursorRO(int)
 * @author Chris Thiessen
 */
public interface ListCursorRO
    extends Lockable
{
    /** Returns the number of elements in the underlying list. */
    public int size();

    /** Returns the index of the element immediately following the
     * cursor's position.  The index() can only be from 0 to the size
     * of the list, inclusive.  If the index() is the size of the
     * list, then it is not followed by an element.  */
    public int index();

    /** Sets the current 'index' of the cursor.  The 'index' must be
     * between 0 and the size of the list, inclusive.  The 'index' is
     * the index of the element immediately following the cursor's
     * position. */
    public void setIndex(int index);

    /** Returns whether 'get(offset)' will succeed. */
    public boolean canGet(int offset);

    /** Returns the element at 'index()+offset'.
     *
     * @exception IndexOutOfBoundsException if <code>offset</code>
     *            puts the cursor out of bounds for a 'get(...)'.
     */
    public Object get(int offset);

    /** Returns whether 'move(offset)' will succeed */
    public boolean canMove(int offset);

    /** Moves the cursor 'offset' elements from its current location.
     *
     * @exception IndexOutOfBoundsException if the 'offset'
     *            puts the cursor out of bounds.
     */
    public void move(int offset);

    /** Moves the cursor 'offset' elements from its current location.
     * If that new location overshoots the beginning or end of the
     * list, the move is cropped to the beginning or end of the list,
     * respectively. */
    public void moveCrop(int offset);
}
