
package com.kataba.coll;

import com.kataba.coll.wrap.*;
import com.kataba.util.*;

/** This class provides a skeletal implementation of the SetRO
 * interface to minimize the effort required to implement this
 * interface.
 *
 * <p>Concrete subclasses of this class must define the following methods:
 * <ul>
 *   <li><code>size()</code>
 *   <li><code>add(Object element)</code>
 *   <li><code>remove(Object element)</code>
 *   <li><code>clear()</code>
 *   <li><code>IteratorRW iteratorRW()</code>
 * </ul>
 *
 * @author Chris Thiessen
 */
public abstract class AbstractSetRW
    extends AbstractCollectionRW
    implements SetRW
{
    /** Constructs */
    public AbstractSetRW() {
    }

    /** Constructs to use the specified Identifier on elements */
    public AbstractSetRW(Identifier _identifier) {
	super(_identifier);
    }


    //
    // implements SetRO
    //

    /** @see SetRO#union(SetRO) */
    public SetRO union(SetRO set) {
        HashSetRW result = new HashSetRW();
        result.addAll((SetRO)this);
        result.addAll(set);
        return result;
    }

    /** @see SetRO#intersection(SetRO) */
    public SetRO intersection(SetRO set) {
        HashSetRW result = new HashSetRW();
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(set.contains(element))
                result.add(element);
        }
        return result;
    }

    /** @see SetRO#xor(SetRO) */
    public SetRO xor(SetRO set) {
        HashSetRW result = new HashSetRW();

        // add the needed elements from 'this'
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(!set.contains(element))
                result.add(element);
        }

        // add the needed elements from 'set'
        for(IteratorRO itr=set.iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(!contains(element))
                result.add(element);
        }

        return result;
    }

    /** @see SetRO#equals(Object) */
    public boolean equals(Object object) {
        SetRO set;
        if(object == null)
            return false;
        else if(object instanceof SetRO)
            set = (SetRO)object;
        else if(object instanceof java.util.Set)
            set = new SetToSetRW((java.util.Set)object);
        else
            return false;

        // if the 'set' contains all the elements of this 'set', return true
        if(set.size() != size())
            return false;
        return containsAll(set);
    }

    //
    // implements CollectionRO
    //

    /** @see CollectionRO#size */
    public abstract int size();


    //
    // implements CollectionRW
    //

    /** @see CollectionRW#addAll(CollectionRO) */
    public boolean addAll(CollectionRO collection) {
	if(collection == null)
	    throw new NullPointerException("collection == null");
	if(collection.size() == 0)
	    return false;

        // prepare for events
        boolean hasPre = preEventEnabled();
        boolean hasPost = postEventsEnabled();
        HashSetRW added = null;
        if(hasPre || hasPost) {
            added = new HashSetRW();
            for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); ) {
                Object element = itr.next();
                if(!contains(element))
                    added.add(element);
            }
        }

        // pre-event
        if(hasPre && added.size() > 0)
            preEvent(PreListener.ADD, added, null);

	// do the add, keeping track of added events
	eventDepth++;
        boolean changed = false;
        for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); ) {
	    Object element = itr.next();
            changed = add(element) || changed;
	}
	eventDepth--;

	// post-event
	if(hasPost && added.size() > 0)
	    postEvent(CollectionRO.Listener.ADD, added, null);

	return changed;
    }

    /** @see CollectionRW#removeAll(CollectionRO) */
    public boolean removeAll(CollectionRO collection) {
	if(collection == null)
	    throw new NullPointerException("collection == null");
	if(collection.size() == 0)
	    return false;

        // prepare for events
        boolean hasPre = preEventEnabled();
        boolean hasPost = postEventsEnabled();
        HashSetRW removed = null;
        if(hasPre || hasPost) {
            removed = new HashSetRW();
            for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); ) {
                Object element = itr.next();
                if(contains(element))
                    removed.add(element);
            }
        }

        // pre-event
        if(hasPre && removed.size() > 0)
            preEvent(PreListener.REMOVE, removed, null);

	// do the remove, keeping track of removed events
	eventDepth++;
        boolean changed = false;
        for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); ) {
	    Object element = itr.next();
	    changed = remove(element) || changed;
	}
	eventDepth--;

	// fire the event
	if(hasPost && removed.size() > 0)
	    postEvent(CollectionRO.Listener.REMOVE, removed, null);

	return changed;
    }

    /** @see CollectionRW#add */
    public abstract boolean add(Object element);

    /** @see CollectionRW#remove */
    public abstract boolean remove(Object element);

    /** @see CollectionRW#clear */
    public abstract void clear();

    /** @see CollectionRW#iterator */
    public abstract IteratorRW iteratorRW();
}
