//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import com.kataba.util.*;

/** Keeps the contents of a destination ListRW matched up with the
 * contents of a source ListRO.  That is, when the source changes, the
 * destination is updated to match.  Subclasses can override
 * 'newDestElement(int)' to override what is meant by 'creating a
 * matching destination element'
 *
 * @author Chris Thiessen
 */
public class ListTracker
    implements ListRO.Listener
{
    private ListRO source;
    private ListRW singleDest;
    private int offset;

    /** Constructs */
    protected ListTracker(ListRO _source, int _destOffset) {
        offset = _destOffset;
        setSource(_source);
    }

    /** Constructs */
    public ListTracker(ListRO _source, ListRW _dest) {
	this(_source, _dest, 0);
    }

    /** Constructs to track the contents of '_source' by modifying
     * '_dest' on list events.  All modifications of '_dest' are
     * offset by '_destOffset' index positions; this allows a fixed
     * header and footer in '_dest' */
    public ListTracker(ListRO _source, ListRW _dest, int _destOffset) {
	offset = _destOffset;
	setSource(_source);
	singleDest = _dest;
    }

    /** Returns the offset from the source List into the destination ListRW */
    protected int getOffset() {
	return offset;
    }

    /** Returns the source of events */
    protected ListRO getSource() {
        return source;
    }

    /** Sets the source List */
    private void setSource(ListRO _source) {
	if(source != null)
	    source.removeListener(this);
	source = _source;

	source.addListener(this, null);
    }

    public void fill() {
        if(source.size() > 0)
            listEvent(null, source, ListRO.Listener.ADD, 0, source.size(), null, null);
    }

    /** Returns the list of destinations to apply the change to */
    protected IteratorRO destinations() {
        return new SingleElementListRO(singleDest).iteratorRO();
    }

    /** Constructs and returns an element for the destination ListRW
     * which corresponds to a new element in the source List */
    public Object newDestElement(int sourceIndex, int destNum) {
	return source.get(sourceIndex);
    }

    /** Returns the index into the destination ListRW corresponding to
     * the specified index into the source List */
    public int destIndex(int sourceIndex) {
	return sourceIndex + offset;
    }

    /** Returns the index into the destination ListRW corresponding to
     * the specified index into the source List */
    public ArrayRO_int destIndexes(ArrayRO_int indexes) {
	int[] destIndexes = new int[indexes.size()];
	for(int i=0; i<destIndexes.length; i++)
	    destIndexes[i] = destIndex(indexes.get(i));
	return new ArrayRO_int(destIndexes);
    }


    //
    // implements ListRO.Listener
    //


    /** @see ListRO.Listener#listEvent */
    public void listEvent(Object sendback, ListRO source, int event
			  , int indexA, int indexB, ArrayRO_int indexes, ListRO elements) {

        int destNum = 0;
	switch(event) {
	case ListRO.Listener.ADD:
            for(IteratorRO itr=destinations(); itr.hasNext(); ) {
                ListRW dest = (ListRW)itr.next();
                for(int i=indexA; i<indexB; i++)
                    dest.add(destIndex(i), newDestElement(i, destNum++));
            }
	    break;

	case ListRO.Listener.REMOVE_RANGE:
            for(IteratorRO itr=destinations(); itr.hasNext(); ) {
                ListRW dest = (ListRW)itr.next();
                dest.removeRange(destIndex(indexA), destIndex(indexB));
	    }
            break;

	case ListRO.Listener.REMOVE_DISJOINT:
            for(IteratorRO itr=destinations(); itr.hasNext(); ) {
                ListRW dest = (ListRW)itr.next();
                dest.removeAll(destIndexes(indexes));
	    }
            break;

	case ListRO.Listener.REPLACE_RANGE:
            for(IteratorRO itr=destinations(); itr.hasNext(); ) {
                ListRW dest = (ListRW)itr.next();
                dest.removeRange(destIndex(indexA), destIndex(indexB));
	    }
            break;

	case ListRO.Listener.MOVE:
            for(IteratorRO itr=destinations(); itr.hasNext(); ) {
                ListRW dest = (ListRW)itr.next();
                dest.move(destIndex(indexA), destIndex(indexB));
	    }
            break;

	case ListRO.Listener.SWAP:
            for(IteratorRO itr=destinations(); itr.hasNext(); ) {
                ListRW dest = (ListRW)itr.next();
                dest.swap(destIndex(indexA), destIndex(indexB));
	    }
            break;
	}
    }
}
