
package com.kataba.coll;

/** Represents an empty SetRO
 *
 * @author Chris Thiessen
 */
public class EmptySetRO
    extends EmptyCollectionRO
    implements SetRO
{
    public static final SetRO INSTANCE = new EmptySetRO();

    /** Constructs */
    public EmptySetRO() {
    }


    //
    // implements SetRO
    //

    /** @see SetRO#union(SetRO) */
    public SetRO union(SetRO set) {
        return set;
    }

    /** @see SetRO#intersection(SetRO) */
    public SetRO intersection(SetRO set) {
        return this;
    }

    /** @see SetRO#xor(SetRO) */
    public SetRO xor(SetRO set) {
        return set;
    }
    
}
