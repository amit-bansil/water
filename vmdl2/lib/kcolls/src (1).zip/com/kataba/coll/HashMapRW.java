
package com.kataba.coll;

import com.kataba.util.*;

import java.util.NoSuchElementException;

/** A set based on hashing into an array of entry objects.
 *
 * @author Chris Thiessen
 */
public class HashMapRW
    extends AbstractMapRW
{
    public static final float DEFAULT_LOAD_FACTOR = 0.75f;
    public static final int DEFAULT_INITIAL_CAPACITY = 16;
    public static final Identifier DEFAULT_IDENTIFIER = DefaultIdentifier.INSTANCE;

    private Entry[] buckets;

    private int size;
    private int loadLimit;
    private float loadFactor;
    private Identifier identifier;

    /** An Entry in a bucket */
    protected class Entry {
	private Object key;
        private Object value;
	private int hashCode;
	private Entry next;

	public Entry(Object _key, Object _value, int _hashCode, Entry _next) {
	    key = _key;
            value = _value;
	    hashCode = _hashCode;
	    next = _next;
	}
    }

    /** Constructs with a default element identifier, load factor, and
     * initial capacity. */
    public HashMapRW() {
	this(DEFAULT_IDENTIFIER, DEFAULT_LOAD_FACTOR, DEFAULT_INITIAL_CAPACITY);
    }

    /** Constructs with the specified element identifier, load factor, and
     * initial capacity. */
    public HashMapRW(Identifier _identifier, float _loadFactor
                     , int initialCapacity) {
	if(initialCapacity < 0)
	    throw new IllegalArgumentException("Initial capacity cannot "
					       + "be negative");
	if(_loadFactor <= 0.0 || _loadFactor > 1.0)
	    throw new IllegalArgumentException("Illegal load factor ("
					       + _loadFactor
					       + "): must be greater than 0"
					       + " and not greater than 1");
	if(_identifier == null)
	    throw new NullPointerException();

	identifier = _identifier;
	loadFactor = _loadFactor;
	buckets = new Entry[initialCapacity];//(int)(initialCapacity / loadFactor)];
	loadLimit = (int)(loadFactor * buckets.length);
    }

    /** Constructs to contain the key-value pairs of the specified 'map' */
    public HashMapRW(MapRO map) {
        putAll(map);
    }

    /** Constructs to contain the key-value pairs of the specified 'map' */
    public HashMapRW(java.util.Map map) {
        putAll(map);
    }


    /** Grows the set of buckets */
    protected void growBuckets() {
	Entry[] oldBuckets = buckets;
	buckets = new Entry[buckets.length * 2 + 1];
	for(int i=0; i<oldBuckets.length; i++) {
	    Entry entry;
	    while((entry = oldBuckets[i]) != null) {
		// remove the current entry
		oldBuckets[i] = entry.next;

		// rehash the entry
		int index = (entry.hashCode & 0x7FFFFFFF) % buckets.length;
		entry.next = buckets[index];
		buckets[index] = entry;
	    }
	}
	loadLimit = (int)(loadFactor * buckets.length);
    }

    private Entry getEntry(Object key, boolean make) {
	int hashCode = identifier.hashCode(key);
	int index = (hashCode & 0x7FFFFFFF) % buckets.length;

	// search for an existing Entry
	Entry entry = null;
	for(entry=buckets[index]; entry!=null; entry=entry.next) {
	    if(entry.hashCode == hashCode
	       && identifier.equals(entry.key, key)) {
                return entry;
	    }
	}

        // if making a new entry
        if(make && entry == null) {
            entry = new Entry(key, NOT_SET, hashCode, buckets[index]);
            buckets[index] = entry;
            size++;

            // grow the buckets if necessary
            if(size > loadLimit)
                growBuckets();
        }

        return entry;
    }




    //
    // MapRO
    //

    /** @see MapRO#size() */
    public int size() {
	return size;
    }

    /** @see MapRO#containsKey(Object) */
    public boolean containsKey(Object key) {
        return getEntry(key, false) != null;
    }

    /** @see MapRO#get(Object) */
    public Object get(Object key) {
        Entry entry = getEntry(key, false);
        return entry==null ? null : entry.value;
    }


    //
    // implements MapRW
    //

    /** @see MapRW#put(Object,Object) */
    public Object put(Object key, Object value) {
        Entry entry = getEntry(key, true);
        Object oldKey = entry.key;
        Object oldValue = entry.value;

        // fire the necessary pre-event
        if(preEventEnabled())
            preEvent(Listener.ADD, new DefaultListRO(key), new DefaultListRO(value));

        // set the value
        entry.key = key;
        entry.value = value;

	// fire necessary events
	if(postEventsEnabled())
	    postEvent(Listener.ADD
                      , new SingleElementListRO(key)
                      , oldValue==NOT_SET ? NOT_SET_LIST : new SingleElementListRO(oldValue)
                      , NOT_SET);

        return oldValue==NOT_SET ? null : oldValue;
    }

    /** @see MapRW#remove(Object) */
    public Object remove(Object key) {
	int hashCode = identifier.hashCode(key);
	int index = (hashCode & 0x7FFFFFFF) % buckets.length;

	// find the matching Entry and return
	Entry previous = null;
	for(Entry entry=buckets[index]; entry!=null; entry=entry.next) {
	    // matches?
	    if(entry.hashCode == hashCode
	       && identifier.equals(entry.key, key)) {

                // fire the necessary pre-event
                if(preEventEnabled())
                    preEvent(Listener.REMOVE, new DefaultListRO(entry.key), null);

		// remove the Entry
		if(previous == null)
		    buckets[index] = entry.next;
		else
		    previous.next = entry.next;
		entry.next = null;
                Object value = entry.value;
		entry.key = null;
                entry.value = null;
		size--;

		// fire necessary events
		if(postEventsEnabled())
		    postEvent(Listener.REMOVE
                              , new SingleElementListRO(key)
                              , new SingleElementListRO(value)
                              , NOT_SET);

		return value;
	    }
	    previous = entry;
	}

	return null;
    }

    /** @see MapRW#clear() */
    public void clear() {
	if(size == 0)
	    return;

        boolean pre = preEventEnabled();
        boolean post = postEventsEnabled();
	ListRO keys = null;
        ListRO values = null;
	if(pre || post)
	    keys = new DefaultListRO(keySetRO());
        if(post)
            values = new DefaultListRO(valuesRO());

        // fire pre-change event
        if(pre)
            preEvent(Listener.REMOVE, keys, null);


        // do the remove
	size = 0;
	for(int i=0; i<buckets.length; i++)
	    buckets[i] = null;

        // fire post-change event
	if(post)
	    postEvent(Listener.REMOVE, keys, values, NOT_SET);
    }

    /** @see MapRW#keyIteratorRW() */
    public IteratorRW keyIteratorRW() {
	return new KeyIteratorRW();
    }

    /** IteratorRW over the keys of the set */
    private class KeyIteratorRW implements IteratorRW {
	int index = -1;
	Entry entry = null;
	Entry previous = null;
	int numVisited = 0;
	boolean isRemoved = false;
        boolean nextCalled = false;

	//
	// implements Lockable
	//

        /** @see Lockable#lock() */
	public Object lock() {
	    return HashMapRW.this.lock();
	}


	//
	// implements IteratorRO
	//

        /** @see IteratorRO#hasNext() */
	public boolean hasNext() {
	    return numVisited < size;
	}

        /** @see IteratorRO#next() */
	public Object next() {
            nextCalled = true;
	    if(numVisited >= size)
		throw new NoSuchElementException();

	    if(entry != null) {
		previous = entry;
		entry = entry.next;
	    }
	    if(entry == null) {
		previous = null;
		for(index=index+1; index<buckets.length; index++) {
		    entry = buckets[index];
		    if(entry != null)
			break;
		}
	    }

	    numVisited++;
            isRemoved = false;
	    return entry.key;
	}


	//
	// implements IteratorRW
	//

        /** @see IteratorRW#remove() */
	public void remove() {
            // cannot call if 'next()' has not called or the element has been removed
            if(!nextCalled || isRemoved)
		throw new IllegalStateException();

            // send pre-change event
            if(preEventEnabled())
                preEvent(PreListener.REMOVE, new SingleElementListRO(entry.key), null);

            // prepare for the event
            Object key = entry.key;
            Object oldValue = entry.value;

            // TODO pre and post-events
	    if(previous != null) {
		previous.next = entry.next;
		entry = previous;
	    } else {
		entry = null;
		previous = null;
		index--;
	    }
	    size--;
	    numVisited--;

            // send post-change event
            if(postEventsEnabled())
                postEvent(Listener.REMOVE, new SingleElementListRO(key)
                          , new SingleElementListRO(oldValue), null);

	    isRemoved = true;
	}
    }
}
