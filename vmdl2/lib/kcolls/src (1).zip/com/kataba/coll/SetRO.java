//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** A CollectionRO in which no contained element may be equal to any
 * other contained element, according to the SetRO's rules of
 * equivalence.
 *
 * <p>An implementation of this interface should document its rules of
 * object equivalence.
 *
 * @author Chris Thiessen
 */
public interface SetRO
    extends CollectionRO
{
    /** Returns a SetRO containing all elements in 'this' and all
     * elements in 'set'.  Note that any of the returned elements
     * which match an element in both 'this' and 'set' will have its
     * instance selected from 'this'. */
    public SetRO union(SetRO set);

    /** Returns a SetRO containing the elements that are members of
     * both 'set' and 'this'.  Note that while the returned elements
     * will match elements in both 'this' and 'set', the actual
     * instances (==) will be selected from 'this'. */
    public SetRO intersection(SetRO set);

    /** Returns a SetRO containing the elements that are members of
     * one or the other of 'this' and 'set', but not both. */
    public SetRO xor(SetRO set);


    //
    // implements the read-only part of java.util.Set
    //

    /** Behaves like java.util.Set.equals(Object), except that SetRO's
     * are treated in the same way as java.util.Set's.
     *
     * @see java.util.Set#equals(Object) */
    public boolean equals(Object object);

    /** Behaves like java.util.Set.hashCode(), except that SetRO's are
     * treated in the same way as java.util.Set's.
     *
     * @see java.util.Set#hashCode() */
    public int hashCode();
}
