//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** A read-write iterator over the elements of some collection of
 * elements of type <code>Object</code>.  Clients should synchronize
 * on 'lock()' if they wish to thread-safe their access to this
 * IteratorRO.
 *
 * @author Chris Thiessen
 */
public interface IteratorRW
    extends IteratorRO, java.util.Iterator
{
    /** @see java.util.Iterator#remove() */
    public void remove();
}
