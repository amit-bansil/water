
package com.kataba.coll;

import com.kataba.coll.wrap.*;
import com.kataba.util.*;

/** This class provides a skeletal implementation of the ListRO
 * interface to minimize the effort required to implement this
 * interface backed by a "random access" data store.
 *
 * <p>Subclasses of this class must define the following methods:
 * <ul>
 *   <li><code>get(int)</code>
 *   <li><code>size()</code>
 *   <li><code>addListener(Listener,Object)</code>
 *   <li><code>removeListener(Listener)</code>
 *   <li><code>addListener(ListRO.Listener,Object)</code>
 *   <li><code>removeListener(ListRO.Listener)</code>
 * </ul>
 *
 * <p>The implementation of all other methods depends on those few.
 *
 * @author Chris Thiessen
 */
public abstract class AbstractListRO
    extends AbstractCollectionRO
    implements ListRO
{
    /** Default constructor */
    protected AbstractListRO() {
    }

    /** Constructs to use the specified Comparator to determine if
     * elements are equal */
    protected AbstractListRO(KComparator comparator) {
	super(comparator);
    }


    //
    // implements CollectionRO
    //

    /** @see CollectionRO#contains(Object) */
    public boolean contains(Object element) {
	return indexOf(element, 0, true) != -1;
    }

    /** @see CollectionRO#iteratorRO() */
    public IteratorRO iteratorRO() {
	return new DefaultListIteratorRO(listCursorRO());
    }


    //
    // implements ListRO
    //

    /** @see ListRO#subListRO(int,int) */
    public ListRO subListRO(int start, int end) {
	if(start < 0)
	    throw new IndexOutOfBoundsException("start:"+start+", size:"+size());
	if(start > end)
	    throw new IllegalArgumentException("start:"+start+" > end:"+end);
	if(end > size())
	    throw new IndexOutOfBoundsException("end:"+end+", size:"+size());

	return new SubListRO(this, start, end);
    }

    /** @see ListRO#indexOf(Object) */
    public int indexOf(Object element) {
	return indexOf(element, 0, true);
    }

    /** @see ListRO#lastIndexOf(Object) */
    public int lastIndexOf(Object element) {
	return indexOf(element, size()-1, false);
    }

    /** @see ListRO#indexOf(Object,int,boolean) */
    public int indexOf(Object element, int startIndex, boolean direction) {
	int size = size();

	if(startIndex < 0 || startIndex > size)
	    throw new IndexOutOfBoundsException("startIndex:"+startIndex+", size:"+size);
	if(startIndex == size)
	    startIndex--;

	for(int i=startIndex; i<size && i>=0; i=(direction?i+1:i-1))
	    if(identifier.equals(get(i), element))
		return i;
	return -1;
    }

    /** @see ListRO#indexesOf(CollectionRO) */
    public ArrayRO_int indexesOf(CollectionRO coll) {
        int[] indexes = new int[10];
        int count = 0;

        // find the matching indexes
        for(int i=0,ii=size(); i<ii; i++) {
            if(coll.contains(get(i))) {
                if(count == indexes.length)
                    indexes = Util.expand(indexes);
                indexes[count++] = i;
            }
        }
        return new ArrayRO_int(indexes, 0, count);
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO() {
	return new DefaultListCursorRO(this, 0);
    }

    /** @see ListRO#listCursorRO(int) */
    public ListCursorRO listCursorRO(int index) {
	return new DefaultListCursorRO(this, index);
    }

    /** Returns an array containing the elements from 'fromIndex' up
     * to, but not including, 'toIndex' */
    public Object[] toArray(int fromIndex, int toIndex) {
	if(fromIndex < 0)
	    throw new IndexOutOfBoundsException("fromIndex:"+fromIndex+", size:"+size());
	if(toIndex > size())
	    throw new IndexOutOfBoundsException("toIndex:"+toIndex+", size:"+size());
	if(fromIndex > toIndex)
	    throw new IllegalArgumentException
		("fromIndex:"+fromIndex+" > toIndex:"+toIndex);

	Object[] array = new Object[toIndex-fromIndex];
	for(int i=fromIndex; i<toIndex; i++)
	    array[i-fromIndex] = get(i);
	return array;
    }

    /** @see ListRO#equals */
    public boolean equals(Object object) {
        ListRO list;
        if(object == null)
            return false;
        else if(object instanceof ListRO)
            list = (ListRO)object;
        else if(object instanceof java.util.List)
            // wrap the java.util.List
            list = new ListToListRW((java.util.List)object);
        else
            return false;

        // compare the list
        if(list.size() != size())
            return false;
        int i=0;
        for(IteratorRO itr=list.iteratorRO(); itr.hasNext(); i++) {
            Object thisElem = get(i);
            Object listElem = itr.next();
            boolean match = thisElem==null ? listElem==null : thisElem.equals(listElem);
            if(!match)
                return false;
        }
        return true;
    }

    /** @see ListRO#hashCode */
    public int hashCode() {
        int hashCode = 1;
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object obj = itr.next();
            hashCode = 31*hashCode + (obj==null ? 0 : obj.hashCode());
        }
        return hashCode;
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO() {
        return new DefaultListIteratorRO(listCursorRO());
    }

    /** @see ListRO#listIteratorRO(int) */
    public ListIteratorRO listIteratorRO(int index) {
        return new DefaultListIteratorRO(listCursorRO(index));
    }


    //
    // abstract methods
    //

    /** @see ListRO#addListener(ListRO.Listener,Object) */
    public abstract void addListener(ListRO.Listener listener
					 , Object sendback);

    /** @see ListRO#removeListener(ListRO.Listener) */
    public abstract void removeListener(ListRO.Listener listener);

    /** @see ListRO#get(int) */
    public abstract Object get(int index);
}
