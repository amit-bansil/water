
package com.kataba.coll;

import com.kataba.util.*;

/** A SwapSortable for sorting a List.  Uses a Comparator to compare
 * elements
 *
 * @author Chris Thiessen
 */
public class ListRWSwapSortable implements SwapSortable {
    private ListRW list;
    private java.util.Comparator comparator;

    /** Constructs around the specified List and uses a
     * DefaultComparator to compare elements */
    public ListRWSwapSortable(ListRW _list) {
	this(_list, new DefaultKComparator());
    }

    /** Constructs around the specified List and Comparator */
    public ListRWSwapSortable(ListRW _list, java.util.Comparator _comparator) {
	list = _list;
	comparator = _comparator;
    }

    /** Sets the ListRW to be sorted */
    public void setList(ListRW _list) {
	list = _list;
    }

    /** Returns the List to be sorted */
    public ListRW getList() {
	return list;
    }

    /** Sets the Comparator used in comparing list elements */
    public void setComparator(java.util.Comparator _comparator) {
	comparator = _comparator;
    }

    /** Returns the Comparator used in comparing list elements */
    public java.util.Comparator getComparator() {
	return comparator;
    }

    //
    // implements SwapSortable
    //

    /** Swaps the element at <code>indexA</code> with the element at
     * <code>indexB</code>
     *
     * @param indexA the index of an element
     * @param indexB the index of an element
     */
    public void swap(int indexA, int indexB) {
	list.swap(indexA, indexB);
    }

    /** Compares the element at <code>indexA</code> with the element
     * at <code>indexB</code>, returning <code>&lt;0</code> if the
     * first is smaller than the second, <code>&gt;0</code> if the
     * second is larger, and <code>0</code> if they are the same.
     *
     * @return <code>&lt;0</code> if the first is smaller than the
     *         second, <code>&gt;0</code> if the second is larger, and
     *         <code>0</code> if they are the same.
     */
    public int compare(int indexA, int indexB) {
	return comparator.compare(list.get(indexA), list.get(indexB));
    }

    /** Returns the number of elements in the collection
     *
     * @return the number of elements in the collection
     */
    public int size() {
	return list.size();
    }
}
