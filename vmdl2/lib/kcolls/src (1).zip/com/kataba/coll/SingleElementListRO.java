//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** An implementation of ListRO which contains only a single element.
 *
 * @author Chris Thiessen
 */
public class SingleElementListRO extends AbstractListRO {
    /** The single element */
    protected Object element;

    /** Constructs to be based on the specified element. */
    public SingleElementListRO(Object _element) {
	element = _element;
    }


    //
    // implements CollectionRO
    //

    /** Registers a listener to be triggered when this collection
     * emits an event. */
    public void addListener(CollectionRO.Listener listener, Object sendback) {
    }

    /** Unregisters a listener previously registered to be triggered
     * when this collection emits an event. */
    public void removeListener(CollectionRO.Listener listener) {
    }

    /** Returns the number of elements in this collection. */
    public int size() {
	return 1;
    }


    //
    // implements ListRO
    //

    /** Registers a listener to be triggered when this list
     * emits an event. */
    public void addListener(ListRO.Listener listener, Object sendback) {
    }

    /** Unregisters a listener previously registered to be triggered
     * when this list emits an event. */
    public void removeListener(ListRO.Listener listener) {
    }

    /** Returns the element at the specified index.
     *
     * @exception IndexOutOfBoundsException if the index is out of bounds */
    public Object get(int index) {
	if(index != 0)
	    throw new IndexOutOfBoundsException("index:"+index+" size:"+1);
	return element;
    }
}
