//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** Represents a read-write set of objects, each mapped to a value
 * Object.  The elements of a MapRW are not guaranteed to be ordered in
 * any particular way.
 *
 * <p>If the element-adding/replacing methods in Set or Collection are
 * called, elements are added to the Map with a 'null' value mapped to
 * them.
 *
 * <p>An implementation of this interface should document its rules of
 * object equivalence.
 *
 * @see java.util.Map
 * @author Chris Thiessen
 */
public interface MapRW
    extends MapRO, java.util.Map
{

    /** Represents a read-write single key-value mapping in a MapRO.
     *
     * @see java.util.Map.Entry
     */
    public interface EntryRW
        extends EntryRO, java.util.Map.Entry
    {
        /** @see java.util.Map.Entry#setValue(Object) */
        public Object setValue(Object value);
    }

    /** Returns an IteratorRW over the keys of the MapRW */
    public IteratorRW keyIteratorRW();

    /** Returns the EntryRW for the specified 'key' */
    public EntryRW getEntryRW(Object key);


    // methods equivalent to those in java.util.Map

    /** @see java.util.Map#entrySet() */
    public SetRW entrySetRW();

    /** @see java.util.Map#keySet() */
    public SetRW keySetRW();

    /** @see java.util.Map#putAll(java.util.Map) */
    public void putAll(MapRO map);

    /** @see java.util.Map#values() */
    public CollectionRW valuesRW();



    //
    // implements the content modification part of the java.util.Map interface
    //

    /** @see java.util.Map#clear() */
    public void clear();

    /** Returns entrySetRW()
     * @see java.util.Map#entrySet() */
    public java.util.Set entrySet();

    /** Returns keySetRW()
     * @see java.util.Map#keySet() */
    public java.util.Set keySet();

    /** Returns valuesRW()
     * @see java.util.Map#values() */
    public java.util.Collection values();

    /** @see java.util.Map#put(Object,Object) */
    public Object put(Object key, Object value);

    /** @see java.util.Map#putAll(java.util.Map) */
    public void putAll(java.util.Map map);

    /** @see java.util.Map#remove(Object) */
    public Object remove(Object key);
}
