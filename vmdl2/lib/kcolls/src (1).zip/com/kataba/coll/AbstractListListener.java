
package com.kataba.coll;

import com.kataba.util.*;

public class AbstractListListener implements ListRO.Listener {

    /** @see ListRO.Listener#listEvent */
    public void listEvent(Object sendback, ListRO source, int event
			  , int indexA, int indexB, ArrayRO_int indexes, ListRO elements) {

	switch(event) {
	case ListRO.Listener.ADD:
	    break;
	case ListRO.Listener.REMOVE_RANGE:
	    break;
	case ListRO.Listener.REMOVE_DISJOINT:
	    break;
	case ListRO.Listener.REPLACE_RANGE:
	    break;
	case ListRO.Listener.MOVE:
	    break;
	case ListRO.Listener.SWAP:
	    break;
	}
    }
}
