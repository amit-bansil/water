
package com.kataba.coll;

import com.kataba.coll.wrap.*;
import com.kataba.util.*;

/** This class provides a skeletal implementation of the MapRW
 * interface to minimize the effort required to implement this
 * interface.
 *
 * <p>Subclasses of this class must define at least the following methods:
 * <ul>
 *   <li><code>get(Object key)</code>
 *   <li><code>size()</code>
 *   <li><code>remove(Object key)</code>
 *   <li><code>put(Object key, Object value)</code>
 *   <li><code>clear()</code>
 *   <li><code>keyIteratorRW()</code>
 * </ul>
 *
 * <p>Changes to a List can be vetoed, or other related action taken,
 * through the use of a List.PreListener.  A registered PreListener
 * will be called before any requested modification of the List
 * contents is performed.  If an exception is thrown, the action will
 * not take place, and the exception will be passed through to the
 * caller.  Subclasses should call preEvent(...) to have a pre-change
 * event sent.
 *
 * <p>Basic support for tracking Listeners and sending events to them
 * is built in.  Subclasses should call postEvent(...) to have a
 * post-change event sent.
 *
 * <p>Subclasses wishing to provide update notification should
 * increment 'eventDepth' before performing their action, decrement it
 * afterwards, and call postEvent(...).
 *
 * @author Chris Thiessen
 */
public abstract class AbstractMapRW
    extends AbstractMapRO
    implements MapRW
{
    protected static final Object NOT_SET = "NOT_SET";
    protected static final ListRO NOT_SET_LIST = new SingleElementListRO(NOT_SET);

    /** The MapListener's */
    private Object[] listeners;
    private int numListeners;
    /** The pre-listener to call before modifications are made to the contents of the list */
    private PreListener preListener;
    /** If not 0, the current action is part of a larger action, and
     * events will not be sent. */
    protected int eventDepth = 0;

    /** Constructs to use the specified Identifier on elements */
    public AbstractMapRW() {
	super(DefaultIdentifier.INSTANCE);
    }

    /** Constructs to use the specified Identifier on elements */
    public AbstractMapRW(Identifier _identifier) {
	super(_identifier);
    }

    /** Implemented by classes which wish to see changes to the
     * AbstractMapRW before they occur, to validate or pre-process
     * those modifications. */
    public interface PreListener {

        /** Event: Key-value mappings are about to added and/or
         * changed.  'keys' contains the keys that will change, and
         * 'newValues' their new values (at matching indices). */
        public static final int ADD = 1;

        /** Event: Mappings are about to be removed.  'keys' contains
         * the keys to be removed. */
        public static final int REMOVE = 2;

        /** Called when the map is changed
         *
         * @param source    the MapRO that changed
         * @param sendback  the Object that this listener was registered along with
         * @param event     the event ID, one of { ADD, REMOVE }
         * @param keys      see the event ID descriptions
         * @param oldValues see the event ID descriptions
         */
        public void preEvent(int event, ListRO keys, ListRO newValues);
    }

    /** Sets the pre-listener.  The pre-listener is called with
     * details of any list-modification operations BEFORE the changes
     * occur. */
    public void setPreListener(PreListener _preListener) {
        preListener = _preListener;
    }

    /** Called before an action is taken */
    protected void preEvent(int event, ListRO keys, ListRO newValues) {
        if(preListener != null)
            preListener.preEvent(event, keys, newValues);
    }

    /** Returns whether pre-events are enabled */
    protected boolean preEventEnabled() {
        if(eventDepth != 0)
            return false;
        return preListener != null;
    }

    /** Returns whether or not there are any registered Listeners */
    protected boolean postEventsEnabled() {
	return eventDepth == 0 && numListeners > 0;
    }

    /** Fires a Map event */
    protected void postEvent(int event, ListRO keys
                             , ListRO oldValues, Object noValue) {
        if(!postEventsEnabled())
	    return;

	// for each pair
	for(int i=0; i<listeners.length; i+=2) {
	    MapRO.Listener listener = (MapRO.Listener)listeners[i];
	    if(listener != null)
		listener.mapEvent(listeners[i+1], this
				  , event, keys, oldValues, noValue);
	}
    }


    //
    // implements MapRO
    //

    /** @see MapRO#addListener(MapRO.Listener,Object) */
    public void addListener(MapRO.Listener listener, Object sendback) {
	if(listener == null)
	    return;
	listeners = PairUtil.add(listeners, numListeners++
				     , listener, sendback);
    }

    /** @see MapRO#removeListener */
    public void removeListener(MapRO.Listener listener) {
	int pair = PairUtil.find(listeners, numListeners, listener);
	if(pair != -1)
	    PairUtil.swapRemove(listeners, numListeners--, pair);
    }

    /** @see MapRO#getEntryRO(Object) */
    public EntryRO getEntryRO(Object key) {
        return getEntryRW(key);
    }

    /** @see MapRO#entrySetRO() */
    public SetRO entrySetRO() {
        return entrySetRW();
    }

    /** @see MapRO#keySetRO() */
    public SetRO keySetRO() {
        return keySetRW();
    }

    /** @see MapRO#valuesRO() */
    public CollectionRO valuesRO() {
        return valuesRW();
    }

    /** Returns an IteratorRO over the keys of the MapRO */
    public IteratorRO keyIteratorRO() {
        return keyIteratorRW();
    }

    // abstract methods

    /** @see MapRO#get(Object) */
    public abstract Object get(Object key);

    /** @see MapRO#size() */
    public abstract int size();


    //
    // implements MapRW
    //

    /** @see java.util.Map#entrySet() */
    public java.util.Set entrySet() {
        return entrySetRW();
    }

    /** @see java.util.Map#values() */
    public java.util.Collection values() {
        return valuesRW();
    }

    /** @see java.util.Map#putAll(java.util.Map) */
    public void putAll(java.util.Map map) {
        putAll((MapRO)new MapToMapRW(map));
    }

    /** @see java.util.Map#putAll(java.util.Map) */
    public void putAll(MapRO map) {
        boolean pre = preEventEnabled();
        boolean post = postEventsEnabled();

        // prepare for events
        ListRO keys = null;
        if(pre || post)
            keys = new DefaultListRO(map.keySetRO());

        // fire the pre event
        if(pre)
            preEvent(PreListener.ADD, keys, new DefaultListRO(map.valuesRO()));

        // prepare for the post-event
        GapListRW oldValues = null;
        Object noValue = null;
        if(post) {
            oldValues = new GapListRW();
            noValue = new Object();
            for(IteratorRO itr=map.keyIteratorRO(); itr.hasNext(); ) {
                Object key = itr.next();
                if(containsKey(key))
                    oldValues.add(get(key));
                else
                    oldValues.add(noValue);
            }
        }

        // do the put
        eventDepth++;
        for(IteratorRO itr=map.keySetRO().iteratorRO(); itr.hasNext(); ) {
            Object key = itr.next();
            put(key, map.get(key));
        }
        eventDepth--;

        // fire the post-event
        if(post)
            postEvent(Listener.ADD, keys, oldValues, noValue);
    }


    /** @see MapRW#entrySetRW() */
    public SetRW entrySetRW() {
        return new EntriesRW();
    }
    private class EntriesRW extends AbstractSetRW {
        /** Returns AbstractMapRW.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRW.this.lock();
        }

        /** @see CollectionRO#contains(Object) */
        public boolean contains(Object element) {
            EntryRO entry = (EntryRO)element;
            EntryRO present = getEntryRO(entry.getKey());
            if(present == null)
                return false;
            return Util.equals(present, entry);
        }

        /** @see CollectionRO#size */
        public int size() {
            return AbstractMapRW.this.size();
        }

        /** @see CollectionRW#add */
        public boolean add(Object element) {
            EntryRO entry = (EntryRO)element;
            if(contains(entry))
                return false;
            put(entry.getKey(), entry.getValue());
            return true;
        }

        /** @see CollectionRW#remove */
        public boolean remove(Object element) {
            EntryRO entry = (EntryRO)element;
            return remove(entry.getKey());
        }

        /** @see CollectionRW#clear */
        public void clear() {
            AbstractMapRW.this.clear();
        }

        /** @see CollectionRW#iterator */
        public IteratorRW iteratorRW() {
            return entryIteratorRW();
        }
    }


    /** @see MapRW#keySet() */
    public java.util.Set keySet() {
        return keySetRW();
    }
    /** @see MapRW#keySetRW() */
    public SetRW keySetRW() {
        return new KeysRW();
    }
    private class KeysRW extends AbstractSetRW {
        /** Returns AbstractMapRW.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRW.this.lock();
        }

        /** @see CollectionRO#contains(Object) */
        public boolean contains(Object element) {
            return containsKey(element);
        }

        /** @see CollectionRO#size */
        public int size() {
            return AbstractMapRW.this.size();
        }

        /** @see CollectionRW#add */
        public boolean add(Object element) {
            throw new UnsupportedOperationException("Cannot add a key without a value");
        }

        /** @see CollectionRW#remove */
        public boolean remove(Object element) {
            return remove(element);
        }

        /** @see CollectionRW#clear */
        public void clear() {
            AbstractMapRW.this.clear();
        }

        /** @see CollectionRW#iterator */
        public IteratorRW iteratorRW() {
            return keyIteratorRW();
        }
    }


    /** @see MapRW#valuesRW() */
    public CollectionRW valuesRW() {
        return new ValuesRW();
    }
    private class ValuesRW extends AbstractSetRW {
        /** Returns AbstractMapRW.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRW.this.lock();
        }

        /** @see CollectionRO#contains(Object) */
        public boolean contains(Object object) {
            return containsValue(object);
        }

        /** @see CollectionRO#size() */
        public int size() {
            return AbstractMapRW.this.size();
        }

        /** @see CollectionRW#add(Object) */
        public boolean add(Object element) {
            throw new UnsupportedOperationException("Cannot add a value to the value Set");
        }

        /** @see CollectionRW#remove(Object) */
        public boolean remove(Object element) {
            throw new UnsupportedOperationException
                ("Cannot remove a value from the value Set");
        }

        /** @see CollectionRW#clear() */
        public void clear() {
            AbstractMapRW.this.clear();
        }

        /** @see CollectionRW#iteratorRW() */
        public IteratorRW iteratorRW() {
            return valueIteratorRW();
        }
    }

    /** Base class for keyIteratorRW-wrapping IteratorRW's */
    private abstract class KeyItrWrapped implements IteratorRW {
        protected IteratorRW keyItr = keyIteratorRW();

        /** Returns AbstractMapRO.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRW.this.lock();
        }

        /** @see IteratorRO#hasNext() */
        public boolean hasNext() {
            return keyItr.hasNext();
        }

        /** @see IteratorRW#remove() */
        public void remove() {
            keyItr.remove();
        }
    }

    /** @see MapRW#entryIteratorRW() */
    private IteratorRW entryIteratorRW() {
        return new EntryIteratorRW();
    }
    private class EntryIteratorRW extends KeyItrWrapped {
        /** @see IteratorRO#next() */
        public Object next() {
            return getEntryRO(keyItr.next());
        }
    }


    /** @see MapRW#valueIteratorRW() */
    private IteratorRW valueIteratorRW() {
        return new ValueIteratorRW();
    }
    private class ValueIteratorRW extends KeyItrWrapped {
        /** @see IteratorRO#next() */
        public Object next() {
            return get(keyItr.next());
        }
    }


    /** @see MapRW#getEntryRW(Object) */
    public EntryRW getEntryRW(Object key) {
        return new ConcreteEntryRW(key);
    }
    protected class ConcreteEntryRW implements EntryRW {
        private Object key;

        /** Constructs */
        private ConcreteEntryRW(Object _key) {
            key = _key;
        }

        /** @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRW.this.lock();
        }

        /** @see MapRO.EntryRO#equals(Object) */
        public boolean equals(Object object) {
            if(object == null)
                return false;

            else if(object instanceof EntryRO) {
                EntryRO entry = (EntryRO)object;
                return Util.equals(getKey(), entry.getKey())
                    && Util.equals(getValue(), entry.getValue());

            } else if(object instanceof java.util.Map.Entry) {
                java.util.Map.Entry entry = (java.util.Map.Entry)object;
                return Util.equals(getKey(), entry.getKey())
                    && Util.equals(getValue(), entry.getValue());

            } else
                return false;
        }

        /** @see MapRO.EntryRO#getKey() */
        public Object getKey() {
            return key;
        }

        /** @see MapRO.EntryRO#getValue() */
        public Object getValue() {
            return get(key);
        }

        /** @see MapRO.EntryRO#hashCode() */
        public int hashCode() {
            Object value = getValue();
            return Util.hashCode(key) ^ Util.hashCode(getValue());
        }

        /** @see MapRW.EntryRW#setValue(Object) */
        public Object setValue(Object value) {
            return put(key, value);
        }
    }


    /** @see java.util.Map#remove(Object) */
    public abstract Object remove(Object key);

    /** @see java.util.Map#put(Object,Object) */
    public abstract Object put(Object key, Object value);

    /** @see java.util.Map#clear() */
    public abstract void clear();

    /** Returns an IteratorRW over the keys of the MapRW */
    public abstract IteratorRW keyIteratorRW();
}
