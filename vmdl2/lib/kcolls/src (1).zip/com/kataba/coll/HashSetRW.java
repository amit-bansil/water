
package com.kataba.coll;

import com.kataba.util.*;

import java.util.NoSuchElementException;

/** A set based on hashing into an array of entry objects.
 *
 * @author Chris Thiessen
 */
public class HashSetRW
    extends AbstractSetRW
    implements SetRW
{
    public static final float _Default_Load_Factor = 0.75f;
    public static final int _Default_Initial_Capacity = 16;
    public static final Identifier DEFAULT_IDENTIFIER
	= DefaultIdentifier.INSTANCE;
    public static final Object _Deleted = new Object();

    private Entry[] buckets;

    private int size;
    private int loadLimit;
    private float loadFactor;
    private Identifier identifier;

    /** An Entry in a bucket */
    protected class Entry {
	Object element;
	int hashCode;
	Entry next;

	public Entry(Object _element, int _hashCode, Entry _next) {
	    element = _element;
	    hashCode = _hashCode;
	    next = _next;
	}
    }

    /** Constructs with a default element identifier, load factor, and
     * initial capacity. */
    public HashSetRW() {
	this(DEFAULT_IDENTIFIER, _Default_Load_Factor
	     , _Default_Initial_Capacity);
    }

    /** Constructs with the specified element identifier, load factor, and
     * initial capacity. */
    public HashSetRW(Identifier _identifier, float _loadFactor
		   , int initialCapacity) {
	if(initialCapacity < 0)
	    throw new IllegalArgumentException("Initial capacity cannot "
					       + "be negative");
	if(_loadFactor <= 0.0 || _loadFactor > 1.0)
	    throw new IllegalArgumentException("Illegal load factor ("
					       + _loadFactor
					       + "): must be greater than 0"
					       + " and not greater than 1");
	if(_identifier == null)
	    throw new NullPointerException();

	identifier = _identifier;
	loadFactor = _loadFactor;
	buckets = new Entry[initialCapacity];//(int)(initialCapacity / loadFactor)];
	loadLimit = (int)(loadFactor * buckets.length);
    }

    /** Grows the set of buckets */
    protected void growBuckets() {
	Entry[] oldBuckets = buckets;
	buckets = new Entry[buckets.length * 2 + 1];
	for(int i=0; i<oldBuckets.length; i++) {
	    Entry entry;
	    while((entry = oldBuckets[i]) != null) {
		// remove the current entry
		oldBuckets[i] = entry.next;

		// rehash the entry
		int index = (entry.hashCode & 0x7FFFFFFF) % buckets.length;
		entry.next = buckets[index];
		buckets[index] = entry;
	    }
	}
	loadLimit = (int)(loadFactor * buckets.length);
    }

    //
    // CollectionRO
    //

    /** @see CollectionRO#size() */
    public int size() {
	return size;
    }

    /** @see CollectionRO#contains(Object) */
    public boolean contains(Object element) {
	int hashCode = identifier.hashCode(element);
	int index = (hashCode & 0x7FFFFFFF) % buckets.length;

	// search for an existing Entry
	for(Entry entry=buckets[index]; entry!=null; entry=entry.next) {
	    if(entry.hashCode == hashCode
	       && identifier.equals(entry.element, element))
		return true;
	}
	return false;
    }

    /** @see CollectionRO#iteratorRO() */
    public IteratorRO iteratorRO() {
	return iteratorRW();
    }


    //
    // CollectionRW
    //

    /** @see CollectionRW#add(Object) */
    public boolean add(Object element) {
	int hashCode = identifier.hashCode(element);
	int index = (hashCode & 0x7FFFFFFF) % buckets.length;

	// search for an existing Entry
	Entry entry;
	for(entry=buckets[index]; entry!=null; entry=entry.next) {
	    if(entry.hashCode == hashCode
	       && identifier.equals(entry.element, element)) {
		entry.element = element;
		break;
	    }
	}

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.ADD, new DefaultListRO(element), null);

	// make a new Entry
	if(entry == null) {
	    entry = new Entry(element, hashCode, buckets[index]);
	    buckets[index] = entry;
	    size++;
	}

	// grow the buckets if necessary
	if(size > loadLimit)
	    growBuckets();

	// fire necessary events
	if(postEventsEnabled())
	    postEvent(Listener.ADD
                      , new DefaultListRO(element)
                      , null);

	return true;
    }

    /** @see CollectionRW#remove(Object) */
    public boolean remove(Object element) {
	int hashCode = identifier.hashCode(element);
	int index = (hashCode & 0x7FFFFFFF) % buckets.length;

	// find the matching Entry and return
	Entry previous = null;
	for(Entry entry=buckets[index]; entry!=null; entry=entry.next) {
	    // matches?
	    if(entry.hashCode == hashCode
	       && identifier.equals(entry.element, element)) {

                // fire the pre event
                if(preEventEnabled())
                    preEvent(PreListener.REMOVE, new DefaultListRO(element), null);

		// remove the Entry
		if(previous == null)
		    buckets[index] = entry.next;
		else
		    previous.next = entry.next;
		entry.next = null;
		entry.element = null;
		size--;

		// fire necessary events
		if(postEventsEnabled())
		    postEvent(Listener.REMOVE
                              , new DefaultListRO(element)
                              , null);

		return true;
	    }
	    previous = entry;
	}

	return false;
    }

    /** @see CollectionRW#clear() */
    public void clear() {
	if(size == 0)
	    return;

	boolean hasListeners = postEventsEnabled() || preEventEnabled();
	ListRO setCopy = null;
	if(hasListeners)
	    setCopy = new DefaultListRO((CollectionRO)this);

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.REMOVE, setCopy, null);

	size = 0;
	for(int i=0; i<buckets.length; i++)
	    buckets[i] = null;

	// fire necessary events
	if(hasListeners)
	    postEvent(Listener.REMOVE, setCopy, null);
    }

    /** @see CollectionRW#iteratorRW() */
    public IteratorRW iteratorRW() {
	return new Itr();
    }

    private class Itr implements IteratorRW {
	int index = -1;
	Entry entry = null;
	Entry previous = null;
	int numVisited = 0;
	boolean isRemoved = false;

	//
	// implements Lockable
	//

        /** @see Lockable#lock() */
	public Object lock() {
	    return HashSetRW.this.lock();
	}


	//
	// implements IteratorRO
	//

        /** @see IteratorRO#hasNext() */
	public boolean hasNext() {
	    return numVisited < size;
	}

        /** @see IteratorRO#next() */
	public Object next() {
	    if(numVisited >= size)
		throw new NoSuchElementException();

	    if(entry != null) {
		previous = entry;
		entry = entry.next;
	    }
	    if(entry == null) {
		previous = null;
		for(index=index+1; index<buckets.length; index++) {
		    entry = buckets[index];
		    if(entry != null)
			break;
		}
	    }

	    numVisited++;
            isRemoved = false;
	    return entry.element;
	}


	//
	// implements IteratorRW
	//

        /** @see IteratorRW#remove() */
	public void remove() {
	    if(isRemoved || index == -1)
                throw new IllegalStateException
                    ("Neither next nor previous have been called,"
                     +" or remove or add have been called since the"
                     +" last call to next or previous.");

            //Out.ln("entry.element: " + entry.element);

	    if(previous != null) {
		previous.next = entry.next;
		entry = previous;
	    } else {
                buckets[index] = entry.next;
		entry = null;
		previous = null;
		index--;
	    }
	    size--;
	    numVisited--;
	    isRemoved = true;
	}
    }
}
