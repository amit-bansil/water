
package com.kataba.coll;

import com.kataba.coll.wrap.*;
import com.kataba.util.*;

/** This class provides a skeletal implementation of the List
 * interface to minimize the effort required to implement this
 * interface.
 *
 * <p>Concrete subclasses of this class must define the following methods:
 * <ul>
 *   <li><code>size()</code>
 *   <li><code>add(Object element)</code>
 *   <li><code>remove(Object element)</code>
 *   <li><code>clear()</code>
 *   <li><code>IteratorRW iteratorRW()</code>
 * </ul>
 *
 * <p>Changes to a List can be vetoed, or other related action taken,
 * through the use of a List.PreListener.  A registered PreListener
 * will be called before any requested modification of the List
 * contents is performed.  If an exception is thrown, the action will
 * not take place, and the exception will be passed through to the caller.
 *
 * <p>Subclasses should call wishing to provide update notification
 * should increment 'eventDepth' before performing their action,
 * decrement it afterwards, and call postEvent(...).
 *
 * @author Chris Thiessen
 */
public abstract class AbstractCollectionRW
    extends AbstractCollectionRO
    implements CollectionRW
{
    /** If not 0, the current action is part of a larger action, and
     * events will not be sent. */
    protected int eventDepth = 0;
    /** The pre-listener to call before modifications are made to the contents of the list */
    private PreListener preListener;

    /** The CollectionRO.Listener's */
    private Object[] collListeners;
    private int numCollListeners;

    /** Constructs */
    public AbstractCollectionRW() {
    }

    /** Constructs to use the specified Identifier on elements */
    public AbstractCollectionRW(Identifier _identifier) {
    super(_identifier);
    }

    /** The number of times this List has been <i>structurally
     * modified</i>. Structural modifications are those that change
     * the size of the List, or otherwise perturb it in such a fashion
     * that iterations in progress may yield incorrect results.  This
     * field is used by the the Iterator and ListIterator
     * implementation returned by the iterator and listIterator
     * methods. If the value of this field changes unexpectedly, the
     * Iterator (or ListIterator) will throw a
     * java.util.ConcurrentModificationException in response to the
     * next, remove, previous, set or add operations. This provides
     * <i>fail-fast behavior</i>, rather than non-deterministic
     * behavior in the face of concurrent modification during
     * iteration.
     *
     * <strong>Use of this field by subclasses is optional.</strong>
     * If a subclass wishes to provide fail-fast Iterators (and
     * ListIterators), then it merely has to increment this field in
     * its add(int, Object) and remove(int) methods (and any other
     * methods that it overrides that result in structural
     * modifications to the List).  If an implementation does not wish
     * to provide fail-fast Iterators, this field may be ignored.  */
    protected transient int modCount = 0;

    /** Implement this interface if you want to screen changes to the
     * AbstractCollectionRW.  If registered (@see
     * setPreListener(PreListener) ) then 'collectionEvent(...)' is
     * called before any action with the details of the action. */
    public interface PreListener {
    /** Elements are about to be added.  'elementsA' contains the
         * elements to be added. */
    public static final int ADD = 1;

    /** Elements are about to be removed.  'elementsA' contains
         * the elements to be removed. */
    public static final int REMOVE = 2;

    /** Elements are about to be replaced. 'elementsA' contains the replaced
     * elements.  'elementsB' contains the elements that replaced
     * them. */
    public static final int REPLACE = 3;

    /** Called before content-changing actions are taken on the
     * listened-to AbstractCollectionRW.  If a RuntimeException is
     * thrown, the action will be cancelled.
     *
     * @param event     the event ID, one of { ADD, REMOVE, REPLACE }
     * @param elementsA see the event ID description
     * @param elementsB see the event ID description
         */
    public void preEvent(int event, CollectionRO elementsA
                             , CollectionRO elementsB);

    /* copy-paste for event switching
    switch(event) {
    case AbstractCollectionRW.PreListener.ADD:
    case AbstractCollectionRW.PreListener.REMOVE:
    case AbstractCollectionRW.PreListener.REPLACE:
    }
    //*/
    }

    /** Sets the pre-listener.  The pre-listener is called with
     * details of any list-modification operations BEFORE the changes
     * occur. */
    public void setPreListener(PreListener listener) {
        preListener = listener;
    }

    /** Called before an action is taken */
    protected void preEvent(int event, CollectionRO elementsA, CollectionRO elementsB) {
        if(preListener != null)
            preListener.preEvent(event, elementsA, elementsB);
    }

    /** Returns whether pre-events are enabled */
    protected boolean preEventEnabled() {
        if(eventDepth != 0)
            return false;
        return preListener != null;
    }


    /** Returns whether or not there are any registered CollectionRO.Listeners. */
    protected boolean postEventsEnabled() {
        return eventDepth == 0 && numCollListeners > 0;
    }

    /** Fires a Collection event */
    protected void postEvent(int event, CollectionRO elementsA, CollectionRO elementsB) {
        if(eventDepth != 0 || numCollListeners == 0)
            return;

    for(int i=0; i<collListeners.length; i+=2) {
        CollectionRO.Listener listener = (CollectionRO.Listener)collListeners[i];
            Object sendback = collListeners[i+1];
            if(listener != null)
                listener.collectionEvent(sendback, this, event, elementsA, elementsB);
    }
    }

    protected ListRO single(Object element) {
        return new SingleElementListRO(element);
    }


    //
    // CollectionRO
    //

    /** @see CollectionRO#addListener */
    public void addListener(CollectionRO.Listener listener, Object sendback) {
    if(listener == null)
        return;
    collListeners = PairUtil.add(collListeners, numCollListeners++
                     , listener, sendback);
    }

    /** @see CollectionRO#removeListener */
    public void removeListener(CollectionRO.Listener listener) {
    int pair = PairUtil.find(collListeners, numCollListeners, listener);
    if(pair != -1)
        PairUtil.swapRemove(collListeners, numCollListeners--, pair);
    }

    /** @see CollectionRO#iteratorRO */
    public IteratorRO iteratorRO() {
    return iteratorRW();
    }

    // abstract methods

    /** @see CollectionRO#size */
    public abstract int size();


    //
    // CollectionRW
    //

    /** @see CollectionRW#iterator() */
    public java.util.Iterator iterator() {
    return iteratorRW();
    }

    /** @see CollectionRW#addAll(CollectionRO) */
    public boolean addAll(CollectionRO collection) {
    if(collection == null)
        throw new NullPointerException("collection == null");
    if(collection.size() == 0)
        return false;

        // pre-event
        if(preEventEnabled())
            preEvent(PreListener.ADD, collection, null);

    // prepare for events
    boolean hasPost = postEventsEnabled();
    Object[] added = null;
    int numAdded = 0;
    if(hasPost)
        added = new Object[collection.size()];

    // do the add, keeping track of added events
    eventDepth++;
        for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); ) {
        Object element = itr.next();
        if(add(element) && hasPost)
        added[numAdded++] = element;
    }
    eventDepth--;

    // fire the event
    if(hasPost && numAdded > 0)
        postEvent(CollectionRO.Listener.ADD
                      , new DefaultListRO(added, 0, numAdded), null);

    return numAdded > 0;
    }

    /** @see CollectionRW#addAll(java.util.Collection) */
    public boolean addAll(java.util.Collection collection) {
        return addAll((CollectionRO)new CollectionToCollectionRW(collection));
    }

    /** @see CollectionRW#removeAll(CollectionRO) */
    public boolean removeAll(CollectionRO collection) {
    if(collection == null)
        throw new NullPointerException("collection == null");
    if(collection.size() == 0)
        return false;

        // pre-event
        if(preListener != null)
            preEvent(PreListener.REMOVE, collection, null);

    // prep for events
    boolean hasCL = postEventsEnabled();
    Object[] removed = null;
    int numRemoved = 0;
    if(hasCL)
        removed = new Object[collection.size()];

    // do the remove, keeping track of removed events
    eventDepth++;
        for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); ) {
        Object element = itr.next();
        if(remove(element) && hasCL)
        removed[numRemoved++] = element;
    }
    eventDepth--;

    // fire the event
    if(hasCL && numRemoved > 0)
        postEvent(CollectionRO.Listener.REMOVE
                      , new DefaultListRO(removed, 0, numRemoved), null);

    return numRemoved > 0;
    }

    /** @see CollectionRW#removeAll(java.util.Collection) */
    public boolean removeAll(java.util.Collection collection) {
        return removeAll((CollectionRO)new CollectionToCollectionRW(collection));
    }


    /** @see CollectionRW#removeAll(CollectionRO) */
    public boolean retainAll(CollectionRO collection) {
    if(collection == null)
        throw new NullPointerException("collection == null");
    if(collection.size() == 0)
        return false;

        java.util.ArrayList removed = new java.util.ArrayList();
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(!collection.contains(element)) {
                removed.add(element);
            }
        }
        return removeAll(removed);
    }

    /** @see CollectionRW#retainAll(java.util.Collection) */
    public boolean retainAll(java.util.Collection collection) {
        if(collection == null) {
            throw new NullPointerException("collection == null");
        }
        
        if(collection.size() == 0) {
            return false;
        }

        java.util.ArrayList removed = new java.util.ArrayList();
        for(java.util.Iterator itr=iterator(); itr.hasNext(); ) {
            Object element = itr.next();
            
            if(!collection.contains(element)) {
                removed.add(element);
            }
        }
        return removeAll(removed);
    }



    // abstract methods

    /** @see CollectionRW#add */
    public abstract boolean add(Object element);

    /** @see CollectionRW#remove */
    public abstract boolean remove(Object element);

    /** @see CollectionRW#clear */
    public abstract void clear();

    /** @see CollectionRW#iterator */
    public abstract IteratorRW iteratorRW();
}
