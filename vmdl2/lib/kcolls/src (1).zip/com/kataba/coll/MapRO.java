//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import com.kataba.util.*;

/** Represents a read-only set of objects, each mapped to a value
 * Object.  The elements of a MapRO are not guaranteed to be ordered
 * in any particular way.
 *
 * <p>An implementation of this interface should document its rules of
 * object equivalence.
 *
 * @see java.util.Map
 * @author Chris Thiessen
 */
public interface MapRO
    extends Lockable
{

    /** Implemented by classes which wish to be notified of changes to
     * the contents of a MapRO */
    public interface Listener {

        /** Key-value mappings were added and/or changed.  'keys'
         * contains the changed keys, and 'oldValues' their old values
         * (at matching indices).  If a value from 'oldValues' ==
         * 'notSet', the matching key is new to the MapRO */
        public static final int ADD = 1;

        /** Mappings were removed.  'keys' contains the removed
         * keys, and 'oldValues' their old values (at matching
         * indices). */
        public static final int REMOVE = 2;

        /** Called when the map is changed
         *
         * @param source    the MapRO that changed
         * @param sendback  the Object that this listener was registered along with
         * @param event     the event ID, one of { ADD, REMOVE }
         * @param keys      see the event ID descriptions
         * @param oldValues see the event ID descriptions
         * @param noValue   see the event ID descriptions
         */
        public void mapEvent(Object sendback, MapRO source, int event
                             , ListRO keys, ListRO oldValues
                             , Object notSet);
    }

    /** Represents a single key-value mapping in a MapRO.  Represents
     * the read-only part of the java.util.Map.Entry interface.
     *
     * @see java.util.Map.Entry
     */
    public interface EntryRO extends Lockable {
        /** @see java.util.Map.Entry#equals(Object) */
        public boolean equals(Object object);

        /** @see java.util.Map.Entry#getKey() */
        public Object getKey();

        /** @see java.util.Map.Entry#getValue() */
        public Object getValue();

        /** @see java.util.Map.Entry#hashCode() */
        public int hashCode();
    }


    /** Registers a listener to be triggered when the contents of this
     * MapRO change.  The 'sendback' is passed to the 'listener' with
     * each event, to provide context. */
    public void addListener(MapRO.Listener listener, Object sendback);

    /** Deregisters a listener registered to notified when the
     * contents of this MapRO change.  More specifically, deregisters
     * the listener which is == to the specified 'listener'. */
    public void removeListener(MapRO.Listener listener);

    /** Returns an IteratorRO over the keys of the MapRO */
    public IteratorRO keyIteratorRO();

    /** Returns the EntryRO for the specified 'key' */
    public EntryRO getEntryRO(Object key);


    // methods which are close to those in java.util.Map

    /** @see java.util.Map#entrySet() */
    public SetRO entrySetRO();

    /** @see java.util.Map#keySet() */
    public SetRO keySetRO();

    /** @see java.util.Map#values() */
    public CollectionRO valuesRO();


    //
    // implements the read-only part of the java.util.Map interface
    //

    /** @see java.util.Map#containsKey(Object) */
    public boolean containsKey(Object key);

    /** @see java.util.Map#containsValue(Object) */
    public boolean containsValue(Object value);

    /** @see java.util.Map#get(Object) */
    public Object get(Object key);

    /** @see java.util.Map#isEmpty() */
    public boolean isEmpty();

    /** @see java.util.Map#size() */
    public int size();

    /** @see java.util.Map#equals(Object) */
    public boolean equals(Object object);

    /** @see java.util.Map#hashCode() */
    public int hashCode();
}
