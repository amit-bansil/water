
package com.kataba.coll;

/** A ListRO of arbitrary size that only contains one element.
 *
 * @author Chris Thiessen
 */
public class MonotonicListRO
    extends AbstractListRO
{
    protected Object element;
    protected int size;

    /** Constructs so that '_element' is the only element in the
     * ListRO and '_size' is the number of elements in it. */
    public MonotonicListRO(Object _element, int _size) {
	if(_size < 0)
	    throw new IllegalArgumentException("'size' must be > 0");
	element = _element;
	size = _size;
    }

    //
    // implements ListRO
    //

    /** Does nothing, since the contents of the ListRO can never change
     *
     * @see ListRO#addListener(ListRO.Listener,Object) */
    public void addListener(ListRO.Listener listener, Object sendback) {
    }

    /** @see ListRO#removeListener(ListRO.Listener) */
    public void removeListener(ListRO.Listener listener) {
    }

    /** Always returns 'element'
     *
     * @see ListRO#get(int) */
    public Object get(int index) {
	if(index < 0 || index >= size)
	    throw new IndexOutOfBoundsException();

	return element;
    }


    //
    // implements CollectionRO
    //

    /** Does nothing, since the contents of the ListRO can never change
     *
     * @see CollectionRO#addListener(CollectionRO.Listener,Object) */
    public void addListener(CollectionRO.Listener listener, Object sendback) {
    }

    /** @see CollectionRO#removeListener(CollectionRO.Listener) */
    public void removeListener(CollectionRO.Listener listener) {
    }

    /** @see CollectionRO#size() */
    public int size() {
	return size;
    }
}
