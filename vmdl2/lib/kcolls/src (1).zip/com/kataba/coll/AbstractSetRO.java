
package com.kataba.coll;

import com.kataba.coll.wrap.*;

/** This class provides a skeletal implementation of the SetRO
 * interface to minimize the effort required to implement this
 * interface.
 *
 * <p>Concrete subclasses of this class must define the following methods:
 * <ul>
 *   <li><code>size()</code>
 *   <li><code>iteratorRO()</code>
 * </ul>
 *
 * @author Chris Thiessen
 */
public abstract class AbstractSetRO
    extends AbstractCollectionRO
    implements SetRO
{

    //
    // implements SetRO
    //

    /** @see SetRO#union(SetRO) */
    public SetRO union(SetRO set) {
        HashSetRW result = new HashSetRW();
        result.addAll(this);
        result.addAll(set);
        return result;
    }

    /** @see SetRO#intersection(SetRO) */
    public SetRO intersection(SetRO set) {
        HashSetRW result = new HashSetRW();
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(set.contains(element))
                result.add(element);
        }
        return result;
    }

    /** @see SetRO#xor(SetRO) */
    public SetRO xor(SetRO set) {
        HashSetRW result = new HashSetRW();

        // add the needed elements from 'this'
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(!set.contains(element))
                result.add(element);
        }

        // add the needed elements from 'set'
        for(IteratorRO itr=set.iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(!contains(element))
                result.add(element);
        }

        return result;
    }

    /** @see SetRO#equals(Object) */
    public boolean equals(Object object) {
        SetRO set;
        if(object == null)
            return false;
        else if(object instanceof SetRO)
            set = (SetRO)object;
        else if(object instanceof java.util.Set)
            set = new SetToSetRW((java.util.Set)object);
        else
            return false;

        // if the 'set' contains all the elements of this 'set', return true
        if(set.size() != size())
            return false;
        return containsAll(set);
    }


    /** @see SetRO#hashCode() */
    public int hashCode() {
        int hashCode = 0;
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(element != null)
                hashCode += element.hashCode();
        }
        return hashCode;
    }


    //
    // implements CollectionRO
    //

    /** @see CollectionRO#size */
    public abstract int size();

    /** @see CollectionRO#iteratorRO */
    public abstract IteratorRO iteratorRO();
}
