//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes all access to the wrapped ListRW on the Object
 * returned by that ListRW's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedListRW
    extends SynchronizedCollectionRW
    implements ListRW
{
    private ListRW list;
    private ListROListener_NewSource listener_newSource;

    /** Constructs to synchronize access to the specified '_list' */
    public SynchronizedListRW(ListRW _list) {
	super(_list);
	list = _list;
    }


    //
    // implements ListRO
    //

    /** @see ListRO#addListener(ListRO.Listener,Object) */
    public void addListener(ListRO.Listener listener, Object sendback) {
        synchronized(lock()) {
            if(listener_newSource == null)
                listener_newSource = new ListROListener_NewSource(list, this);
            listener_newSource.addListener(listener, sendback);
        }
    }

    /** @see ListRO#removeListener(ListRO.Listener) */
    public void removeListener(ListRO.Listener listener) {
        synchronized(lock()) {
            if(listener_newSource != null)
                listener_newSource.removeListener(listener);
        }
    }

    /** @see ListRO#get(int) */
    public Object get(int index) {
        synchronized(lock()) {
            return list.get(index);
        }
    }

    /** @see ListRO#subListRO(int,int) */
    public ListRO subListRO(int fromIndex, int toIndex) {
        synchronized(lock()) {
            return new SynchronizedListRO(list.subListRO(fromIndex, toIndex));
        }
    }

    /** @see ListRO#indexOf(Object) */
    public int indexOf(Object element) {
        synchronized(lock()) {
            return list.indexOf(element);
        }
    }

    /** @see ListRO#indexOf(Object,int,boolean) */
    public int indexOf(Object element, int startIndex, boolean direction) {
        synchronized(lock()) {
            return list.indexOf(element, startIndex, direction);
        }
    }

    /** @see ListRO#indexesOf(CollectionRO) */
    public ArrayRO_int indexesOf(CollectionRO collection) {
        synchronized(lock()) {
            return list.indexesOf(collection);
        }
    }

    /** @see ListRO#indexOf(Object) */
    public int lastIndexOf(Object element) {
        synchronized(lock()) {
            return list.lastIndexOf(element);
        }
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO() {
        synchronized(lock()) {
            return new SynchronizedListCursorRO(list.listCursorRO());
        }
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO(int index) {
        synchronized(lock()) {
            return new SynchronizedListCursorRO(list.listCursorRO(index));
        }
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO() {
        synchronized(lock()) {
            return new SynchronizedListIteratorRO(list.listIteratorRO());
        }
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO(int index) {
        synchronized(lock()) {
            return new SynchronizedListIteratorRO(list.listIteratorRO(index));
        }
    }


    //
    // implements ListRW
    //


    /** @see ListRW#add(int,Object) */
    public void add(int index, Object element) {
        synchronized(lock()) {
            list.add(index, element);
        }
    }

    /** @see ListRW#addAll(int,CollectionRO) */
    public boolean addAll(int index, CollectionRO collection) {
        synchronized(lock()) {
            return list.addAll(index, collection);
        }
    }

    /** @see ListRW#addAll(int,java.util.Collection) */
    public boolean addAll(int index, java.util.Collection collection) {
        synchronized(lock()) {
            return list.addAll(index, collection);
        }
    }

    /** @see ListRW#remove(int) */
    public Object remove(int index) {
        synchronized(lock()) {
            return list.remove(index);
        }
    }

    /** @see ListRW#removeRange(int,int) */
    public void removeRange(int fromIndex, int toIndex) {
        synchronized(lock()) {
            list.removeRange(fromIndex, toIndex);
        }
    }

    /** @see ListRW#removeAll(ArrayRO_int) */
    public void removeAll(ArrayRO_int indexes) {
        synchronized(lock()) {
            list.removeAll(indexes);
        }
    }

    /** @see ListRW#retainAll(ArrayRO_int) */
    public void retainAll(ArrayRO_int indexes) {
        synchronized(lock()) {
            list.retainAll(indexes);
        }
    }

    /** @see ListRW#set(int,Object) */
    public Object set(int index, Object element) {
        synchronized(lock()) {
            return list.set(index, element);
        }
    }

    /** @see ListRW#swap(int,int) */
    public void swap(int indexA, int indexB) {
        synchronized(lock()) {
            list.swap(indexA, indexB);
        }
    }

    /** @see ListRW#move(int,int) */
    public void move(int fromIndex, int toIndex) {
        synchronized(lock()) {
            list.move(fromIndex, toIndex);
        }
    }

    /** @see ListRW#subListRW(int,int) */
    public ListRW subListRW(int fromIndex, int toIndex) {
        synchronized(lock()) {
            return list.subListRW(fromIndex, toIndex);
        }
    }

    /** @see ListRW#subListRW(int,int) */
    public java.util.List subList(int fromIndex, int toIndex) {
        synchronized(lock()) {
            return list.subListRW(fromIndex, toIndex);
        }
    }

    /** @see ListRW#listCursorRW() */
    public ListCursorRW listCursorRW() {
        synchronized(lock()) {
            return list.listCursorRW();
        }
    }

    /** @see ListRW#listCursorRW(int) */
    public ListCursorRW listCursorRW(int index) {
        synchronized(lock()) {
            return list.listCursorRW(index);
        }
    }

    /** @see ListRW#listIteratorRW() */
    public ListIteratorRW listIteratorRW() {
        synchronized(lock()) {
            return list.listIteratorRW();
        }
    }

    /** @see ListRW#listIteratorRW(int) */
    public ListIteratorRW listIteratorRW(int index) {
        synchronized(lock()) {
            return list.listIteratorRW(index);
        }
    }

    /** @see ListRW#listIterator() */
    public java.util.ListIterator listIterator() {
        synchronized(lock()) {
            return list.listIterator();
        }
    }

    /** @see ListRW#listIterator(int) */
    public java.util.ListIterator listIterator(int index) {
        synchronized(lock()) {
            return list.listIterator(index);
        }
    }
}

