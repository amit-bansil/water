//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a List.  Calls to List methods on instances of this class
 * are forwarded to the wrapped List.  This class can be used to
 * restrict the interface of the wrapped List to just the List
 * interface.
 *
 * @author Chris Thiessen
 */
public class WrappedListRW
    extends WrappedCollectionRW
    implements ListRW
{
    protected ListRW list;
    private ListROListener_NewSource listener_newSource;

    /** Constructs to adapt the specified List */
    public WrappedListRW(ListRW _list) {
	super(_list);
	list = _list;
    }

    //
    // implements ListRO
    //

    /** @see ListRO#addListener(ListRO.Listener,Object) */
    public void addListener(ListRO.Listener listener, Object sendback) {
	if(listener_newSource == null)
	    listener_newSource = new ListROListener_NewSource(list, this);
	listener_newSource.addListener(listener, sendback);
    }

    /** @see ListRO#removeListener(ListRO.Listener) */
    public void removeListener(ListRO.Listener listener) {
	if(listener_newSource != null)
	    listener_newSource.removeListener(listener);
    }

    /** @see ListRO#get(int) */
    public Object get(int index) {
	return list.get(index);
    }

    /** @see ListRO#subListRO(int,int) */
    public ListRO subListRO(int fromIndex, int toIndex) {
	return list.subListRO(fromIndex, toIndex);
    }

    /** @see ListRO#indexOf(Object) */
    public int indexOf(Object element) {
	return list.indexOf(element);
    }

    /** @see ListRO#indexOf(Object,int,boolean) */
    public int indexOf(Object element, int startIndex, boolean direction) {
	return list.indexOf(element, startIndex, direction);
    }

    /** @see ListRO#indexesOf(CollectionRO) */
    public ArrayRO_int indexesOf(CollectionRO collection) {
	return list.indexesOf(collection);
    }

    /** @see ListRO#indexOf(Object) */
    public int lastIndexOf(Object element) {
	return list.lastIndexOf(element);
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO() {
	return list.listCursorRO();
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO(int index) {
	return list.listCursorRO(index);
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO() {
	return list.listIteratorRO();
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO(int index) {
	return list.listIteratorRO(index);
    }


    //
    // implements ListRW
    //


    /** @see ListRW#add(int,Object) */
    public void add(int index, Object element) {
	list.add(index, element);
    }

    /** @see ListRW#addAll(int,CollectionRO) */
    public boolean addAll(int index, CollectionRO collection) {
	return list.addAll(index, collection);
    }

    /** @see ListRW#addAll(int,java.util.Collection) */
    public boolean addAll(int index, java.util.Collection collection) {
	return list.addAll(index, collection);
    }

    /** @see ListRW#remove(int) */
    public Object remove(int index) {
	return list.remove(index);
    }

    /** @see ListRW#removeRange(int,int) */
    public void removeRange(int fromIndex, int toIndex) {
	list.removeRange(fromIndex, toIndex);
    }

    /** @see ListRW#removeAll(ArrayRO_int) */
    public void removeAll(ArrayRO_int indexes) {
	list.removeAll(indexes);
    }

    /** @see ListRW#retainAll(ArrayRO_int) */
    public void retainAll(ArrayRO_int indexes) {
	list.retainAll(indexes);
    }

    /** @see ListRW#set(int,Object) */
    public Object set(int index, Object element) {
	return list.set(index, element);
    }

    /** @see ListRW#swap(int,int) */
    public void swap(int indexA, int indexB) {
	list.swap(indexA, indexB);
    }

    /** @see ListRW#move(int,int) */
    public void move(int fromIndex, int toIndex) {
	list.move(fromIndex, toIndex);
    }

    /** @see ListRW#subListRW(int,int) */
    public ListRW subListRW(int fromIndex, int toIndex) {
	return list.subListRW(fromIndex, toIndex);
    }

    /** @see ListRW#subListRW(int,int) */
    public java.util.List subList(int fromIndex, int toIndex) {
	return list.subListRW(fromIndex, toIndex);
    }

    /** @see ListRW#listCursorRW() */
    public ListCursorRW listCursorRW() {
	return list.listCursorRW();
    }

    /** @see ListRW#listCursorRW(int) */
    public ListCursorRW listCursorRW(int index) {
	return list.listCursorRW(index);
    }

    /** @see ListRW#listIteratorRW() */
    public ListIteratorRW listIteratorRW() {
	return list.listIteratorRW();
    }

    /** @see ListRW#listIteratorRW(int) */
    public ListIteratorRW listIteratorRW(int index) {
	return list.listIteratorRW(index);
    }

    /** @see ListRW#listIterator() */
    public java.util.ListIterator listIterator() {
	return list.listIterator();
    }

    /** @see ListRW#listIterator(int) */
    public java.util.ListIterator listIterator(int index) {
	return list.listIterator(index);
    }
}
