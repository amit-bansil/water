//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a ListCursorRO.  Calls to ListCursorRO methods on instances of
 * this class are forwarded to the wrapped ListCursorRO.  This class can
 * be used to restrict the interface of the wrapped ListCursorRO to just
 * the ListCursorRO interface.
 *
 * @author Chris Thiessen
 */
public class WrappedListCursorRO
    extends WrappedLockable
    implements ListCursorRO
{
    protected ListCursorRO listCursorRO;

    /** Constructs to wrap the specified ListCursorRO */
    public WrappedListCursorRO(ListCursorRO _listCursorRO) {
	super(_listCursorRO);
	listCursorRO = _listCursorRO;
    }


    //
    // implements ListCursorRO
    //

    /** @see ListCursorRO#size() */
    public int size() {
	return listCursorRO.size();
    }

    /** @see ListCursorRO#index() */
    public int index() {
	return listCursorRO.index();
    }

    /** @see ListCursorRO#setIndex(int) */
    public void setIndex(int index) {
        listCursorRO.setIndex(index);
    }

    /** @see ListCursorRO#canGet(int) */
    public boolean canGet(int offset) {
	return listCursorRO.canGet(offset);
    }

    /** @see ListCursorRO#get(int) */
    public Object get(int offset) {
	return listCursorRO.get(offset);
    }

    /** @see ListCursorRO#canMove(int) */
    public boolean canMove(int offset) {
	return listCursorRO.canMove(offset);
    }

    /** @see ListCursorRO#move(int) */
    public void move(int offset) {
	listCursorRO.move(offset);
    }

    /** @see ListCursorRO#moveCrop(int) */
    public void moveCrop(int offset) {
	listCursorRO.moveCrop(offset);
    }
}
