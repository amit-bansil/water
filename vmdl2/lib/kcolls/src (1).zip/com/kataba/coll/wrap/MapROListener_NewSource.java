
package com.kataba.coll.wrap;
import com.kataba.coll.*;
import com.kataba.util.*;

/** A MapRO.Listener which multiplexes received events to a
 * list of other MapRO.Listeners, while reporting the source of
 * the event to be a different MapRO.
 *
 * @author Chris Thiessen
 */
public class MapROListener_NewSource
    implements MapRO.Listener
{
    private MapRO oldSource;
    private MapRO newSource;
    private ListRW listeners;

    /** Constructs */
    public MapROListener_NewSource(MapRO _oldSource, MapRO _newSource) {
        oldSource = _oldSource;
        newSource = _newSource;
    }

    /** Adds the specified listener */
    public void addListener(MapRO.Listener listener, Object sendback) {
        if(listener == null)
            throw new NullPointerException();

	if(listeners == null) {
	    listeners = new GapListRW();
            oldSource.addListener(this, null);
        }
	listeners.add(listener);
	listeners.add(sendback);
    }

    /** Removes the specified listener.  If the list of registered
     * listeners drops to listeners, this listener is unregistered
     * from the 'source' MapRO */
    public void removeListener(MapRO.Listener listener) {
	if(listeners != null) {
	    listeners.remove(listener);

            // if no more listeners, unregister the listener
            if(listeners.size() == 0) {
                oldSource.removeListener(this);
                listeners = null;
            }
        }
    }

    /** Fires a MapRO event to each of the registered
     * listeners, re-sourcing the event to the 'source'
     * MapRO */
    public void fireEvent(int event, ListRO keys, ListRO oldValues, Object noValue) {
	if(listeners == null)
	    return;

	int size = listeners.size();
	for(int i=0; i<size; i+=2) {
	    MapRO.Listener listener = (MapRO.Listener)listeners.get(i);
	    Object sendback = listeners.get(i+1);

	    listener.mapEvent(sendback, newSource, event, keys, oldValues, noValue);
	}
    }


    //
    // implements MapRO.Listener
    //

    /** @see com.kataba.coll.MapRO.Listener#mapEvent */
    public void mapEvent(Object sendback, MapRO source, int event
                         , ListRO keys, ListRO oldValues, Object noValue) {
	fireEvent(event, keys, oldValues, noValue);
    }
}
