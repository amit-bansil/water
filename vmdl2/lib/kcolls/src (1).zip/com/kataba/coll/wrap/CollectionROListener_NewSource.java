
package com.kataba.coll.wrap;
import com.kataba.coll.*;
import com.kataba.util.*;

/** A ListRO.Listener which multiplexes received events to a list of
 * other CollectionRO.Listeners, while reporting the source of the
 * event to be a different CollectionRO.
 *
 * @author Chris Thiessen
 */
public class CollectionROListener_NewSource
    implements CollectionRO.Listener
{
    private CollectionRO oldSource;
    private CollectionRO newSource;
    private ListRW listeners;

    /** Constructs */
    public CollectionROListener_NewSource(CollectionRO _oldSource, CollectionRO _newSource) {
        oldSource = _oldSource;
        newSource = _newSource;
    }

    /** Adds the specified listener */
    public void addListener(CollectionRO.Listener listener, Object sendback) {
        if(listener == null)
            throw new NullPointerException();

	if(listeners == null) {
	    listeners = new GapListRW();
            oldSource.addListener(this, null);
        }
	listeners.add(listener);
	listeners.add(sendback);
    }

    /** Removes the specified listener.  If the list of registered
     * listeners drops to listeners, this listener is unregistered
     * from the 'source' CollectionRO */
    public void removeListener(CollectionRO.Listener listener) {
	if(listeners != null) {
	    listeners.remove(listener);

            // if no more listeners, unregister the listener
            if(listeners.size() == 0) {
                oldSource.removeListener(this);
                listeners = null;
            }
        }
    }

    /** Fires a CollectionRO event to each of the registered listeners,
     * re-sourcing the event to the 'source' CollectionRO */
    protected void fireCollectionEvent(int event, CollectionRO elementsA
                                       , CollectionRO elementsB) {
	if(listeners == null)
	    return;

	for(int i=0; i<listeners.size(); i+=2) {
	    CollectionRO.Listener listener = (CollectionRO.Listener)listeners.get(i);
	    Object sendback = listeners.get(i+1);

	    listener.collectionEvent(sendback, newSource, event, elementsA, elementsB);
	}
    }

    //
    // implements CollectionRO.Listener
    //

    /** @see com.kataba.coll.CollectionRO.Listener#collectionEvent */
    public void collectionEvent(Object sendback, CollectionRO source
                                , int event, CollectionRO elementsA, CollectionRO elementsB) {
	fireCollectionEvent(event, elementsA, elementsB);
    }
}
