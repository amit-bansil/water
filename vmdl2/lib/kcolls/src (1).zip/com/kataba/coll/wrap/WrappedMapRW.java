//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Wraps a MapRW.  Calls to MapRW methods on instances of this class
 * are forwarded to the wrapped MapRW.  This class can be used to
 * restrict the interface of the wrapped MapRW to just the MapRW
 * interface.
 *
 * @author Chris Thiessen
 */
public class WrappedMapRW
    extends WrappedMapRO
    implements MapRW
{
    protected MapRW map;

    /** Constructs to wrap the specified MapRO */
    public WrappedMapRW(MapRW _map) {
        super(_map);
	map = _map;
    }


    //
    // implements MapRW
    //

    /** @see MapRW#keyIteratorRW() */
    public IteratorRW keyIteratorRW() {
        return map.keyIteratorRW();
    }

    /** @see MapRW#getEntryRW(Object) */
    public EntryRW getEntryRW(Object key) {
        return map.getEntryRW(key);
    }

    /** @see MapRW#entrySetRW() */
    public SetRW entrySetRW() {
        return map.entrySetRW();
    }

    /** @see MapRW#keySetRW() */
    public SetRW keySetRW() {
        return map.keySetRW();
    }

    /** @see MapRW#putAll(MapRO) */
    public void putAll(MapRO _map) {
        map.putAll(_map);
    }

    /** @see MapRW#valuesRW() */
    public CollectionRW valuesRW() {
        return map.valuesRW();
    }

    /** @see MapRW#clear() */
    public void clear() {
        map.clear();
    }

    /** @see MapRW#entrySet() */
    public java.util.Set entrySet() {
        return map.entrySet();
    }

    /** @see java.util.Map#keySet() */
    public java.util.Set keySet() {
        return map.keySet();
    }

    /** @see MapRW#values() */
    public java.util.Collection values() {
        return map.values();
    }

    /** @see MapRW#put(Object,Object) */
    public Object put(Object key, Object value) {
        return map.put(key, value);
    }

    /** @see MapRW#putAll(java.util.Map) */
    public void putAll(java.util.Map _map) {
        map.putAll(_map);
    }

    /** @see MapRW#remove(Object) */
    public Object remove(Object key) {
        return map.remove(key);
    }
}
