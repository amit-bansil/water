//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a java.util.List so that it can be used as a ListRW.
 *
 * @author Chris Thiessen
 */
public class ListToListRW
    extends CollectionToCollectionRW
    implements ListRW
{
    private java.util.List list;

    /** Constructs to wrap the specified list */
    public ListToListRW(java.util.List _list) {
        super(_list);
	if(_list == null)
	    throw new NullPointerException("'_list' == null");
	list = _list;
    }

    /** Validates that the specified 'indexes' contain ascending,
     * non-duplicating indexes */
    private void validateIndexes(ArrayRO_int indexes) {
        // validate the indexes
        int size = size();
        int lastIndex = -1;
        if(indexes.get(0) < 0)
            throw new IndexOutOfBoundsException
                ("indexes[0]:"+indexes.get(0)+", size:" + size);
        for(int i=0,ii=indexes.size(); i<ii; i++) {
            int index = indexes.get(i);
            if(index <= lastIndex)
                throw new IllegalArgumentException
                    ("indexes["+i+"]:"+index+" > indexes["+(i-1)+"]:"+lastIndex);
            if(index >= size)
                throw new IndexOutOfBoundsException
                    ("indexes["+i+"]:"+index+", size:" + size);
            lastIndex = index;
        }
    }

    private void validateIndex(int index) {
        validateIndex("index", index);
    }

    private void validateIndex(String indexName, int index) {
        if(index < 0 || index >= size())
            throw new IndexOutOfBoundsException(indexName+":"+index+", size:"+size());
    }

    private void validateAddIndex(int index) {
        validateAddIndex("index", index);
    }

    private void validateAddIndex(String indexName, int index) {
        if(index < 0 || index > size())
            throw new IndexOutOfBoundsException(indexName+":"+index+", size:"+size());
    }



    //
    // implements ListRO
    //

    /** @see ListRO#addListener(ListRO.Listener,Object) */
    public void addListener(ListRO.Listener listener, Object sendback) {
        throw new UnsupportedOperationException
            ("JDK collection wrappers do not support change events");
    }

    /** @see ListRO#removeListener(ListRO.Listener) */
    public void removeListener(ListRO.Listener listener) {
        throw new UnsupportedOperationException
            ("JDK collection wrappers do not support change events");
    }

    /** @see ListRO#indexOf(Object,int,boolean) */
    public int indexOf(Object object, int startIndex, boolean direction) {
        validateAddIndex("startIndex", startIndex);
        int shift = direction ? 1 : -1;
        for(int i=startIndex; i<size() && i>=0; i+=shift) {
            Object element = get(i);
            if(Util.equals(element, object))
                return i;
        }
        return -1;
    }

    /** @see ListRO#indexesOf(CollectionRO) */
    public ArrayRO_int indexesOf(CollectionRO coll) {
        int[] indexes = new int[10];
        int count = 0;

        // find the matching indexes
        for(int i=0,ii=size(); i<ii; i++) {
            if(coll.contains(get(i))) {
                if(count == indexes.length)
                    indexes = Util.expand(indexes);
                indexes[count++] = i;
            }
        }
        return new ArrayRO_int(indexes, 0, count);
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO() {
        return new DefaultListCursorRO(this, 0);
    }

    /** @see ListRO#listCursorRO(int) */
    public ListCursorRO listCursorRO(int index) {
        return new DefaultListCursorRO(this, index);
    }


    //
    // close equivalenst to java.util.List methods
    //

    /** @see ListRO#subListRO(int,int) */
    public ListRO subListRO(int fromIndex, int toIndex) {
        return new ListToListRW(list.subList(fromIndex, toIndex));
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO() {
        return new DefaultListIteratorRO(listCursorRO());
    }

    /** @see ListRO#listIteratorRO(int) */
    public ListIteratorRO listIteratorRO(int index) {
        return new DefaultListIteratorRO(listCursorRO(index));
    }


    //
    // implements read-only part of java.util.List
    //

    /** @see ListRO#get(int) */
    public Object get(int index) {
        validateIndex(index);
        return list.get(index);
    }

    /** @see ListRO#indexOf(Object) */
    public int indexOf(Object element) {
        return list.indexOf(element);
    }

    /** @see ListRO#lastIndexOf(Object) */
    public int lastIndexOf(Object element) {
        return list.lastIndexOf(element);
    }

    /** @see ListRO#equals(Object) */
    public boolean equals(Object object) {
        ListRO list;
        if(object == null)
            return false;
        else if(object instanceof ListRO)
            list = (ListRO)object;
        else if(object instanceof java.util.List)
            // wrap the java.util.List
            list = new ListToListRW((java.util.List)object);
        else
            return false;

        // compare the list
        if(list.size() != size())
            return false;
        int i=0;
        for(IteratorRO itr=list.iteratorRO(); itr.hasNext(); i++) {
            Object thisElem = get(i);
            Object listElem = itr.next();
            boolean match = thisElem==null ? listElem==null : thisElem.equals(listElem);
            if(!match)
                return false;
        }
        return true;
    }

    /** @see ListRO#hashCode() */
    public int hashCode() {
        return list.hashCode();
    }


    //
    // implements ListRW
    //

    /** @see ListRW#swap(int,int) */
    public void swap(int indexA, int indexB) {
        if(indexA < 0 || indexA >= size())
            throw new IndexOutOfBoundsException("indexA:"+indexA+", size:"+size());
        if(indexB < 0 || indexB >= size())
            throw new IndexOutOfBoundsException("indexB:"+indexB+", size:"+size());

        Object a = list.get(indexA);
        list.set(indexA, get(indexB));
        list.set(indexB, a);
    }

    /** @see ListRW#move(int,int) */
    public void move(int fromIndex, int toIndex) {
        if(fromIndex < 0 || fromIndex >= size())
            throw new IndexOutOfBoundsException("fromIndex:"+fromIndex+", size:"+size());
        if(toIndex < 0 || toIndex > size())
            throw new IndexOutOfBoundsException("toIndex:"+toIndex+", size:"+size());

        // if the move isn't required
        if(toIndex == fromIndex || toIndex == fromIndex+1)
            return;

        add(toIndex, get(fromIndex));
        remove(fromIndex);
    }

    /** @see ListRW#removeRange(int,int) */
    public void removeRange(int start, int end) {
        if(start < 0)
            throw new IndexOutOfBoundsException("start:"+start+" < 0");
        if(start > end)
            throw new IllegalArgumentException
                ("start:"+start+" > end:"+end);
        if(end > size())
            throw new IndexOutOfBoundsException
                ("end:"+end+" > size:"+size());

        for(int i=end-1; i>=start; i--)
            list.remove(i);
    }

    /** @see ListRW#removeAll(ArrayRO_int) */
    public void removeAll(ArrayRO_int indexes) {
        validateIndexes(indexes);
        for(int i=indexes.size()-1; i>=0; i--)
            remove(indexes.get(i));
    }

    /** @see ListRW#retainAll(ArrayRO_int) */
    public void retainAll(ArrayRO_int indexes) {
        int[] inverse = new int[size() - indexes.size()];
        int inverse_i = 0;
        int indexes_i = 0;
        for(int i=0; i<size(); i++) {
            if(i == indexes.get(indexes_i))
                indexes_i++;
            else
                inverse[inverse_i++] = i;
        }

        // remove
        for(int i=indexes.size()-1; i>=0; i--)
            remove(indexes.get(i));
    }


    /** @see ListRW#listCursorRW() */
    public ListCursorRW listCursorRW() {
        return new DefaultListCursorRW(this, 0);
    }

    /** @see ListRW#listCursorRW(int) */
    public ListCursorRW listCursorRW(int index) {
        return new DefaultListCursorRW(this, index);
    }

    /** @see ListRW#addAll(int,java.util.Collection) */
    public boolean addAll(int index, CollectionRO collection) {
        validateAddIndex(index);
        if(collection == null)
            throw new NullPointerException("collection == null");
        return list.addAll(index, new GapListRW(collection));
    }

    /** @see ListRW#subList(int,int) */
    public ListRW subListRW(int fromIndex, int toIndex) {
	if(fromIndex < 0)
	    throw new IndexOutOfBoundsException("fromIndex:"+fromIndex+", list.size:"+size());
	if(fromIndex > toIndex)
	    throw new IllegalArgumentException
		("fromIndex:"+fromIndex+" > toIndex:"+toIndex+"");
	if(toIndex > list.size())
	    throw new IndexOutOfBoundsException
		("toIndex:"+toIndex+", list.size:"+size());
        return new ListToListRW(list.subList(fromIndex, toIndex));
    }

    /** @see ListRW#listIteratorRW() */
    public ListIteratorRW listIteratorRW() {
        return new DefaultListIteratorRW(listCursorRW());
    }

    /** @see ListRW#listIteratorRW(int) */
    public ListIteratorRW listIteratorRW(int index) {
        return new DefaultListIteratorRW(listCursorRW(index));
    }


    // JDK methods

    /** @see ListRW#add(int,Object) */
    public void add(int index, Object element) {
        validateAddIndex(index);
        list.add(index, element);
    }

    /** @see ListRW#addAll(int,java.util.Collection) */
    public boolean addAll(int index, java.util.Collection collection) {
        validateAddIndex(index);
        if(collection == null)
            throw new NullPointerException("collection == null");
        return list.addAll(index, collection);
    }

    /** @see ListRW#remove(int) */
    public Object remove(int index) {
        validateIndex(index);
        return list.remove(index);
    }

    /** @see ListRW#set(int,Object) */
    public Object set(int index, Object newElement) {
        validateIndex(index);
        return list.set(index, newElement);
    }

    /** @see ListRW#listIterator() */
    public java.util.ListIterator listIterator() {
        return list.listIterator();
    }

    /** @see ListRW#listIterator(int) */
    public java.util.ListIterator listIterator(int index) {
        return list.listIterator(index);
    }

    /** @see ListRW#subList(int,int) */
    public java.util.List subList(int fromIndex, int toIndex) {
        return list.subList(fromIndex, toIndex);
    }
}
