//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes all access to the wrapped MapRO on the Object
 * returned by that MapRO's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedMapRO
    extends WrappedLockable
    implements MapRO
{
    protected MapRO mapRO;
    protected MapROListener_NewSource sourceMapListener;

    /** Constructs to synchronize access to the specified '_mapRO' */
    public SynchronizedMapRO(MapRO _mapRO) {
        super(_mapRO);
	mapRO = _mapRO;
    }


    //
    // implements MapRO
    //

    /** @see MapRO#addListener(MapRO.Listener,Object) */
    public void addListener(MapRO.Listener listener, Object sendback) {
        synchronized(lock()) {
            if(sourceMapListener == null)
                sourceMapListener = new MapROListener_NewSource(mapRO, this);
            sourceMapListener.addListener(listener, sendback);
        }
    }

    /** @see MapRO#removeListener(MapRO.Listener) */
    public void removeListener(MapRO.Listener listener) {
        synchronized(lock()) {
            if(sourceMapListener != null)
                sourceMapListener.removeListener(listener);
        }
    }

    /** @see MapRO#keyIteratorRO() */
    public IteratorRO keyIteratorRO() {
        synchronized(lock()) {
            return new SynchronizedIteratorRO(mapRO.keyIteratorRO());
        }
    }

    /** @see MapRO#getEntryRO(Object) */
    public EntryRO getEntryRO(Object key) {
        synchronized(lock()) {
            return new SynchronizedMapRO_EntryRO(mapRO.getEntryRO(key));
        }
    }

    /** @see MapRO#entrySetRO() */
    public SetRO entrySetRO() {
        synchronized(lock()) {
            return new SynchronizedSetRO(mapRO.entrySetRO());
        }
    }

    /** @see MapRO#keySetRO() */
    public SetRO keySetRO() {
        synchronized(lock()) {
            return new SynchronizedSetRO(mapRO.keySetRO());
        }
    }

    /** @see MapRO#valuesRO() */
    public CollectionRO valuesRO() {
        synchronized(lock()) {
            return new SynchronizedCollectionRO(mapRO.valuesRO());
        }
    }

    /** @see MapRO#containsKey(Object) */
    public boolean containsKey(Object key) {
        synchronized(lock()) {
            return mapRO.containsKey(key);
        }
    }

    /** @see MapRO#containsValue(Object) */
    public boolean containsValue(Object value) {
        synchronized(lock()) {
            return mapRO.containsValue(value);
        }
    }

    /** @see MapRO#get(Object) */
    public Object get(Object key) {
        synchronized(lock()) {
            return mapRO.get(key);
        }
    }

    /** @see MapRO#isEmpty() */
    public boolean isEmpty() {
        synchronized(lock()) {
            return mapRO.isEmpty();
        }
    }

    /** @see MapRO#size() */
    public int size() {
        synchronized(lock()) {
            return mapRO.size();
        }
    }

    /** @see MapRO#equals(Object) */
    public boolean equals(Object object) {
        synchronized(lock()) {
            return mapRO.equals(object);
        }
    }

    /** @see MapRO#hashCode() */
    public int hashCode() {
        synchronized(lock()) {
            return mapRO.hashCode();
        }
    }
}
