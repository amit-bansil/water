//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes access to the wrapped MapRO.EntryRO.
 *
 * @author Chris Thiessen
 */
public class SynchronizedMapRO_EntryRO
    extends WrappedLockable
    implements MapRO.EntryRO
{
    protected MapRO.EntryRO entryRO;

    /** Constructs to wrap the specified MapRO.EntryRO */
    public SynchronizedMapRO_EntryRO(MapRO.EntryRO _entryRO) {
	super(_entryRO);
	entryRO = _entryRO;
    }


    //
    // implements MapRO.EntryRO
    //

    /** @see com.kataba.coll.MapRO.EntryRO#equals(Object) */
    public boolean equals(Object object) {
        synchronized(lock()) {
            return entryRO.equals(object);
        }
    }

    /** @see com.kataba.coll.MapRO.EntryRO#getKey() */
    public Object getKey() {
        synchronized(lock()) {
            return entryRO.getKey();
        }
    }

    /** @see com.kataba.coll.MapRO.EntryRO#getValue() */
    public Object getValue() {
        synchronized(lock()) {
            return entryRO.getValue();
        }
    }

    /** @see com.kataba.coll.MapRO.EntryRO#hashCode() */
    public int hashCode() {
        synchronized(lock()) {
            return entryRO.hashCode();
        }
    }
}
