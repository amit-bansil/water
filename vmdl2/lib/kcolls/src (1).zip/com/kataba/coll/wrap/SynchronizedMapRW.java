//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Synchronizes all access to the wrapped MapRW on the Object
 * returned by that MapRW's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedMapRW
    extends SynchronizedMapRO
    implements MapRW
{
    protected MapRW map;

    /** Constructs to synchronize access the specified '_map' */
    public SynchronizedMapRW(MapRW _map) {
        super(_map);
	map = _map;
    }


    //
    // implements MapRW
    //

    /** @see MapRW#keyIteratorRW() */
    public IteratorRW keyIteratorRW() {
        synchronized(lock()) {
            return new SynchronizedIteratorRW(map.keyIteratorRW());
        }
    }

    /** @see MapRW#getEntryRW(Object) */
    public EntryRW getEntryRW(Object key) {
        synchronized(lock()) {
            return new SynchronizedMapRW_EntryRW(map.getEntryRW(key));
        }
    }

    /** @see MapRW#entrySetRW() */
    public SetRW entrySetRW() {
        synchronized(lock()) {
            return new SynchronizedSetRW(map.entrySetRW());
        }
    }

    /** @see MapRW#keySetRW() */
    public SetRW keySetRW() {
        synchronized(lock()) {
            return new SynchronizedSetRW(map.keySetRW());
        }
    }

    /** @see MapRW#putAll(MapRO) */
    public void putAll(MapRO _map) {
        synchronized(lock()) {
            map.putAll(_map);
        }
    }

    /** @see MapRW#valuesRW() */
    public CollectionRW valuesRW() {
        synchronized(lock()) {
            return new SynchronizedCollectionRW(map.valuesRW());
        }
    }

    /** @see MapRW#clear() */
    public void clear() {
        synchronized(lock()) {
            map.clear();
        }
    }

    /** @see MapRW#entrySet() */
    public java.util.Set entrySet() {
        return entrySetRW();
    }

    /** @see java.util.Map#keySet() */
    public java.util.Set keySet() {
        return keySetRW();
    }

    /** @see MapRW#values() */
    public java.util.Collection values() {
        return valuesRW();
    }

    /** @see MapRW#put(Object,Object) */
    public Object put(Object key, Object value) {
        synchronized(lock()) {
            return map.put(key, value);
        }
    }

    /** @see MapRW#putAll(java.util.Map) */
    public void putAll(java.util.Map _map) {
        synchronized(lock()) {
            map.putAll(_map);
        }
    }

    /** @see MapRW#remove(Object) */
    public Object remove(Object key) {
        synchronized(lock()) {
            return map.remove(key);
        }
    }
}
