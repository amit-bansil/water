//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a java.util.Iterator to look like a com.kataba.coll.IteratorRW.
 *
 * @author Chris Thiessen
 */
public class IteratorToIteratorRW
    extends AbstractLockable
    implements IteratorRW
{
    private java.util.Iterator itr;

    public IteratorToIteratorRW(java.util.Iterator _itr) {
	itr = _itr;
    }


    //
    // implements IteratorRO
    //

    /** @see IteratorRO#hasNext() */
    public boolean hasNext() {
	return itr.hasNext();
    }

    /** @see IteratorRO#next() */
    public Object next() {
	return itr.next();
    }


    //
    // implements IteratorRW
    //

    /** @see IteratorRW#remove() */
    public void remove() {
        try {
            itr.remove();
        } catch(IllegalStateException ex) {
            if(ex.getMessage() == null)
                throw new IllegalStateException
                    ("Neither next nor previous have been called,"
                     +" or remove or add have been called since the"
                     +" last call to next or previous.");
            throw ex;
        }
    }
}
