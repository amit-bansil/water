//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes all access to the wrapped ListIteratorRO on the Object
 * returned by that ListIteratorRO's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedListIteratorRO
    extends SynchronizedIteratorRO
    implements ListIteratorRO
{
    protected ListIteratorRO itrRO;

    /** Constructs to synchronize access to the specified '_itrRO' */
    public SynchronizedListIteratorRO(ListIteratorRO _itrRO) {
	super(_itrRO);
	itrRO = _itrRO;
    }


    //
    // implements ListIteratorRO
    //

    /** @see ListIteratorRO#hasPrevious() */
    public boolean hasPrevious() {
	return itrRO.hasPrevious();
    }

    /** @see ListIteratorRO#previous() */
    public Object previous() {
	return itrRO.previous();
    }

    /** @see ListIteratorRO#nextIndex() */
    public int nextIndex() {
	return itrRO.nextIndex();
    }

    /** @see ListIteratorRO#previousIndex() */
    public int previousIndex() {
	return itrRO.previousIndex();
    }
}
