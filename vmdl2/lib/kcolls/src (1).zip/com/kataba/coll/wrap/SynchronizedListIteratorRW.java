//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes all access to the wrapped ListIteratorRW on the Object
 * returned by that ListIteratorRW's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedListIteratorRW
    extends SynchronizedListIteratorRO
    implements ListIteratorRW
{
    protected ListIteratorRW itr;

    /** Constructs to synchronize access to the specified '_itr' */
    public SynchronizedListIteratorRW(ListIteratorRW _itr) {
	super(_itr);
	itr = _itr;
    }

    //
    // implements IteratorRW
    //

    /** @see IteratorRW#remove() */
    public void remove() {
        synchronized(lock()) {
            itr.remove();
        }
    }


    //
    // implements ListIteratorRW
    //

    /** @see java.util.ListIterator#add(Object) */
    public void add(Object object) {
        synchronized(lock()) {
            itr.add(object);
        }
    }

    /** @see java.util.ListIterator#set(Object) */
    public void set(Object object) {
        synchronized(lock()) {
            itr.set(object);
        }
    }
}
