//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Wraps a Collection.  Calls to Collection methods on instances of
 * this class are forwarded to the wrapped Collection.  This class can
 * be used to restrict the interface of the wrapped Collection to just
 * the Collection interface.
 *
 * @author Chris Thiessen
 */
public class WrappedCollectionRW
    extends WrappedCollectionRO
    implements CollectionRW
{
    protected CollectionRW coll;

    /** Constructs */
    public WrappedCollectionRW(CollectionRW _coll) {
	super(_coll);
	coll = _coll;
    }


    //
    // implements Collection
    //

    /** @see CollectionRW#add */
    public boolean add(Object element) {
	return coll.add(element);
    }

    /** @see CollectionRW#addAll */
    public boolean addAll(CollectionRO collection) {
	return coll.addAll(collection);
    }

    /** @see CollectionRW#addAll */
    public boolean addAll(java.util.Collection collection) {
	return coll.addAll(collection);
    }

    /** @see CollectionRW#remove */
    public boolean remove(Object element) {
	return coll.remove(element);
    }

    /** @see CollectionRW#removeAll */
    public boolean removeAll(CollectionRO collection) {
	return coll.removeAll(collection);
    }

    /** @see CollectionRW#removeAll */
    public boolean removeAll(java.util.Collection collection) {
	return coll.removeAll(collection);
    }

    /** @see CollectionRW#retainAll */
    public boolean retainAll(CollectionRO collection) {
	return coll.retainAll(collection);
    }

    /** @see CollectionRW#retainAll */
    public boolean retainAll(java.util.Collection collection) {
	return coll.retainAll(collection);
    }

    /** @see CollectionRW#clear() */
    public void clear() {
	coll.clear();
    }

    /** @see CollectionRW#iterator() */
    public java.util.Iterator iterator() {
	return coll.iterator();
    }

    /** @see CollectionRW#iteratorRW() */
    public IteratorRW iteratorRW() {
	return coll.iteratorRW();
    }
}
