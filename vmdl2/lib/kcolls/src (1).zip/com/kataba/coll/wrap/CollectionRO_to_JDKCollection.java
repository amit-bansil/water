//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Wraps a CollectionRO to look like a java.util.Collection.
 *
 * @author Chris Thiessen
 */
public class CollectionRO_to_JDKCollection
    implements java.util.Collection
{
    private CollectionRO coll;

    /** Constructs to wrap the specified '_coll' */
    public CollectionRO_to_JDKCollection(CollectionRO _coll) {
	if(_coll == null)
	    throw new NullPointerException("'_coll' == null");
	coll = _coll;
    }


    //
    // implements java.util.Collection
    //

    /** @see java.util.Collection#size */
    public int size() {
	return coll.size();
    }

    /** @see java.util.Collection#isEmpty */
    public boolean isEmpty() {
	return coll.isEmpty();
    }

    /** @see java.util.Collection#contains(Object) */
    public boolean contains(Object o) {
	return coll.contains(o);
    }

    /** @see java.util.Collection#iterator() */
    public java.util.Iterator iterator() {
	return new IteratorRO_to_JDKIterator(coll.iteratorRO());
    }

    /** @see java.util.Collection#toArray() */
    public Object[] toArray() {
	return coll.toArray();
    }

    /** @see java.util.Collection#toArray(Object[]) */
    public Object[] toArray(Object a[]) {
        int size = size();
        if(a.length < size)
            a = (Object[])java.lang.reflect.Array.newInstance
		(a.getClass().getComponentType(), size);

        IteratorRO it=coll.iteratorRO();
        for (int i=0; i<size; i++)
            a[i] = it.next();

        if (a.length > size)
            a[size] = null;

        return a;
    }


    // Modification Operations

    /** @see java.util.Collection#add(Object) */
    public boolean add(Object o) {
	throw new UnsupportedOperationException();
    }

    /** @see java.util.Collection#remove(Object) */
    public boolean remove(Object o) {
	throw new UnsupportedOperationException();
    }


    // Bulk Operations

    /** @see java.util.Collection#containsAll(java.util.Collection) */
    public boolean containsAll(java.util.Collection c) {
	throw new UnsupportedOperationException();
    }

    /** @see java.util.Collection#addAll(java.util.Collection) */
    public boolean addAll(java.util.Collection c) {
	throw new UnsupportedOperationException();
    }

    /** @see java.util.Collection#removeAll(java.util.Collection) */
    public boolean removeAll(java.util.Collection c) {
	throw new UnsupportedOperationException();
    }

    /** @see java.util.Collection#retainAll(java.util.Collection) */
    public boolean retainAll(java.util.Collection c) {
	throw new UnsupportedOperationException();
    }

    /** @see java.util.Collection#clear() */
    public void clear() {
	throw new UnsupportedOperationException();
    }


    // Comparison and hashing

    /** @see java.util.Collection#equals */
    public boolean equals(Object o) {
	return super.equals(o);
    }

    /** @see java.util.Collection#hashCode */
    public int hashCode() {
	return super.hashCode();
    }
}
