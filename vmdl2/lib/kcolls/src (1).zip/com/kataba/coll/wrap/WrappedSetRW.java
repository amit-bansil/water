//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Wraps a SetRW.  Calls to SetRW methods on instances of this class are
 * forwarded to the wrapped SetRW.  This class can be used to restrict
 * the interface of the wrapped SetRW to just the SetRW interface.
 *
 * @author Chris Thiessen
 */
public class WrappedSetRW
    extends WrappedCollectionRW
    implements SetRW
{
    protected SetRW set;

    /** Constructs to wrap the specified SetRW */
    public WrappedSetRW(SetRW _set) {
	super(_set);
	set = _set;
    }


    //
    // implements SetRO
    //

    /** @see SetRO#union(SetRO) */
    public SetRO union(SetRO set) {
        return set.union(set);
    }

    /** @see SetRO#intersection(SetRO) */
    public SetRO intersection(SetRO set) {
        return set.intersection(set);
    }

    /** @see SetRO#xor(SetRO) */
    public SetRO xor(SetRO set) {
        return set.xor(set);
    }
}
