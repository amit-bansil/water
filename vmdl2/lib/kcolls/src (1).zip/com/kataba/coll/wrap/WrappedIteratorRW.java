//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Wraps a Iterator.  Calls to Iterator methods on instances of this
 * class are forwarded to the wrapped Iterator.  This class can be
 * used to restrict the interface of the wrapped Iterator to just the
 * Iterator interface.
 *
 * @author Chris Thiessen
 */
public class WrappedIteratorRW
    extends WrappedIteratorRO
    implements IteratorRW
{
    protected IteratorRW itr;

    /** Constructs to wrap the specified Iterator */
    public WrappedIteratorRW(IteratorRW _itr) {
	super(_itr);
	itr = _itr;
    }


    //
    // implements IteratorRW
    //

    /** @see IteratorRW#remove */
    public void remove() {
	itr.remove();
    }
}
