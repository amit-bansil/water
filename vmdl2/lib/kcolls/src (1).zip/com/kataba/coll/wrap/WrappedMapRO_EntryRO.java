//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a MapRO.EntryRO.  Calls to MapRO.EntryRO methods on
 * instances of this class are forwarded to the wrapped MapRO.EntryRO.
 * This class can be used to restrict the interface of the wrapped
 * MapRO.EntryRO to just the MapRO.EntryRO interface.
 *
 * @author Chris Thiessen
 */
public class WrappedMapRO_EntryRO
    extends WrappedLockable
    implements MapRO.EntryRO
{
    protected MapRO.EntryRO entryRO;

    /** Constructs to wrap the specified MapRO.EntryRO */
    public WrappedMapRO_EntryRO(MapRO.EntryRO _entryRO) {
	super(_entryRO);
	entryRO = _entryRO;
    }


    //
    // implements MapRO.EntryRO
    //

    /** @see com.kataba.coll.MapRO.EntryRO#equals(Object) */
    public boolean equals(Object object) {
        return entryRO.equals(object);
    }

    /** @see com.kataba.coll.MapRO.EntryRO#getKey() */
    public Object getKey() {
        return entryRO.getKey();
    }

    /** @see com.kataba.coll.MapRO.EntryRO#getValue() */
    public Object getValue() {
        return entryRO.getValue();
    }

    /** @see com.kataba.coll.MapRO.EntryRO#hashCode() */
    public int hashCode() {
        return entryRO.hashCode();
    }
}
