//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes all access to the wrapped ListRO on the Object
 * returned by that ListRO's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedListRO
    extends SynchronizedCollectionRO
    implements ListRO
{
    private ListRO listRO;
    private ListROListener_NewSource listener_newSource;

    /** Constructs to synchronize access to the specified '_listRO' */
    public SynchronizedListRO(ListRO _listRO) {
	super(_listRO);
	listRO = _listRO;
    }


    //
    // implements ListRO
    //

    /** @see ListRO#addListener(ListRO.Listener,Object) */
    public void addListener(ListRO.Listener listener, Object sendback) {
        synchronized(lock()) {
            if(listener_newSource == null)
                listener_newSource = new ListROListener_NewSource(listRO, this);
            listener_newSource.addListener(listener, sendback);
        }
    }

    /** @see ListRO#removeListener(ListRO.Listener) */
    public void removeListener(ListRO.Listener listener) {
        synchronized(lock()) {
            if(listener_newSource != null)
                listener_newSource.removeListener(listener);
        }
    }

    /** @see ListRO#get(int) */
    public Object get(int index) {
        synchronized(lock()) {
            return listRO.get(index);
        }
    }

    /** @see ListRO#subListRO(int,int) */
    public ListRO subListRO(int fromIndex, int toIndex) {
        synchronized(lock()) {
            return new SynchronizedListRO(listRO.subListRO(fromIndex, toIndex));
        }
    }

    /** @see ListRO#indexOf(Object) */
    public int indexOf(Object element) {
        synchronized(lock()) {
            return listRO.indexOf(element);
        }
    }

    /** @see ListRO#indexOf(Object,int,boolean) */
    public int indexOf(Object element, int startIndex, boolean direction) {
        synchronized(lock()) {
            return listRO.indexOf(element, startIndex, direction);
        }
    }

    /** @see ListRO#indexesOf(CollectionRO) */
    public ArrayRO_int indexesOf(CollectionRO collection) {
        synchronized(lock()) {
            return listRO.indexesOf(collection);
        }
    }

    /** @see ListRO#indexOf(Object) */
    public int lastIndexOf(Object element) {
        synchronized(lock()) {
            return listRO.lastIndexOf(element);
        }
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO() {
        synchronized(lock()) {
            return new SynchronizedListCursorRO(listRO.listCursorRO());
        }
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO(int index) {
        synchronized(lock()) {
            return new SynchronizedListCursorRO(listRO.listCursorRO(index));
        }
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO() {
        synchronized(lock()) {
            return new SynchronizedListIteratorRO(listRO.listIteratorRO());
        }
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO(int index) {
        synchronized(lock()) {
            return new SynchronizedListIteratorRO(listRO.listIteratorRO(index));
        }
    }
}
