//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a java.util.Iterator to look like a com.kataba.coll.IteratorRO
 *
 * @author Chris Thiessen
 */
public class IteratorRO_to_JDKIterator
    implements java.util.Iterator
{
    private IteratorRO itr;

    public IteratorRO_to_JDKIterator(IteratorRO _itr) {
	itr = _itr;
    }


    //
    // implements java.util.Iterator
    //

    /** @see java.util.Iterator#hasNext() */
    public boolean hasNext() {
	return itr.hasNext();
    }

    /** @see java.util.Iterator#next() */
    public Object next() {
	return itr.next();
    }

    /** @see java.util.Iterator#remove() */
    public void remove() {
	throw new UnsupportedOperationException();
    }
}
