
package com.kataba.coll.wrap;
import com.kataba.coll.*;
import com.kataba.util.*;

/** A ListRO.Listener which multiplexes received events to a list of
 * other ListRO.Listeners, while reporting the source of the event to
 * be a different ListRO.
 *
 * @author Chris Thiessen
 */
public class ListROListener_NewSource
    implements ListRO.Listener
{
    private ListRO oldSource;
    private ListRO newSource;
    private ListRW listeners;

    /** Constructs */
    public ListROListener_NewSource(ListRO _oldSource, ListRO _newSource) {
        oldSource = _oldSource;
        newSource = _newSource;
    }

    /** Adds the specified listener */
    public void addListener(ListRO.Listener listener, Object sendback) {
        if(listener == null)
            throw new NullPointerException();

	if(listeners == null) {
	    listeners = new GapListRW();
            oldSource.addListener(this, null);
        }
	listeners.add(listener);
	listeners.add(sendback);
    }

    /** Removes the specified listener.  If the list of registered
     * listeners drops to listeners, this listener is unregistered
     * from the 'source' ListRO */
    public void removeListener(ListRO.Listener listener) {
	if(listeners != null) {
	    listeners.remove(listener);

            // if no more listeners, unregister the listener
            if(listeners.size() == 0) {
                oldSource.removeListener(this);
                listeners = null;
            }
        }
    }

    /** Fires a ListRO event to each of the registered listeners,
     * re-sourcing the event to the 'source' ListRO */
    protected void fireListEvent(int event, int indexA, int indexB, ArrayRO_int indexes
				 , ListRO elements) {
	if(listeners == null)
	    return;

	for(int i=0; i<listeners.size(); i+=2) {
	    ListRO.Listener listener = (ListRO.Listener)listeners.get(i);
	    Object sendback = listeners.get(i+1);

	    listener.listEvent(sendback, newSource
			       , event, indexA, indexB, indexes, elements);
	}
    }

    //
    // implements ListRO.Listener
    //

    /** @see com.kataba.coll.ListRO.Listener#listEvent */
    public void listEvent(Object sendback, ListRO source, int event
			  , int indexA, int indexB, ArrayRO_int indexes, ListRO elements) {
	fireListEvent(event, indexA, indexB, indexes, elements);
    }
}
