
package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

//TODO: equals and hashCode
public class MapToMapRW
    implements MapRW
{
    java.util.Map map;

    /** Constructs */
    public MapToMapRW(java.util.Map _map) {
        map = _map;
    }

    //
    // implements Lockable
    //

    /** @see Lockable#lock */
    public Object lock() {
        return map;
    }


    //
    // implements MapRO
    //

    /** @see MapRO#addListener(MapRO.Listener,Object) */
    public void addListener(Listener listener, Object sendback) {
        throw new UnsupportedOperationException
            ("JDK collection wrappers do not support change events");
    }

    /** @see MapRO#removeListener(MapRO.Listener) */
    public void removeListener(Listener listener) {
        throw new UnsupportedOperationException
            ("JDK collection wrappers do not support change events");
    }

    /** Inner faker of LocalEntries */
    private class LocalEntryRW implements EntryRW {
        private Object key;
        private LocalEntryRW(Object _key) {
            key = _key;
        }
        public Object lock() { return lock(); }
        public boolean equals(Object object) {
            if(object == null || !(object instanceof EntryRO))
                return false;
            EntryRO entry = (EntryRO)object;
            return Util.equals(key, entry.getKey())
                && Util.equals(getValue(), entry.getValue());
        }
        public Object getKey() { return key; }
        public Object getValue() { return get(key); }
        public int hashCode() { return key.hashCode(); }
        public Object setValue(Object value) { return put(key, value); }
    }

    /** @see MapRO#getEntryRO */
    public EntryRO getEntryRO(Object key) {
        return getEntryRW(key);
    }

    /** @see MapRO#keyIteratorRO */
    public IteratorRO keyIteratorRO() {
        return new IteratorToIteratorRW(map.keySet().iterator());
    }


    // methods which are close to those in java.util.Map

    /** @see MapRO#entrySetRO */
    public SetRO entrySetRO() {
        return entrySetRW();
    }

    /** @see MapRO#keySetRO */
    public SetRO keySetRO() {
        return keySetRW();
    }

    /** @see MapRO#valuesRO */
    public CollectionRO valuesRO() {
        return valuesRW();
    }


    //
    // implements the read-only part of the java.util.Map interface
    //

    /** @see MapRO#containsKey */
    public boolean containsKey(Object key) {
        return map.containsKey(key);
    }

    /** @see MapRO#containsValue */
    public boolean containsValue(Object value) {
        return map.containsValue(value);
    }

    /** @see MapRO#get */
    public Object get(Object key) {
        return map.get(key);
    }

    /** @see MapRO#isEmpty */
    public boolean isEmpty() {
        return map.isEmpty();
    }

    /** @see MapRO#size */
    public int size() {
        return map.size();
    }

    /** @see MapRO#equals */
    public boolean equals(Object object) {
        return map.equals(object);
    }

    /** @see MapRO#hashCode */
    public int hashCode() {
        return map.hashCode();
    }



    //
    // implements MapRW
    //

    /** @see MapRW#keyIteratorRW */
    public IteratorRW keyIteratorRW() {
        return new IteratorToIteratorRW(map.keySet().iterator());
    }

    /** @see MapRW#getEntryRW */
    public EntryRW getEntryRW(Object key) {
        return new LocalEntryRW(key);
    }


    // methods equivalent to those in java.util.Map

    /** @see MapRW#entrySet */
    public SetRW entrySetRW() {
        return new SetToSetRW(map.entrySet());
    }


    /** @see MapRW#keySetRW */
    public SetRW keySetRW() {
        return new SetToSetRW(map.keySet());
    }

    /** @see MapRW#valuesRW */
    public CollectionRW valuesRW() {
        return new CollectionToCollectionRW(map.values());
    }

    /** @see MapRW#putAll(MapRO) */
    public void putAll(MapRO _map) {
        map.putAll(new HashMapRW(_map));
    }




    //
    // implements the content modification part of the java.util.Map interface
    //

    //protected void postEvent(int event, ListRO keys
    //                       , ListRO oldValues, Object noValue);

    /** @see MapRW#clear */
    public void clear() {
        map.clear();
    }

    /** @see MapRW#entrySet */
    public java.util.Set entrySet() {
        return new SetToSetRW(map.entrySet());
    }

    /** @see MapRW#keySet */
    public java.util.Set keySet() {
        return new SetToSetRW(map.keySet());
    }

    /** @see MapRW#values */
    public java.util.Collection values() {
        return new CollectionToCollectionRW(map.values());
    }

    /** @see MapRW#put */
    public Object put(Object key, Object value) {
        return map.put(key, value);
    }

    /** @see MapRW#putAll(java.util.Map) */
    public void putAll(java.util.Map _map) {
        map.putAll(_map);
    }

    /** @see MapRW#remove(Object) */
    public Object remove(Object key) {
        return map.remove(key);
    }
}
