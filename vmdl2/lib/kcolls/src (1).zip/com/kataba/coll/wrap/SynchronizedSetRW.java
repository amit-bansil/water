//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Synchronizes all access to the wrapped SetRW on the Object
 * returned by that SetRW's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedSetRW
    extends SynchronizedCollectionRW
    implements SetRW
{
    private SetRW set;

    /** Constructs to synchronize access to the specified '_set' */
    public SynchronizedSetRW(SetRW _set) {
	super(_set);
	set = _set;
    }


    //
    // implements SetRO
    //

    /** @see SetRO#union(SetRO) */
    public SetRO union(SetRO set) {
        synchronized(lock()) {
            return new SynchronizedSetRO(set.union(set));
        }
    }

    /** @see SetRO#intersection(SetRO) */
    public SetRO intersection(SetRO set) {
        synchronized(lock()) {
            return new SynchronizedSetRO(set.intersection(set));
        }
    }

    /** @see SetRO#xor(SetRO) */
    public SetRO xor(SetRO set) {
        synchronized(lock()) {
            return new SynchronizedSetRO(set.xor(set));
        }
    }
}
