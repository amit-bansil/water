//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a ListIteratorRO.  Calls to ListIteratorRO methods on
 * instances of this class are forwarded to the wrapped
 * ListIteratorRO.  This class can be used to restrict the interface
 * of the wrapped ListIteratorRO to just the ListIteratorRO interface.
 *
 * @author Chris Thiessen
 */
public class WrappedListIteratorRO
    extends WrappedIteratorRO
    implements ListIteratorRO
{
    protected ListIteratorRO itrRO;

    /** Constructs to wrap the specified ListIteratorRO */
    public WrappedListIteratorRO(ListIteratorRO _itrRO) {
	super(_itrRO);
	itrRO = _itrRO;
    }


    //
    // implements ListIteratorRO
    //

    /** @see ListIteratorRO#hasPrevious() */
    public boolean hasPrevious() {
	return itrRO.hasPrevious();
    }

    /** @see ListIteratorRO#previous() */
    public Object previous() {
	return itrRO.previous();
    }

    /** @see ListIteratorRO#nextIndex() */
    public int nextIndex() {
	return itrRO.nextIndex();
    }

    /** @see ListIteratorRO#previousIndex() */
    public int previousIndex() {
	return itrRO.previousIndex();
    }
}
