//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Wraps a ListCursorRW.  Calls to ListCursorRW methods on instances
 * of this class are forwarded to the wrapped ListCursorRW.  This
 * class can be used to restrict the interface of the wrapped
 * ListCursorRW to just the ListCursorRW interface.
 *
 * @author Chris Thiessen
 */
public class WrappedListCursorRW
    extends WrappedListCursorRO
    implements ListCursorRW
{
    protected ListCursorRW listCursor;

    /** Constructs to wrap the specified ListCursorRO */
    public WrappedListCursorRW(ListCursorRW _listCursor) {
	super(_listCursor);
	listCursor = _listCursor;
    }


    //
    // implements ListCursorRW
    //

    /** @see ListCursorRW#add(int,Object) */
    public void add(int offset, Object element) {
	listCursor.add(offset, element);
    }

    /** @see ListCursorRW#remove(int) */
    public void remove(int offset) {
	listCursor.remove(offset);
    }

    /** @see ListCursorRW#set(int,Object) */
    public void set(int offset, Object element) {
	listCursor.set(offset, element);
    }
}
