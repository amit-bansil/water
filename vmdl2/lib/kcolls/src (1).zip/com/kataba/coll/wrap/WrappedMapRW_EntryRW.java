//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a MapRW.EntryRW.  Calls to MapRW.EntryRW methods on
 * instances of this class are forwarded to the wrapped MapRW.EntryRW.
 * This class can be used to restrict the interface of the wrapped
 * MapRW.EntryRW to just the MapRW.EntryRW interface.
 *
 * @author Chris Thiessen
 */
public class WrappedMapRW_EntryRW
    extends WrappedMapRO_EntryRO
    implements MapRW.EntryRW
{
    protected MapRW.EntryRW entry;

    /** Constructs to wrap the specified MapRW.EntryRW */
    public WrappedMapRW_EntryRW(MapRW.EntryRW _entry) {
	super(_entry);
	entry = _entry;
    }


    //
    // implements MapRW.EntryRW
    //

    /** @see com.kataba.coll.MapRW.EntryRW#equals(Object) */
    public Object setValue(Object value) {
        return entry.setValue(value);
    }
}
