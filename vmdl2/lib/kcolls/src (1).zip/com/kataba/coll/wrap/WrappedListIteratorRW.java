//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a ListIteratorRW.  Calls to ListIteratorRW methods on
 * instances of this class are forwarded to the wrapped
 * ListIteratorRW.  This class can be used to restrict the interface
 * of the wrapped ListIteratorRW to just the ListIteratorRW interface.
 *
 * @author Chris Thiessen
 */
public class WrappedListIteratorRW
    extends WrappedListIteratorRO
    implements ListIteratorRW
{
    protected ListIteratorRW itr;

    /** Constructs to wrap the specified ListIteratorRW */
    public WrappedListIteratorRW(ListIteratorRW _itr) {
	super(_itr);
	itr = _itr;
    }

    //
    // implements IteratorRW
    //

    /** @see IteratorRW#remove() */
    public void remove() {
        itr.remove();
    }


    //
    // implements ListIteratorRW
    //

    /** @see java.util.ListIterator#add(Object) */
    public void add(Object object) {
        itr.add(object);
    }

    /** @see java.util.ListIterator#set(Object) */
    public void set(Object object) {
        itr.set(object);
    }
}
