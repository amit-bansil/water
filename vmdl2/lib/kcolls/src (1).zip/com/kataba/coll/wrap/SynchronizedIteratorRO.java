
package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes all access to the wrapped IteratorRO on the Object
 * returned by that IteratorRO's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedIteratorRO
    implements IteratorRO
{
    private IteratorRO itrRO;

    /** Constructs to synchronize access to the specified '_itrRO' */
    public SynchronizedIteratorRO(IteratorRO _itrRO) {
	itrRO = _itrRO;
    }

    //
    // implements Lockable
    //

    /** @see Lockable#lock() */
    public Object lock() {
	return itrRO.lock();
    }

    //
    // implements IteratorRO
    //

    /** @see IteratorRO#hasNext() */
    public boolean hasNext() {
	synchronized(itrRO.lock()) {
	    return itrRO.hasNext();
	}
    }

    /** @see IteratorRO#next() */
    public Object next() {
	synchronized(itrRO.lock()) {
	    return itrRO.next();
	}
    }
}
