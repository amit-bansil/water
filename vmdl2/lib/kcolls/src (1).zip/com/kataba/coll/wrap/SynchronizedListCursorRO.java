
package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes all access to the wrapped ListCursorRO on the Object
 * returned by that ListCursorRO's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedListCursorRO implements ListCursorRO {
    /** The object being wrapped. */
    private ListCursorRO listCursorRO;

    /** Constructs to synchronize access to the specified '_listCursorRO' */
    public SynchronizedListCursorRO(ListCursorRO _listCursorRO) {
	listCursorRO = _listCursorRO;
    }


    //
    // implements Lockable
    //

    /** @see Lockable#lock() */
    public Object lock() {
	return listCursorRO.lock();
    }


    //
    // implements ListCursorRO
    //

    /** @see ListCursorRO#size() */
    public int size() {
	synchronized(lock()) {
	    return listCursorRO.size();
	}
    }

    /** @see ListCursorRO#index() */
    public int index() {
	synchronized(lock()) {
	    return listCursorRO.index();
	}
    }

    /** @see ListCursorRO#setIndex(int) */
    public void setIndex(int index) {
	synchronized(lock()) {
            listCursorRO.setIndex(index);
        }
    }

    /** @see ListCursorRO#canGet(int) */
    public boolean canGet(int offset) {
	synchronized(lock()) {
	    return listCursorRO.canGet(offset);
	}
    }

    /** @see ListCursorRO#get(int) */
    public Object get(int offset) {
	synchronized(lock()) {
	    return listCursorRO.get(offset);
	}
    }

    /** @see ListCursorRO#canMove(int) */
    public boolean canMove(int offset) {
	synchronized(lock()) {
	    return listCursorRO.canMove(offset);
	}
    }

    /** @see ListCursorRO#move(int) */
    public void move(int offset) {
	synchronized(lock()) {
	    listCursorRO.move(offset);
	}
    }

    /** @see ListCursorRO#moveCrop(int) */
    public void moveCrop(int offset) {
	synchronized(lock()) {
	    listCursorRO.moveCrop(offset);
	}
    }
}
