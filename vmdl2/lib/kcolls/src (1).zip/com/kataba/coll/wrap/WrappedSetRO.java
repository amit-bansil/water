//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Wraps a SetRO.  Calls to SetRO methods on instances of this class
 * are forwarded to the wrapped SetRO.  This class can be used to
 * restrict the interface of the wrapped SetRO to just the SetRO
 * interface.
 *
 * @author Chris Thiessen
 */
public class WrappedSetRO
    extends WrappedCollectionRO
    implements SetRO
{
    protected SetRO setRO;

    /** Constructs to wrap the specified SetRO */
    public WrappedSetRO(SetRO _setRO) {
	super(_setRO);
	setRO = _setRO;
    }


    //
    // implements SetRO
    //

    /** @see SetRO#union(SetRO) */
    public SetRO union(SetRO set) {
        return setRO.union(set);
    }

    /** @see SetRO#intersection(SetRO) */
    public SetRO intersection(SetRO set) {
        return setRO.intersection(set);
    }

    /** @see SetRO#xor(SetRO) */
    public SetRO xor(SetRO set) {
        return setRO.xor(set);
    }
}
