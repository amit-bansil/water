//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a MapRO.  Calls to MapRO methods on instances of this class
 * are forwarded to the wrapped MapRO.  This class can be used to
 * restrict the interface of the wrapped MapRO to just the MapRO
 * interface.
 *
 * @author Chris Thiessen
 */
public class WrappedMapRO
    extends WrappedLockable
    implements MapRO
{
    protected MapRO mapRO;
    protected MapROListener_NewSource sourceMapListener;

    /** Constructs to wrap the specified MapRO */
    public WrappedMapRO(MapRO _mapRO) {
        super(_mapRO);
	mapRO = _mapRO;
    }

    //
    // implements MapRO
    //

    /** @see MapRO#addListener(MapRO.Listener,Object) */
    public void addListener(MapRO.Listener listener, Object sendback) {
	if(sourceMapListener == null)
	    sourceMapListener = new MapROListener_NewSource(mapRO, this);
	sourceMapListener.addListener(listener, sendback);
    }

    /** @see MapRO#removeListener(MapRO.Listener) */
    public void removeListener(MapRO.Listener listener) {
	if(sourceMapListener != null)
	    sourceMapListener.removeListener(listener);
    }

    /** @see MapRO#keyIteratorRO() */
    public IteratorRO keyIteratorRO() {
        return mapRO.keyIteratorRO();
    }

    /** @see MapRO#getEntryRO(Object) */
    public EntryRO getEntryRO(Object key) {
        return mapRO.getEntryRO(key);
    }


    // methods which are close to those in java.util.Map

    /** @see MapRO#entrySetRO() */
    public SetRO entrySetRO() {
        return mapRO.entrySetRO();
    }

    /** @see MapRO#keySetRO() */
    public SetRO keySetRO() {
        return mapRO.keySetRO();
    }

    /** @see MapRO#valuesRO() */
    public CollectionRO valuesRO() {
        return mapRO.valuesRO();
    }


    //
    // implements the read-only part of the java.util.Map interface
    //

    /** @see MapRO#containsKey(Object) */
    public boolean containsKey(Object key) {
        return mapRO.containsKey(key);
    }

    /** @see MapRO#containsValue(Object) */
    public boolean containsValue(Object value) {
        return mapRO.containsValue(value);
    }

    /** @see MapRO#get(Object) */
    public Object get(Object key) {
        return mapRO.get(key);
    }

    /** @see MapRO#isEmpty() */
    public boolean isEmpty() {
        return mapRO.isEmpty();
    }

    /** @see MapRO#size() */
    public int size() {
        return mapRO.size();
    }

    /** @see MapRO#equals(Object) */
    public boolean equals(Object object) {
        return mapRO.equals(object);
    }

    /** @see MapRO#hashCode() */
    public int hashCode() {
        return mapRO.hashCode();
    }

}
