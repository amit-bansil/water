
package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a java.util.Collection so that it can be used as a CollectionRW.
 *
 * @author Chris Thiessen
 */
public class CollectionToCollectionRW
    implements CollectionRW
{
    private java.util.Collection coll;

    /** Constructs to wrap the specified Collection */
    public CollectionToCollectionRW(java.util.Collection _coll) {
        coll = _coll;
        if(coll == null)
            throw new NullPointerException("_coll == null");
    }

    //
    // implements Lockable
    //

    /** @see Lockable#lock() */
    public Object lock() {
        return coll;
    }

    //
    // implements CollectionRO
    //

    /** @see CollectionRO#addListener(CollectionRO.Listener,Object) */
    public void addListener(Listener listener, Object sendback) {
        throw new UnsupportedOperationException
            ("JDK collection wrappers do not support change events");
    }

    /** @see CollectionRO#removeListener(CollectionRO.Listener) */
    public void removeListener(Listener listener) {
        throw new UnsupportedOperationException
            ("JDK collection wrappers do not support change events");
    }

    /** @see CollectionRO#get(Object) */
    public Object get(Object object) {
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object elem = itr.next();
            if(Util.equals(elem, object))
                return elem;
        }
        throw new java.util.NoSuchElementException("No such element: " + object);
    }

    /** @see CollectionRO#containsAll(CollectionRO) */
    public boolean containsAll(CollectionRO collection) {
        return containsAll((java.util.Collection)new GapListRW(collection));
    }

    /** @see CollectionRO#iteratorRO() */
    public IteratorRO iteratorRO() {
        return iteratorRW();
    }

    /** @see CollectionRO#size() */
    public int size() {
        return coll.size();
    }

    /** @see CollectionRO#isEmpty() */
    public boolean isEmpty() {
        return coll.isEmpty();
    }

    /** @see CollectionRO#contains(Object) */
    public boolean contains(Object object) {
        return coll.contains(object);
    }

    /** @see CollectionRO#containsAll(java.util.Collection) */
    public boolean containsAll(java.util.Collection collection) {
        return coll.containsAll(collection);
    }

    /** @see CollectionRO#toArray() */
    public Object[] toArray() {
        return coll.toArray();
    }

    /** @see CollectionRO#toArray(Object[]) */
    public Object[] toArray(Object[] array) {
        return coll.toArray(array);
    }

    /** @see CollectionRO#equals(Object) */
    public boolean equals(Object o) {
        return coll.equals(o);
    }

    /** @see CollectionRO#hashCode() */
    public int hashCode() {
        return coll.hashCode();
    }


    //
    // implements CollectionRW
    //

    /** @see CollectionRW#addAll(CollectionRO) */
    public boolean addAll(CollectionRO collection) {
        if(collection == null)
            throw new NullPointerException("collection == null");
        return coll.addAll(new GapListRW(collection));
    }

    /** @see CollectionRW#removeAll(CollectionRO) */
    public boolean removeAll(CollectionRO collection) {
        return coll.removeAll(new GapListRW(collection));
    }

    /** @see CollectionRW#retainAll(CollectionRO) */
    public boolean retainAll(CollectionRO collection) {
        return coll.retainAll(new GapListRW(collection));
    }

    /** @see CollectionRW#iteratorRW */
    public IteratorRW iteratorRW() {
        return new IteratorToIteratorRW(coll.iterator());
    }

    /** @see CollectionRW#add(Object) */
    public boolean add(Object object) {
        return coll.add(object);
    }

    /** @see CollectionRW#addAll(Collection) */
    public boolean addAll(java.util.Collection collection) {
        if(collection == null)
            throw new NullPointerException("collection == null");
        return coll.addAll(collection);
    }

    /** @see CollectionRW#remove(Object) */
    public boolean remove(Object element) {
        return coll.remove(element);
    }

    /** @see CollectionRW#removeAll(Collection) */
    public boolean removeAll(java.util.Collection collection) {
        return coll.removeAll(collection);
    }

    /** @see CollectionRW#retainAll(Collection) */
    public boolean retainAll(java.util.Collection collection) {
        return coll.retainAll(collection);
    }

    /** @see CollectionRW#clear */
    public void clear() {
        coll.clear();
    }

    /** @see CollectionRW#iterator() */
    public java.util.Iterator iterator() {
        return coll.iterator();
    }
}
