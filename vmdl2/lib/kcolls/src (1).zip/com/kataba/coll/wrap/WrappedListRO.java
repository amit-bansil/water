//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a ListRO.  Calls to ListRO methods on instances of this
 * class are forwarded to the wrapped ListRO.  This class can be used
 * to restrict the interface of the wrapped ListRO to just the ListRO
 * interface.
 *
 * @author Chris Thiessen
 */
public class WrappedListRO
    extends WrappedCollectionRO
    implements ListRO
{
    protected ListRO listRO;
    protected ListROListener_NewSource sourceListListener;

    /** Constructs to adapt the specified ListRO */
    public WrappedListRO(ListRO _listRO) {
	super(_listRO);
	listRO = _listRO;
    }


    //
    // implements ListRO
    //

    /** @see ListRO#addListener(ListRO.Listener,Object) */
    public void addListener(ListRO.Listener listener, Object sendback) {
	if(sourceListListener == null)
	    sourceListListener = new ListROListener_NewSource(listRO, this);
	sourceListListener.addListener(listener, sendback);
    }

    /** @see ListRO#removeListener(ListRO.Listener) */
    public void removeListener(ListRO.Listener listener) {
	if(sourceListListener != null)
	    sourceListListener.removeListener(listener);
    }

    /** @see ListRO#get(int) */
    public Object get(int index) {
	return listRO.get(index);
    }

    /** @see ListRO#subListRO(int,int) */
    public ListRO subListRO(int fromIndex, int toIndex) {
	return listRO.subListRO(fromIndex, toIndex);
    }

    /** @see ListRO#indexOf(Object) */
    public int indexOf(Object element) {
	return listRO.indexOf(element);
    }

    /** @see ListRO#indexOf(Object,int,boolean) */
    public int indexOf(Object element, int startIndex, boolean direction) {
	return listRO.indexOf(element, startIndex, direction);
    }

    /** @see ListRO#indexesOf(CollectionRO) */
    public ArrayRO_int indexesOf(CollectionRO collection) {
	return listRO.indexesOf(collection);
    }

    /** @see ListRO#indexOf(Object) */
    public int lastIndexOf(Object element) {
	return listRO.lastIndexOf(element);
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO() {
	return listRO.listCursorRO();
    }

    /** @see ListRO#listCursorRO() */
    public ListCursorRO listCursorRO(int index) {
	return listRO.listCursorRO(index);
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO() {
	return listRO.listIteratorRO();
    }

    /** @see ListRO#listIteratorRO() */
    public ListIteratorRO listIteratorRO(int index) {
	return listRO.listIteratorRO(index);
    }
}
