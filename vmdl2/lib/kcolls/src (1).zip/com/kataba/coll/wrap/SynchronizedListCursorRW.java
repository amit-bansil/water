
package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Synchronizes all access to the wrapped ListCursorRW on the Object
 * returned by that ListCursorRW's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedListCursorRW
    extends SynchronizedListCursorRO
    implements ListCursorRW
{
    /** The object being wrapped. */
    private ListCursorRW listCursor;

    /** Constructs to synchronize access to the specified '_listCursor' */
    public SynchronizedListCursorRW(ListCursorRW _listCursor) {
	super(_listCursor);
	listCursor = _listCursor;
    }


    //
    // implements ListCursorRW
    //

    /** @see ListCursorRW#add(int,Object) */
    public void add(int offset, Object element) {
	synchronized(lock()) {
	    listCursor.add(offset, element);
	}
    }

    /** @see ListCursorRW#remove(int) */
    public void remove(int offset) {
	synchronized(lock()) {
	    listCursor.remove(offset);
	}
    }

    /** @see ListCursorRW#set(int,Object) */
    public void set(int offset, Object element) {
	synchronized(lock()) {
	    listCursor.set(offset, element);
	}
    }
}
