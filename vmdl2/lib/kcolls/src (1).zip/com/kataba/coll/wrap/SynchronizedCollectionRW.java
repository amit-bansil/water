
package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Synchronizes all access to the wrapped CollectionRW on the Object
 * returned by that CollectionRW's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedCollectionRW
    extends SynchronizedCollectionRO
    implements CollectionRW
{
    /** The collection being synchronized */
    private CollectionRW coll;

    /** Constructs to synchronize access to the specified '_coll' */
    public SynchronizedCollectionRW(CollectionRW _coll) {
	super(_coll);
	coll = _coll;
    }


    //
    // implements Collection
    //

    /** @see CollectionRW#add */
    public boolean add(Object element) {
        synchronized(lock()) {
            return coll.add(element);
        }
    }

    /** @see CollectionRW#addAll */
    public boolean addAll(CollectionRO collection) {
        synchronized(lock()) {
            return coll.addAll(collection);
        }
    }

    /** @see CollectionRW#addAll */
    public boolean addAll(java.util.Collection collection) {
        synchronized(lock()) {
            return coll.addAll(collection);
        }
    }

    /** @see CollectionRW#remove */
    public boolean remove(Object element) {
        synchronized(lock()) {
            return coll.remove(element);
        }
    }

    /** @see CollectionRW#removeAll */
    public boolean removeAll(CollectionRO collection) {
        synchronized(lock()) {
            return coll.removeAll(collection);
        }
    }

    /** @see CollectionRW#removeAll */
    public boolean removeAll(java.util.Collection collection) {
        synchronized(lock()) {
            return coll.removeAll(collection);
        }
    }

    /** @see CollectionRW#retainAll */
    public boolean retainAll(CollectionRO collection) {
        synchronized(lock()) {
            return coll.retainAll(collection);
        }
    }

    /** @see CollectionRW#retainAll */
    public boolean retainAll(java.util.Collection collection) {
        synchronized(lock()) {
            return coll.retainAll(collection);
        }
    }

    /** @see CollectionRW#clear() */
    public void clear() {
        synchronized(lock()) {
            coll.clear();
        }
    }

    /** @see CollectionRW#iterator() */
    public java.util.Iterator iterator() {
        return iteratorRW();
    }

    /** @see CollectionRW#iteratorRW() */
    public IteratorRW iteratorRW() {
        synchronized(lock()) {
            return new SynchronizedIteratorRW(coll.iteratorRW());
        }
    }
}
