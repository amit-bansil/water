
package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Wraps a java.util.Set so that it can be used as a SetRW.
 *
 * @author Chris Thiessen
 */
public class SetToSetRW
    extends CollectionToCollectionRW
    implements SetRW
{
    private java.util.Set set;

    /** Constructs to wrap the specified Set */
    public SetToSetRW(java.util.Set _set) {
        super(_set);
        set = _set;
        if(set == null)
            throw new NullPointerException("_set == null");
    }



    //
    // implements SetRO
    //

    /** @see SetRO#equals(Object) */
    public boolean equals(Object object) {
        SetRO set;
        if(object == null)
            return false;
        else if(object instanceof SetRO)
            set = (SetRO)object;
        else if(object instanceof java.util.Set)
            set = new SetToSetRW((java.util.Set)object);
        else
            return false;

        // if the 'set' contains all the elements of this 'set', return true
        if(set.size() != size())
            return false;
        return containsAll(set);
    }

    /** @see SetRO#union(SetRO) */
    public SetRO union(SetRO set) {
        HashSetRW result = new HashSetRW();
        result.addAll((SetRO)this);
        result.addAll(set);
        return result;
    }

    /** @see SetRO#intersection(SetRO) */
    public SetRO intersection(SetRO set) {
        HashSetRW result = new HashSetRW();
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(set.contains(element))
                result.add(element);
        }
        return result;
    }

    /** @see SetRO#xor(SetRO) */
    public SetRO xor(SetRO set) {
        HashSetRW result = new HashSetRW();

        // add the needed elements from 'this'
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(!set.contains(element))
                result.add(element);
        }

        // add the needed elements from 'set'
        for(IteratorRO itr=set.iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(!contains(element))
                result.add(element);
        }

        return result;
    }

    /** @see SetRO#hashCode() */
    public int hashCode() {
        int hashCode = 0;
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(element != null)
                hashCode += element.hashCode();
        }
        return hashCode;
    }
}
