//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Synchronizes all access to the wrapped CollectionRO on the Object
 * returned by that CollectionRO's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedCollectionRO
    implements CollectionRO
{
    private CollectionRO collRO;
    private CollectionROListener_NewSource listener_newSource;

    /** Constructs to synchronize access to the specified '_collRO' */
    public SynchronizedCollectionRO(CollectionRO _collRO) {
	collRO = _collRO;
    }


    //
    // implements Lockable
    //

    /** @see Lockable#lock */
    public Object lock() {
	return collRO.lock();
    }


    //
    // implements CollectionRO
    //

    /** @see CollectionRO#addListener */
    public void addListener(Listener listener
                            , Object sendback) {
        synchronized(lock()) {
            if(listener_newSource == null)
                listener_newSource = new CollectionROListener_NewSource(collRO, this);
            listener_newSource.addListener(listener, sendback);
        }
    }

    /** @see CollectionRO#removeListener */
    public void removeListener(Listener listener) {
        synchronized(lock()) {
            if(listener_newSource != null)
                listener_newSource.removeListener(listener);
        }
    }

    /** @see CollectionRO#size */
    public int size() {
        synchronized(lock()) {
            return collRO.size();
        }
    }

    /** @see CollectionRO#isEmpty */
    public boolean isEmpty() {
        synchronized(lock()) {
            return collRO.isEmpty();
        }
    }

    /** @see CollectionRO#contains */
    public boolean contains(Object element) {
        synchronized(lock()) {
            return collRO.contains(element);
        }
    }

    /** @see CollectionRO#containsAll(CollectionRO) */
    public boolean containsAll(CollectionRO collection) {
        synchronized(lock()) {
            return collRO.containsAll(collection);
        }
    }

    /** @see CollectionRO#containsAll(java.util.Collection) */
    public boolean containsAll(java.util.Collection collection) {
        synchronized(lock()) {
            return collRO.containsAll(collection);
        }
    }

    /** @see CollectionRO#get */
    public Object get(Object element) {
        synchronized(lock()) {
            return collRO.get(element);
        }
    }

    /** @see CollectionRO#iteratorRO */
    public IteratorRO iteratorRO() {
        synchronized(lock()) {
            return new SynchronizedIteratorRO(collRO.iteratorRO());
        }
    }

    /** @see CollectionRO#toArray() */
    public Object[] toArray() {
        synchronized(lock()) {
            return collRO.toArray();
        }
    }

    /** @see CollectionRO#toArray(Object[]) */
    public Object[] toArray(Object[] array) {
        synchronized(lock()) {
            return collRO.toArray(array);
        }
    }

    /** @see CollectionRO#equals(Object) */
    public boolean equals(Object object) {
        synchronized(lock()) {
            return collRO.equals(object);
        }
    }

    /** @see CollectionRO#hashCode() */
    public int hashCode() {
        synchronized(lock()) {
            return collRO.hashCode();
        }
    }
}
