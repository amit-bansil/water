
package com.kataba.coll.wrap;

import com.kataba.coll.*;
/** Synchronizes all access to the wrapped IteratorRW on the Object
 * returned by that IteratorRW's lock() method
 *
 * @author Chris Thiessen
 */
public class SynchronizedIteratorRW
    extends SynchronizedIteratorRO
    implements IteratorRW
{
    /** The iterator being synchronized */
    private IteratorRW itr;

    /** Constructs to synchronize access to the specified '_itr' */
    public SynchronizedIteratorRW(IteratorRW _itr) {
	super(_itr);
	itr = _itr;
    }

    /** @see IteratorRW#remove() */
    public void remove() {
	synchronized(itr.lock()) {
	    itr.remove();
	}
    }
}
