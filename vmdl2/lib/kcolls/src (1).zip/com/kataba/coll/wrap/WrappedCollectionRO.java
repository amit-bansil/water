//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a CollectionRO.  Calls to CollectionRO methods on instances
 * of this class are forwarded to the wrapped CollectionRO.  This
 * class can be used to restrict the interface of the wrapped
 * CollectionRO to just the CollectionRO interface.
 *
 * @author Chris Thiessen
 */
public class WrappedCollectionRO
    extends WrappedLockable
    implements CollectionRO
{
    protected CollectionRO collRO;
    private CollectionROListener_NewSource listener_newSource;

    /** Constructs */
    public WrappedCollectionRO(CollectionRO _collRO) {
	super(_collRO);
	collRO = _collRO;
    }

    //
    // implements CollectionRO
    //

    /** @see CollectionRO#addListener */
    public void addListener(Listener listener
                            , Object sendback) {
        if(listener_newSource == null)
            listener_newSource = new CollectionROListener_NewSource(collRO, this);
        listener_newSource.addListener(listener, sendback);
    }

    /** @see CollectionRO#removeListener */
    public void removeListener(Listener listener) {
        if(listener_newSource != null)
            listener_newSource.removeListener(listener);
    }

    /** @see CollectionRO#size */
    public int size() {
	return collRO.size();
    }

    /** @see CollectionRO#isEmpty */
    public boolean isEmpty() {
	return collRO.isEmpty();
    }

    /** @see CollectionRO#contains */
    public boolean contains(Object element) {
	return collRO.contains(element);
    }

    /** @see CollectionRO#containsAll(CollectionRO) */
    public boolean containsAll(CollectionRO collection) {
	return collRO.containsAll(collection);
    }

    /** @see CollectionRO#containsAll(java.util.Collection) */
    public boolean containsAll(java.util.Collection collection) {
	return collRO.containsAll(collection);
    }

    /** @see CollectionRO#get */
    public Object get(Object element) {
	return collRO.get(element);
    }

    /** @see CollectionRO#iteratorRO */
    public IteratorRO iteratorRO() {
	return collRO.iteratorRO();
    }

    /** @see CollectionRO#toArray() */
    public Object[] toArray() {
	return collRO.toArray();
    }

    /** @see CollectionRO#toArray(Object[]) */
    public Object[] toArray(Object[] array) {
	return collRO.toArray(array);
    }

    /** @see CollectionRO#equals(Object) */
    public boolean equals(Object object) {
        return collRO.equals(object);
    }

    /** @see CollectionRO#hashCode() */
    public int hashCode() {
        return collRO.hashCode();
    }
}
