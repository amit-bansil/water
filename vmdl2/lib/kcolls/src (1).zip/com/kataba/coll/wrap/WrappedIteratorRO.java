//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll.wrap;

import com.kataba.coll.*;
import com.kataba.util.*;

/** Wraps a IteratorRO.  Calls to IteratorRO methods on instances of
 * this class are forwarded to the wrapped IteratorRO.  This class can
 * be used to restrict the interface of the wrapped IteratorRO to just
 * the IteratorRO interface.
 *
 * @author Chris Thiessen
 */
public class WrappedIteratorRO
    extends WrappedLockable
    implements IteratorRO
{
    protected IteratorRO itrRO;

    /** Constructs to wrap the specified IteratorRO */
    public WrappedIteratorRO(IteratorRO _itrRO) {
	super(_itrRO);
	itrRO = _itrRO;
    }


    //
    // implements IteratorRO
    //

    /** @see IteratorRO#hasNext */
    public boolean hasNext() {
	return itrRO.hasNext();
    }

    /** @see IteratorRO#next */
    public Object next() {
	return itrRO.next();
    }
}
