
package com.kataba.coll;

import com.kataba.util.*;

import java.util.NoSuchElementException;

/** An IteratorRO with no elements to retrieve */
public class EmptyIteratorRO
    extends AbstractLockable
    implements IteratorRO
{
    /** EmptyIteratorRO has no state, so just use this 'INSTANCE' */
    public static final EmptyIteratorRO INSTANCE = new EmptyIteratorRO();

    /** @see IteratorRO#hasNext */
    public boolean hasNext() {
	return false;
    }

    /** @see IteratorRO#next */
    public Object next() {
	throw new NoSuchElementException();
    }
}
