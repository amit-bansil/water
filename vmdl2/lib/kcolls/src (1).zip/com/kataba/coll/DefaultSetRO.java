
package com.kataba.coll;

import com.kataba.coll.wrap.*;

/** The default implementation of <code>SetRO</code>.  Uses an
 * array for multiple elements, and a single element otherwise.
 *
 * @author Chris Thiessen
 */
public class DefaultSetRO
    extends WrappedSetRO
{
    public static final DefaultSetRO empty = new DefaultSetRO(new Object[0]);

    /** Constructs to be based on the specified array. */
    public DefaultSetRO(Object[] elements) {
	super(new HashSetRW());

	SetRW set = (SetRW)collRO;
	for(int i=0; i<elements.length; i++)
	    set.add(elements[i]);
    }

    /** Constructs to be based on the specified element. */
    public DefaultSetRO(Object element) {
	super(new HashSetRW());

	((SetRW)collRO).add(element);
    }

    /** Constructs to contain the elements in the specified collection. */
    public DefaultSetRO(CollectionRO coll) {
	super(new HashSetRW());

	((SetRW)collRO).addAll(coll);
    }
}
