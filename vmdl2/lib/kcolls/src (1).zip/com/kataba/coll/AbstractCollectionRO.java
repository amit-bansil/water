
package com.kataba.coll;

import com.kataba.util.*;

import java.util.*;

/** This class provides a skeletal implementation of the ListRO
 * interface to minimize the effort required to implement this
 * interface backed by a "random access" data store.
 *
 * <p>Concrete subclasses of this class must define the following methods:
 * <ul>
 *   <li><code>size()</code>
 *   <li><code>iteratorRO()</code>
 * </ul>
 *
 * @author Chris Thiessen
 */
public abstract class AbstractCollectionRO
    extends AbstractLockable
    implements CollectionRO
{
    public static final Identifier DEFAULT_IDENTIFIER
        = DefaultIdentifier.INSTANCE;

    protected Identifier identifier = DEFAULT_IDENTIFIER;

    /** Default constructor */
    protected AbstractCollectionRO() {
    }

    /** Constructs to use the specified Identifier to determine if
     * elements are equal */
    protected AbstractCollectionRO(Identifier _identifier) {
        identifier = _identifier;
    }

    /** @see Object#toString */
    public String toString() {
        StringBuffer buf = new StringBuffer("{");
        int i=0;
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            if(i++ != 0)
                buf.append(",");
            buf.append(itr.next());
        }
        buf.append("}");
        return buf.toString();
    }

    //
    // implements CollectionRO
    //

    /** @see CollectionRO#addListener */
    public void addListener(CollectionRO.Listener listener, Object sendback) {
        // do nothing
    }

    /** @see CollectionRO#removeListener */
    public void removeListener(CollectionRO.Listener listener) {
        // do nothing
    }

    /** @see CollectionRO#isEmpty */
    public boolean isEmpty() {
        return size() == 0;
    }

    /** @see CollectionRO#contains */
    public boolean contains(Object element) {
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); )
            if(identifier.equals(itr.next(), element))
                return true;
        return false;
    }

    /** @see CollectionRO#containsAll(CollectionRO) */
    public boolean containsAll(CollectionRO collection) {
        for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); )
            if(!contains(itr.next()))
                return false;
        return true;
    }

    /** @see CollectionRO#containsAll(java.util.Collection) */
    public boolean containsAll(java.util.Collection coll) {
        for(java.util.Iterator itr=coll.iterator(); itr.hasNext(); ) {
            if(!contains(itr.next()))
                return false;
        }
        return true;
    }

    /** @see CollectionRO#get */
    public Object get(Object object) {
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object element = itr.next();
            if(identifier.equals(object, element))
                return element;
        }
        throw new NoSuchElementException("No such element: " + object);
    }

    /** @see CollectionRO#toArray */
    public Object[] toArray() {
        return toArray(new Object[size()]);
    }

    /** @see CollectionRO#toArray */
    public Object[] toArray(Object[] array) {
        if(array.length < size())
            array = (Object[])java.lang.reflect.Array
                .newInstance(array.getClass().getComponentType(), size());

        int count = 0;
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); )
            array[count++] = itr.next();
        return array;
    }


    /** Returns 'true' if 'object' is a CollectionRO and contains the
     * same objects in the same order as this Collection.
     *
     * @see CollectionRO#equals(Object)
     */
    public boolean equals(Object object) {
        if(object == null || !(object instanceof CollectionRO))
            return false;
        CollectionRO coll = (CollectionRO)object;
        if(coll.size() != size())
            return false;
        for(IteratorRO itr=iteratorRO(), itr2=coll.iteratorRO(); itr.hasNext(); )
            if(!Util.equals(itr.next(), itr2.next()))
                return false;
        return true;
    }

    /** @see CollectionRO#hashCode() */
    public int hashCode() {
        int hashCode = 1;
        for(IteratorRO itr=iteratorRO(); itr.hasNext(); ) {
            Object obj = itr.next();
            hashCode = 31*hashCode + (obj==null ? 0 : obj.hashCode());
        }
        return hashCode;
    }


    // abstract

    /** @see CollectionRO#size */
    public abstract int size();

    /** @see CollectionRO#iteratorRO */
    public abstract IteratorRO iteratorRO();
}

