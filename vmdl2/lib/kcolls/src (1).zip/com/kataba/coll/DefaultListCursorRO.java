//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import com.kataba.util.*;

import java.util.*;

/** Default implementation of ListCursorRO for ListRO's where the
 * contents can be efficiently accessed by element-index-oriented
 * operations.
 *
 * @author Chris Thiessen
 */
public class DefaultListCursorRO
    implements ListCursorRO
{
    /** The ListRO */
    protected ListRO listRO;
    /** The current index */
    protected int index;

    /** Constructs a cursor positioned at the specified '_index' in
     * the specified '_listRO' */
    public DefaultListCursorRO(ListRO _listRO, int _index) {
	listRO = _listRO;
	index = _index;
        if(index < 0 || index > listRO.size())
            throw new IllegalArgumentException
                ("index:"+index+" _listRO.size():"+listRO.size());
    }


    //
    // implements Lockable
    //

    /** @see Lockable#lock() */
    public Object lock() {
	return listRO.lock();
    }


    //
    // implements ListCursorRO
    //

    /** @see ListCursorRO#size */
    public int size() {
	return listRO.size();
    }

    /** @see ListCursorRO#index */
    public int index() {
	return index;
    }

    /** @see ListCursorRO#setIndex(int) */
    public void setIndex(int _index) {
        if(_index < 0 || _index > size())
            throw new IndexOutOfBoundsException("index:"+_index+", size:"+size());
        index = _index;
    }

    /** @see ListCursorRO#canGet(int) */
    public boolean canGet(int offset) {
	int getIndex = index + offset;
	return getIndex >= 0 && getIndex < listRO.size();
    }

    /** @see ListCursorRO#get(int) */
    public Object get(int offset) {
	if(!canGet(offset))
	    throw new IndexOutOfBoundsException();
	else
	    return listRO.get(index + offset);
    }

    /** @see ListCursorRO#canMove(int) */
    public boolean canMove(int offset) {
	int moveIndex = index + offset;
	return (moveIndex >= 0 && moveIndex <= listRO.size());
    }

    /** @see ListCursorRO#move(int) */
    public void move(int offset) {
	if(canMove(offset))
	    index = index + offset;
	else
	    throw new IndexOutOfBoundsException();
    }

    /** @see ListCursorRO#moveCrop(int) */
    public void moveCrop(int offset) {
        if(index + offset < 0)
            index = 0;
        else if(index + offset > listRO.size())
            index = listRO.size();
        else
            index += offset;
    }
}
