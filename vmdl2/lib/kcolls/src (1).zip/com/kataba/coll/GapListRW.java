
package com.kataba.coll;

import com.kataba.util.*;

/** This is a subclass of GapArray which stores elements of type Object
 *
 * @author Chris Thiessen
 */
public class GapListRW
    extends AbstractListRW
{

    //private GapListBuffer buffer;

    /** Constructs */
    public GapListRW() {
        initBuffer();
        //buffer = new GapListBuffer();
    }

    /** Constructs so that the GapListRW will only accept elements
     * which match the specified 'elementFilter' */ 
    public GapListRW(Filter elementFilter) {
        setPreListener(new FilterListPreListener(elementFilter));
    }

    /** Constructs with the elements of the specified CollectionRO as
     * its initial contents. */
    public GapListRW(CollectionRO collection) {
       this(collection.size());
       addAll(collection);
    }

    /** Constructs with the elements from the specified IteratorRO as
     * its initial contents. */
    public GapListRW(IteratorRO itr) {
	initBuffer();
	//buffer = new GapListBuffer();
	while(itr.hasNext()) {
	    add(itr.next());
	}
    }

    /** Constructs with the specified initial capacity */ 
    public GapListRW(int initialCapacity) {
        initBuffer(initialCapacity);
        //buffer = new GapListBuffer(initialCapacity);
    }


    //
    // implements CollectionRO
    //

    /** Returns the number of elements in this collection. */
    public int size() {
        return buf_size();
    }

    /** Returns the elements of the collection in an array */
    public Object[] toArray() {
        Object[] array = new Object[size()];
        buf_copyTo(array);
        return array;
    }


    //
    // implements Collection
    //

    /** Removes all elements from this collection.
     *
     * @return <code>true</code> if the collection changed as a result
     *         of the operation
     */
    public void clear() {
        if(size() == 0)
            return;

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.REMOVE_RANGE, 0, size(), null, null);

        // if there are interested event listeners, make a copy of
        // this list's elements
        ListRO removed = null;
	if(postEventEnabled(ListRO.Listener.REMOVE_RANGE))
            removed = new DefaultListRO((CollectionRO)this);

        // clear the list
        buf_remove(0, size());

	// fire the post event
	if(removed != null)
	    postEvent(ListRO.Listener.REMOVE_RANGE, 0, removed.size(), null, removed);
    }


    //
    // implements ListRO
    //

    /** Returns the element at the specified index */
    public Object get(int index) {
	if(index < 0 || index >= size())
	    throw new IndexOutOfBoundsException("index:"+index+", size:"+size());
        return buf_get(index);
    }


    //
    // implements List
    //

    /** Inserts an element index the collection at the specified index. */
    public void add(int index, Object element) {
	if(index < 0 || index > size())
	    throw new IndexOutOfBoundsException("index:"+index+", size:"+size());

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.ADD, index, -1, null, single(element));

        buf_add(index, 1, true);
        buf_set(index, element);
        modCount++;

        // fire the events
	if(postEventEnabled(ListRO.Listener.ADD))
            postEvent(ListRO.Listener.ADD, index, index+1, null, null);
    }

    /** @see ListRW#remove(int) */
    public Object remove(int index) {
	if(index < 0 || index >= size())
	    throw new IndexOutOfBoundsException("index:"+index+", size:"+size());

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.REMOVE_RANGE, index, index+1, null, null);

        Object element = buf_get(index);
        buf_remove(index, 1);
        modCount++;

        // fire the event
	if(postEventEnabled(ListRO.Listener.REMOVE_RANGE))
            postEvent(ListRO.Listener.REMOVE_RANGE, index, index+1, null, single(element));

        return element;
    }

    /** @see ListRW#removeRange(int,int) */
    public void removeRange(int start, int end) {
	if(start < 0)
            throw new IndexOutOfBoundsException("start:"+start+" < 0");
        if(start > end)
            throw new IllegalArgumentException
                ("start:"+start+" > end:"+end);
	if(end > size())
	    throw new IllegalArgumentException
		("end:"+end+" > size:"+size());

        if(end - start == 0)
            return;

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.REMOVE_RANGE, start, end, null, null);

        // prepare to fire the change event
        ListRO oldElements = null;
        boolean postEventEnabled = postEventEnabled(ListRO.Listener.REMOVE_RANGE);
        if(postEventEnabled)
            oldElements = new DefaultListRO(toArray(start, end));

        // remove the range of elements
        buf_remove(start, end-start);
        modCount++;

        // fire the post event
        if(postEventEnabled)
            postEvent(ListRO.Listener.REMOVE_RANGE, start, end, null, oldElements);
    }

    /** Replaces the element at the specified index.
     *
     * @return the element originally at that index
     */
    public Object set(int index, Object element) {
	if(index < 0 || index >= size())
	    throw new IndexOutOfBoundsException("index:"+index+", size:"+size());

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.REPLACE_RANGE, index, index+1, null, single(element));

	Object oldElement = buf_get(index);
	buf_set(index, element);
	modCount++;

	// fire the post event
	if(postEventEnabled(ListRO.Listener.REPLACE_RANGE))
	    postEvent(ListRO.Listener.REPLACE_RANGE, index, index+1
		      , null, single(oldElement));

	return oldElement;
    }




    //
    // copied from GapListBuffer
    //

    /** The default capacity of a GapArray */
    public static final int DEFAULT_CAPACITY = 16;
    private static final int MIN_ARRAYCOPY = 20;

    /** The array buffer that is being manipulated */
    private Object[] buffer;
    /** The current size of the buffer */
    private int bufferSize;
    /** The number of elements stored to the left of the gap */
    private int left;
    /** The number of elements stored to the right of the gap */
    private int right;

    /** Initializes the buffer */
    private void initBuffer() {
        initBuffer(DEFAULT_CAPACITY);
    }

    private void initBuffer(int initialCapacity) {
        if(initialCapacity < 0)
            throw new IllegalArgumentException("Illegal Capacity: "
                                               + initialCapacity);
        buffer = new Object[initialCapacity];
        bufferSize = initialCapacity;
        left = 0;
        right = 0;
    }

    /** Resets the specified range of buffer elements.
     *
     * @param fromIndex the start of the range to be reset
     * @param toIndex the limit of the range to be reset (the
     *                element at this index should not be reset)
     */
    private void buf_resetElements(int fromIndex, int toIndex) {
        for(int i=fromIndex; i<toIndex; i++)
            buffer[i] = null;
    }

    /** Maps an index into the gap array to an index into the buffer.
     *
     * @param index the index into the GapArray
     * @returns the corresponding index into the buffer */
    private final int buf_bufferIndexOf(int index) {
        if(index < left)
            return index;
        else
            return bufferSize - right + (index - left);
    }

    private void buf_set(int index, Object element) {
        buffer[buf_bufferIndexOf(index)] = element;
    }

    private Object buf_get(int index) {
        return buffer[buf_bufferIndexOf(index)];
    }

    /** Returns the number of elements stored in the Array.
     *
     * @returns the number of elements stored in the Array */
    private int buf_size() {
        return left + right;
    }

    /** Internal function that checks whether */
    private final boolean buf_isSane() {
        if((left + right <= bufferSize)
           && (left >= 0)
           && (right >= 0)
           && (bufferSize >= 0)
           && (buffer != null))
            return true;
        else
            return false;
    }

    /** Returns the number of additional elements that can be stored
     * in the Array without further allocation.
     *
     * @return the number of elemetns that can be stored in the Array
     *         without further allocation. */
    private int buf_capacity() {
        return bufferSize - left - right;
    }

    /** Makes space for elements to be inserted at the specified index.
     *
     * @param index  the index at which to insert the space
     * @param space  the amount of space to create
     * @param onLeft whether or not the space should be made on the left */
    private final void buf_add(int index, int space, boolean onLeft) {

        // shift the gap
        buf_shiftGap(index);
        buf_ensureCapacity(space);
        if(onLeft)
            left += space;
        else
            right += space;
    }

    /** Shift the gap in the buffer to be before the specified index.
     *
     * @param index the index the gap should be shifted to */
    private final void buf_shiftGap(int index) {
        // figure out how much and which direction to shift
        int shiftVector = left - index;

        /*
	Out.ln("GapList.buf_shiftGap: " + index);
	Out.ln("  index: " + index);
	Out.ln("  left: " + left);
	Out.ln("  right: " + right);
	Out.ln("  shiftVector: " + shiftVector);
	Out.ln("  buffer.length: " + buffer.length);
	Out.ln("  bufferSize: " + bufferSize);
	Out.ln("  pre-shift: " + this);
	Out.ln("  buffer: " + Util.toString(buffer));
	//*/

        // do the shift
        if(shiftVector == 0)
            return;
        else if(shiftVector > 0) {
            int shiftSize = shiftVector;
            buf_arraycopy(buffer, left - shiftSize
                          , buffer, bufferSize - right - shiftSize
                          , shiftSize);
	    //Out.ln("  buffer: " + Util.toString(buffer));
            buf_resetElements(left - shiftSize
                              , Math.min(bufferSize - right - shiftSize, left));
	    //Out.ln("  buffer: " + Util.toString(buffer));
        } else {
            int shiftSize = -shiftVector;
            buf_arraycopy(buffer, bufferSize - right
                          , buffer, left
                          , shiftSize);
            buf_resetElements(Math.max(left + shiftSize, bufferSize - right)
                              , bufferSize - right + shiftSize);
        }
        left -= shiftVector;
        right += shiftVector;

	//Out.ln("  post-shift: " + this);
    }

    /** Ensures that <code>capacity</code> elements can be added
     * without further allocation.
     *
     * @param capacity how many elements should be storable without
     *                 further allocation */
    private void buf_ensureCapacity(int capacity) {
        // if we've not enough capacity
        if(bufferSize - left - right < capacity) {
            int newBufferSize = Math.max(bufferSize * 2 + 1
                                         , capacity + left + right);
            Object[] newBuffer = new Object[newBufferSize];

            // copy the elements from the old buffer to the new
            if(left > 0)
                buf_arraycopy(buffer, 0, newBuffer, 0, left);
            if(right > 0)
                buf_arraycopy(buffer, bufferSize-right
                              , newBuffer, newBufferSize-right
                              , right);

            // make the old new
            buffer = newBuffer;
            bufferSize = newBufferSize;
        }
    }

    /** Removes a range of elements from the buffer.
     *
     * @param index the beginning of the range to remove
     * @param numElements the number of elements to remove */
    private final void buf_remove(int index, int numElements) {
        // remove the elements
        buf_shiftGap(index);

        // reset the erased element
        buf_resetElements(bufferSize-right, bufferSize-right+numElements);

        // shrink the right side
        right -= numElements;
    }

    /** Copy the elements in this collection into the specified array */
    private final void buf_copyTo(Object array) {
        System.arraycopy(buffer, 0, array, 0, left);
        System.arraycopy(buffer, bufferSize-right, array, left, right);
    }

    private final void buf_arraycopy(Object[] source, int sourceIndex
                                     , Object[] dest, int destIndex
                                     , int length) {
        if(length < MIN_ARRAYCOPY) {
            if(sourceIndex > destIndex)
                for(int i=0; i<length; i++)
                    dest[i + destIndex] = source[i + sourceIndex];
            else
                for(int i=length-1; i>=0; i--)
                    dest[i + destIndex] = source[i + sourceIndex];
        } else
            System.arraycopy(source, sourceIndex, dest, destIndex, length);
    }
}
