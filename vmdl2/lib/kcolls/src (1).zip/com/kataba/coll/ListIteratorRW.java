
package com.kataba.coll;

import com.kataba.util.*;

/** A read-only ListIterator over the elements of some collection of
 * elements of type <code>Object</code>.  Clients should synchronize
 * on 'lock()' if they wish to thread-safe their access to this
 * ListIteratorRO.
 *
 * @author Chris Thiessen
 */
public interface ListIteratorRW
    extends ListIteratorRO, IteratorRW, java.util.ListIterator
{

    //
    // implements the content-modification portion of java.util.ListIterator
    //

    /** @see java.util.ListIterator#add(Object) */
    public void add(Object object);

    /** @see java.util.ListIterator#set(Object) */
    public void set(Object object);
}
