
package com.kataba.coll;

import com.kataba.util.*;

import java.util.NoSuchElementException;
import java.io.*;

/** A SetRW which doesn't use objects for entries.  Instead, it hashes
 * into array indices that serve the same purposes.  This gives better
 * performance with large sets of objects.  Also, instead of creating
 * an object for every entry in the set, only 2 objects are created
 * for <b>any</b> set size.
 *
 * @author Chris Thiessen
 */
public class ArrayHashSetRW
    extends AbstractSetRW
    implements SetRW
{
    public static final float DEFAULT_LOAD_FACTOR = 0.75f;
    public static final int DEFAULT_INITIAL_CAPACITY = 16;
    public static final Object DELETED = new Object();

    /** The number of entries.  Entries are indexes into and are
     * represented by the 'nexts', and 'hashCodes' subarrays.  They
     * represent are linked-list nodes for chains on hash
     * 'buckets'. */
    protected int numEntries;

    /** Contains as ranges all necessary 'int[]'s.  This is to reduce
     * the number of objects created, which in some cases can be
     * very important. */
    protected int[] intArray;
    /** The index into 'intArray' of the embedded 'buckets' array.
     * Each bucket is an index into an entry chain.  Elements are
     * hashed into a bucket and added to its entry chain.  Buckets
     * without existing chains contain the value '-1'. */
    protected int buckets;
    /** The size of the 'buckets' subarray */
    protected int numBuckets;
    /** The index into 'intArray' of the embedded 'nexts' array.
     * 'next[entry]' is the index of the next entry in the 'entry's
     * chain. */
    protected int nexts;
    /** The index into 'intArray' of the embedded 'hashCodes'
     * array.  'hashcodes[entry]' is the hash-code of that entry's
     * element. */
    protected int hashCodes;

    /* Contains as ranges all necessary 'Object[]'s.  This is to
     * reduce the number of objects created, which in some cases can
     * be very important. */
    protected Object[] objectArray;
    /** Just like a bucket, but its chain contains all the unused entries */
    protected int freeBucket;
    /** Has values */
    protected boolean hasValues = false;

    /** The number of elements in the HashSet */
    protected int size;
    /** The ratio of buckets to elements.  Defaults to
     * '_Default_Load_Factor' */
    protected float loadFactor;

    /** Constructs with a default element identifier, load factor, and
     * initial capacity. */
    public ArrayHashSetRW() {
	this(DEFAULT_IDENTIFIER, DEFAULT_LOAD_FACTOR
	     , DEFAULT_INITIAL_CAPACITY);
    }

    /** Constructs with the specified element identifier, load factor, and
     * initial capacity. */
    public ArrayHashSetRW(Identifier _identifier, float _loadFactor
		       , int initialCapacity) {
	super(_identifier);

	if(initialCapacity < 1)
	    throw new IllegalArgumentException("Initial capacity cannot "
					       + "be less than 1");
	if(_loadFactor <= 0.0 || _loadFactor > 1.0)
	    throw new IllegalArgumentException("Illegal load factor ("
					       + _loadFactor
					       + "): must be greater than 0"
					       + " and not greater than 1");
	if(_identifier == null)
	    throw new NullPointerException();

	loadFactor = _loadFactor;

	createBuckets(initialCapacity);

	//Out.ln("numBuckets: " + numBuckets);
    }


    //
    // array element setting/getting methods
    //

    private int bucket(int index) {
        return intArray[buckets+index];
    }
    private void bucket(int index, int value) {
        intArray[buckets+index] = value;
    }
    private int next(int index) {
        return intArray[nexts+index];
    }
    private void next(int index, int value) {
        intArray[nexts+index] = value;
    }
    private int hashCode(int index) {
        return intArray[hashCodes+index];
    }
    private void hashCode(int index, int value) {
        intArray[hashCodes+index] = value;
    }
    private Object element(int index) {
        return objectArray[index];
    }
    private void element(int index, Object element) {
        objectArray[index] = element;
    }
    private Object value(int index) {
        if(!hasValues)
            return null;
        return objectArray[numEntries+index];
    }
    private void value(int index, Object element) {
        if(hasValues)
            objectArray[numEntries+index] = element;
    }

    /** Prints debugging information about the internals of the set */
    public void printEntries(PrintStream ps) {
	ps.println("# of buckets: " + numBuckets);
	ps.println("# of entries: " + numEntries);
	ps.println("freeBucket: " + freeBucket);
	for(int i=0; i<numEntries; i++) {
	    ps.println("[" + i + "]");
	    ps.println("  next: " + next(i));
	    ps.println("  element: " + element(i));
	    ps.println("  hashCode: " + hashCode(i));
	}
    }

    /** Initializes the 'intArray' array. */
    protected void initIntArray(int capacity) {
	numBuckets = (int)(numEntries / loadFactor);
	numBuckets = (numBuckets==0)?1:numBuckets;
	buckets = 0;
	nexts = buckets + numBuckets;
	hashCodes = nexts + numEntries;
        intArray = new int[numBuckets + 2*numEntries];
    }

    /** Initializes the 'objectArray' array. */
    protected void initObjectArray(int capacity) {
        objectArray = new Object[hasValues ? numEntries*2 : numEntries];
    }

    /** Creates the arrays necessary for the specified number of buckets */
    protected void createBuckets(int capacity) {
        //Out.ln("createBuckets("+capacity+")");

        numEntries = capacity;
        initIntArray(capacity);
        initObjectArray(capacity);

	// initialize 'buckets'
	for(int i=0; i<numBuckets; i++)
	    bucket(i, -1);

	// initialize 'nexts'
	for(int i=0; i<numEntries; i++)
	    next(i, i-1);

	// initialize size
	freeBucket = numEntries - 1;
	size = 0;
    }

    /** Grows the set of buckets */
    protected void growBuckets() {
	int oldNumBuckets = numBuckets;
	int oldNumEntries = numEntries;
	int[] oldIntArray = intArray;
	Object[] oldObjectArray = objectArray;
	int oldBuckets = buckets;
	int oldNexts = nexts;
	int oldHashCodes = hashCodes;

	// recreate the buckets with double+1 capacity
	createBuckets(numEntries * 2 + 1);

	// for each old bucket
	for(int i=0; i<oldNumBuckets; i++) {
	    // rehash the entries on the 'oldBuckets[i]' chain
	    for(int oldEntry=oldIntArray[oldBuckets+i]
		    ; oldEntry!=-1
		    ; oldEntry=oldIntArray[oldNexts+oldEntry]) {
		int hashCode = oldIntArray[oldHashCodes+oldEntry];
		i_add(oldObjectArray[oldEntry]
                      , hasValues ? oldObjectArray[oldEntry+oldNumEntries] : null
		      , hashCode, (hashCode & 0x7FFFFFFF) % numBuckets);
	    }
	}
    }

    /** For internal use only; this method does not check that the
     * 'element' is unique.  Adds a unique 'element', with a
     * precalculated 'hashCode', to the appropriate bucket chain.
     *
     * @return the new entry
     */
    protected int i_add(Object element, Object value, int hashCode, int bucket) {
	// grow the buckets if necessary
	if(size >= numEntries) {
	    growBuckets();
	    // use the 'hashCode' to decide which 'bucket' to put the
	    // 'element' in
	    bucket = (hashCode & 0x7FFFFFFF) % numBuckets;
	    //bucket = ((hashCode<0?-hashCode:hashCode) & 0x7FFFFFFF) % numBuckets;
	}

	// the 'entry' at which the element will be stored
	int entry = freeBucket;
	freeBucket = next(freeBucket);

	// add the element onto the front of the 'bucket's chain
	next(entry, bucket(bucket));
	bucket(bucket, entry);
	hashCode(entry, hashCode);
	element(entry, element);
        value(entry, value);

	// increment size
	size++;

	return entry;
    }

    /** Frees the specified 'entry' in the specified 'bucket', with
     * the specified previous entry in its chain, 'prevEntry' */
    protected void freeEntry(int bucket, int entry, int prevEntry) {
	// remove the entry from the bucket chain
	if(prevEntry == -1)
	    bucket(bucket, next(entry));
	else
	    next(prevEntry, next(entry));

	// clear the entry and put it back in the free chain
	element(entry, null);
        value(entry, null);
	next(entry, freeBucket);
	freeBucket = entry;

	// decrement 'size'
	size--;
    }


    /** Returns the entry containing the specified element, or -1 if
     * there is no matching entry. */
    protected int findEntry(Object element) {
	int hashCode = identifier.hashCode(element);
	int bucket = (hashCode & 0x7FFFFFFF) % numBuckets;
	return findEntry(element, hashCode, bucket);
    }

    /** Returns the entry containing the specified element, or -1 if
     * there is no matching entry.  Pass identifier.hashCode(element)
     * into 'hashCode'.  Use 0 in 'hashCode' to indicate it's unknown */
    protected int findEntry(Object element, int hashCode, int bucket) {
	// the bucket whose chain the entry must be in
	//int bucket = (hashCode & 0x7FFFFFFF) % numBuckets;

	// iterate through the 'bucket's chain
	for(int entry=bucket(bucket)
		; entry!=-1
		; entry=next(entry)) {
	    // if the current 'entry' is a match
	    if(hashCode(entry) == hashCode
	       && identifier.equals(element(entry), element))
		return entry;
	}

	// none found
	return -1;
    }


    //
    // CollectionRO
    //

    /** @see CollectionRO#size */
    public int size() {
	return size;
    }

    /** @see CollectionRO#contains */
    public boolean contains(Object element) {
	return findEntry(element) != -1;
    }

    /** @see CollectionRO#get(Object) */
    public Object get(Object element) {
	int entry = findEntry(element);
	if(entry == -1)
            throw new NoSuchElementException("No such element: " + element);
	return element(entry);
    }

    /** @see CollectionRO#iteratorRO */
    public IteratorRO iteratorRO() {
	return iteratorRW();
    }

    /** Returns the objectArray of the collection in an array. */
    public Object[] toArray() {
	Object[] array = new Object[size];
	int num = 0;
	for(int i=0; i<numBuckets; i++) {
	    int entry = bucket(i);
	    while(entry != -1) {
		array[num++] = element(entry);
		entry = next(entry);
	    }
	}
	return array;
    }


    //
    // implements Collection
    //

    /** @see CollectionRW#add */
    public boolean add(Object element) {
	int hashCode = identifier.hashCode(element);
	//int hashCode = identifier.hashCode(element);
	//int bucket = ((hashCode<0?-hashCode:hashCode) & 0x7FFFFFFF) % numBuckets;
	int bucket = (hashCode & 0x7FFFFFFF) % numBuckets;

	// if there's an existing entry, return
	if(findEntry(element, hashCode, bucket) != -1)
	    return false;

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.ADD, new DefaultListRO(element), null);

	// make a new new entry
	i_add(element, null, hashCode, bucket);

	// fire necessary events
	if(postEventsEnabled())
	    postEvent(Listener.ADD
				, new DefaultListRO(element), null);

	return true;
    }

    /** @see CollectionRW#remove */
    public boolean remove(Object element) {
	int hashCode = identifier.hashCode(element);
	int bucket = (hashCode & 0x7FFFFFFF) % numBuckets;

	// iterate through the bucket chain
	int previous = -1;
	for(int entry=bucket(bucket)
		; entry!=-1
		; entry=next(entry)) {
	    // if the entry matches
	    if(hashCode(entry) == hashCode
	       && identifier.equals(element(entry), element)) {

                // fire the pre event
                if(preEventEnabled())
                    preEvent(PreListener.REMOVE, new DefaultListRO(element), null);

		// free the entry
		freeEntry(bucket, entry, previous);

		// fire the REMOVE event
		if(postEventsEnabled())
		    postEvent(Listener.REMOVE
					, new DefaultListRO(element), null);

		return true;
	    }
	    // reset 'previous', the previous entry in the chain
	    previous = entry;
	}

	return false;
    }

    /** @see CollectionRW#clear */
    public void clear() {
	// if already empty
	if(size == 0)
	    return;

	// if there are listeners, make a copy of this Set for the event
	boolean hasListeners = postEventsEnabled();
	ListRO setCopy = null;
	if(hasListeners)
	    setCopy = new DefaultListRO(toArray());

	// fire the pre event
	if(preEventEnabled())
	    preEvent(PreListener.REMOVE, setCopy, null);

	// reset the size and clear the buckets
	size = 0;
	for(int i=0; i<numBuckets; i++)
	    bucket(i, -1);

	// clear the entries
	freeBucket = numEntries-1;
	for(int i=0; i<numEntries; i++) {
	    next(i, i-1);
	    element(i, null);
            value(i, null);
	}

	// fire the event
	if(hasListeners)
	    postEvent(Listener.REMOVE, setCopy, null);
    }

    /** @see CollectionRW#iterator */
    public IteratorRW iteratorRW() {
	return new Itr();
    }

    class Itr implements IteratorRW {
	int bucket = -1;
	int entry = -1;
	int previous = -1;
	int numVisited = 0;
	boolean isRemoved = false;

	//
	// implements Lockable
	//

	/** Returns an object you can synchronize on to atomicize multiple
	 * operations on this collection. */
	public Object lock() {
	    return ArrayHashSetRW.this.lock();
	}


	//
	// implements IteratorRO
	//

        /** @see IteratorRO#hasNext() */
	public boolean hasNext() {
	    return numVisited < size;
	}

        /** @see IteratorRO#next() */
	public Object next() {
	    if(numVisited >= size)
		throw new NoSuchElementException();

	    if(entry != -1) {
		previous = entry;
		entry = ArrayHashSetRW.this.next(entry);
	    }
	    if(entry == -1) {
		previous = -1;
		for(bucket=bucket+1; bucket<numBuckets; bucket++) {
		    entry = bucket(bucket);
		    if(entry != -1)
			break;
		}
	    }

	    numVisited++;
            isRemoved = false;
	    return element(entry);
	}


	//
	// implements IteratorRW
	//

        /** @see IteratorRW#next() */
	public void remove() {
	    if(isRemoved || bucket == -1)
                throw new IllegalStateException
                    ("Neither next nor previous have been called,"
                     +" or remove or add have been called since the"
                     +" last call to next or previous.");

            freeEntry(bucket, entry, previous);
	    if(previous != -1) {
		entry = previous;
	    } else {
		entry = -1;
		previous = -1;
		bucket--;
	    }
	    numVisited--;
	    isRemoved = true;
	}
    }
}
