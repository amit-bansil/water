
package com.kataba.coll;

import com.kataba.coll.wrap.*;
import com.kataba.util.*;

/** Utility methods for Kataba Collections.  Roughly equivalent to java.util.Collections.
 *
 * @see java.util.Collections
 * @author Chris Thiessen
 */
public class CollectionsRW {
    /** Sorts the elements of a list.  Uses the DefaultKComparator to
     * compare elements, and the com.kataba.util.QuickSwapSorter class
     * to do the sorting.
     *
     * <p>Equivalent to
     * <code>QuickSwapSorter.INSTANCE.sort(new ListRWSwapSortable(sort))</code>
     *
     * @see com.kataba.util.QuickSwapSorter
     * @see com.kataba.util.DefaultKComparator
     *
     * @param list the ListRW to sort
     */
    public static void sort(ListRW list) {
        QuickSwapSorter.INSTANCE.sort(new ListRWSwapSortable(list));
    }

    /** Sorts the elements of a list.  Uses the specified 'comparator'
     * to compare elements, and the com.kataba.util.QuickSwapSorter
     * class to do the sorting.
     *
     * <p>Equivalent to
     * <code>QuickSwapSorter.INSTANCE.sort(new ListRWSwapSortable(sort, comparator))</code>
     *
     * @see com.kataba.util.QuickSwapSorter
     * @see com.kataba.util.DefaultKComparator
     *
     * @param list the ListRW to sort
     * @param comparator used to determine element ordering
     */
    public static void sort(ListRW list, java.util.Comparator comparator) {
        QuickSwapSorter.INSTANCE.sort(new ListRWSwapSortable(list, comparator));
    }

    /** Returns a synchronized (thread-safe) CollectionRW backed by
     * the specified 'collection'.  The returned Collection
     * synchronizes all access on the Object returned by
     * 'collection.lock()'.  */
    public static CollectionRW synchronizedCollectionRW(CollectionRW collection) {
        return new SynchronizedCollectionRW(collection);
    }

    /** Returns a synchronized (thread-safe) CollectionRO backed by
     * the specified 'collection'.  The returned Collection
     * synchronizes all access on the Object returned by
     * 'collection.lock()'.  */
    public static CollectionRO synchronizedCollectionRO(CollectionRO collection) {
        return new SynchronizedCollectionRO(collection);
    }

    /** Returns a synchronized (thread-safe) ListRW backed by the
     * specified 'list'.  The returned List synchronizes all access on
     * the Object returned by 'list.lock()'.  */
    public static ListRW synchronizedListRW(ListRW list) {
        return new SynchronizedListRW(list);
    }

    /** Returns a synchronized (thread-safe) ListRO backed by the
     * specified 'list'.  The returned List synchronizes all access on
     * the Object returned by 'list.lock()'.  */
    public static ListRO synchronizedListRO(ListRO list) {
        return new SynchronizedListRO(list);
    }

    /** Returns a synchronized (thread-safe) SetRW backed by the
     * specified 'set'.  The returned Set synchronizes all access on
     * the Object returned by 'set.lock()'.  */
    public static SetRW synchronizedSetRW(SetRW set) {
        return new SynchronizedSetRW(set);
    }

    /** Returns a synchronized (thread-safe) SetRO backed by the
     * specified 'set'.  The returned Set synchronizes all access on
     * the Object returned by 'set.lock()'.  */
    public static SetRO synchronizedSetRO(SetRO set) {
        return new SynchronizedSetRO(set);
    }

    /** Returns a synchronized (thread-safe) MapRW backed by the
     * specified 'map'.  The returned Map synchronizes all access on
     * the Object returned by 'map.lock()'.  */
    public static MapRW synchronizedMapRW(MapRW map) {
        return new SynchronizedMapRW(map);
    }

    /** Returns a synchronized (thread-safe) MapRO backed by the
     * specified 'map'.  The returned Map synchronizes all access on
     * the Object returned by 'map.lock()'.  */
    public static MapRO synchronizedMapRO(MapRO map) {
        return new SynchronizedMapRO(map);
    }


    /** Returns a CollectionRW backed by the specified 'collection'.
     *
     * <p>Equivalent to <code>new CollectionToCollectionRW(collection)</code> */
    public static CollectionRW collectionRW(java.util.Collection collection) {
        return new CollectionToCollectionRW(collection);
    }

    /** Returns a ListRW backed by the specified 'list'.
     *
     * <p>Equivalent to <code>new ListToListRW(list)</code> */
    public static ListRW listRW(java.util.List list) {
        return new ListToListRW(list);
    }

    /** Returns a SetRW backed by the specified 'set'.
     *
     * <p>Equivalent to <code>new SetToSetRW(set)</code> */
    public static SetRW setRW(java.util.Set set) {
        return new SetToSetRW(set);
    }

    /** Returns a MapRW backed by the specified 'map'.
     *
     * <p>Equivalent to <code>new MapToMapRW(map)</code>.  Presently unsupported. */
    public static MapRW mapRW(java.util.Map map) {
        return new MapToMapRW(map);
    }

    /** Wraps the specified 'collectionRW' to safely expose only the CollectionRO interface.
     *
     * <p>Equivalent to <code>new WrappedCollectionRO(collectionRW)</code>
     */
    public static CollectionRO collectionRO(CollectionRW collectionRW) {
        return new WrappedCollectionRO(collectionRW);
    }

    /** Wraps the specified 'listRW' to safely expose only the ListRO interface.
     *
     * <p>Equivalent to <code>new WrappedListRO(listRW)</code>
     */
    public static ListRO listRO(ListRW listRW) {
        return new WrappedListRO(listRW);
    }

    /** Wraps the specified 'setRW' to safely expose only the SetRO interface.
     *
     * <p>Equivalent to <code>new WrappedSetRO(setRW)</code>
     */
    public static SetRO setRO(SetRW setRW) {
        return new WrappedSetRO(setRW);
    }

    /** Wraps the specified 'mapRW' to safely expose only the MapRO interface.
     *
     * <p>Equivalent to <code>new WrappedMapRO(mapRW)</code>
     */
    public static MapRO mapRO(MapRW mapRW) {
        return new WrappedMapRO(mapRW);
    }
}
