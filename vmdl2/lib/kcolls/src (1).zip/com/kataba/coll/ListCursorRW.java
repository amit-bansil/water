//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** Extends ListCursorRO to provide read-write operations centered on
 * the position of the cursor.
 *
 * @see ListRW#listCursorRW()
 * @see ListRW#listCursorRW(int)
 * @author Chris Thiessen
 */
public interface ListCursorRW
    extends ListCursorRO
{
    /** Adds an element at index 'index()+offset' in the list.
     *
     * @exception IndexOutOfBoundsException if 'index()+offset' is out of bounds
     */
    public void add(int offset, Object element);

    /** Removes the element at index 'index()+offset' in the list.
     *
     * @exception IndexOutOfBoundsException if 'index()+offset' is not
     * the index of a list element.
     */
    public void remove(int offset);

    /** Replaces the element at index 'index()+offset' in the list.
     *
     * @exception IndexOutOfBoundsException if the 'index()+offset' is
     * not the index of a list element.
     */
    public void set(int offset, Object element);
}
