//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** An implementation of ListRO which contains a contiguous range of elements
 *  from a given list.
 *
 * @author Chris Thiessen
 */
public class SubListRO
    extends AbstractListRO
{
    protected ListRO list;
    protected int start;
    protected int end;

    /** Constructs to be based on the specified element.
     *@param _list the list on which to base the sublist
     *@param _start the starting index of the range of elements
     *@param _end the ending index of the range of elemnets
     */
    public SubListRO(ListRO _list, int _start, int _end) {
    list = _list;
    start = _start;
    end = _end;
    if(start < 0)
        throw new IndexOutOfBoundsException("start:"+start+", list.size:"+size());
    if(start > end)
        throw new IllegalArgumentException
        ("start:"+start+" > end:"+end+"");
    if(end > list.size())
        throw new IndexOutOfBoundsException
        ("end:"+end+", list.size:"+list.size());
    }


    //
    // implements CollectionRO
    //

    /** Registers a listener to be triggered when this collection
     * emits an event. */
    public void addListener(CollectionRO.Listener listener, Object sendback) {
    }

    /** Unregisters a listener previously registered to be triggered
     * when this collection emits an event. */
    public void removeListener(CollectionRO.Listener listener) {
    }

    /** Returns the number of elements in this collection. */
    public int size() {
    return end - start;
    }


    //
    // implements ListRO
    //

    /** Registers a listener to be triggered when this list
     * emits an event. */
    public void addListener(ListRO.Listener listener, Object sendback) {
    }

    /** Unregisters a listener previously registered to be triggered
     * when this list emits an event. */
    public void removeListener(ListRO.Listener listener) {
    }

    /** Returns the element at the specified index.
     *
     * @exception IndexOutOfBoundsException if the index is out of bounds */
    public Object get(int index) {
    return list.get(index + start);
    }
}
