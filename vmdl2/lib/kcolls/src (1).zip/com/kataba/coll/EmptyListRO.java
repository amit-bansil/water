
package com.kataba.coll;

/** Represents an empty read-only list
 *
 * @author Chris Thiessen
 */
public class EmptyListRO
    extends AbstractListRO
{
    public static final EmptyListRO INSTANCE = new EmptyListRO();

    /** Constructs */
    public EmptyListRO() {
    }

    //
    // implements CollectionRO
    //

    /** @see CollectionRO#size() */
    public int size() {
        return 0;
    }

    //
    // implements ListRO
    //

    /** Does nothing, since the contents of the ListRO can never change
     *
     * @see ListRO#addListener(ListRO.Listener,Object) */
    public void addListener(ListRO.Listener listener, Object sendback) {
    }

    /** @see ListRO#removeListener(ListRO.Listener) */
    public void removeListener(ListRO.Listener listener) {
    }

    /** @see ListRO#get(int) */
    public Object get(int index) {
        throw new IndexOutOfBoundsException("index:"+index+", size:"+size());
    }

}
