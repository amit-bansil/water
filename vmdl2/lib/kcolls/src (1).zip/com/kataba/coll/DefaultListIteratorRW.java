
package com.kataba.coll;

import com.kataba.util.*;

/** The default iterator for lists.  Uses a cursor from the specified
 * list to retrieve elements from the list.  Whatever concurrent
 * access semantics the cursor exhibits, whether fail-fast or robust,
 * are reflected by this iterator.
 *
 * @author Chris Thiessen
 */
public class DefaultListIteratorRW
    extends DefaultListIteratorRO
    implements ListIteratorRW
{
    /** The cursor being used */
    protected ListCursorRW listCursor;

    /** Constructs to iterate through the elements matched by the
     * specified filter. */
    public DefaultListIteratorRW(ListCursorRW _listCursor) {
	super(_listCursor);
	listCursor = _listCursor;
    }

    //
    // implements ListIteratorRW
    //

    /** @see ListIteratorRW#add(Object) */
    public void add(Object object) {
        listCursor.add(0, object);
        listCursor.move(1);
        lastIndex = -1;
    }

    /** @see ListIteratorRW#set(Object) */
    public void set(Object object) {
        if(lastIndex == -1)
            throw new IllegalStateException("Neither next nor previous have been called,"
                                            +" or remove or add have been called since the"
                                            +" last call to next or previous.");
        listCursor.set(lastIndex - listCursor.index(), object);
    }


    //
    // implements IteratorRW
    //

    /** @see IteratorRW#remove() */
    public void remove() {
        if(lastIndex == -1)
            throw new IllegalStateException("Neither next nor previous have been called,"
                                            +" or remove or add have been called since the"
                                            +" last call to next or previous.");

        int offset = lastIndex - listCursor.index();
        listCursor.remove(offset);
        listCursor.move(offset);
        lastIndex = -1;
    }
}
