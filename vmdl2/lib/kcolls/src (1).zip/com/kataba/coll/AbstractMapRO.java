
package com.kataba.coll;

import com.kataba.coll.wrap.*;
import com.kataba.util.*;

/** This class provides a skeletal implementation of the MapRO
 * interface to minimize the effort required to implement this
 * interface.
 *
 * <p>Subclasses of this class must define the following methods:
 * <ul>
 *   <li><code>get(Object key)</code>
 *   <li><code>size()</code>
 *   <li><code>keyIteratorRO()</code>
 * </ul>
 *
 * <p>The implementation of all other methods depends on those few.
 *
 * @author Chris Thiessen
 */
public abstract class AbstractMapRO
    implements MapRO
{
    public static final Identifier DEFAULT_IDENTIFIER
	= DefaultIdentifier.INSTANCE;

    protected Identifier identifier = DEFAULT_IDENTIFIER;

    /** Constructs use the default Identifier */
    public AbstractMapRO() {
        this(DEFAULT_IDENTIFIER);
    }

    /** Constructs to use the specified Identifier on elements */
    public AbstractMapRO(Identifier _identifier) {
	identifier = _identifier;
    }


    //
    // extends Object
    //

    /** @see Object#toString */
    public String toString() {
        StringBuffer text = new StringBuffer();
        text.append("{");
        for(IteratorRO itr=keyIteratorRO(); itr.hasNext(); ) {
            Object key = itr.next();
            Object value = get(key);
            text.append(key+":"+value);
            if(itr.hasNext())
                text.append(",");
        }
        text.append("}");
        return text.toString();
    }

    //
    // implements Lockable
    //

    /** @see Lockable#lock() */
    public Object lock() {
        return this;
    }


    //
    // implements MapRO
    //

    /** Do nothing
     *
     * @see MapRO#addListener(MapRO.Listener,Object)
     */
    public void addListener(MapRO.Listener listener, Object sendback) {
        // do nothing
    }

    /** @see MapRO#removeListener(MapRO.Listener) */
    public void removeListener(MapRO.Listener listener) {
        // do nothing
    }

    /** @see MapRO#containsKey(Object) */
    public boolean containsKey(Object key) {
        return keySetRO().contains(key);
    }

    /** @see MapRO#containsValue(Object) */
    public boolean containsValue(Object value) {
        for(IteratorRO itr=keyIteratorRO(); itr.hasNext(); ) {
            Object temp = get(itr.next());
            if(Util.equals(temp, value))
                return true;
        }
        return false;
    }

    /** @see MapRO#isEmpty() */
    public boolean isEmpty() {
        return size() == 0;
    }

    /** @see MapRO#equals */
    public boolean equals(Object object) {
        MapRO map;
        if(object == null)
            return false;
        else if(object instanceof MapRO)
            map = (MapRO)object;
        else if(object instanceof java.util.Map)
            // wrap the java.util.Map
            map = new MapToMapRW((java.util.Map)object);
        else
            return false;

        return map.entrySetRO().equals(entrySetRO());
    }

    /** @see MapRO#hashCode */
    public int hashCode() {
        return entrySetRO().hashCode();
    }


    /** @see MapRO#entrySetRO() */
    public SetRO entrySetRO() {
        return new EntriesRO();
    }
    private class EntriesRO extends AbstractSetRO {
        /** Returns AbstractMapRO.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRO.this.lock();
        }

        /** @see CollectionRO#contains(Object) */
        public boolean contains(Object object) {
            EntryRO entry = (EntryRO)object;
            EntryRO present = getEntryRO(object);
            if(present == null)
                return false;
            return Util.equals(present, entry);
        }

        /** @see CollectionRO#size */
        public int size() {
            return AbstractMapRO.this.size();
        }

        /** @see CollectionRO#iteratorRO */
        public IteratorRO iteratorRO() {
            return entryIteratorRO();
        }
    }


    /** @see MapRO#keySetRO() */
    public SetRO keySetRO() {
        return new KeysRO();
    }
    private class KeysRO extends AbstractSetRO {
        /** Returns AbstractMapRO.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRO.this.lock();
        }

        /** @see CollectionRO#contains(Object) */
        public boolean contains(Object object) {
            return containsKey(object);
        }

        /** @see CollectionRO#size */
        public int size() {
            return AbstractMapRO.this.size();
        }

        /** @see CollectionRO#iteratorRO */
        public IteratorRO iteratorRO() {
            return keyIteratorRO();
        }
    }


    /** @see MapRO#valuesRO() */
    public CollectionRO valuesRO() {
        return new ValuesRO();
    }
    private class ValuesRO extends AbstractSetRO {
        /** Returns AbstractMapRO.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRO.this.lock();
        }

        /** @see CollectionRO#contains(Object) */
        public boolean contains(Object object) {
            return containsValue(object);
        }

        /** @see CollectionRO#size */
        public int size() {
            return AbstractMapRO.this.size();
        }

        /** @see CollectionRO#iteratorRO */
        public IteratorRO iteratorRO() {
            return valueIteratorRO();
        }
    }

    /** Returns an IteratorRO over the values mapped to by the MapRO */
    protected IteratorRO valueIteratorRO() {
        return new ValueIteratorRO();
    }
    private class ValueIteratorRO implements IteratorRO {
        private IteratorRO keyItr = keyIteratorRO();

        /** Returns AbstractMapRO.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRO.this.lock();
        }

        /** @see IteratorRO#hasNext() */
        public boolean hasNext() {
            return keyItr.hasNext();
        }

        /** @see IteratorRO#next() */
        public Object next() {
            return get(keyItr.next());
        }
    }

    /** Returns an IteratorRO over the EntryRO's in the Map */
    protected IteratorRO entryIteratorRO() {
        return new EntryIteratorRO();
    }
    private class EntryIteratorRO implements IteratorRO {
        private IteratorRO keyItr = keyIteratorRO();

        /** Returns AbstractMapRO.this.lock()
         * @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRO.this.lock();
        }

        /** @see IteratorRO#hasNext() */
        public boolean hasNext() {
            return keyItr.hasNext();
        }

        /** @see IteratorRO#next() */
        public Object next() {
            return get(keyItr.next());
        }
    }

    /** @see MapRO#getEntryRO(Object) */
    public EntryRO getEntryRO(Object key) {
        return new ConcreteEntryRO(key);
    }
    private class ConcreteEntryRO implements EntryRO {
        private Object key;

        /** Constructs */
        private ConcreteEntryRO(Object _key) {
            key = _key;
        }

        /** @see Lockable#lock() */
        public Object lock() {
            return AbstractMapRO.this.lock();
        }

        /** @see java.util.Map.Entry#equals(Object) */
        public boolean equals(Object object) {
            if(object == null)
                return false;

            else if(object instanceof EntryRO) {
                EntryRO entry = (EntryRO)object;
                return Util.equals(getKey(), entry.getKey())
                    && Util.equals(getValue(), entry.getValue());

            } else if(object instanceof java.util.Map.Entry) {
                java.util.Map.Entry entry = (java.util.Map.Entry)object;
                return Util.equals(getKey(), entry.getKey())
                    && Util.equals(getValue(), entry.getValue());

            } else
                return false;
        }

        /** @see java.util.Map.Entry#getKey() */
        public Object getKey() {
            return key;
        }

        /** @see java.util.Map.Entry#getValue() */
        public Object getValue() {
            return get(key);
        }

        /** @see java.util.Map.Entry#hashCode() */
        public int hashCode() {
            Object value = getValue();
            return Util.hashCode(key) ^ Util.hashCode(getValue());
        }
    }


    // abstract methods

    /** @see MapRO#get(Object) */
    public abstract Object get(Object key);

    /** @see MapRO#size() */
    public abstract int size();

    /** Returns an IteratorRO over the values of the MapRO */
    public abstract IteratorRO keyIteratorRO();
}
