
package com.kataba.coll;

import java.util.NoSuchElementException;

/** A SetRW which acts as a delta of another.  That is, it is based on
 * the contents of another SetRW.  When changes are made to through
 * this SetRW, those changes are stored, but the base set is left
 * unmodified.
 *
 * @author Chris Thiessen
 */
public class DeltaSet
    extends AbstractSetRW
    implements SetRW
{
    private SetRO basis;
    private HashSetRW added = new HashSetRW();
    private HashSetRW removed = new HashSetRW();

    /** Constructs to be based on the specified Set */
    public DeltaSet(SetRW _basis) {
	basis = _basis;
	if(basis == null)
	    basis = new EmptySetRO();
    }

    /** Returns the Set of added elements */
    public SetRO getAdded() {
	return added;
    }

    /** Returns the Set of removed elements */
    public SetRO getRemoved() {
	return removed;
    }

    /** Applies the accumulated changes to the basis SetRW */
    public void applyChanges() {
        //TODO: implement
        //basis.removeAll(removed);
        //basis.addAll(added);
    }


    //
    // implements CollectionRO
    //

    /** @see CollectionRO#contains(Object) */
    public boolean contains(Object element) {
	return (added.contains(element)
		|| (!removed.contains(element)
		    && basis.contains(element)));
    }

    /** @see CollectionRO#size() */
    public int size() {
	return basis.size() + added.size() - removed.size();
    }


    //
    // implements CollectionRW
    //


    /** @see CollectionRW#add(Object) */
    public boolean add(Object element) {
	if(removed.contains(element))
	    return removed.remove(element);
	else if(!added.contains(element))
	    return added.add(element);
	else
	    return false;
    }

    /** @see CollectionRW#remove(Object) */
    public boolean remove(Object element) {
	if(added.remove(element))
	    return true;
	else if(basis.contains(element))
	    return removed.add(element);
	else
	    return false;
    }

    /** @see CollectionRW#clear() */
    public void clear() {
	if(size() > 0) {
	    added.clear();
	    removed.addAll(basis);
	}
    }

    /** @see CollectionRW#iteratorRW() */
    public IteratorRW iteratorRW() {
	return new Itr();
    }

    private class Itr implements IteratorRW {
	IteratorRO basisItr;
	IteratorRW addedItr;

	boolean addedDepleted;
	boolean hasPrev;
	boolean prevFromAdded;
	boolean basisHasNext;
	Object basisPrev;
	Object basisNext;

	public Itr() {
	    basisItr = basis.iteratorRO();
	    addedItr = added.iteratorRW();
	}

	//
	// implements Lockable
	//

        /** @see Lockable#lock() */
	public Object lock() {
	    return DeltaSet.this.lock();
	}


	//
	// implements IteratorRO
	//

        /** @see IteratorRO#hasNext() */
	public boolean hasNext() {
	    if(!addedDepleted) {
		if(addedItr.hasNext())
		    return true;
		else {
		    addedDepleted = true;
		    return hasNext();
		}
	    } else if(basisHasNext)
		return true;
	    else {
		while(basisItr.hasNext()) {
		    Object element = basisItr.next();
		    if(!removed.contains(element)) {
			basisHasNext = true;
			basisNext = element;
			return true;
		    }
		}
		return false;
	    }
	}

        /** @see IteratorRO#next() */
	public Object next() {
	    if(hasNext()) {
		if(!addedDepleted) {
		    hasPrev = true;
		    prevFromAdded = true;
		    return addedItr.next();
		} else if(basisHasNext) {
		    hasPrev = true;
		    prevFromAdded = false;
		    basisPrev = basisNext;
		    basisHasNext = false;
		    basisNext = null;
		    return basisPrev;
		} else
		    throw new RuntimeException("Shouldn't be here");
	    } else {
		hasPrev = false;
		throw new NoSuchElementException();
	    }
	}


	//
	// IteratorRW
	//

        /** @see IteratorRW#remove() */
	public void remove() {
	    if(hasPrev) {
		if(prevFromAdded)
		    addedItr.remove();
		else
		    removed.remove(basisPrev);
	    } else
		throw new IllegalStateException();
	}
    }
}
