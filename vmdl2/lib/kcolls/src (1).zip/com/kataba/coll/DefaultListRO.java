//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** The default implementation of <code>ListRO</code>.  Uses an
 * array for multiple elements, and a single element otherwise.
 *
 * @author Chris Thiessen
 */
public class DefaultListRO extends AbstractListRO {
    /** An empty ListRO */
    public static final ListRO empty = new DefaultListRO();

    /** The single element */
    protected Object element;
    /** The multiple elements */
    protected Object[] elements;
    /** The index into 'elements' */
    protected int start;
    /** The number of elements */
    protected int size;

    /** Constructs to be empty */
    public DefaultListRO() {
	size = 0;
    }

    /** Constructs to be based on the specified array.
     *
     * WARNING: Do not modify the array subsequently; it is used in
     * place. */
    public DefaultListRO(Object[] _elements) {
	elements = _elements;
	start = 0;
	size = elements.length;
    }

    /** Constructs to contain the range of elements in '_elements'
     * from '_start', up to but not including 'end'.
     *
     * WARNING: Do not modify the array subsequently; it is used in
     * place. */
    public DefaultListRO(Object[] _elements, int _start, int end) {
	elements = _elements;
	start = _start;
	size = end - start;

	if(start < 0)
	    throw new IndexOutOfBoundsException
		("start:"+start+", elements.length:"+elements.length);
	if(start > end)
	    throw new IllegalArgumentException
		("start:"+start+" > elements.length:"+end);
	if(end >= elements.length)
	    throw new IllegalArgumentException
		("end:"+start+", elements.length:"+elements.length);
    }

    /** Constructs to be based on the specified element. */
    public DefaultListRO(Object _element) {
	element = _element;
	size = 1;
    }

    public DefaultListRO(IteratorRO itr) {
    }

    /** Constructs to contain the elements in the specified collection. */
    public DefaultListRO(CollectionRO coll) {
	this(coll.toArray());
    }

    /** Constructs to contain the elements in the specified collection. */
    public DefaultListRO(java.util.Collection coll) {
	this(coll.toArray());
    }

    /** Constructs to contain the elements of 'coll1', followed by the
     * elemenst of 'coll2' */
    public DefaultListRO(CollectionRO coll1, CollectionRO coll2) {
	size = coll1.size() + coll2.size();
	elements = new Object[size];
	start = 0;
	int i=0;
	for(IteratorRO itr=coll1.iteratorRO(); itr.hasNext(); )
	    elements[i++] = itr.next();
	for(IteratorRO itr=coll2.iteratorRO(); itr.hasNext(); )
	    elements[i++] = itr.next();
    }


    //
    // implements CollectionRO
    //

    /** Registers a listener to be triggered when this collection
     * emits an event. */
    public void addListener(CollectionRO.Listener listener, Object sendback) {
    }

    /** Unregisters a listener previously registered to be triggered
     * when this collection emits an event. */
    public void removeListener(CollectionRO.Listener listener) {
    }

    /** Returns the number of elements in this collection. */
    public int size() {
	return size;
    }


    //
    // implements ListRO
    //

    /** Registers a listener to be triggered when this list
     * emits an event. */
    public void addListener(ListRO.Listener listener, Object sendback) {
    }

    /** Unregisters a listener previously registered to be triggered
     * when this list emits an event. */
    public void removeListener(ListRO.Listener listener) {
    }

    /** Returns the element at the specified index.
     *
     * @exception IndexOutOfBoundsException if the index is out of bounds */
    public Object get(int index) {
	if(index < 0 || index >= size)
	    throw new IndexOutOfBoundsException();

	if(elements != null)
	    return elements[start+index];
	else
	    return element;
    }

}
