
package com.kataba.coll;

import com.kataba.util.*;

import java.util.NoSuchElementException;

/** The default read-only iterator for read-only lists.  Uses the
 * specified cursor to retrieve elements from the list.  Whatever
 * concurrent access semantics the cursor exhibits, whether fail-fast
 * or robust, are reflected by this iterator.
 *
 * @author Chris Thiessen
 */
public class DefaultListIteratorRO
    implements ListIteratorRO
{
    /** The cursor being used */
    protected ListCursorRO listCursorRO;

    protected int lastIndex = -1;

    /** Constructs to iterate through the elements matched by the
     * specified filter. */
    public DefaultListIteratorRO(ListCursorRO _listCursorRO) {
	listCursorRO = _listCursorRO;
    }


    //
    // Lockable
    //

    /** Returns an object you can synchronize on to atomicize multiple
     * operations on this iterator and the underlying collection
     *
     * @see Lockable#lock */
    public Object lock() {
	return listCursorRO.lock();
    }


    //
    // implements IteratorRO
    //

    /** @see IteratorRO#hasNext() */
    public boolean hasNext() {
        return listCursorRO.canGet(0);
    }

    /** @see IteratorRO#next() */
    public Object next() {
        if(!hasNext())
	    throw new NoSuchElementException();
        Object object = listCursorRO.get(0);
        lastIndex = listCursorRO.index();
        listCursorRO.move(1);
        return object;
    }


    //
    // implements ListIteratorRO
    //

    /** @see ListIteratorRO#hasPrevious */
    public boolean hasPrevious() {
        return listCursorRO.canGet(-1);
    }

    /** @see ListIteratorRO#previous */
    public Object previous() {
        if(!hasPrevious())
	    throw new NoSuchElementException();
        Object object = listCursorRO.get(-1);
        listCursorRO.move(-1);
        lastIndex = listCursorRO.index();
        return object;
    }

    /** @see ListIteratorRO#nextIndex */
    public int nextIndex() {
        return listCursorRO.index();
    }

    /** @see ListIteratorRO#previousIndex */
    public int previousIndex() {
        return listCursorRO.index() - 1;
    }
}
