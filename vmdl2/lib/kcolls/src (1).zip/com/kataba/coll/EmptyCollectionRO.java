
package com.kataba.coll;

/** Represents an empty read-only collection
 *
 * @author Chris Thiessen
 */
public class EmptyCollectionRO
    extends AbstractCollectionRO
{
    /** Default instance of this class */
    public static final EmptyCollectionRO INSTANCE = new EmptyCollectionRO();

    /** Constructs */
    public EmptyCollectionRO() {
    }


    //
    // implements CollectionRO
    //

    /** Does nothing, since the contents of the CollectionRO can never change
     *
     * @see CollectionRO#addListener(CollectionRO.Listener,Object) */
    public void addListener(Listener listener, Object sendback) {
    }

    /** @see CollectionRO#removeListener(CollectionRO.Listener) */
    public void removeListener(Listener listener) {
    }

    /** @see CollectionRO#contains(Object) */
    public boolean contains(Object element) {
	return false;
    }

    /** @see CollectionRO#size() */
    public int size() {
	return 0;
    }

    /** @see CollectionRO#iteratorRO() */
    public IteratorRO iteratorRO() {
	return new EmptyIteratorRO();
    }
}
