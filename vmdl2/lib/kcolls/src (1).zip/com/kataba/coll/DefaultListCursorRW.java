//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import java.util.*;

/** Default implementation of ListCursorRW for List's where the
 * contents can be efficiently accessed and modified by
 * element-index-oriented operations.
 *
 * @author Chris Thiessen
 */
public class DefaultListCursorRW
    extends DefaultListCursorRO
    implements ListCursorRW
{
    /** The List */
    protected ListRW list;

    /** Constructs a cursor positioned at the specified '_index' in
     * the specified '_list' */
    public DefaultListCursorRW(ListRW _list, int _index) {
	super(_list, _index);
	list = _list;
    }


    //
    // implements ListCursorRW
    //

    /** @see ListCursorRW#add(int,Object) */
    public void add(int offset, Object element) {
	int addIndex = index + offset;
	if(addIndex >= 0 && addIndex <= list.size())
	    list.add(addIndex, element);
	else
	    throw new IndexOutOfBoundsException();
    }

    /** @see ListCursorRW#remove(int) */
    public void remove(int offset) {
	int removeIndex = index + offset;
	if(removeIndex >= 0 && removeIndex < list.size())
	    list.remove(removeIndex);
	else
	    throw new IndexOutOfBoundsException();
    }

    /** @see ListCursorRW#set(int,Object) */
    public void set(int offset, Object element) {
	int setIndex = index + offset;
	if(setIndex >= 0 && setIndex < list.size())
	    list.set(setIndex, element);
	else
	    throw new IndexOutOfBoundsException();
    }
}
