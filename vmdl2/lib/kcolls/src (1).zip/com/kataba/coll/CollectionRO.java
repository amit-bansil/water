//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import com.kataba.util.*;

/** Represents a read-only collection of Objects.  The elements of a
 * CollectionRO are not guaranteed to be ordered in any
 * particular way.
 *
 * <p>While this interface provides no modification methods, there is
 * no guarantee that the contents of the CollectionRO will remain
 * unchanged.  An implementation of CollectionRO.Listener which
 * is registered with a CollectionRO will receive notifications
 * of changes to the contents of the CollectionRO after they
 * occur.
 *
 * <p>An implementation of this interface should document its rules of
 * object equivalence.
 *
 * @see java.util.Collection
 * @author Chris Thiessen
 */
public interface CollectionRO
    extends Lockable
{
    /** Implemented by classes which wish to be notified of changes to
     * the contents of a CollectionRO */
    public interface Listener {
	/** Elements were added.  'elementsA' contains the added elements. */
	public static final int ADD = 1;

	/** Elements were removed.  'elementsA' contains the removed elements. */
	public static final int REMOVE = 2;

	/** Elements were replaced. 'elementsA' contains the replaced
	 * elements.  'elementsB' contains the elements that replaced
	 * them. */
	public static final int REPLACE = 3;

	/** Called after any listened-to CollectionRO changes.  Thrown
	 * exceptions will not prevent any other Listeners from being
	 * notified of the event.
	 *
	 * @param sendback  the Object registered along with this listener,
	 *                  to provide context
	 * @param source    the CollectionRO whose contents changed
	 * @param event     the event ID, one of { ADD, REMOVE, REPLACE }
	 * @param elementsA see the event ID description
	 * @param elementsA see the event ID description */
	public void collectionEvent(Object sendback, CollectionRO source
				    , int event, CollectionRO elementsA
				    , CollectionRO elementsB);

	/* copy-paste for event switching
	switch(event) {
	case CollectionRO.Listener.ADD:
	case CollectionRO.Listener.REMOVE:
	case CollectionRO.Listener.REPLACE:
	}
	*/
    }

    /** Registers a listener to be triggered when the contents of this
     * CollectionRO change. The 'sendback' is passed to the 'listener'
     * with each event, to provide context. */
    public void addListener(Listener listener, Object sendback);

    /** Deregisters a listener registered to be notified when the
     * contents of this CollectionRO change.  More specifically,
     * deregisters the listener which is == to the specified
     * 'listener'. */
    public void removeListener(Listener listener);

    /** Returns an element in this collection which is equal to the
     * specified 'object' under the CollectionRO's rules of
     * equivalence.
     *
     * @exception NoSuchElementException if no matching element was
     *            found
     */
    public Object get(Object object);

    /** @see CollectionRO#containsAll(java.util.Collection) */
    public boolean containsAll(CollectionRO collection);

    /** Returns a read-only iterator over the contents of this Collection.
     *
     * @see java.util.Collection#iterator() */
    public IteratorRO iteratorRO();


    //
    // implements the read-only part of java.util.Collection
    //

    /** @see java.util.Collection#size() */
    public int size();

    /** @see java.util.Collection#isEmpty() */
    public boolean isEmpty();

    /** @see java.util.Collection#contains(Object) */
    public boolean contains(Object object);

    /** @see java.util.Collection#containsAll(java.util.Collection) */
    public boolean containsAll(java.util.Collection collection);

    /** @see java.util.Collection#toArray() */
    public Object[] toArray();

    /** @see java.util.Collection#toArray(Object[]) */
    public Object[] toArray(Object[] array);

    /** @see java.util.Collection#equals(Object) */
    public boolean equals(Object o);

    /** @see java.util.Collection#hashCode() */
    public int hashCode();
}
