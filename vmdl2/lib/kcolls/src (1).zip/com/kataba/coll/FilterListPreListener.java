
package com.kataba.coll;

import com.kataba.util.*;

/** A AbstractListRW.PreListener which throws
 * IllegalArgumentException's when an element is added which doesn't
 * match the Filter specified on construction.
 *
 * @author Chris Thiessen
 */
public class FilterListPreListener
    implements AbstractListRW.PreListener
{
    private Filter filter;

    /** Constructs to filter elements with the specified '_filter' */
    FilterListPreListener(Filter _filter) {
        filter = _filter;
    };

    /** @see AbstractListRW.PreListener#preEvent */
    public void preEvent(int event
                         , int indexA, int indexB, ArrayRO_int indexes
                         , ListRO elements) {
        switch(event) {
        case AbstractListRW.PreListener.ADD:
        case AbstractListRW.PreListener.REPLACE_RANGE:
            for(int i=0; i<elements.size(); i++) {
                Object element = elements.get(i);
                if(!filter.match(element))
                    throw new IllegalArgumentException("Illegal element: " + element);
            }
            break;
        }
    }
}
