package com.kataba.coll.test;


import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;



/**
 *  Tests multithreaded access to the MapRW with listeners.
 */
public class ThreadTestMapRW extends KTestCase implements MapRO.Listener {

    static final int DEFAULT_NUM_THREADS = 2;
    static final int DEFAULT_RUNNING_SECONDS = 10;
    static final int DEFAULT_NUM_ENTRIES = 10;
    static final int KEY_RANGE = 10;
    static final int VALUE_RANGE = 100;

    public static void main(String [] args) {

        int numThreads = DEFAULT_NUM_THREADS;
        int seconds = DEFAULT_RUNNING_SECONDS;
        boolean rogueThread = false;

        if (args.length > 0) {
            for (int i = 0 ; i < args.length; ++i) {
                String arg = args[i];
                int index = arg.indexOf("-t");
                if (index != -1) {
                    String num = arg.substring(index + 2);
                    try {
                        numThreads = (Integer.valueOf(num)).intValue();
                    } catch (NumberFormatException e) {
                        Out.ln("BAD THREAD ARGUMENT(" + arg + "); DEFAULTING TO 2 THREADS");
                        Out.ln("threads=" + num);
                    }
                }
                
                index = arg.indexOf("-s");
                if (index != -1) {
                    String sec = arg.substring(index + 2);
                    try {
                        seconds = (Integer.valueOf(sec)).intValue();
                    } catch (NumberFormatException e) {
                        Out.ln("BAD SECONDS ARGUMENT(" + arg + "); DEFAULTING TO 2 THREADS");
                        Out.ln("seconds=" + sec);
                    }                    
                }
 
                index = arg.indexOf("-r"); // rogue thread
                if (index != -1) {
                    rogueThread = true;
                }
            }
        }

        Out.ln("Running ThreadTestMapRW with " + numThreads + " threads for " + seconds + " seconds");

        ThreadTestMapRW test = new ThreadTestMapRW(numThreads, seconds, rogueThread);
        test.start(args);
    }

    private int _numThreads;
    private long _millsToRun;
    private MapRW _map;
    private MapRW _noSyncMap;
    private Random _random = new Random();
    private boolean _rogueThread;

    /** constructs with default thread count */
    public ThreadTestMapRW() {
        this(DEFAULT_NUM_THREADS, DEFAULT_RUNNING_SECONDS, false);
    }

    /** constructs with specified thread count
     *@param numThreads the number of threads each for adding and removing from the map
     */
    public ThreadTestMapRW(int numThreads, int seconds, boolean rogueThread) {
        super("ThreadTestMapRW(MapRW)");
        _numThreads = numThreads;
        _millsToRun = seconds * 1000;
        _rogueThread = rogueThread;
        _noSyncMap = new ArrayHashMapRW();
        _map = new SynchronizedMapRW(_noSyncMap);
        _map.addListener(this, null);
    }

    /** @see KTestCase#test() */
    public void test() {
        
        long startTime = System.currentTimeMillis();

        // create 'numThreads' adder threads
        for (int i = 0; i < _numThreads; ++i) {

            final int adderThreadId = i;

            // adds random keys
            Thread adderThread = new Thread() {
                public void run() {
                    while (true) {

                        pause(pauseTime());

                        Object key = key();
                        Object value = value();
                        Out.ln("ADDER(" + adderThreadId + ") put(" + key + ", " + value + ")");
                        _map.put(key, value);
                    }
                }
            };

            adderThread.start();                                    
        }

        // create 'numThreads' removed threads
        for (int i = 0; i < _numThreads; ++i) {

            final int removeThreadId = i;

            // removes random keys
            Thread removerThread = new Thread() {
                public void run() {
                    while (true) {

                        pause(pauseTime());

                        Object key = key();
                        Out.ln("REMOVER(" + removeThreadId + ") remove(" + key + ")");
                        _map.remove(key);
                    }
                }
            };

            removerThread.start();
        }

        // thred that inspects the Map.
        Thread inspectorGadgetThread = new Thread() {
            public void run() {
                while (true) {

                    pause(pauseTime(true));

                    synchronized (_map.lock()) {

                        Out.ln("------------------------------------------");
                        Out.ln("WAKING UP TO INSPECT THE MAP (synch'ing)...");

                        inspect("isEmpty()=>" + _map.isEmpty());
                        inspect("size()=>" + _map.size());
                        Object key = key();
                        inspect("containsKey(" + key + ")=>" + _map.containsKey(key));
                        Object value = value();
                        inspect("containsValue(" + value + ")=>" + _map.containsValue(value));
                        key = key();
                        try {
                            inspect("get(" + key + ")=>" + _map.get(key));
                        } catch (NoSuchElementException e) {
                            inspect("get(" + key + ")=>" + e);
                        }
                    
                        Out.ln("------------------------------------------");
                    }
                    
                    
                }
            }
        };

        inspectorGadgetThread.start();

        if (_rogueThread) {
            Thread rogue = new Thread() {
                public void run() {
                    
                    // TODO: while loop with pauses
                    
                    Object key;
                    // randomly add/remove entries from the map; sometimes
                    // remove all and see what happens
                    int rogueAction = getRogueAction();
                    switch (rogueAction) {
                    case (0):   // remove key
                        key = key();    
                        Out.ln("ROGUE THREAD - remove(" + key + ")!");
                        _noSyncMap.remove(key());
                        break;
                    case (1):   // put a key
                        key = key();
                        Out.ln("ROGUE THREAD - put(" + key + ", " + value() + ")");
                        _noSyncMap.put(key(), value());
                        break;
                    case (2):   // remove all
                        //TODO: remove all
                        break;
                    }
                }
            };
            rogue.start();
        }
        
        // spin until the time is finished
        while (true) {
            if ((System.currentTimeMillis() - startTime) >= _millsToRun) {
                System.exit(0);
            } else {
                pause(500);
            }
        }
    }

    private int getRogueAction() {
        return (_random.nextInt() % 3);     // action 0, 1, or 2
    }

    private long pauseTime() {
        return pauseTime(false);
    }

    private long pauseTime(boolean longTime) {
        int time = _random.nextInt();
        if (time < 0) {
            time *= -1;
        }
        if (longTime) {
            return (long)((time % 10) * 500);
        } else {
            return (long)((time % 10) * 100);
        }
    }

    private void pause(long ms) {
        try {
            Thread.sleep(ms);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void inspect(Object msg) {
        msg = "INSPECT - " + msg;
        Out.ln(msg);
    }

    private Object key() {
        return e(_random.nextInt() % KEY_RANGE);
    }

    private Object value() {
        return e(_random.nextInt() % VALUE_RANGE);
    }

    private static void out() {
        Out.ln();
    }

    //
    // implements MapRO.Listener
    //
    public void mapEvent(Object sendback, MapRO source, int event, ListRO keys, ListRO oldValues , Object notSet) {
        /*
        Out.ln();
        Out.ln("MAIN");
        Out.ln("Map event occurred(" + ((event == MapRO.Listener.ADD) ? "ADD" : "REMOVE") + ")");
        Out.ln("\tkeys = " + keys);
        Out.ln("\toldValues = " + oldValues);
        Out.ln("\tnotSet = " + notSet);
        Out.ln();
        Out.ln();
        */
    }


}
