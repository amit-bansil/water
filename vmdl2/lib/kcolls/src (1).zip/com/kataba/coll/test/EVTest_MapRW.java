
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** An EVTest for the com.kataba.coll.MapRW class
 *  For each method in the class, an expected-value test 
 *  method and an expected-exception test method is generated.
 *
 * @author com.kataba.util.EVTest_Gen
 */
public abstract class EVTest_MapRW
    extends EVTest
{

    protected MapRW _modelToTest;
    protected Exception exception;

    /** Constructs */
    public EVTest_MapRW(String _name) {
        super(_name);
    }

    public Object put(Object a, Object b, Object expectedValue) {
        String test = "put("+a+','+b+','+ expectedValue + ")";

        Object ret = _modelToTest.put(a, b);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object put(Object a, Object b, Exception expectedException) {
        String test = "put("+a+','+b+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.put(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object remove(Object a, Object expectedValue) {
        String test = "remove("+a+','+ expectedValue + ")";

        Object ret = _modelToTest.remove(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object remove(Object a, Exception expectedException) {
        String test = "remove("+a+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.remove(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public java.util.Collection values(Object expectedValue) {
        String test = "values("+ expectedValue + ")";

        java.util.Collection ret = _modelToTest.values();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public java.util.Collection values(Exception expectedException) {
        String test = "values("+ expectedException + ")";
        java.util.Collection ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.values();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void clear() {
        clear((Exception)null);
    }

    public void clear(Exception expectedException) {
        String test = "clear("+ expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.clear();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public java.util.Set keySet(Object expectedValue) {
        String test = "keySet("+ expectedValue + ")";

        java.util.Set ret = _modelToTest.keySet();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public java.util.Set keySet(Exception expectedException) {
        String test = "keySet("+ expectedException + ")";
        java.util.Set ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.keySet();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public java.util.Set entrySet(Object expectedValue) {
        String test = "entrySet("+ expectedValue + ")";

        java.util.Set ret = _modelToTest.entrySet();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public java.util.Set entrySet(Exception expectedException) {
        String test = "entrySet("+ expectedException + ")";
        java.util.Set ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.entrySet();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void putAll(MapRO a) {
        putAll(a, (Exception)null);
    }

    public void putAll(MapRO a, Exception expectedException) {
        String test = "putAll("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.putAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void putAll(java.util.Map a) {
        putAll(a, (Exception)null);
    }

    public void putAll(java.util.Map a, Exception expectedException) {
        String test = "putAll("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.putAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public IteratorRW keyIteratorRW(Object expectedValue) {
        String test = "keyIteratorRW("+ expectedValue + ")";

        IteratorRW ret = _modelToTest.keyIteratorRW();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public IteratorRW keyIteratorRW(Exception expectedException) {
        String test = "keyIteratorRW("+ expectedException + ")";
        IteratorRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.keyIteratorRW();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public MapRW.EntryRW getEntryRW(Object a, Object expectedValue) {
        String test = "getEntryRW("+a+','+ expectedValue + ")";

        MapRW.EntryRW ret = _modelToTest.getEntryRW(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public MapRW.EntryRW getEntryRW(Object a, Exception expectedException) {
        String test = "getEntryRW("+a+',' + expectedException + ")";
        MapRW.EntryRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.getEntryRW(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public SetRW entrySetRW(Object expectedValue) {
        String test = "entrySetRW("+ expectedValue + ")";

        SetRW ret = _modelToTest.entrySetRW();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public SetRW entrySetRW(Exception expectedException) {
        String test = "entrySetRW("+ expectedException + ")";
        SetRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.entrySetRW();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public SetRW keySetRW(Object expectedValue) {
        String test = "keySetRW("+ expectedValue + ")";

        SetRW ret = _modelToTest.keySetRW();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public SetRW keySetRW(Exception expectedException) {
        String test = "keySetRW("+ expectedException + ")";
        SetRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.keySetRW();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public CollectionRW valuesRW(Object expectedValue) {
        String test = "valuesRW("+ expectedValue + ")";

        CollectionRW ret = _modelToTest.valuesRW();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public CollectionRW valuesRW(Exception expectedException) {
        String test = "valuesRW("+ expectedException + ")";
        CollectionRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.valuesRW();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int hashCode(int expectedValue) {
        String test = "hashCode("+ expectedValue + ")";

        int ret = _modelToTest.hashCode();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int hashCode(Exception expectedException) {
        String test = "hashCode("+ expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.hashCode();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean equals(Object a, boolean expectedValue) {
        String test = "equals("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.equals(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean equals(Object a, Exception expectedException) {
        String test = "equals("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.equals(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object get(Object a, Object expectedValue) {
        String test = "get("+a+','+ expectedValue + ")";

        Object ret = _modelToTest.get(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object get(Object a, Exception expectedException) {
        String test = "get("+a+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.get(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int size(int expectedValue) {
        String test = "size("+ expectedValue + ")";

        int ret = _modelToTest.size();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int size(Exception expectedException) {
        String test = "size("+ expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.size();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean isEmpty(boolean expectedValue) {
        String test = "isEmpty("+ expectedValue + ")";

        boolean ret = _modelToTest.isEmpty();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean isEmpty(Exception expectedException) {
        String test = "isEmpty("+ expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.isEmpty();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean containsValue(Object a, boolean expectedValue) {
        String test = "containsValue("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.containsValue(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean containsValue(Object a, Exception expectedException) {
        String test = "containsValue("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.containsValue(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean containsKey(Object a, boolean expectedValue) {
        String test = "containsKey("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.containsKey(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean containsKey(Object a, Exception expectedException) {
        String test = "containsKey("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.containsKey(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void addListener(MapRO.Listener a, Object b) {
        addListener(a, b, (Exception)null);
    }

    public void addListener(MapRO.Listener a, Object b, Exception expectedException) {
        String test = "addListener("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.addListener(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void removeListener(MapRO.Listener a) {
        removeListener(a, (Exception)null);
    }

    public void removeListener(MapRO.Listener a, Exception expectedException) {
        String test = "removeListener("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.removeListener(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public IteratorRO keyIteratorRO(Object expectedValue) {
        String test = "keyIteratorRO("+ expectedValue + ")";

        IteratorRO ret = _modelToTest.keyIteratorRO();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public IteratorRO keyIteratorRO(Exception expectedException) {
        String test = "keyIteratorRO("+ expectedException + ")";
        IteratorRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.keyIteratorRO();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public MapRO.EntryRO getEntryRO(Object a, Object expectedValue) {
        String test = "getEntryRO("+a+','+ expectedValue + ")";

        MapRO.EntryRO ret = _modelToTest.getEntryRO(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public MapRO.EntryRO getEntryRO(Object a, Exception expectedException) {
        String test = "getEntryRO("+a+',' + expectedException + ")";
        MapRO.EntryRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.getEntryRO(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public SetRO entrySetRO(Object expectedValue) {
        String test = "entrySetRO("+ expectedValue + ")";

        SetRO ret = _modelToTest.entrySetRO();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public SetRO entrySetRO(Exception expectedException) {
        String test = "entrySetRO("+ expectedException + ")";
        SetRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.entrySetRO();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public SetRO keySetRO(Object expectedValue) {
        String test = "keySetRO("+ expectedValue + ")";

        SetRO ret = _modelToTest.keySetRO();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public SetRO keySetRO(Exception expectedException) {
        String test = "keySetRO("+ expectedException + ")";
        SetRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.keySetRO();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public CollectionRO valuesRO(Object expectedValue) {
        String test = "valuesRO("+ expectedValue + ")";

        CollectionRO ret = _modelToTest.valuesRO();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public CollectionRO valuesRO(Exception expectedException) {
        String test = "valuesRO("+ expectedException + ")";
        CollectionRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.valuesRO();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object lock(Object expectedValue) {
        String test = "lock("+ expectedValue + ")";

        Object ret = _modelToTest.lock();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object lock(Exception expectedException) {
        String test = "lock("+ expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.lock();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }
}
