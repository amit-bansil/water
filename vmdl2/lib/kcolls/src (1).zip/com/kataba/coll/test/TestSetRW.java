
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;

/** Tests various implementations of SetRW
 *
 * @author Chris Thiessen
 */
class TestSetRW
    extends TestSuite
{

    /** Testing mainline */
    public static void main(String[] args) {
    TestSetRW test = new TestSetRW();
        test.init(args);
    test.runTest();
    }

    /** Constructs */
    public TestSetRW() {
        super("setrw");
        addTest(new DiffTest());
        addTest(new EVTest());
    }

    public static class DiffTest
        extends DiffTest_SetRW
        implements CollTestData.Test
    {
        private CollTestData data;
        private CollectionEvent preEvent = null;
        private CollectionEvent postEvent = null;

        static final int ADD = CollectionRO.Listener.ADD;
        static final int REMOVE = CollectionRO.Listener.REMOVE;
        static final int REPLACE = CollectionRO.Listener.REPLACE;

        static final int WRAPPER_SET = 1;
        static final int HASH_SET = 2;
        static final int SYNCH_SET = 4;
        static final int JDK_SET = 5;

        private DiffTest() {
            super("diff");
            data = new CollTestData(this, CollTestData.Types.JDK_SET);
        }

        //
        // extends DiffTest
        //

        /** @see KTestCase#test() */
        protected void test() {
            data.testColls(new int[] {
                CollTestData.Types.HASH_SET
                , CollTestData.Types.WRAPPER_SET
                , CollTestData.Types.SYNCH_SET
                //, CollTestData.Types.JDK_SET
                , CollTestData.Types.ARRAY_HASH_SET
            });
        }

        /** @see DiffTest#resetModels() */
        protected void resetModels() {
            resetE();
            data.reset();

            // modelA
            modelA = (SetRW)data.collA;
            modelA.addListener(new CollectionListener(), null);
            switch(data.collType) {
            case CollTestData.Types.WRAPPER_SET:
            case CollTestData.Types.SYNCH_SET:
                break;
            default:
                ((AbstractCollectionRW)modelA).setPreListener(new PreListener());
            }

            // modelB
            modelB = (SetRW)data.collB;
        }

        /** @see DiffTest#postMethodTest(String) */
        protected boolean postMethodTest(String item) {
            if(postEvent != null)
                error(item, "missing post-event: ("+postEvent+")");
            postEvent = null;

            if(preEvent != null)
                error(item, "missing pre-event: ("+preEvent+")");
            preEvent = null;

            // compare the lists
            if(modelA.size() != modelB.size())
                error("Size differs: modelA("+modelA.size()+") modelB("+modelB.size()+")");
            for(IteratorRO itrA=modelA.iteratorRO(); itrA.hasNext(); ) {
                Object element = itrA.next();
                if(!modelB.contains(element)) {
                    error("Element:"+element+" in modelA:"+modelA+" but not in modelB:"+modelB);
                    return false;
                }
            }

            return super.postMethodTest(item);
        }

        /** @see CollTestData.Test#testColl() */
        public void testColl() {
            push("implements CollectionRW");

            push("add(Object)");
            resetModels();
            add(e());
            add(e());
            pop();

            push("clear()");
            resetModels();
            clear();
            add(e());
            add(e());
            add(e());
            clear();
            resetModels();
            add(e());
            add(e());
            add(e());
            add(e());
            clear();
            pop();

            push("addAll(CollectionRO)");
            resetModels();
            addAll((CollectionRO)null);
            addAll(coll(0));
            addAll(coll(3));
            addAll(coll(5));
            addAll(coll(0));
            addAll((CollectionRO)null);
            pop();

            push("remove(Object)");
            resetModels();
            remove(null);
            remove(e(0));
            remove(e(1));
            addAll(coll(4));
            remove(null);
            remove(e(0));
            remove(e(4));
            remove(e(3));
            pop();

            push("removeAll(CollectionRO)");
            resetModels();
            addAll(coll(4));
            removeAll(coll(new Object[] { e(0), e(2), e(3), e(5), e(7) }));
            resetModels();
            addAll(coll(3));
            removeAll(coll(new Object[] { e(2), e(1), e(0), e(2), e(1) }));
            resetModels();
            addAll(coll(new Object[] { e(0), e(1), e(0) }));
            resetModels();
            removeAll(coll(new Object[] { e(0), e(2), e(3), e(5), e(7) }));
            addAll(coll(new Object[] { e(0), e(1), e(0) }));
            removeAll(coll(new Object[] { e(0) }));
            pop();

            //  push("iterator()");
            //  resetModels();
            //  iterator();
            pop("implements CollectionRW");

            //*
            push("implements CollectionRO");

            push("size()");
            resetModels();
            size();
            add(e());
            size();
            addAll(coll(4));
            size();
            clear();
            size();
            pop();

            push("isEmpty()");
            resetModels();
            isEmpty();
            add(e());
            isEmpty();
            addAll(coll(4));
            isEmpty();
            clear();
            isEmpty();
            pop();

            push("contains(Object)");
            resetModels();
            contains(null);
            contains(e(0));
            addAll(coll(4));
            contains(null);
            contains(e(0));
            contains(e(3));
            contains(e(4));
            clear();
            contains(e(0));
            pop();

            push("get(Object)");
            resetModels();
            get(null);
            get(e());
            addAll(coll(1));
            get(null);
            get(e(0));
            get(e());
            addAll(coll(3));
            get(null);
            get(e(0));
            get(e());
            pop();

            push("get(Object)");
            resetModels();
            get(null);
            get(e());
            addAll(coll(1));
            get(null);
            get(e(0));
            get(e());
            addAll(coll(3));
            get(null);
            get(e(0));
            get(e());
            pop();

            push("toArray()");
            resetModels();
            toArray();
            addAll(coll(3));
            toArray();
            pop();

            pop("implements CollectionRO");
        }

        //
        // event handling
        //

        void expectEvent(int event, CollectionRO elementsA, CollectionRO elementsB) {
            if(preEvent != null) {
                error("missing pre event: "+preEvent);
                preEvent = null;
            }
            if(postEvent != null) {
                error("missing post event: "+postEvent);
                postEvent = null;
            }
            switch(data.collType) {
            case CollTestData.Types.WRAPPER_SET:
            case CollTestData.Types.SYNCH_SET:
                break;
            default:
                preEvent = new CollectionEvent(null, modelA, event, elementsA, elementsB);
            }
            postEvent = new CollectionEvent(null, modelA, event, elementsA, elementsB);
        }

        class CollectionEvent {
            Object sendback;
            CollectionRO source;
            int event;
            CollectionRO elementsA;
            CollectionRO elementsB;

            CollectionEvent(Object _sendback, CollectionRO _source
                            , int _event, CollectionRO _elementsA
                            , CollectionRO _elementsB) {
                sendback = _sendback;
                source = _source;
                event = _event;
                elementsA = _elementsA==null?null:new DefaultSetRO(_elementsA);
                elementsB = _elementsB==null?null:new DefaultSetRO(_elementsB);
            }

            public boolean equals(Object object) {
                if(object == null || !(object instanceof CollectionEvent))
                    return false;
                CollectionEvent e = (CollectionEvent)object;
                return sendback == e.sendback
                    && source == e.source
                    && event == e.event
                    && Util.equals(elementsA, e.elementsA)
                    && Util.equals(elementsB, e.elementsB)
                    //&& Util.equals(new DefaultSetRO(elementsA), new DefaultSetRO(e.elementsA))
                    //&& Util.equals(new DefaultSetRO(elementsB), new DefaultSetRO(e.elementsB))
                    ;
            }

            String event() {
                switch(event) {
                case ADD:
                    return "ADD";
                case REMOVE:
                    return "REMOVE";
                case REPLACE:
                    return "REPLACE";
                default:
                    error("Illegal event: " + event);
                    return "--ERROR--";
                }
            }

            public String toString() {
                return event()+","+elementsA+","+elementsB
                    +"("+elementsA.getClass()+")"
                    ;
            }
        }

        private class CollectionListener implements CollectionRO.Listener {
            /** @see CollectionRO.Listener#collectionEvent */
            public void collectionEvent(Object sendback, CollectionRO source
                                        , int event, CollectionRO elementsA
                                        , CollectionRO elementsB) {
                CollectionEvent actual
                    = new CollectionEvent(sendback, source, event, elementsA, elementsB);

                // were any events expected?
                if(postEvent == null) {
                    error("unexpected post ("+actual+")");
                    return;
                }

                // check it
                if(actual.source != postEvent.source)
                    error("Unexpected post source: " + actual.source);
                else if(!actual.equals(postEvent))
                    error("expected post ("+postEvent+"), got ("+actual+")");
                else
                    ok("post event ("+actual+")");

                postEvent = null;
            }
        }

        private class PreListener implements AbstractCollectionRW.PreListener {
            /** @see AbstractCollectionRW.PreListener#preEvent */
            public void preEvent(int event, CollectionRO elementsA, CollectionRO elementsB) {
                CollectionEvent actual
                    = new CollectionEvent(null, modelA, event, elementsA, elementsB);

                // were any events expected?
                if(preEvent == null) {
                    error("unexpected pre ("+actual+")");
                    return;
                }

                // check it
                if(actual.source != preEvent.source)
                    error("Unexpected pre source: " + actual.source);
                else if(!actual.equals(preEvent))
                    error("expected pre ("+preEvent+"), got ("+actual+")");
                else
                    ok("pre event ("+actual+")");

                preEvent = null;
            }
        }


        //
        // implements Collection
        //

        public boolean add(Object element) {
            if(!modelA.contains(element))
                expectEvent(ADD, collro(element), null);
            return super.add(element);
        }

        public boolean addAll(CollectionRO coll) {
            if(coll != null) {
                HashSetRW added = new HashSetRW();
                for(IteratorRO itr=coll.iteratorRO(); itr.hasNext(); ) {
                    Object element = itr.next();
                    if(!modelA.contains(element))
                        added.add(element);
                }
                if(added.size() > 0)
                    expectEvent(ADD, added, null);
            }
            return super.addAll(coll);
        }

        public boolean remove(Object element) {
            if(modelA.contains(element))
                expectEvent(REMOVE, collro(element), null);
            return super.remove(element);
        }

        public boolean removeAll(CollectionRO collection) {
            HashSetRW removed = new HashSetRW();
            for(IteratorRO itr=collection.iteratorRO(); itr.hasNext(); ) {
                Object element = itr.next();
                if(modelA.contains(element))
                    removed.add(element);
            }
            if(removed.size() > 0)
                expectEvent(REMOVE, removed, null);
            return super.removeAll(collection);
        }

        public void clear() {
            if(modelA.size() > 0)
                expectEvent(REMOVE, new DefaultListRO((SetRO)modelA), null);
            super.clear();
        }
    }

    /**
     *  Expected-value test for SetRW.
     */
    public static class EVTest
        extends EVTest_SetRW
        implements CollTestData.Test
    {
        private CollTestData data;
        
        public EVTest() {
            super("evtest");
            data = new CollTestData(this, CollTestData.Types.JDK_SET);
        }

        protected void resetData() {
            resetE();   // resets the 'lastElement' variable
            data.reset();
            _modelToTest = (SetRW)data.collA;
            //_modelToTest.addListener(new CollectionListener(), null);
        }

        /** @see KTestCase#test() */        
        protected void test() {
            data.testColls(new int[] {
                CollTestData.Types.HASH_SET
                , CollTestData.Types.WRAPPER_SET
                , CollTestData.Types.SYNCH_SET
                , CollTestData.Types.ARRAY_HASH_SET
            });                    
        }

        /** @see CollTestData.Test#testColl() */
        public void testColl() {

            push("empty set operations");
            resetData();
            
            Exception noSuchElementException = new NoSuchElementException();
            
            // remove from empty set
            push("empty remove()");
            remove(e(), false);
            remove(e(), (Exception)null);
            pop();

            // clear empty set
            push("empty clear()");
            clear();
            pop();
            
            // removeAll from empty set
            push("empty removeAll()");
            removeAll(coll(3), false);
            removeAll(coll(3), (Exception)null);
            removeAll(javaCollection(new String[]{"foo", "bar", "foobar"}), false);
            removeAll(javaCollection(3), (Exception)null);
            pop();

            push("empty retainAll()");
            retainAll(javaCollection(new String[]{"foo", "bar"}), false);
            retainAll(javaCollection(new String[]{"foo", "bar"}), (Exception)null);
            pop();

            push("empty get()");
            resetData();            
            get(e(), noSuchElementException);
            pop();

            push("empty contains()");
            contains(e(), false);
            contains(e(), (Exception)null);
            pop();

            push("empty size()");
            size(0);
            size((Exception)null);
            pop();

            push("empty containsAll");
            containsAll(coll(3), false);
            containsAll(coll(3), (Exception)null);
            pop();

            pop();  // push("empty set operations");


            push("isEmpty()");
            resetData();
            isEmpty(true);
            pop();
            
            push("add(Object)");
            resetData();
            
            add(e(1), true);
            add(e(2), true);
            add(e(3), true);

            add(e(), (Exception)null);
            
            pop();
            
            push("remove(Object)");
            resetData();
            add(e(1), true);
            add(e(2), true);
            add(e(3), true);
            remove(e(1), true);
            remove(e(2), true);
            remove(e(3), true);
            remove(e(4), false);
            remove(e(5), false);
            pop();

            push("addAll(java.util.Collection)");
            resetData();
            addAll((CollectionRO)coll(3), true);
            resetData();
            addAll(coll(6), (Exception)null);   // addAll(CollectionRO)
            resetData();
            addAll(javaCollection(4), true);
            resetData();
            addAll(javaCollection(4), (Exception)null);
            pop();

            push("iterator()");
            resetData();
            addAll(javaCollection(3), true);
            iterator((Exception)null);
            pop();
            

            push("clear()");
            resetData();
            addAll(javaCollection(3), true);            
            clear();
            size(0);
            pop();
            

            push("removeAll(java.util.Collection)");
            resetData();
            java.util.Collection javaColl = javaCollection(new String[]{"foo", "bar", "foobar"});
            addAll(javaColl, true);
            removeAll(javaColl, (Exception)null);
            size(0);
            pop();
            
            push("retainAll(java.util.Collection)");
            resetData();
            addAll(javaCollection(new Object[]{e(1), e(2), e(3), e(4)}), true);
            retainAll(javaCollection(new Object[]{e(1), e(4)}), true);
            containsAll(coll(new Object[]{e(1), e(4)}), true);      // these elements should remain
            containsAll(coll(new Object[]{e(2), e(3)}), false);     // these elements should be gone
            containsAll(coll(new Object[]{e(1), e(2), e(3), e(4)}), false); // original elements should not all be present
            pop();

            push("retainAll(CollectionRO)");
            resetData();
            addAll((CollectionRO)coll(new Object[]{e(1), e(2), e(3)}), true);
            retainAll((CollectionRO)coll(new Object[]{e(1)}), true);
            containsAll(coll(new Object[]{e(1)}), true);            // these elements should remain
            containsAll(coll(new Object[]{e(2), e(3)}), false);     // these elements should be gone
            containsAll(coll(new Object[]{e(1), e(2), e(3)}), false);     // original elements should not all be present
            
            try {
                retainAll((CollectionRO)null, false);
                error("did not get expected NPE calling retainAll(null)");
            } catch (NullPointerException npe) {
                ok("got expected NPE calling retainAll(null)");
            }
            pop();

            push("equals()");
            resetData();
            SetRW otherSet = new ArrayHashSetRW();
            java.util.Collection foobarCollection = javaCollection(new String[]{"foo", "bar", "foobar"});
            otherSet.addAll(foobarCollection);
            addAll(foobarCollection, true);
            equals(otherSet, true);
            equals(otherSet, (Exception)null);
            pop();

            push("get(Object)");
            resetData();
            addAll(coll(2), true);
            get(e(1), e(1));
            get(e(1), (Exception)null);
            pop();

            push("isEmpty()");
            resetData();
            isEmpty(true);
            add(e(1), true);
            isEmpty(false);
            pop();

            push("contains(Object)");
            resetData();
            addAll(coll(5), true);
            contains(e(1), true);
            contains(e(6), false);
            contains(e(2), (Exception)null);
            pop();

            push("size()");
            resetData();
            addAll(coll(10), true);
            size(10);
            resetE();
            removeAll(coll(5), true);
            size(5);
            resetData();
            addAll(coll(new String[]{"foo", "bar", "foobar"}), true);
            remove("foobar", true);
            remove("foo", true);
            size(1);
            remove("foobar", false);
            size(1);
            remove("bar", true);
            remove("bar", false);
            size(0);
            size((Exception)null);
            pop();

            /*
            push("toArray()");
            resetData();
            java.util.Collection foo = javaCollection(new String[]{"foo", "bar"});
            Object [] fooArray = foo.toArray();
            addAll(foo, true);
            toArray(fooArray);
            toArray((Exception)null);
            pop();
            */
            
            
            
        }
        


    }
}
