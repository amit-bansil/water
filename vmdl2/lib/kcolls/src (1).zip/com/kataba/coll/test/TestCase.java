package com.kataba.coll.test;

import com.kataba.util.*;


/** Test case class. */
public abstract class TestCase implements Runnable {

    private String name;
    private String lastMsg;
    

    public TestCase() {

    }

    public TestCase(String _name) {
        name = _name;
    }
    
    public String toString() {
        return name != null ? name : getClass().getName();
    }

    protected void startmsg(String msg) {
        Out.ln("----------------------------------------------------------");
        lastMsg = msg;
        Out.ln("START - " + msg);
        Out.ln();
    }

    protected void endmsg() {
        if (lastMsg != null) {
            endmsg(lastMsg);
        }
    }

    protected void endmsg(String msg) {
        Out.ln();
        Out.ln("\tEND - " + msg);
        Out.ln();
    }

    protected void msg(String msg) {
        Out.ln();
        Out.ln("**** " + msg);
        Out.ln();
    }

    //
    // Implements Runnable
    //
    public abstract void run();
    
}
