
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;

/** Runs all tests in this package
 *
 * @author Chris Thiessen
 */
public class TestAll
    extends TestSuite
{
    public static void main(String[] args) {
        new TestAll().start(args);
    }

    /** Constructs */
    public TestAll() {
        super("coll");
        addTest(new TestListCursorRW());
        addTest(new TestListRW());
        addTest(new TestSetRW());
        addTest(new TestMapRW());
        addTest(new TestIteratorRO());
        addTest(new TestIteratorRW());
        addTest(new TestListIterator());
        addTest(new TestListCursorRW());
        addTest(new ThreadTestMapRW());
    }
}
