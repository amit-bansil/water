
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** A DiffTest for the com.kataba.coll.MapRW class
 *
 * @author com.kataba.util.DiffTest_Gen
 */
public abstract class DiffTest_MapRW
    extends DiffTest
    implements MapRW
{
    protected MapRW modelA;
    protected MapRW modelB;

    /** Constructs */
    public DiffTest_MapRW(String _name) {
        super(_name);
    }

    public Object put(Object a, Object b) {
        String test = "put("+a+','+b+')';
        preMethodTest("put");

        Object modelARet = null;
        try {
            modelARet = modelA.put(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.put(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object remove(Object a) {
        String test = "remove("+a+')';
        preMethodTest("remove");

        Object modelARet = null;
        try {
            modelARet = modelA.remove(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.remove(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public java.util.Collection values() {
        String test = "values("+')';
        preMethodTest("values");

        java.util.Collection modelARet = null;
        try {
            modelARet = modelA.values();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        java.util.Collection modelBRet = null;
        try {
            modelBRet = modelB.values();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void clear() {
        String test = "clear("+')';
        preMethodTest("clear");

        try {
            modelA.clear();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.clear();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public java.util.Set keySet() {
        String test = "keySet("+')';
        preMethodTest("keySet");

        java.util.Set modelARet = null;
        try {
            modelARet = modelA.keySet();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        java.util.Set modelBRet = null;
        try {
            modelBRet = modelB.keySet();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public java.util.Set entrySet() {
        String test = "entrySet("+')';
        preMethodTest("entrySet");

        java.util.Set modelARet = null;
        try {
            modelARet = modelA.entrySet();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        java.util.Set modelBRet = null;
        try {
            modelBRet = modelB.entrySet();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void putAll(MapRO a) {
        String test = "putAll("+a+')';
        preMethodTest("putAll");

        try {
            modelA.putAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.putAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public void putAll(java.util.Map a) {
        String test = "putAll("+a+')';
        preMethodTest("putAll");

        try {
            modelA.putAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.putAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public IteratorRW keyIteratorRW() {
        String test = "keyIteratorRW("+')';
        preMethodTest("keyIteratorRW");

        IteratorRW modelARet = null;
        try {
            modelARet = modelA.keyIteratorRW();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        IteratorRW modelBRet = null;
        try {
            modelBRet = modelB.keyIteratorRW();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public MapRW.EntryRW getEntryRW(Object a) {
        String test = "getEntryRW("+a+')';
        preMethodTest("getEntryRW");

        MapRW.EntryRW modelARet = null;
        try {
            modelARet = modelA.getEntryRW(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        MapRW.EntryRW modelBRet = null;
        try {
            modelBRet = modelB.getEntryRW(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public SetRW entrySetRW() {
        String test = "entrySetRW("+')';
        preMethodTest("entrySetRW");

        SetRW modelARet = null;
        try {
            modelARet = modelA.entrySetRW();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        SetRW modelBRet = null;
        try {
            modelBRet = modelB.entrySetRW();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public SetRW keySetRW() {
        String test = "keySetRW("+')';
        preMethodTest("keySetRW");

        SetRW modelARet = null;
        try {
            modelARet = modelA.keySetRW();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        SetRW modelBRet = null;
        try {
            modelBRet = modelB.keySetRW();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public CollectionRW valuesRW() {
        String test = "valuesRW("+')';
        preMethodTest("valuesRW");

        CollectionRW modelARet = null;
        try {
            modelARet = modelA.valuesRW();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        CollectionRW modelBRet = null;
        try {
            modelBRet = modelB.valuesRW();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int hashCode() {
        String test = "hashCode("+')';
        preMethodTest("hashCode");

        int modelARet = 0;
        try {
            modelARet = modelA.hashCode();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.hashCode();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean equals(Object a) {
        String test = "equals("+a+')';
        preMethodTest("equals");

        boolean modelARet = false;
        try {
            modelARet = modelA.equals(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.equals(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object get(Object a) {
        String test = "get("+a+')';
        preMethodTest("get");

        Object modelARet = null;
        try {
            modelARet = modelA.get(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.get(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int size() {
        String test = "size("+')';
        preMethodTest("size");

        int modelARet = 0;
        try {
            modelARet = modelA.size();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.size();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean isEmpty() {
        String test = "isEmpty("+')';
        preMethodTest("isEmpty");

        boolean modelARet = false;
        try {
            modelARet = modelA.isEmpty();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.isEmpty();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean containsValue(Object a) {
        String test = "containsValue("+a+')';
        preMethodTest("containsValue");

        boolean modelARet = false;
        try {
            modelARet = modelA.containsValue(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.containsValue(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean containsKey(Object a) {
        String test = "containsKey("+a+')';
        preMethodTest("containsKey");

        boolean modelARet = false;
        try {
            modelARet = modelA.containsKey(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.containsKey(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void addListener(MapRO.Listener a, Object b) {
        String test = "addListener("+a+','+b+')';
        preMethodTest("addListener");

        try {
            modelA.addListener(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.addListener(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public void removeListener(MapRO.Listener a) {
        String test = "removeListener("+a+')';
        preMethodTest("removeListener");

        try {
            modelA.removeListener(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.removeListener(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public IteratorRO keyIteratorRO() {
        String test = "keyIteratorRO("+')';
        preMethodTest("keyIteratorRO");

        IteratorRO modelARet = null;
        try {
            modelARet = modelA.keyIteratorRO();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        IteratorRO modelBRet = null;
        try {
            modelBRet = modelB.keyIteratorRO();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public MapRO.EntryRO getEntryRO(Object a) {
        String test = "getEntryRO("+a+')';
        preMethodTest("getEntryRO");

        MapRO.EntryRO modelARet = null;
        try {
            modelARet = modelA.getEntryRO(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        MapRO.EntryRO modelBRet = null;
        try {
            modelBRet = modelB.getEntryRO(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public SetRO entrySetRO() {
        String test = "entrySetRO("+')';
        preMethodTest("entrySetRO");

        SetRO modelARet = null;
        try {
            modelARet = modelA.entrySetRO();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        SetRO modelBRet = null;
        try {
            modelBRet = modelB.entrySetRO();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public SetRO keySetRO() {
        String test = "keySetRO("+')';
        preMethodTest("keySetRO");

        SetRO modelARet = null;
        try {
            modelARet = modelA.keySetRO();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        SetRO modelBRet = null;
        try {
            modelBRet = modelB.keySetRO();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public CollectionRO valuesRO() {
        String test = "valuesRO("+')';
        preMethodTest("valuesRO");

        CollectionRO modelARet = null;
        try {
            modelARet = modelA.valuesRO();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        CollectionRO modelBRet = null;
        try {
            modelBRet = modelB.valuesRO();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object lock() {
        String test = "lock("+')';
        preMethodTest("lock");

        Object modelARet = null;
        try {
            modelARet = modelA.lock();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.lock();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }
}
