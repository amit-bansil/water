
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** An EVTest for the com.kataba.coll.ListRW class
 *  For each method in the class, an expected-value test 
 *  method and an expected-exception test method is generated.
 *
 * @author com.kataba.util.EVTest_Gen
 */
public abstract class EVTest_ListRW
    extends EVTest
{

    protected ListRW _modelToTest;
    protected Exception exception;

    /** Constructs */
    public EVTest_ListRW(String _name) {
        super(_name);
    }

    public boolean addAll(int a, java.util.Collection b, boolean expectedValue) {
        String test = "addAll("+a+','+b+','+ expectedValue + ")";

        boolean ret = _modelToTest.addAll(a, b);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean addAll(int a, java.util.Collection b, Exception expectedException) {
        String test = "addAll("+a+','+b+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.addAll(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean addAll(int a, CollectionRO b, boolean expectedValue) {
        String test = "addAll("+a+','+b+','+ expectedValue + ")";

        boolean ret = _modelToTest.addAll(a, b);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean addAll(int a, CollectionRO b, Exception expectedException) {
        String test = "addAll("+a+','+b+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.addAll(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void add(int a, Object b) {
        add(a, b, (Exception)null);
    }

    public void add(int a, Object b, Exception expectedException) {
        String test = "add("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.add(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public Object remove(int a, Object expectedValue) {
        String test = "remove("+a+','+ expectedValue + ")";

        Object ret = _modelToTest.remove(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object remove(int a, Exception expectedException) {
        String test = "remove("+a+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.remove(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object set(int a, Object b, Object expectedValue) {
        String test = "set("+a+','+b+','+ expectedValue + ")";

        Object ret = _modelToTest.set(a, b);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object set(int a, Object b, Exception expectedException) {
        String test = "set("+a+','+b+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.set(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void removeAll(com.kataba.util.ArrayRO_int a) {
        removeAll(a, (Exception)null);
    }

    public void removeAll(com.kataba.util.ArrayRO_int a, Exception expectedException) {
        String test = "removeAll("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.removeAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void retainAll(com.kataba.util.ArrayRO_int a) {
        retainAll(a, (Exception)null);
    }

    public void retainAll(com.kataba.util.ArrayRO_int a, Exception expectedException) {
        String test = "retainAll("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.retainAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public java.util.List subList(int a, int b, Object expectedValue) {
        String test = "subList("+a+','+b+','+ expectedValue + ")";

        java.util.List ret = _modelToTest.subList(a, b);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public java.util.List subList(int a, int b, Exception expectedException) {
        String test = "subList("+a+','+b+',' + expectedException + ")";
        java.util.List ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.subList(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void removeRange(int a, int b) {
        removeRange(a, b, (Exception)null);
    }

    public void removeRange(int a, int b, Exception expectedException) {
        String test = "removeRange("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.removeRange(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public java.util.ListIterator listIterator(int a, Object expectedValue) {
        String test = "listIterator("+a+','+ expectedValue + ")";

        java.util.ListIterator ret = _modelToTest.listIterator(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public java.util.ListIterator listIterator(int a, Exception expectedException) {
        String test = "listIterator("+a+',' + expectedException + ")";
        java.util.ListIterator ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listIterator(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public java.util.ListIterator listIterator(Object expectedValue) {
        String test = "listIterator("+ expectedValue + ")";

        java.util.ListIterator ret = _modelToTest.listIterator();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public java.util.ListIterator listIterator(Exception expectedException) {
        String test = "listIterator("+ expectedException + ")";
        java.util.ListIterator ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listIterator();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void swap(int a, int b) {
        swap(a, b, (Exception)null);
    }

    public void swap(int a, int b, Exception expectedException) {
        String test = "swap("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.swap(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void move(int a, int b) {
        move(a, b, (Exception)null);
    }

    public void move(int a, int b, Exception expectedException) {
        String test = "move("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.move(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public ListCursorRW listCursorRW(int a, Object expectedValue) {
        String test = "listCursorRW("+a+','+ expectedValue + ")";

        ListCursorRW ret = _modelToTest.listCursorRW(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListCursorRW listCursorRW(int a, Exception expectedException) {
        String test = "listCursorRW("+a+',' + expectedException + ")";
        ListCursorRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listCursorRW(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListCursorRW listCursorRW(Object expectedValue) {
        String test = "listCursorRW("+ expectedValue + ")";

        ListCursorRW ret = _modelToTest.listCursorRW();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListCursorRW listCursorRW(Exception expectedException) {
        String test = "listCursorRW("+ expectedException + ")";
        ListCursorRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listCursorRW();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListRW subListRW(int a, int b, Object expectedValue) {
        String test = "subListRW("+a+','+b+','+ expectedValue + ")";

        ListRW ret = _modelToTest.subListRW(a, b);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListRW subListRW(int a, int b, Exception expectedException) {
        String test = "subListRW("+a+','+b+',' + expectedException + ")";
        ListRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.subListRW(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListIteratorRW listIteratorRW(Object expectedValue) {
        String test = "listIteratorRW("+ expectedValue + ")";

        ListIteratorRW ret = _modelToTest.listIteratorRW();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListIteratorRW listIteratorRW(Exception expectedException) {
        String test = "listIteratorRW("+ expectedException + ")";
        ListIteratorRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listIteratorRW();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListIteratorRW listIteratorRW(int a, Object expectedValue) {
        String test = "listIteratorRW("+a+','+ expectedValue + ")";

        ListIteratorRW ret = _modelToTest.listIteratorRW(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListIteratorRW listIteratorRW(int a, Exception expectedException) {
        String test = "listIteratorRW("+a+',' + expectedException + ")";
        ListIteratorRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listIteratorRW(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int hashCode(int expectedValue) {
        String test = "hashCode("+ expectedValue + ")";

        int ret = _modelToTest.hashCode();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int hashCode(Exception expectedException) {
        String test = "hashCode("+ expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.hashCode();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean equals(Object a, boolean expectedValue) {
        String test = "equals("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.equals(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean equals(Object a, Exception expectedException) {
        String test = "equals("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.equals(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int indexOf(Object a, int expectedValue) {
        String test = "indexOf("+a+','+ expectedValue + ")";

        int ret = _modelToTest.indexOf(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int indexOf(Object a, Exception expectedException) {
        String test = "indexOf("+a+',' + expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.indexOf(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int indexOf(Object a, int b, boolean c, int expectedValue) {
        String test = "indexOf("+a+','+b+','+c+','+ expectedValue + ")";

        int ret = _modelToTest.indexOf(a, b, c);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int indexOf(Object a, int b, boolean c, Exception expectedException) {
        String test = "indexOf("+a+','+b+','+c+',' + expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.indexOf(a, b, c);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int lastIndexOf(Object a, int expectedValue) {
        String test = "lastIndexOf("+a+','+ expectedValue + ")";

        int ret = _modelToTest.lastIndexOf(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int lastIndexOf(Object a, Exception expectedException) {
        String test = "lastIndexOf("+a+',' + expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.lastIndexOf(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object get(int a, Object expectedValue) {
        String test = "get("+a+','+ expectedValue + ")";

        Object ret = _modelToTest.get(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object get(int a, Exception expectedException) {
        String test = "get("+a+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.get(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void addListener(ListRO.Listener a, Object b) {
        addListener(a, b, (Exception)null);
    }

    public void addListener(ListRO.Listener a, Object b, Exception expectedException) {
        String test = "addListener("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.addListener(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void removeListener(ListRO.Listener a) {
        removeListener(a, (Exception)null);
    }

    public void removeListener(ListRO.Listener a, Exception expectedException) {
        String test = "removeListener("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.removeListener(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public com.kataba.util.ArrayRO_int indexesOf(CollectionRO a, Object expectedValue) {
        String test = "indexesOf("+a+','+ expectedValue + ")";

        com.kataba.util.ArrayRO_int ret = _modelToTest.indexesOf(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public com.kataba.util.ArrayRO_int indexesOf(CollectionRO a, Exception expectedException) {
        String test = "indexesOf("+a+',' + expectedException + ")";
        com.kataba.util.ArrayRO_int ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.indexesOf(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListCursorRO listCursorRO(Object expectedValue) {
        String test = "listCursorRO("+ expectedValue + ")";

        ListCursorRO ret = _modelToTest.listCursorRO();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListCursorRO listCursorRO(Exception expectedException) {
        String test = "listCursorRO("+ expectedException + ")";
        ListCursorRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listCursorRO();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListCursorRO listCursorRO(int a, Object expectedValue) {
        String test = "listCursorRO("+a+','+ expectedValue + ")";

        ListCursorRO ret = _modelToTest.listCursorRO(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListCursorRO listCursorRO(int a, Exception expectedException) {
        String test = "listCursorRO("+a+',' + expectedException + ")";
        ListCursorRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listCursorRO(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListRO subListRO(int a, int b, Object expectedValue) {
        String test = "subListRO("+a+','+b+','+ expectedValue + ")";

        ListRO ret = _modelToTest.subListRO(a, b);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListRO subListRO(int a, int b, Exception expectedException) {
        String test = "subListRO("+a+','+b+',' + expectedException + ")";
        ListRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.subListRO(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListIteratorRO listIteratorRO(Object expectedValue) {
        String test = "listIteratorRO("+ expectedValue + ")";

        ListIteratorRO ret = _modelToTest.listIteratorRO();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListIteratorRO listIteratorRO(Exception expectedException) {
        String test = "listIteratorRO("+ expectedException + ")";
        ListIteratorRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listIteratorRO();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public ListIteratorRO listIteratorRO(int a, Object expectedValue) {
        String test = "listIteratorRO("+a+','+ expectedValue + ")";

        ListIteratorRO ret = _modelToTest.listIteratorRO(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public ListIteratorRO listIteratorRO(int a, Exception expectedException) {
        String test = "listIteratorRO("+a+',' + expectedException + ")";
        ListIteratorRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.listIteratorRO(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object get(Object a, Object expectedValue) {
        String test = "get("+a+','+ expectedValue + ")";

        Object ret = _modelToTest.get(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object get(Object a, Exception expectedException) {
        String test = "get("+a+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.get(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean contains(Object a, boolean expectedValue) {
        String test = "contains("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.contains(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean contains(Object a, Exception expectedException) {
        String test = "contains("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.contains(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int size(int expectedValue) {
        String test = "size("+ expectedValue + ")";

        int ret = _modelToTest.size();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int size(Exception expectedException) {
        String test = "size("+ expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.size();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object[] toArray(Object expectedValue) {
        String test = "toArray("+ expectedValue + ")";

        Object[] ret = _modelToTest.toArray();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object[] toArray(Exception expectedException) {
        String test = "toArray("+ expectedException + ")";
        Object[] ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.toArray();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object[] toArray(Object[] a, Object expectedValue) {
        String test = "toArray("+a+','+ expectedValue + ")";

        Object[] ret = _modelToTest.toArray(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object[] toArray(Object[] a, Exception expectedException) {
        String test = "toArray("+a+',' + expectedException + ")";
        Object[] ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.toArray(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean isEmpty(boolean expectedValue) {
        String test = "isEmpty("+ expectedValue + ")";

        boolean ret = _modelToTest.isEmpty();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean isEmpty(Exception expectedException) {
        String test = "isEmpty("+ expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.isEmpty();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean containsAll(CollectionRO a, boolean expectedValue) {
        String test = "containsAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.containsAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean containsAll(CollectionRO a, Exception expectedException) {
        String test = "containsAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.containsAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean containsAll(java.util.Collection a, boolean expectedValue) {
        String test = "containsAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.containsAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean containsAll(java.util.Collection a, Exception expectedException) {
        String test = "containsAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.containsAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void addListener(CollectionRO.Listener a, Object b) {
        addListener(a, b, (Exception)null);
    }

    public void addListener(CollectionRO.Listener a, Object b, Exception expectedException) {
        String test = "addListener("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.addListener(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void removeListener(CollectionRO.Listener a) {
        removeListener(a, (Exception)null);
    }

    public void removeListener(CollectionRO.Listener a, Exception expectedException) {
        String test = "removeListener("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.removeListener(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public IteratorRO iteratorRO(Object expectedValue) {
        String test = "iteratorRO("+ expectedValue + ")";

        IteratorRO ret = _modelToTest.iteratorRO();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public IteratorRO iteratorRO(Exception expectedException) {
        String test = "iteratorRO("+ expectedException + ")";
        IteratorRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.iteratorRO();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object lock(Object expectedValue) {
        String test = "lock("+ expectedValue + ")";

        Object ret = _modelToTest.lock();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object lock(Exception expectedException) {
        String test = "lock("+ expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.lock();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean addAll(CollectionRO a, boolean expectedValue) {
        String test = "addAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.addAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean addAll(CollectionRO a, Exception expectedException) {
        String test = "addAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.addAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean addAll(java.util.Collection a, boolean expectedValue) {
        String test = "addAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.addAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean addAll(java.util.Collection a, Exception expectedException) {
        String test = "addAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.addAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean add(Object a, boolean expectedValue) {
        String test = "add("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.add(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean add(Object a, Exception expectedException) {
        String test = "add("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.add(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public java.util.Iterator iterator(Object expectedValue) {
        String test = "iterator("+ expectedValue + ")";

        java.util.Iterator ret = _modelToTest.iterator();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public java.util.Iterator iterator(Exception expectedException) {
        String test = "iterator("+ expectedException + ")";
        java.util.Iterator ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.iterator();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean remove(Object a, boolean expectedValue) {
        String test = "remove("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.remove(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean remove(Object a, Exception expectedException) {
        String test = "remove("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.remove(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void clear() {
        clear((Exception)null);
    }

    public void clear(Exception expectedException) {
        String test = "clear("+ expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.clear();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public boolean removeAll(java.util.Collection a, boolean expectedValue) {
        String test = "removeAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.removeAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean removeAll(java.util.Collection a, Exception expectedException) {
        String test = "removeAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.removeAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean removeAll(CollectionRO a, boolean expectedValue) {
        String test = "removeAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.removeAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean removeAll(CollectionRO a, Exception expectedException) {
        String test = "removeAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.removeAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean retainAll(java.util.Collection a, boolean expectedValue) {
        String test = "retainAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.retainAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean retainAll(java.util.Collection a, Exception expectedException) {
        String test = "retainAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.retainAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean retainAll(CollectionRO a, boolean expectedValue) {
        String test = "retainAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.retainAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean retainAll(CollectionRO a, Exception expectedException) {
        String test = "retainAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.retainAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public IteratorRW iteratorRW(Object expectedValue) {
        String test = "iteratorRW("+ expectedValue + ")";

        IteratorRW ret = _modelToTest.iteratorRW();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public IteratorRW iteratorRW(Exception expectedException) {
        String test = "iteratorRW("+ expectedException + ")";
        IteratorRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.iteratorRW();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }
}
