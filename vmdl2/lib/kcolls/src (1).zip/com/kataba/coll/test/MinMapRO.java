
package com.kataba.coll.test;

import com.kataba.coll.*;

public class MinMapRO extends AbstractMapRO {
    /** @see MapRO#get(Object) */
    public Object get(Object key) {
        return null;
    }

    /** @see MapRO#size() */
    public int size() {
        return 0;
    }

    /** Returns an IteratorRO over the values of the MapRO */
    public IteratorRO keyIteratorRO() {
        return null;
    }
}
