
package com.kataba.coll.test;

import com.kataba.coll.*;

public class MinMapRW extends AbstractMapRW {
    /** @see MapRO#get(Object) */
    public Object get(Object key) {
        return null;
    }

    /** @see MapRO#size() */
    public int size() {
        return 0;
    }

    /** @see MapRW#keyIteratorRW() */
    public IteratorRW keyIteratorRW() {
        return null;
    }

    /** @see MapRW#remove(Object) */
    public Object remove(Object key) {
        return null;
    }

    /** @see MapRW#put(Object,Object) */
    public Object put(Object key, Object value) {
        return null;
    }

    /** @see MapRO#clear() */
    public void clear() {
    }
}
