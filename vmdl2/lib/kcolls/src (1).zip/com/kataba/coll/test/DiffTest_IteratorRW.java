
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** A DiffTest for the com.kataba.coll.IteratorRW class
 *
 * @author com.kataba.util.DiffTest_Gen
 */
public abstract class DiffTest_IteratorRW
    extends DiffTest
    implements IteratorRW
{
    protected IteratorRW modelA;
    protected IteratorRW modelB;

    /** Constructs */
    public DiffTest_IteratorRW(String _name) {
        super(_name);
    }

    public void remove() {
        String test = "remove("+')';
        preMethodTest("remove");

        try {
            modelA.remove();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.remove();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public Object next() {
        String test = "next("+')';
        preMethodTest("next");

        Object modelARet = null;
        try {
            modelARet = modelA.next();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.next();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean hasNext() {
        String test = "hasNext("+')';
        preMethodTest("hasNext");

        boolean modelARet = false;
        try {
            modelARet = modelA.hasNext();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.hasNext();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object lock() {
        String test = "lock("+')';
        preMethodTest("lock");

        Object modelARet = null;
        try {
            modelARet = modelA.lock();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.lock();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }
}
