
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

public class TestHashMap
    implements MapRO.Listener
{
    public static void main(String[] args) {
	new TestHashMap().main();
    }

    public void main() {
	HashMapRW map = new HashMapRW(HashMapRW.DEFAULT_IDENTIFIER
                                      , HashMapRW.DEFAULT_LOAD_FACTOR
                                      , 1);

	map.addListener(this, null);

	Out.ln("\nempty");
	print(map, "   ");

	Out.ln("\na:A");
	map.put("a", "A");
	print(map, "   ");

	Out.ln("\na:A b:B");
	map.put("b", "B");
	print(map, "   ");

	Out.ln("\na:A b:bb");
	map.put("b", "bb");
	print(map, "   ");

	Out.ln("\nb:bb");
	map.remove("a");
	print(map, "   ");

	Out.ln("\nb:bb c:null d:null");
	//map.putAll(new DefaultListRO(new Object[] { "c", "thekeyofathousandyears" }));
	print(map, "   ");

	Out.ln("\nb:bb c:null d:null");
	//map.putAll(new DefaultListRO(new Object[] { "c", "thekeyofathousandyears" }));
	print(map, "   ");

	Out.ln("\nclear()");
	map.clear();
	print(map, "   ");
    }


    /** @see MapRO.Listener#mapEvent */
    public void mapEvent(Object sendback, MapRO source, int event
			 , ListRO elements, ListRO oldValues, Object noValue) {
	String eventString = "";
	switch(event) {
	case MapRO.Listener.ADD:
	    eventString += "ADD";
	    break;
	    //case MapListener.CHANGE:
	    //eventString += "CHANGE";
	    //break;
	case MapRO.Listener.REMOVE:
	    eventString += "REMOVE";
	    break;
	}

	System.out.print("   event:" + eventString);

	// 'elements'
	if(elements == null)
	    System.out.print("  elements:null");
	else {
	    System.out.print("  elements:{ ");
	    for(int i=0; i<elements.size(); i++) {
		Object obj = elements.get(i);
		System.out.print((obj!=null)?("'"+obj+"' "):"null");
	    }
	    System.out.print("}");
	}

	// 'oldValues'
	if(oldValues == null)
	    System.out.print("  oldValues:null");
	else {
	    System.out.print("  oldValues:{ ");
	    for(int i=0; i<oldValues.size(); i++) {
		Object obj = oldValues.get(i);
		System.out.print((obj!=null)?("'"+obj+"' "):"null");
	    }
	    System.out.print("}");
	}

	// 'newValues'
	/*
	if(newValues == null)
	    System.out.print("  newValues:null");
	else {
	    System.out.print("  newValues:{");
	    for(int i=0; i<newValues.size(); i++) {
		Object obj = newValues.get(i);
		System.out.print((obj!=null)?("'"+obj+"' "):"null");
	    }
	    System.out.print("}");
	}
	*/

	Out.ln();
    }

    public static void print(MapRO map, String pre) {
	Out.ln(pre + "size: " + map.size());
	for(IteratorRO itr=map.keyIteratorRO(); itr.hasNext(); ) {
	    Object key = itr.next();
	    Object value = map.get(key);
	    Out.ln(pre + "'" + key + "': '" + value + "'");
	}
    }
}
