
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** An EVTest for the com.kataba.coll.SetRW class
 *  For each method in the class, an expected-value test 
 *  method and an expected-exception test method is generated.
 *
 * @author com.kataba.util.EVTest_Gen
 */
public abstract class EVTest_SetRW
    extends EVTest
{

    protected SetRW _modelToTest;
    protected Exception exception;

    /** Constructs */
    public EVTest_SetRW(String _name) {
        super(_name);
    }

    public boolean addAll(CollectionRO a, boolean expectedValue) {
        String test = "addAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.addAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean addAll(CollectionRO a, Exception expectedException) {
        String test = "addAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.addAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean addAll(java.util.Collection a, boolean expectedValue) {
        String test = "addAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.addAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean addAll(java.util.Collection a, Exception expectedException) {
        String test = "addAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.addAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean add(Object a, boolean expectedValue) {
        String test = "add("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.add(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean add(Object a, Exception expectedException) {
        String test = "add("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.add(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public java.util.Iterator iterator(Object expectedValue) {
        String test = "iterator("+ expectedValue + ")";

        java.util.Iterator ret = _modelToTest.iterator();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public java.util.Iterator iterator(Exception expectedException) {
        String test = "iterator("+ expectedException + ")";
        java.util.Iterator ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.iterator();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean remove(Object a, boolean expectedValue) {
        String test = "remove("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.remove(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean remove(Object a, Exception expectedException) {
        String test = "remove("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.remove(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void clear() {
        clear((Exception)null);
    }

    public void clear(Exception expectedException) {
        String test = "clear("+ expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.clear();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public boolean removeAll(java.util.Collection a, boolean expectedValue) {
        String test = "removeAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.removeAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean removeAll(java.util.Collection a, Exception expectedException) {
        String test = "removeAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.removeAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean removeAll(CollectionRO a, boolean expectedValue) {
        String test = "removeAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.removeAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean removeAll(CollectionRO a, Exception expectedException) {
        String test = "removeAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.removeAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean retainAll(java.util.Collection a, boolean expectedValue) {
        String test = "retainAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.retainAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean retainAll(java.util.Collection a, Exception expectedException) {
        String test = "retainAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.retainAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean retainAll(CollectionRO a, boolean expectedValue) {
        String test = "retainAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.retainAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean retainAll(CollectionRO a, Exception expectedException) {
        String test = "retainAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.retainAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public IteratorRW iteratorRW(Object expectedValue) {
        String test = "iteratorRW("+ expectedValue + ")";

        IteratorRW ret = _modelToTest.iteratorRW();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public IteratorRW iteratorRW(Exception expectedException) {
        String test = "iteratorRW("+ expectedException + ")";
        IteratorRW ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.iteratorRW();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int hashCode(int expectedValue) {
        String test = "hashCode("+ expectedValue + ")";

        int ret = _modelToTest.hashCode();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int hashCode(Exception expectedException) {
        String test = "hashCode("+ expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.hashCode();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean equals(Object a, boolean expectedValue) {
        String test = "equals("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.equals(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean equals(Object a, Exception expectedException) {
        String test = "equals("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.equals(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object get(Object a, Object expectedValue) {
        String test = "get("+a+','+ expectedValue + ")";

        Object ret = _modelToTest.get(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object get(Object a, Exception expectedException) {
        String test = "get("+a+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.get(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean contains(Object a, boolean expectedValue) {
        String test = "contains("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.contains(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean contains(Object a, Exception expectedException) {
        String test = "contains("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.contains(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int size(int expectedValue) {
        String test = "size("+ expectedValue + ")";

        int ret = _modelToTest.size();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int size(Exception expectedException) {
        String test = "size("+ expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.size();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object[] toArray(Object [] expectedValue) {
        String test = "toArray("+ expectedValue + ")";

        Object[] ret = _modelToTest.toArray();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object[] toArray(Exception expectedException) {
        String test = "toArray("+ expectedException + ")";
        Object[] ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.toArray();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object[] toArray(Object[] a, Object [] expectedValue) {
        String test = "toArray("+a+','+ expectedValue + ")";

        Object[] ret = _modelToTest.toArray(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object[] toArray(Object[] a, Exception expectedException) {
        String test = "toArray("+a+',' + expectedException + ")";
        Object[] ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.toArray(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean isEmpty(boolean expectedValue) {
        String test = "isEmpty("+ expectedValue + ")";

        boolean ret = _modelToTest.isEmpty();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean isEmpty(Exception expectedException) {
        String test = "isEmpty("+ expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.isEmpty();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean containsAll(CollectionRO a, boolean expectedValue) {
        String test = "containsAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.containsAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean containsAll(CollectionRO a, Exception expectedException) {
        String test = "containsAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.containsAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean containsAll(java.util.Collection a, boolean expectedValue) {
        String test = "containsAll("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.containsAll(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean containsAll(java.util.Collection a, Exception expectedException) {
        String test = "containsAll("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.containsAll(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void addListener(CollectionRO.Listener a, Object b) {
        addListener(a, b, (Exception)null);
    }

    public void addListener(CollectionRO.Listener a, Object b, Exception expectedException) {
        String test = "addListener("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.addListener(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void removeListener(CollectionRO.Listener a) {
        removeListener(a, (Exception)null);
    }

    public void removeListener(CollectionRO.Listener a, Exception expectedException) {
        String test = "removeListener("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.removeListener(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public IteratorRO iteratorRO(Object expectedValue) {
        String test = "iteratorRO("+ expectedValue + ")";

        IteratorRO ret = _modelToTest.iteratorRO();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public IteratorRO iteratorRO(Exception expectedException) {
        String test = "iteratorRO("+ expectedException + ")";
        IteratorRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.iteratorRO();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object lock(Object expectedValue) {
        String test = "lock("+ expectedValue + ")";

        Object ret = _modelToTest.lock();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object lock(Exception expectedException) {
        String test = "lock("+ expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.lock();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public SetRO xor(SetRO a, Object expectedValue) {
        String test = "xor("+a+','+ expectedValue + ")";

        SetRO ret = _modelToTest.xor(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public SetRO xor(SetRO a, Exception expectedException) {
        String test = "xor("+a+',' + expectedException + ")";
        SetRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.xor(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public SetRO union(SetRO a, Object expectedValue) {
        String test = "union("+a+','+ expectedValue + ")";

        SetRO ret = _modelToTest.union(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public SetRO union(SetRO a, Exception expectedException) {
        String test = "union("+a+',' + expectedException + ")";
        SetRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.union(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public SetRO intersection(SetRO a, Object expectedValue) {
        String test = "intersection("+a+','+ expectedValue + ")";

        SetRO ret = _modelToTest.intersection(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public SetRO intersection(SetRO a, Exception expectedException) {
        String test = "intersection("+a+',' + expectedException + ")";
        SetRO ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.intersection(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }
}
