package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;


/** Tests various implementations of MapRW
 *
 * @author Chris Thiessen
 */
class TestMapRW
    extends TestSuite
{

    static final int HASHMAPRW = 1;
    static final int ARRAYHASHMAPRW = 2;

    /** Testing mainline */
    public static void main(String[] args) {
	new TestMapRW().start(args);
    }

    /** Constructs */
    public TestMapRW() {
        super("maprw");
        addTest(new DiffTest());
        addTest(new EVTest());
    }

    public static class DiffTest
        extends DiffTest_MapRW
    {
        //private MapEvent preEvent = null;
        private MapEvent postEvent = null;

        private static final int ADD = MapRO.Listener.ADD;
        private static final int REMOVE = MapRO.Listener.REMOVE;

        private int mapType;

        public static void main(String[] args) {
            new DiffTest().start(args);
        }

        private DiffTest() {
            super("diff");
        }

        protected void resetModels() {
            resetE();
            switch(mapType) {
            case HASHMAPRW:
                modelA = new HashMapRW();
                break;
            case ARRAYHASHMAPRW:
                modelA = new ArrayHashMapRW();
                break;
            default:
                throw new IllegalStateException("mapType: "+mapType);
            }
            modelA.addListener(new PostListener(), null);

            modelB = new MapToMapRW(new java.util.HashMap());
            //modelB = new ArrayHashMapRW();
        }

        public void test() {
            push("HashMapRW");
            mapType = HASHMAPRW;
            testType();
            pop();

            push("ArrayHashMapRW");
            mapType = ARRAYHASHMAPRW;
            testType();
            pop();
        }

        private void testType() {
            resetModels();
            put("0", "0");
            put("0", "1");

            resetModels();
            put("0", "0");
            put("0", "1");
            remove("0");
            put("0", "0");
            put("0", "1");
            clear();

            put("1", "2");
            clear();

        }

        /** @see DiffTest#postMethodTest(String) */
        protected boolean postMethodTest(String item) {
            if(postEvent != null)
                error(item, "missing post-event: ("+postEvent+")");
            postEvent = null;

            /*
            if(preEvent != null)
                error(item, "missing pre-event: ("+preEvent+")");
            preEvent = null;
            */

            // compare the lists
            if(modelA.size() != modelB.size())
                error("Size differs: modelA("+modelA.size()+") modelB("+modelB.size()+")");
            for(IteratorRO itr=modelA.keyIteratorRO(); itr.hasNext(); ) {
                Object key = itr.next();
                if(!modelA.containsKey(key)) {
                    error("modelA has key '"+key+"' but doesn't");
                    return false;
                }
                if(!modelB.containsKey(key)) {
                    error("modelA has key '"+key+"' but modelB does not");
                    return false;
                }
                if(modelA.get(key) != modelB.get(key))
                    error("values for key '"+key+"' differ:"
                          +" modelA("+modelA.get(key)+")"
                          +" modelB("+modelB.get(key)+")");
            }

            return super.postMethodTest(item);
        }


        //
        // event-handling
        //


        /** Expects events */
        void expectEvent(int event, ListRO keys, ListRO newValues) {
            if(/*preEvent != null || */postEvent != null)
                throw new IllegalStateException();

            /*
            switch(data.collType) {
            case CollTestData.Types.WRAPPER_LIST:
            case CollTestData.Types.SYNCH_LIST:
                break;
            default:
            */

            Object notSet = new Object();
            ListRW oldValues = new GapListRW();
            // construct the old values
            for(int i=0; i<keys.size(); i++) {
                Object key = keys.get(i);
                if(modelA.containsKey(key))
                    oldValues.add(modelA.get(key));
                else
                    oldValues.add(notSet);
            }

            //preEvent = new MapEvent(null, modelA, event, keys, newValues, notSet);
            postEvent = new MapEvent(null, modelA, event, keys, oldValues, notSet);
        }

        /** Stores the details of an expected or actual event */
        class MapEvent {
            Object sendback;
            MapRO source;
            int event;
            ListRO keys;
            ListRO values;
            Object notSet;

            /** Constructs */
            MapEvent(Object _sendback, MapRO _source, int _event
                     , ListRO _keys, ListRO _values, Object _notSet) {
                sendback = _sendback;
                source = _source;
                event = _event;
                keys = _keys;
                values = _values;
                notSet = _notSet;
            }

            public boolean equals(Object object) {
                if(object == null || !(object instanceof MapEvent))
                    return false;
                MapEvent me = (MapEvent)object;

                boolean valuesEqual = true;
                if(values.size() == me.values.size()) {
                    for(int i=0; i<values.size(); i++) {
                        Object value = values.get(i);
                        Object meValue = me.values.get(i);
                        if(!((value == notSet && meValue == me.notSet)
                             || Util.equals(value, meValue))) {
                            valuesEqual = false;
                            break;
                        }
                    }
                } else
                    valuesEqual = false;

                return sendback == me.sendback
                    && source == me.source
                    && event == me.event
                    && Util.equals(keys, me.keys)
                    && valuesEqual;
            }

            String event() {
                switch(event) {
                case ADD:
                    return "ADD";
                case REMOVE:
                    return "REMOVE";
                default:
                    error("Illegal event: " + event);
                    return "--ERROR--";
                }
            }

            public String toString() {
                return event()+","+keys+","+values+","+notSet;
            }
        }

        private class PostListener implements MapRO.Listener {
            /** @see MapRO.Listener.mapEvent */
            public void mapEvent(Object sendback, MapRO source, int event
                                 , ListRO keys, ListRO oldValues
                                 , Object notSet) {
                MapEvent actual
                    = new MapEvent(sendback, source, event, keys, oldValues, notSet);

                // were any events expected?
                if(postEvent == null) {
                    error("unexpected post ("+actual+")");
                    return;
                }

                // check it
                if(actual.source != postEvent.source)
                    error("Unexpected post source: " + actual.source);
                else if(!actual.equals(postEvent))
                    error("expected post ("+postEvent+"), got ("+actual+")");
                else
                    ok("post event ("+actual+")");

                postEvent = null;
            }
        }


        /*
        private class PreListener implements AbstractListRW.PreListener {
            public void preEvent(int event, int indexA, int indexB, ArrayRO_int indexes, ListRO elements) {
                ListEvent actual = new ListEvent(null, modelA, event, indexA, indexB, indexes
                                                 , elements);

                // were any events expected?
                if(preEvent == null) {
                    error("unexpected pre ("+actual+")");
                    return;
                }

                // check it
                if(actual.source != preEvent.source)
                    error("Unexpected pre source: " + actual.source);
                else if(!actual.equals(preEvent))
                    error("expected pre ("+preEvent+"), got ("+actual+")");
                else
                    ok("pre event ("+actual+")");

                preEvent = null;
            }
        }
        */


        //
        // implements MapRW
        //
        /** @see MapRW#put */
        public Object put(Object key, Object value) {
            expectEvent(ADD, listro(key), listro(value));
            return super.put(key, value);
        }

        /** @see MapRW#putAll(java.util.Map) */
        public void putAll(java.util.Map map) {
            // expected event
            ListRO keys = new DefaultListRO(map.keySet());
            ListRW newValues = new GapListRW();
            for(int i=0; i<keys.size(); i++) {
                Object key = keys.get(i);
                newValues.add(map.get(key));
            }
            expectEvent(ADD, keys, newValues);

            // call super
            super.putAll(map);
        }

        /** @see MapRW#putAll(MapRO) */
        public void putAll(MapRO map) {
            // expected event
            ListRO keys = new DefaultListRO(map.keySetRO());
            ListRW newValues = new GapListRW();
            for(int i=0; i<keys.size(); i++) {
                Object key = keys.get(i);
                newValues.add(map.get(key));
            }
            expectEvent(ADD, keys, newValues);

            super.putAll(map);
        }

        /** @see MapRW#remove */
        public Object remove(Object key) {
            if(modelA.containsKey(key))
                expectEvent(REMOVE, listro(key), null);
            return super.remove(key);
        }

        /** @see MapRW#clear */
        public void clear() {
            expectEvent(REMOVE, listro(modelA.keySetRO()), null);
            super.clear();
        }
    }


    /**
     *  Expected-value test for MapRW.
     *
     *  Calls MapRW methods, passing the expected return value as a parameter.
     *  EVTest_MapRW will spit out errors if the expected value does not match
     *  the actual return value from the method.
     *  
     */
    public static class EVTest extends EVTest_MapRW {

        
        private int _mapType;
        private Vector _testCollection;
        
        public static void main(String[] args) {
            new EVTest().start(args);
        }

        private EVTest() {
            super("expvalue");
        }

        protected void resetModels() {
            resetModels(0);
        }

        // resets the test data
        protected void resetModels(int numElements) {
            resetE();
            switch(_mapType) {
            case HASHMAPRW:
                _modelToTest = new HashMapRW();
                _testCollection = new Vector(numElements);
                break;
            case ARRAYHASHMAPRW:
                _modelToTest = new ArrayHashMapRW();
                _testCollection = new Vector(numElements);
                break;
            default:
                throw new IllegalStateException("_mapType: " + _mapType);
            }
            
            for (int i = 0; i < numElements; ++i) {
                _modelToTest.put(e(i), e(i));
                _testCollection.addElement(e(i));
            }
            
            // TODO:  Should we add this listener?
            //_modelToTest.addListener(new PostListener(), null);
        }

        private MapRO createMapRO(int numElements) {
            MapRW map = new HashMapRW();
            loadUpTheMap(map, numElements);
            return map;
        }

        private void loadUpTheMap(MapRW map, int numElements) {
            for (int i = 0; i < numElements; ++i) {
                map.put(e(i), e(i));
            }
        }

        public void test() {

            push("HashMapRW");
            testMapType(HASHMAPRW);
            pop();

            //push("ArrayHashMapRW");
            //testMapType(ARRAYHASHMAPRW);
            //pop();

        }

        // puts the 'next' key-value pair into the map using the e() method
        // e() generates String objects with ascending integer values, so
        // calling a series of put(e(), e()) will result in adding a mappings
        // of (n, n + 1), (n + 2, n + 3), etc.
        private void put() {
            put(e(), e(), (String)null);
        }

        private HashMap createJavaUtilHashMap(int numElements) {
            HashMap map = new java.util.HashMap();
            for (int i = 0; i < numElements; ++i) {
                map.put(e(i), e(i));
            }
            return map;
        }

        private void testMapType(int type) {
            MapRO mapRO;
            int numElements;
            Exception npe = new NullPointerException();
            
            _mapType = type;

            push("size()");
            resetModels();
            size(0);
            put();
            size(1);
            put();
            put();
            size(3);
            remove("0", "1");
            size(2);
            remove("2", "3");
            size(1);
            put();
            size(2);
            
            pop();

            push("isEmpty()");
            resetModels();
            isEmpty(true);
            put();
            isEmpty(false);
            remove("0", "1");
            isEmpty(true);
            pop();
            
            push("containsKey()");
            resetModels();
            containsKey("0", false);
            containsKey("1", false);
            containsKey("1", (Exception)null);
            put();
            containsKey("0", true);
            containsKey("0", (Exception)null);
            containsKey("1", (Exception)null);
            containsKey("1", false);            
            remove("0", "1");
            containsKey("0", false);
            containsKey("1", false);            
            pop();

            
            push("containsValue()");
            resetModels();
            containsValue("0", false);
            containsValue("1", false);
            containsValue("1", (Exception)null);
            put();
            containsValue("0", false);
            containsValue("1", true);
            containsValue("1", (Exception)null);
            remove("0", "1");
            containsValue("0", false);
            containsValue("1", false);            
            pop();
            
            push("put()");
            resetModels();
            put("0", "1", (String)null);
            put("0", "1", (Exception)null);
            put("0", "2", "1");     // previous value "1"
            
            put("2", null, null);   // map permits null values
            put(null, null, null);  // map permits null keys???
            put(null, null, null);
            
            pop();

            push("putAll()");
            numElements = 10;
            resetModels();
            
            // create a map with 'numElements' mappings of "0" => "0", "1" => "1", etc.
            // add it to the test model
            mapRO = createMapRO(numElements);
            putAll(mapRO);
            putAll(mapRO, (Exception)null);
            equals(mapRO, true);
            isEmpty(false);
            pop();
            
            push("get()");
            resetModels();
            get("0", (String)null);         // no mapping
            get("0", (Exception)null);      // no exception
            put("0", "0", (String)null);    // expect previous value == null
            put("0", "1", "0");             // expect previous value == "0"
            get("0", "1");                  // expect value == "1"
            get("1", (String)null);         // no "1" key yet
            
            pop();

            push("remove()");
            resetModels();
            put();
            put();
            remove("0", "1");
            containsKey("0", false);
            remove("2", "3");
            containsKey("2", false);
            size(0);
            mapRO = createMapRO(numElements);
            putAll(mapRO);
            for (int i = 0; i < numElements; ++i) {
                remove(e(i), e(i));
            }
            size(0);
            
            pop();

            push("clear()");
            resetModels();
            
            put();
            put();
            put();
            size(3);
            clear();
            size(0);
            pop();

            numElements = 5;

            // get back a Set view of the map and make sure
            // it contains the correct values
            push("entrySet()");
            resetModels(numElements);
            
            // note:  we won't call entrySet() with an expected value; only an expected exception
            java.util.Set entrySet = entrySet((Exception)null);

            push("Set.contains(entry)");
            boolean missingEntry = false;
            for (int i = 0; i < numElements; ++i) {

                // make sure the set contains an entryRO for each key
                MapRO.EntryRO entryRO = _modelToTest.getEntryRO(e(i));
                if (! entrySet.contains(entryRO)) {
                    error("entrySet() has missing entry");
                    missingEntry = true;
                    break;
                }
            }

            if (! missingEntry) {
                ok("entrySet() has all entries");
            }
            
            pop();  // push("Set.contains()");
            pop();  // push("entrySet()")

            push("keySet()");
            
            resetModels(numElements);

            java.util.Set keySet = keySet((Exception)null);
            
            push("Set.contains(key)");
            boolean missingKey = false;
            IteratorRO keyIterator =  _modelToTest.keyIteratorRO();
            
            while (keyIterator.hasNext()) {
                Object next = keyIterator.next();
                if (! _modelToTest.containsKey(next)) {
                    missingKey = true;
                }
            }
            
            if (! missingKey) {
                ok("keySet() has correct keys");
            }
            
            pop();  //push("Set.contains(key)");
            pop();  // push("keySet()");

            push("values()");
            resetModels(numElements);
            
            // call values() with expected exception
            java.util.Collection values = values((Exception)null);

            // check that every element 'values' exists in the '_testCollection' vector
            // created in resetModels
            java.util.Iterator iter = _testCollection.iterator();
            missingEntry = false;
            while (iter.hasNext()) {
                Object elem = iter.next();
                if (! values.contains(elem)) {
                    missingEntry = true;                    
                    error("entry missing from values() (" + elem + ")");
                }
            }
            
            if (! missingEntry) {
                ok("all entries present in values()");
            }
                
            pop();  // push("values()");


            push("keyIteratorRO()");
            resetModels(numElements);
            
            keyIterator = keyIteratorRO((Exception)null);
            keySet = keySet((Exception)null);
            Vector vector = new Vector();
            
            // make sure the keys returned by the iterator are as expected
            int count = 0;
            while (keyIterator.hasNext()) {
                Object next = keyIterator.next();
                count++;
                vector.addElement(next);
            }
            
            if (count == numElements) {
                ok("number of elements returned by the keyIterator is correct");
            } else {
                error("number of elements returned by the keyIterator is not correct");
            }

            // make sure the keySet returned from the underlying model contains
            // all the keys added to the vector in the while loop above.
            if (keySet.containsAll(vector)) { 
                ok("keyIterator returned the correct keys");
            } else {
                error("keyIterator did not return the correct keys");
            }
                
            pop();

        
        }
    }
}
