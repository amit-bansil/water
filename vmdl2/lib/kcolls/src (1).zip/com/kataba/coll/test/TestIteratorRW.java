
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.util.*;
import java.io.*;

/** Tests various implementations of IteratorRW
 *
 * @author Chris Thiessen
 */
class TestIteratorRW
    extends TestSuite
{
    /** Starts the Test */
    public static void main(String[] args) {
        TestIteratorRW test = new TestIteratorRW();
        test.init(args);
        test.runTest();
    }

    /** Constructs */
    public TestIteratorRW() {
        super("itrrw");
        addTest(new DiffTest());
        addTest(new EVTest());
    }

    /** Diff-based test of IteratorRW */
    public static class DiffTest
        extends DiffTest_IteratorRW
        implements CollTestData.Test
    {
        private CollTestData data;
        private int collSize = 0;

        private DiffTest() {
            super("diff");
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);
        }

        /** @see DiffTest#resetModels() */
        public void resetModels() {
            data.reset();

            // setup the collections
            data.collA.addAll(coll(collSize));
            data.collB.addAll((CollectionRO)data.collA);

            // grab the new model IteratorRWs
            modelA = data.collA.iteratorRW();
            modelB = new IteratorToIteratorRW(data.listB.iterator());
        }

        /** @see DiffTest#postMethodTest */
        public boolean postMethodTest(String method) {
            return !super.postMethodTest(method)
                ? false
                : data.compareColls();
        }

        /** @see DiffTest#test */
        public void test() {
            data.testColls(CollTestData.TYPES.values());
        }

        /** @see CollTestData.Test#testColl */
        public void testColl() {
            for(int j=0; j<1; j++) {
                collSize = j;

                push("collSize: " + collSize);

                push("next()");
                resetModels();
                next();
                next();
                next();
                next();
                pop();

                push("hasNext()");
                resetModels();
                hasNext();
                next();
                hasNext();
                next();
                hasNext();
                next();
                hasNext();
                next();
                pop();

                push("remove()");
                resetModels();
                remove();
                hasNext();
                remove();
                next();
                remove();
                next();
                remove();
                hasNext();
                remove();
                remove();
                next();
                remove();
                next();
                remove();
                pop();

                pop();
            }
        }
    }


    /** Expected-value test of IteratorRW */
    public static class EVTest
        extends EVTest_IteratorRW
        implements CollTestData.Test
    {
        private CollTestData data;
        private int collSize = 0;
        
        private EVTest() {
            super("expvalue");
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);
        }

        /** @see EVTest.test() */
        public void test() {
            data.testColls(CollTestData.TYPES.values());
        }

        private void resetData(int collectionSize) {
            resetE();   // resets the 'lastElement' variable
            data.reset();
            data.collA.addAll(coll(collectionSize));
            _modelToTest = data.collA.iteratorRW();
        }

        /** @see CollTestData.Test#testColl */
        public void testColl() {
            resetData(0);

            push("hasNext()");
            hasNext(false);
            hasNext(false);

            resetData(1);
            
            hasNext(true);
            hasNext(true);            
            next(e(0));
            hasNext(false);

            pop();

            push("next()");

            Exception nsee = new NoSuchElementException();
                        
            resetData(0);
            next(nsee);
            
            resetData(1);
            next(e(0));
            next(nsee);
            
            pop();
            
            push("remove()");
            
            Exception ise = new IllegalStateException();
            
            resetData(3);
            remove(ise);    // should throw exception because next() hasn't been called
            next(e(0));
            remove(null);
            next(e(1));
            remove(null);
            next(e(2));
            remove(null);
            remove(ise);

            next(nsee);
            remove(ise);
            
            pop();
            
        }
    }
        
}

