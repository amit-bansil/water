
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;

/** Tests various implementations of ListRW
 *
 * @author Chris Thiessen
 */
class TestListRW
    extends TestSuite
{

    /** Testing mainline */
    public static void main(String[] args) {
        new TestListRW().start(args);
    }

    /** Constructs */
    public TestListRW() {
        super("listrw");
        addTest(new DiffTest());
        addTest(new EVTest());
    }

    public static class DiffTest
        extends DiffTest_ListRW
        implements CollTestData.Test
    {
        private CollTestData data;
        private ListEvent preEvent = null;
        private ListEvent postEvent = null;

        private static final int ADD = ListRO.Listener.ADD;
        private static final int REMOVE_RANGE = ListRO.Listener.REMOVE_RANGE;
        private static final int REMOVE_DISJOINT = ListRO.Listener.REMOVE_DISJOINT;
        private static final int REPLACE_RANGE = ListRO.Listener.REPLACE_RANGE;
        private static final int MOVE = ListRO.Listener.MOVE;
        private static final int SWAP = ListRO.Listener.SWAP;

        public static void main(String[] args) {
            new DiffTest().start(args);
        }

        private DiffTest() {
            super("diff");
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);
        }


        //
        // extends DiffTest
        //

        protected void test() {
            data.testColls(new int[] {
                CollTestData.Types.GAP_LIST
                //, CollTestData.Types.JDK_LIST
                , CollTestData.Types.WRAPPER_LIST
                , CollTestData.Types.SYNCH_LIST
            });
        }

        protected void resetModels() {
            resetE();
            data.reset();

            modelA = (ListRW)data.collA;
            modelA.addListener(new PostListener(), null);
            switch(data.collType) {
            case CollTestData.Types.WRAPPER_LIST:
            case CollTestData.Types.SYNCH_LIST:
                break;
            default:
                ((AbstractListRW)modelA).setPreListener(new PreListener());
            }

            modelB = (ListRW)data.collB;
        }

        /** @see DiffTest#postMethodTest(String) */
        protected boolean postMethodTest(String item) {
            if(postEvent != null)
                error(item, "missing post-event: ("+postEvent+")");
            postEvent = null;

            if(preEvent != null)
                error(item, "missing pre-event: ("+preEvent+")");
            preEvent = null;

            // compare the lists
            if(modelA.size() != modelB.size())
                error("Size differs: modelA("+modelA.size()+") modelB("+modelB.size()+")");
            for(int i=0; i<modelA.size(); i++) {
                if(!Util.equals(modelA.get(i), modelB.get(i))) {
                    error("Element at index "+i+" differs:"
                          + " modelA:"+modelA+" modelB:"+modelB);
                    return false;
                }
            }

            return super.postMethodTest(item);
        }

        public void testColl() {
            push("implements CollectionRW");

            push("add(Object)");
            resetModels();
            add(e());
            add(e());
            pop();

            push("clear()");
            resetModels();
            clear();
            add(e());
            add(e());
            add(e());
            clear();
            resetModels();
            add(e());
            add(e());
            add(e());
            add(e());
            clear();
            pop();

            push("addAll(CollectionRO)");
            resetModels();
            addAll((CollectionRO)null);
            addAll(coll(0));
            addAll(coll(3));
            addAll(coll(5));
            addAll(coll(0));
            addAll((CollectionRO)null);
            pop();

            push("remove(Object)");
            resetModels();
            remove(null);
            remove(e(0));
            remove(e(1));
            addAll(coll(4));
            remove(null);
            remove(e(0));
            remove(e(4));
            remove(e(3));
            pop();

            push("removeAll(CollectionRO)");
            resetModels();
            addAll(coll(4));
            removeAll(coll(new Object[] { e(0), e(2), e(3), e(5), e(7) })
                      , new int[] { 0, 2, 3 }
                      , listro(e(0), e(2), e(3)));
            resetModels();
            addAll(coll(3));
            removeAll(coll(new Object[] { e(2), e(1), e(0), e(2), e(1) })
                      , new int[] { 0, 1, 2 }
                      , listro(e(0), e(1), e(2)));
            resetModels();
            addAll(coll(new Object[] { e(0), e(1), e(0) }));
            remove(2);
            remove(0);
            resetModels();
            removeAll(coll(new Object[] { e(0), e(2), e(3), e(5), e(7) }));
            addAll(coll(new Object[] { e(0), e(1), e(0) }));
            removeAll(coll(new Object[] { e(0) })
                      , new int[] { 0, 2 }
                      , listro(e(0), e(0)));
            pop();

            pop("implements CollectionRW");


            push("implements ListRW");

            push("add(int, Object)");
            resetModels();
            add(1, e());
            add(-1, e());
            add(0, e());
            add(0, e());
            add(1, e());
            add(3, e());
            add(5, e());
            pop();

            push("addAll(int, CollectionRO)");
            resetModels();
            addAll(0, (CollectionRO)null);
            addAll(0, coll(0));
            addAll(1, coll(3));
            addAll(-1, coll(3));
            addAll(0, coll(3));
            addAll(0, coll(3));
            addAll(7, coll(3));
            addAll(6, coll(3));
            addAll(2, coll(3));
            resetModels();
            addAll(0, coll(1));
            addAll(0, coll(0));
            pop();

            push("remove(int)");
            resetModels();
            addAll(0, coll(5));
            remove(-1);
            remove(5);
            remove(4);
            remove(2);
            remove(0);
            remove(0);
            remove(0);
            remove(0);
            remove(0);
            pop();

            push("remove(int,int)");
            resetModels();
            addAll(0, coll(5));
            removeRange(-1,0);
            removeRange(1,0);
            removeRange(1,1);
            removeRange(1,2);
            removeRange(0,1);
            removeRange(0,modelA.size());
            pop();

            push("set(int,Object)");
            resetModels();
            set(-1, e());
            set(1, e());
            set(0, e());
            add(e());
            set(0, e());
            addAll(coll(5));
            set(5, e());
            pop();

            push("swap(int,int)");
            resetModels();
            swap(0,0);
            swap(-1,0);
            addAll(coll(5));
            swap(0,0);
            swap(-1,0);
            swap(0,1);
            swap(0,5);
            swap(4,0);
            swap(0,4);
            pop();

            push("move(int,int)");
            resetModels();
            move(0,0);
            move(-1,0);
            addAll(coll(5));
            move(0,0);
            move(-1,0);
            move(1,0);
            move(0,1);
            move(0,5);
            move(0,4);
            pop();

            pop("implements ListRW");


            //*
            push("implements CollectionRO");

            push("size()");
            resetModels();
            size();
            add(e());
            size();
            addAll(coll(4));
            size();
            clear();
            size();
            pop();

            push("isEmpty()");
            resetModels();
            isEmpty();
            add(e());
            isEmpty();
            addAll(coll(4));
            isEmpty();
            clear();
            isEmpty();
            pop();

            push("contains(Object)");
            resetModels();
            contains(null);
            contains(e(0));
            addAll(coll(4));
            contains(null);
            contains(e(0));
            contains(e(3));
            contains(e(4));
            clear();
            contains(e(0));
            pop();

            push("get(Object)");
            resetModels();
            get(null);
            get(e());
            addAll(coll(1));
            get(null);
            get(e(0));
            get(e());
            addAll(coll(3));
            get(null);
            get(e(0));
            get(e());
            pop();

            push("get(Object)");
            resetModels();
            get(null);
            get(e());
            addAll(coll(1));
            get(null);
            get(e(0));
            get(e());
            addAll(coll(3));
            get(null);
            get(e(0));
            get(e());
            pop();

            push("toArray()");
            resetModels();
            toArray();
            addAll(coll(3));
            toArray();
            pop();

            pop("implements CollectionRO");


            push("implements ListRO");

            push("get(int)");
            resetModels();
            get(-1);
            get(0);
            get(1);
            addAll(coll(3));
            get(-1);
            get(0);
            get(2);
            get(3);
            pop();

            push("subListRW(int,int)");
            resetModels();
            subListRW(-1,0);
            subListRW(0,0);
            subListRW(1,0);
            subListRW(-1,1);
            subListRW(0,1);
            subListRW(1,1);
            addAll(coll(3));
            subListRW(-1,0);
            subListRW(0,0);
            subListRW(1,0);
            subListRW(-1,1);
            subListRW(0,1);
            subListRW(1,1);
            subListRW(0,3);
            pop();

            push("indexOf(int)");
            resetModels();
            indexOf(null);
            indexOf(e(0));
            addAll(coll(3));
            indexOf(null);
            indexOf(e(0));
            indexOf(e(1));
            indexOf(e(2));
            indexOf(e(3));
            pop();

            push("indexOf(int,int,boolean)");
            resetModels();
            indexOf(null, 0, true);
            indexOf(null, -1, true);
            indexOf(null, 1, true);
            indexOf(e(0), 0, true);
            indexOf(e(0), -1, true);
            indexOf(e(0), 1, true);
            indexOf(null, 0, false);
            indexOf(null, -1, false);
            indexOf(null, 1, false);
            indexOf(e(0), 0, false);
            indexOf(e(0), -1, false);
            indexOf(e(0), 1, false);

            addAll(coll(3));
            indexOf(null, 0, true);
            indexOf(null, -1, true);
            indexOf(null, 1, true);
            indexOf(e(0), 0, true);
            indexOf(e(0), -1, true);
            indexOf(e(0), 1, true);
            indexOf(null, 0, false);
            indexOf(null, -1, false);
            indexOf(null, 1, false);
            indexOf(e(0), 0, false);
            indexOf(e(0), -1, false);
            indexOf(e(0), 1, false);
            pop();

            //  Out.ln("  listCursorRO()");
            //  resetModels();
            //  listCursorRO();

            /*
              Out.ln("  toArray(int,int)");
              resetModels();
              toArray(0,0);
              toArray(-1,0);
              toArray(0,-1);
              toArray(0,1);
              toArray(1,0);
              toArray(0,3);
              toArray(0,4);
              addAll(coll(3));
              toArray(0,0);
              toArray(-1,0);
              toArray(0,-1);
              toArray(0,1);
              toArray(1,0);
              toArray(0,3);
              toArray(0,4);
            //*/

            pop("implements ListRO");

        }


        //
        // construction methods
        //

        void speedTests() {
            for(int k=14; k<30; k+=2) {
                Out.ln("Size: "+k);

                Out.ln("  arraycopy");
                //GapList.MIN_ARRAYCOPY = 0;
                for(int j=0; j<4; j++)
                    speedTests(k);

                Out.ln("  manual");
                //GapList.MIN_ARRAYCOPY = 1000;
                for(int j=0; j<4; j++)
                    speedTests(k);

            }
        }

        void speedTests(int num) {
            GapListRW gapList = new GapListRW();
            for(int i=0; i<num; i++)
                gapList.add("1");
            com.kataba.util.Timer timer = new com.kataba.util.Timer();
            for(int i=0; i<2000000; i++) {
                gapList.remove(num-1);
                gapList.add(0, "1");
            }
            timer.elapsed(Out.out, "    ");
        }


        //
        // event-handling
        //

        void expectEvent(int event, int indexA, int indexB, ArrayRO_int indexes
                         , ListRO preElems, ListRO postElems) {
            if(preEvent != null || postEvent != null)
                throw new IllegalStateException();
            switch(data.collType) {
            case CollTestData.Types.WRAPPER_LIST:
            case CollTestData.Types.SYNCH_LIST:
                break;
            default:
                if(event == ADD)
                    preEvent = new ListEvent(null, modelA, event, indexA, -1
                                             , indexes, preElems);
                else
                    preEvent = new ListEvent(null, modelA, event, indexA, indexB
                                             , indexes, preElems);
            }
            postEvent = new ListEvent(null, modelA, event, indexA, indexB, indexes, postElems);
        }

        /** Stores the details of an expected or actual event */
        class ListEvent {
            Object sendback;
            ListRO source;
            int event;
            int indexA;
            int indexB;
            ArrayRO_int indexes;
            ListRO elements;

            ListEvent(Object _sendback, ListRO _source, int _event
                      , int _indexA, int _indexB, ArrayRO_int _indexes, ListRO _elements) {
                sendback = _sendback;
                source = _source;
                event = _event;
                indexA = _indexA;
                indexB = _indexB;
                indexes = _indexes;
                elements = _elements;
            }

            public boolean equals(Object object) {
                if(object == null || !(object instanceof ListEvent))
                    return false;
                ListEvent le = (ListEvent)object;
                return sendback == le.sendback
                    && source == le.source
                    && event == le.event
                    && indexA == le.indexA
                    && indexB == le.indexB
                    && Util.equals(indexes, le.indexes)
                    && Util.equals(elements, le.elements);
            }

            String event() {
                switch(event) {
                case ADD:
                    return "ADD";
                case REMOVE_RANGE:
                    return "REMOVE_RANGE";
                case REMOVE_DISJOINT:
                    return "REMOVE_DISJOINT";
                case REPLACE_RANGE:
                    return "REPLACE_RANGE";
                case MOVE:
                    return "MOVE";
                case SWAP:
                    return "SWAP";
                default:
                    error("Illegal event: " + event);
                    return "--ERROR--";
                }
            }

            public String toString() {
                return event()+","+indexA+","+indexB+","+indexes+","+elements;
            }
        }

        private class PostListener implements ListRO.Listener {
            /** @see ListRO.Listener.listEvent */
            public void listEvent(Object sendback, ListRO source, int event
                                  , int indexA, int indexB, ArrayRO_int indexes
                                  , ListRO elements) {
                ListEvent actual
                    = new ListEvent(sendback, source, event, indexA, indexB, indexes, elements);

                // were any events expected?
                if(postEvent == null) {
                    error("unexpected post ("+actual+")");
                    return;
                }

                // check it
                if(actual.source != postEvent.source)
                    error("Unexpected post source: " + actual.source);
                else if(!actual.equals(postEvent))
                    error("expected post ("+postEvent+"), got ("+actual+")");
                else
                    ok("post event ("+actual+")");

                postEvent = null;
            }
        }

        private class PreListener implements AbstractListRW.PreListener {
            /** @see AbstractList.PreListener */
            public void preEvent(int event, int indexA, int indexB, ArrayRO_int indexes, ListRO elements) {
                ListEvent actual = new ListEvent(null, modelA, event, indexA, indexB, indexes
                                                 , elements);

                // were any events expected?
                if(preEvent == null) {
                    error("unexpected pre ("+actual+")");
                    return;
                }

                // check it
                if(actual.source != preEvent.source)
                    error("Unexpected pre source: " + actual.source);
                else if(!actual.equals(preEvent))
                    error("expected pre ("+preEvent+"), got ("+actual+")");
                else
                    ok("pre event ("+actual+")");

                preEvent = null;
            }
        }


        //
        // implements Collection
        //

        public boolean add(Object element) {
            expectEvent(ADD, modelA.size(), modelA.size()+1, null, listro(element), null);
            return super.add(element);
        }

        public boolean addAll(CollectionRO coll) {
            if(coll != null && coll.size() > 0)
                expectEvent(ADD, modelA.size(), modelA.size()+coll.size(), null
                            , listro(coll), null);
            return super.addAll(coll);
        }

        public boolean remove(Object element) {
            int index = modelA.indexOf(element);
            if(index != -1)
                expectEvent(REMOVE_RANGE, index, index+1, null, null, listro(element));
            return super.remove(element);
        }

        public boolean removeAll(CollectionRO collection, int[] indexes, ListRO eventElements) {
            expectEvent(REMOVE_DISJOINT, -1, -1, new ArrayRO_int(indexes), null, eventElements);
            return removeAll(collection);
        }

        public void clear() {
            if(modelA.size() > 0)
                expectEvent(REMOVE_RANGE, 0, modelA.size(), null, null, listro(modelA));
            super.clear();
        }

        //
        // implements List
        //

        public void add(int index, Object element) {
            if(index >= 0 && index <= modelA.size())
                expectEvent(ADD, index, index+1, null, listro(element), null);
            super.add(index, element);
        }

        public boolean addAll(int index, CollectionRO coll) {
            if(index >= 0 && index <= modelA.size() && coll != null && coll.size() > 0)
                expectEvent(ADD, index, index+coll.size(), null, listro(coll), null);
            return super.addAll(index, coll);
        }

        public Object remove(int index) {
            if(index >= 0 && index < modelA.size())
                expectEvent(REMOVE_RANGE, index, index+1, null, null, listro(modelA.get(index)));
            return super.remove(index);
        }

        public void removeRange(int start, int end) {
            if(start >= 0 && start < end && end <= modelA.size())
                expectEvent(REMOVE_RANGE, start, end, null, null, listro(modelA.subListRO(start,end)));
            super.removeRange(start, end);
        }

        public Object set(int index, Object element) {
            if(index >= 0 && index < modelA.size())
                expectEvent(REPLACE_RANGE, index, index+1, null
                            , listro(element)
                            , listro(modelA.get(index)));
            return super.set(index, element);
        }

        public void swap(int indexA, int indexB) {
            if(indexA >= 0 && indexA < modelA.size()
               && indexB >= 0 && indexB < modelA.size())
                expectEvent(SWAP, indexA, indexB, null, null, null);
            super.swap(indexA, indexB);
        }

        public void move(int fromIndex, int toIndex) {
            if(fromIndex != toIndex
               && fromIndex != toIndex-1
               && fromIndex >= 0 && fromIndex < modelA.size()
               && toIndex >= 0 && toIndex <= modelA.size()) {
                expectEvent(MOVE, fromIndex, toIndex, null, null, null);
            }
            super.move(fromIndex, toIndex);
        }
    }

    /** expected-value test on ListRW */
    public static class EVTest
        extends EVTest_ListRW
        implements CollTestData.Test
    {
        private CollTestData data;

        public EVTest() {
            super("expvalue");
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);            
        }

        public void test() {
            data.testColls(new int[] {
                CollTestData.Types.GAP_LIST
                , CollTestData.Types.WRAPPER_LIST
                , CollTestData.Types.SYNCH_LIST
            });        
        }
        
        protected void resetData() {
            resetE();   // resets the 'lastElement' variable
            data.reset();
            
            if (data.collA instanceof ListRW) {
                _modelToTest = (ListRW)data.collA;
            }
        }

        public void testColl() {

            resetData();
            
            push("add(int, Object)");
            add(0, e());
            add(0, e());
            add(0, e());
            pop();

            push("iteratorRO()");
            iteratorRO((Exception)null);
            pop();

            push("listIteratorRO()");
            listIteratorRO((Exception)null);                
            pop();

            push("iteratorRW()");
            iteratorRW((Exception)null);
            pop();
        
            push("listIteratorRW()");
            listIteratorRW((Exception)null);                
            pop();
            
            // test for ConcurrentModificationException
            push("listIterator-ConcurrentModificationException");
            resetData();
            _modelToTest.add(0, e());
            _modelToTest.add(1, e());
            _modelToTest.add(2, e());
            
            ListCursorRO cursor = _modelToTest.listCursorRO();
            
            // modify the list
            _modelToTest.add(3, e());
            
            try {
                cursor.size();
                error("no ConcurrentModificationException thrown calling iter.next()");
            } catch (ConcurrentModificationException e) {
                ok("got ConcurrentModificationException calling iter.next()");
            }
            pop();
        }

    }
}
