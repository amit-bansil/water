
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** A DiffTest for the com.kataba.coll.SetRW class
 *
 * @author com.kataba.util.DiffTest_Gen
 */
public abstract class DiffTest_SetRW
    extends DiffTest
    implements SetRW
{
    protected SetRW modelA;
    protected SetRW modelB;

    /** Constructs */
    public DiffTest_SetRW(String _name) {
        super(_name);
    }

    public boolean addAll(CollectionRO a) {
        String test = "addAll("+a+')';
        preMethodTest("addAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.addAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.addAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean addAll(java.util.Collection a) {
        String test = "addAll("+a+')';
        preMethodTest("addAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.addAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.addAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean add(Object a) {
        String test = "add("+a+')';
        preMethodTest("add");

        boolean modelARet = false;
        try {
            modelARet = modelA.add(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.add(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public java.util.Iterator iterator() {
        String test = "iterator("+')';
        preMethodTest("iterator");

        java.util.Iterator modelARet = null;
        try {
            modelARet = modelA.iterator();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        java.util.Iterator modelBRet = null;
        try {
            modelBRet = modelB.iterator();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean remove(Object a) {
        String test = "remove("+a+')';
        preMethodTest("remove");

        boolean modelARet = false;
        try {
            modelARet = modelA.remove(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.remove(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void clear() {
        String test = "clear("+')';
        preMethodTest("clear");

        try {
            modelA.clear();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.clear();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public boolean removeAll(java.util.Collection a) {
        String test = "removeAll("+a+')';
        preMethodTest("removeAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.removeAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.removeAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean removeAll(CollectionRO a) {
        String test = "removeAll("+a+')';
        preMethodTest("removeAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.removeAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.removeAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean retainAll(java.util.Collection a) {
        String test = "retainAll("+a+')';
        preMethodTest("retainAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.retainAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.retainAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean retainAll(CollectionRO a) {
        String test = "retainAll("+a+')';
        preMethodTest("retainAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.retainAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.retainAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public IteratorRW iteratorRW() {
        String test = "iteratorRW("+')';
        preMethodTest("iteratorRW");

        IteratorRW modelARet = null;
        try {
            modelARet = modelA.iteratorRW();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        IteratorRW modelBRet = null;
        try {
            modelBRet = modelB.iteratorRW();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int hashCode() {
        String test = "hashCode("+')';
        preMethodTest("hashCode");

        int modelARet = 0;
        try {
            modelARet = modelA.hashCode();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.hashCode();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean equals(Object a) {
        String test = "equals("+a+')';
        preMethodTest("equals");

        boolean modelARet = false;
        try {
            modelARet = modelA.equals(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.equals(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object get(Object a) {
        String test = "get("+a+')';
        preMethodTest("get");

        Object modelARet = null;
        try {
            modelARet = modelA.get(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.get(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean contains(Object a) {
        String test = "contains("+a+')';
        preMethodTest("contains");

        boolean modelARet = false;
        try {
            modelARet = modelA.contains(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.contains(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int size() {
        String test = "size("+')';
        preMethodTest("size");

        int modelARet = 0;
        try {
            modelARet = modelA.size();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.size();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object[] toArray() {
        String test = "toArray("+')';
        preMethodTest("toArray");

        Object[] modelARet = null;
        try {
            modelARet = modelA.toArray();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object[] modelBRet = null;
        try {
            modelBRet = modelB.toArray();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object[] toArray(Object[] a) {
        String test = "toArray("+a+')';
        preMethodTest("toArray");

        Object[] modelARet = null;
        try {
            modelARet = modelA.toArray(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object[] modelBRet = null;
        try {
            modelBRet = modelB.toArray(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean isEmpty() {
        String test = "isEmpty("+')';
        preMethodTest("isEmpty");

        boolean modelARet = false;
        try {
            modelARet = modelA.isEmpty();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.isEmpty();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean containsAll(CollectionRO a) {
        String test = "containsAll("+a+')';
        preMethodTest("containsAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.containsAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.containsAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean containsAll(java.util.Collection a) {
        String test = "containsAll("+a+')';
        preMethodTest("containsAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.containsAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.containsAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void addListener(CollectionRO.Listener a, Object b) {
        String test = "addListener("+a+','+b+')';
        preMethodTest("addListener");

        try {
            modelA.addListener(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.addListener(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public void removeListener(CollectionRO.Listener a) {
        String test = "removeListener("+a+')';
        preMethodTest("removeListener");

        try {
            modelA.removeListener(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.removeListener(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public IteratorRO iteratorRO() {
        String test = "iteratorRO("+')';
        preMethodTest("iteratorRO");

        IteratorRO modelARet = null;
        try {
            modelARet = modelA.iteratorRO();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        IteratorRO modelBRet = null;
        try {
            modelBRet = modelB.iteratorRO();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object lock() {
        String test = "lock("+')';
        preMethodTest("lock");

        Object modelARet = null;
        try {
            modelARet = modelA.lock();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.lock();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public SetRO xor(SetRO a) {
        String test = "xor("+a+')';
        preMethodTest("xor");

        SetRO modelARet = null;
        try {
            modelARet = modelA.xor(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        SetRO modelBRet = null;
        try {
            modelBRet = modelB.xor(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public SetRO union(SetRO a) {
        String test = "union("+a+')';
        preMethodTest("union");

        SetRO modelARet = null;
        try {
            modelARet = modelA.union(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        SetRO modelBRet = null;
        try {
            modelBRet = modelB.union(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public SetRO intersection(SetRO a) {
        String test = "intersection("+a+')';
        preMethodTest("intersection");

        SetRO modelARet = null;
        try {
            modelARet = modelA.intersection(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        SetRO modelBRet = null;
        try {
            modelBRet = modelB.intersection(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }
}
