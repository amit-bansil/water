
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;

public abstract class TestUtil {

    public static KJListIteratorPair createListIteratorInfo() {        
        return createListIteratorInfo(0);
    }

    public static KJListIteratorPair createListIteratorInfo(int elementCount) {
        GapListRW katabaList = new GapListRW();
        
        for (int i = 0; i < elementCount; ++i) {
            katabaList.add(new Integer(i));
        }

        com.kataba.coll.ListIteratorRW ki = katabaList.listIteratorRW();

        java.util.Collection javaUtilCollection = (java.util.Collection)katabaList;
        Vector vector = new Vector(javaUtilCollection);
        java.util.ListIterator ji = vector.listIterator();
        
        KJListIteratorPair info = new KJListIteratorPair();
        
        info.kList = katabaList;
        info.jList = vector;
        info.ki = ki;
        info.ji = ji;
        
        return info;
    }

}
