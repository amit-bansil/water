
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;

//
// TODO:  Write a wrapper class that implements the interface being tested,
// and which takes two list iterators upon construction.  Whenever one
// of the methods is called, it should call the method on both iterators
// and compare the results.
//
// Find out why the last test case is failing.
//

/**
 * Tests the default implementation of the ListIteratorRO interface.
 *<p>
 * The following read-only methods of the ListIterator interface are tested.
 *
 *   boolean hasNext();
 *   Object next();
 *   boolean hasPrevious();
 *   Object previous();
 *   int nextIndex();
 *   int previousIndex();
 */
 
 /*
 *  
 *
 *@author Ray Vander Veen
 */
public class TestListIteratorRO
    extends CollectionTest
{
    /** constructs a TestListIteratorRO instance with command-line arguments
     *@param args command line arguments
     */
    public TestListIteratorRO(String [] args) {
        super(args);
    }
    
    protected void runTests() {        
        testingNotice("ListIteratorRO");
        testEmptyList();
        testOneElementList();
        testManyElementList();
        testAgainstStandardJavaListIterator();
    }
    
    /** Ensures that ListIteratorRO behaves correctly with an empty list
     *<p>
     *  Both hasNext() and hasPrevious() should return false for an empty list
     *
     */
    public void testEmptyList() {
        runTest(new TestEmptyList());
    }

    /** Ensures that ListIteratorRO behaves correctly on a one-element list.
     *<p>
     *  - hasNext() should return true before anything is done to the one-element list
     *  - hasPrevious() should return false before anything is done to the one-element list
     *  - next() and previous() should return the same element
     *
     */
    public void testOneElementList() {
        runTest(new TestOneElementList());
    }
    
    /** Ensures that a ListIteratorRO bahaves correctly on a one-element list.
     *<p>
     */
    public void testManyElementList() {
        runTest(new TestManyElementList());
    }
    
    /** Ensures that ListIteratorRO.nextIndex() and ListIteratorRO.previousIndex()
     *  behave correctly.
     */
    public void testAgainstStandardJavaListIterator() {
        runTest(new TestAgainstStandardJavaListIterator());
    }
    
    /** mainline */
    public static void main(String [] args) {

        TestListIteratorRO tiro = new TestListIteratorRO(args);

        tiro.runTests();
        tiro.summary();
        
    }

    class TestEmptyList extends TestCase {
        
        public TestEmptyList() {
            super("TestEmptyList");
        }
        
        /** @see TestCase.run */
        public void run() {
            GapListRW list = createList();
            ListIteratorRO iterator = list.listIteratorRO();
    
            // no items in the list; hasNext() should return false
            if (iterator.hasNext()) {
                error("ListIteratorRO.hasNext() => true for empty list");
            } else {
                ok("ListIteratorRO.hasNext() => false for empty list");
            }
            
            if (iterator.hasPrevious()) {
                error("ListIteratorRO.hasPrevious() => true for empty list");
            } else {
                ok("ListIteratorRO.hasPrevious() => false for empty list");
            }
            
        }
    }

    class TestOneElementList extends TestCase {

        public TestOneElementList() {
            super("TestOneElementList");
        }

        /** @see TestCase.run */
        public void run() {
            GapListRW list = createList(SEQUENTIAL_LIST, 1);
            ListIteratorRO iterator = list.listIteratorRO();

            if (iterator.hasNext()) {
                ok("ListIteratorRO.hasNext() => true for non-empty list");
            } else {
                error("ListIteratorRO.hasNext() => false for non-empty list");
            }

            if (iterator.hasPrevious()) {
                error("ListIteratorRO.hasPrevious() => true for one-element list");
            } else {
                ok("ListIteratorRO.hasPrevious() => true for non-empty list");
            }

            // move to the next element, then call has previous again, and it should
            // return true.
            Object next = iterator.next();

            if (iterator.hasNext()) {
                error("ListIteratorRO.hasNext() => true after next()");
            } else {
                ok("ListIteratorRO.hasNext() => false after next()");
            }

            // test hasPrevious() after call to next()
            if (iterator.hasPrevious()) {
                ok("ListIteratorRO.hasPrevious() => true after next()");
            } else {
                error("ListIteratorRO.hasPrevious() => false after next()");
            }

            // make sure the object retrieved earlier from next() is the same
            // object as that returned now by previous()
            Object prev = iterator.previous();

            if (prev.equals(next)) {
                ok("next == prev");
            } else {
                error("next != prev");
            }

            // reset the iterator
            iterator = list.listIteratorRO();

            // try one more time for good measure to make sure the iterator state
            // isn't messed up
            try {
                next = iterator.next();
                prev = iterator.previous();
                Object next1 = iterator.next();
                //Object prev1 = iterator.previous();

                //if (prev.equals(next) && prev.equals(next1) && prev.equals(prev1)) {
                //    ok("prev() == next()");
                //} else {
                //    error("prev() != next() after alternating next() and prev()");
                //}

            } catch (NoSuchElementException e) {
                error("next() threw NoSuchElementException");
                throw(e);
            }

            // call next(), then call hasPrevious(); it should return true
            list = createList(SEQUENTIAL_LIST, 1);
            iterator = list.listIteratorRO();

            try {

                if (iterator.hasNext() && iterator.next() != null) {
                    ok("next() != null after hasNext() => true");
                } else {
                    error("! (next() != null after hasNext() => true)");
                }

            } catch (NoSuchElementException e1) {
                error("NoSuchElementException calling next() after hasNext() => true");
                throw(e1);
            } 

            try {

                if (iterator.hasPrevious() && iterator.previous() != null) {
                    ok("previous() != null after hasPrevious() => true");
                } else {
                    error("! (previous() != null after hasPrevious() => true)");
                }
            } catch (NoSuchElementException e2) {
                error("NoSuchElementException calling previous() after hasPrevious() => true");                        
                throw(e2);
            }
        }
        
    }

    class TestManyElementList extends TestCase {
        public TestManyElementList() {
            super("TestManyElementList");
        }
        
        /** @see TestCase.run */
        public void run() {
            int count = 20;
            GapListRW list = createList(SEQUENTIAL_LIST, count);
            ListIteratorRO iterator = list.listIteratorRO();

            // iterate from beginning of the list to the end
            while (iterator.hasNext()) {
                iterator.next();
            }
            
            // iterate from end of the list to the beginning
            // there should be 'count' iterations because after calling
            // next() as many times as possible, we're "off the end" of the list,
            // with no next element.
            int num = count;
            while (iterator.hasPrevious()) {
                num--;
                iterator.previous();
            }
            
            if (num == 0) {
                ok("previous() was called correct number of times");
            } else {
                error("foobar");
                error("expected " + count + "calls to previous; actual: " + (count - num));
            }
        
        
            // iterate to the middle element of the list, then dance on that element
            int middle = count >> 1;
            int dances = 20;
            while (iterator.hasNext() && middle > 0) {
                middle--;
                iterator.next();
            }

            for (int i = 0; i < 20; ++i) {
                try {
                    Object next = iterator.next();
                    Object prev = iterator.previous();
                    Object next2 = iterator.next();
                    Object prev2 = iterator.previous();
                    
                    if (next != next2) {
                        error("next != next");
                        break;
                    }
                    
                    if (prev != prev2) {
                        error("prev != prev");
                        break;
                    }

                    dances--;

                } catch (NoSuchElementException e) {
                    error("next() or prev() caused exception");
                    throw(e);   // throw it again in case the superclass wants
                                // to print a stack trace
                }
            }

            if (dances == 0) {
                ok("repeated calls to next() and prev() produced correct result");                
            }
        }
    }


    class TestAgainstStandardJavaListIterator extends TestCase {
        
        public TestAgainstStandardJavaListIterator() {
            super("TestAgainstStandardJavaListIterator");
        }
    
        /** @see TestCase.run */
        public void run() {

            int count = 5;
            GapListRW katabaList = createList(SEQUENTIAL_LIST, count);
            com.kataba.coll.ListIteratorRO ki = katabaList.listIteratorRO();

            java.util.Collection javaUtilCollection = (java.util.Collection)katabaList;
            Vector vector = new Vector(javaUtilCollection);
            java.util.ListIterator ji = vector.listIterator();
            
            // make sure hasNext() works correctly
            int numEqualElems = 0;
            
            while (ki.hasNext() && ji.hasNext()) {
                if (ki.next().equals(ji.next())) {
                    numEqualElems++;
                } else {
                    error("katabase.nextIndex() != java.nextNextIndex() (" + ki.next() + "," + ji.next());
                }
            }

            if (numEqualElems != count) {
                error("Kataba and Java next() not equivalent.(" + numEqualElems + "," + count);
            } else {
                ok("Kataba and Java list next() are equivalent.");
            }

            int numOkPrevious = count;
            int numOkPreviousIndex = count;

            while (ki.hasPrevious() && ji.hasPrevious()) {

                if (ki.previous().equals(ji.previous())) {
                    numOkPrevious--;

                    if (ki.previousIndex() == ji.previousIndex()) {
                        numOkPreviousIndex--;
                    }
                }
            }

            if (numOkPrevious != 0) {
                error("Kataba and Java previous() not equivalent.");
            } else {
                ok("Kataba and Java list previous() are equivalent.");
            }
            
            if (numOkPreviousIndex != 0) {
                error("Kataba and Java previousIndex() not equivalent: " + numOkPreviousIndex);
            } else {
                ok("Kataba and Java list previousIndex() are equivalent.");
            }
                        
        }
    }

}

