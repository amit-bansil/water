
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;

public abstract class TestInterfaceWrapper {
    
    protected TestInterfaceWrapper() {
        
    }
    
    protected void echo(Object o) {
        Out.ln(o);
    }
}