
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** A DiffTest for the com.kataba.coll.ListRW class
 *
 * @author com.kataba.util.DiffTest_Gen
 */
public abstract class DiffTest_ListRW
    extends DiffTest
    implements ListRW
{
    protected ListRW modelA;
    protected ListRW modelB;

    /** Constructs */
    public DiffTest_ListRW(String _name) {
        super(_name);
    }

    public boolean addAll(int a, java.util.Collection b) {
        String test = "addAll("+a+','+b+')';
        preMethodTest("addAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.addAll(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.addAll(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean addAll(int a, CollectionRO b) {
        String test = "addAll("+a+','+b+')';
        preMethodTest("addAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.addAll(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.addAll(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void add(int a, Object b) {
        String test = "add("+a+','+b+')';
        preMethodTest("add");

        try {
            modelA.add(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.add(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public Object remove(int a) {
        String test = "remove("+a+')';
        preMethodTest("remove");

        Object modelARet = null;
        try {
            modelARet = modelA.remove(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.remove(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object set(int a, Object b) {
        String test = "set("+a+','+b+')';
        preMethodTest("set");

        Object modelARet = null;
        try {
            modelARet = modelA.set(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.set(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void removeAll(com.kataba.util.ArrayRO_int a) {
        String test = "removeAll("+a+')';
        preMethodTest("removeAll");

        try {
            modelA.removeAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.removeAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public void retainAll(com.kataba.util.ArrayRO_int a) {
        String test = "retainAll("+a+')';
        preMethodTest("retainAll");

        try {
            modelA.retainAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.retainAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public java.util.List subList(int a, int b) {
        String test = "subList("+a+','+b+')';
        preMethodTest("subList");

        java.util.List modelARet = null;
        try {
            modelARet = modelA.subList(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        java.util.List modelBRet = null;
        try {
            modelBRet = modelB.subList(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void removeRange(int a, int b) {
        String test = "removeRange("+a+','+b+')';
        preMethodTest("removeRange");

        try {
            modelA.removeRange(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.removeRange(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public java.util.ListIterator listIterator(int a) {
        String test = "listIterator("+a+')';
        preMethodTest("listIterator");

        java.util.ListIterator modelARet = null;
        try {
            modelARet = modelA.listIterator(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        java.util.ListIterator modelBRet = null;
        try {
            modelBRet = modelB.listIterator(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public java.util.ListIterator listIterator() {
        String test = "listIterator("+')';
        preMethodTest("listIterator");

        java.util.ListIterator modelARet = null;
        try {
            modelARet = modelA.listIterator();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        java.util.ListIterator modelBRet = null;
        try {
            modelBRet = modelB.listIterator();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void swap(int a, int b) {
        String test = "swap("+a+','+b+')';
        preMethodTest("swap");

        try {
            modelA.swap(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.swap(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public void move(int a, int b) {
        String test = "move("+a+','+b+')';
        preMethodTest("move");

        try {
            modelA.move(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.move(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public ListCursorRW listCursorRW(int a) {
        String test = "listCursorRW("+a+')';
        preMethodTest("listCursorRW");

        ListCursorRW modelARet = null;
        try {
            modelARet = modelA.listCursorRW(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListCursorRW modelBRet = null;
        try {
            modelBRet = modelB.listCursorRW(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListCursorRW listCursorRW() {
        String test = "listCursorRW("+')';
        preMethodTest("listCursorRW");

        ListCursorRW modelARet = null;
        try {
            modelARet = modelA.listCursorRW();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListCursorRW modelBRet = null;
        try {
            modelBRet = modelB.listCursorRW();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListRW subListRW(int a, int b) {
        String test = "subListRW("+a+','+b+')';
        preMethodTest("subListRW");

        ListRW modelARet = null;
        try {
            modelARet = modelA.subListRW(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListRW modelBRet = null;
        try {
            modelBRet = modelB.subListRW(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListIteratorRW listIteratorRW() {
        String test = "listIteratorRW("+')';
        preMethodTest("listIteratorRW");

        ListIteratorRW modelARet = null;
        try {
            modelARet = modelA.listIteratorRW();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListIteratorRW modelBRet = null;
        try {
            modelBRet = modelB.listIteratorRW();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListIteratorRW listIteratorRW(int a) {
        String test = "listIteratorRW("+a+')';
        preMethodTest("listIteratorRW");

        ListIteratorRW modelARet = null;
        try {
            modelARet = modelA.listIteratorRW(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListIteratorRW modelBRet = null;
        try {
            modelBRet = modelB.listIteratorRW(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int hashCode() {
        String test = "hashCode("+')';
        preMethodTest("hashCode");

        int modelARet = 0;
        try {
            modelARet = modelA.hashCode();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.hashCode();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean equals(Object a) {
        String test = "equals("+a+')';
        preMethodTest("equals");

        boolean modelARet = false;
        try {
            modelARet = modelA.equals(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.equals(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int indexOf(Object a) {
        String test = "indexOf("+a+')';
        preMethodTest("indexOf");

        int modelARet = 0;
        try {
            modelARet = modelA.indexOf(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.indexOf(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int indexOf(Object a, int b, boolean c) {
        String test = "indexOf("+a+','+b+','+c+')';
        preMethodTest("indexOf");

        int modelARet = 0;
        try {
            modelARet = modelA.indexOf(a, b, c);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.indexOf(a, b, c);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int lastIndexOf(Object a) {
        String test = "lastIndexOf("+a+')';
        preMethodTest("lastIndexOf");

        int modelARet = 0;
        try {
            modelARet = modelA.lastIndexOf(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.lastIndexOf(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object get(int a) {
        String test = "get("+a+')';
        preMethodTest("get");

        Object modelARet = null;
        try {
            modelARet = modelA.get(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.get(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void addListener(ListRO.Listener a, Object b) {
        String test = "addListener("+a+','+b+')';
        preMethodTest("addListener");

        try {
            modelA.addListener(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.addListener(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public void removeListener(ListRO.Listener a) {
        String test = "removeListener("+a+')';
        preMethodTest("removeListener");

        try {
            modelA.removeListener(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.removeListener(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public com.kataba.util.ArrayRO_int indexesOf(CollectionRO a) {
        String test = "indexesOf("+a+')';
        preMethodTest("indexesOf");

        com.kataba.util.ArrayRO_int modelARet = null;
        try {
            modelARet = modelA.indexesOf(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        com.kataba.util.ArrayRO_int modelBRet = null;
        try {
            modelBRet = modelB.indexesOf(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListCursorRO listCursorRO() {
        String test = "listCursorRO("+')';
        preMethodTest("listCursorRO");

        ListCursorRO modelARet = null;
        try {
            modelARet = modelA.listCursorRO();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListCursorRO modelBRet = null;
        try {
            modelBRet = modelB.listCursorRO();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListCursorRO listCursorRO(int a) {
        String test = "listCursorRO("+a+')';
        preMethodTest("listCursorRO");

        ListCursorRO modelARet = null;
        try {
            modelARet = modelA.listCursorRO(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListCursorRO modelBRet = null;
        try {
            modelBRet = modelB.listCursorRO(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListRO subListRO(int a, int b) {
        String test = "subListRO("+a+','+b+')';
        preMethodTest("subListRO");

        ListRO modelARet = null;
        try {
            modelARet = modelA.subListRO(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListRO modelBRet = null;
        try {
            modelBRet = modelB.subListRO(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListIteratorRO listIteratorRO() {
        String test = "listIteratorRO("+')';
        preMethodTest("listIteratorRO");

        ListIteratorRO modelARet = null;
        try {
            modelARet = modelA.listIteratorRO();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListIteratorRO modelBRet = null;
        try {
            modelBRet = modelB.listIteratorRO();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public ListIteratorRO listIteratorRO(int a) {
        String test = "listIteratorRO("+a+')';
        preMethodTest("listIteratorRO");

        ListIteratorRO modelARet = null;
        try {
            modelARet = modelA.listIteratorRO(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        ListIteratorRO modelBRet = null;
        try {
            modelBRet = modelB.listIteratorRO(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object get(Object a) {
        String test = "get("+a+')';
        preMethodTest("get");

        Object modelARet = null;
        try {
            modelARet = modelA.get(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.get(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean contains(Object a) {
        String test = "contains("+a+')';
        preMethodTest("contains");

        boolean modelARet = false;
        try {
            modelARet = modelA.contains(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.contains(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int size() {
        String test = "size("+')';
        preMethodTest("size");

        int modelARet = 0;
        try {
            modelARet = modelA.size();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.size();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object[] toArray() {
        String test = "toArray("+')';
        preMethodTest("toArray");

        Object[] modelARet = null;
        try {
            modelARet = modelA.toArray();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object[] modelBRet = null;
        try {
            modelBRet = modelB.toArray();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object[] toArray(Object[] a) {
        String test = "toArray("+a+')';
        preMethodTest("toArray");

        Object[] modelARet = null;
        try {
            modelARet = modelA.toArray(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object[] modelBRet = null;
        try {
            modelBRet = modelB.toArray(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean isEmpty() {
        String test = "isEmpty("+')';
        preMethodTest("isEmpty");

        boolean modelARet = false;
        try {
            modelARet = modelA.isEmpty();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.isEmpty();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean containsAll(CollectionRO a) {
        String test = "containsAll("+a+')';
        preMethodTest("containsAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.containsAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.containsAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean containsAll(java.util.Collection a) {
        String test = "containsAll("+a+')';
        preMethodTest("containsAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.containsAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.containsAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void addListener(CollectionRO.Listener a, Object b) {
        String test = "addListener("+a+','+b+')';
        preMethodTest("addListener");

        try {
            modelA.addListener(a, b);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.addListener(a, b);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public void removeListener(CollectionRO.Listener a) {
        String test = "removeListener("+a+')';
        preMethodTest("removeListener");

        try {
            modelA.removeListener(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.removeListener(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public IteratorRO iteratorRO() {
        String test = "iteratorRO("+')';
        preMethodTest("iteratorRO");

        IteratorRO modelARet = null;
        try {
            modelARet = modelA.iteratorRO();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        IteratorRO modelBRet = null;
        try {
            modelBRet = modelB.iteratorRO();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object lock() {
        String test = "lock("+')';
        preMethodTest("lock");

        Object modelARet = null;
        try {
            modelARet = modelA.lock();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.lock();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean addAll(CollectionRO a) {
        String test = "addAll("+a+')';
        preMethodTest("addAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.addAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.addAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean addAll(java.util.Collection a) {
        String test = "addAll("+a+')';
        preMethodTest("addAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.addAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.addAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean add(Object a) {
        String test = "add("+a+')';
        preMethodTest("add");

        boolean modelARet = false;
        try {
            modelARet = modelA.add(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.add(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public java.util.Iterator iterator() {
        String test = "iterator("+')';
        preMethodTest("iterator");

        java.util.Iterator modelARet = null;
        try {
            modelARet = modelA.iterator();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        java.util.Iterator modelBRet = null;
        try {
            modelBRet = modelB.iterator();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean remove(Object a) {
        String test = "remove("+a+')';
        preMethodTest("remove");

        boolean modelARet = false;
        try {
            modelARet = modelA.remove(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.remove(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public void clear() {
        String test = "clear("+')';
        preMethodTest("clear");

        try {
            modelA.clear();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        try {
            modelB.clear();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            ok(test, "void");
        }
    }

    public boolean removeAll(java.util.Collection a) {
        String test = "removeAll("+a+')';
        preMethodTest("removeAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.removeAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.removeAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean removeAll(CollectionRO a) {
        String test = "removeAll("+a+')';
        preMethodTest("removeAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.removeAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.removeAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean retainAll(java.util.Collection a) {
        String test = "retainAll("+a+')';
        preMethodTest("retainAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.retainAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.retainAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean retainAll(CollectionRO a) {
        String test = "retainAll("+a+')';
        preMethodTest("retainAll");

        boolean modelARet = false;
        try {
            modelARet = modelA.retainAll(a);
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.retainAll(a);
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public IteratorRW iteratorRW() {
        String test = "iteratorRW("+')';
        preMethodTest("iteratorRW");

        IteratorRW modelARet = null;
        try {
            modelARet = modelA.iteratorRW();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        IteratorRW modelBRet = null;
        try {
            modelBRet = modelB.iteratorRW();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }
}
