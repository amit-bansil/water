
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

public class CollTestData {
    public static class Types extends Enum_int {
        public static final int WRAPPER_LIST = 1;
        public static final int GAP_LIST = 2;
        public static final int SYNCH_LIST = 3;
        public static final int JDK_LIST = 4;

        public static final int HASH_SET = 5;
        public static final int ARRAY_HASH_SET = 6;
        public static final int WRAPPER_SET = 7;
        public static final int SYNCH_SET = 8;
        public static final int JDK_SET = 9;

        private Types() {}
    }
    static Types TYPES = new Types();

    private Test test;

    public int bType;
    public int collType;
    public CollectionRW collA;
    public CollectionRW collB;
    public java.util.List listB;
    public java.util.Set setB;

    public CollTestData(Test _test, int _bType) {
        test = _test;
        bType = _bType;
    }

    /** Executes the test on a given collection type. */
    public void testColl(int _collType) {
        test.push("collection: " + TYPES.getName(_collType));
        collType = _collType;
        test.testColl();
        test.pop();
    }

    /** Executes the test on a given set of collection types. */
    public void testColls(int[] collTypes) {
        for(int i=0; i<collTypes.length; i++) {
            testColl(collTypes[i]);
        }
    }

    public void runTestAgainstListImplementations() {
        // note:  the loop depends on the contiguous constants for the
        // list types
        for (int type = Types.WRAPPER_LIST; type <= Types.JDK_LIST; ++type) {
            test.push("collection: " + TYPES.getName(type));
            collType = type;
            test.testColl();
            test.pop();
        }
    }

    public void runTestAgainstSetImplementations() {
        for (int type = Types.HASH_SET; type <= Types.JDK_SET; ++type) {
            test.push("collection: " + TYPES.getName(type));
            collType = type;
            test.testColl();
            test.pop();
        }
    }

    /** Resets 'collA' and 'collB' */
    public void reset() {
        // construct
        collA = newColl(collType);

        // constructs the appropriate version
        switch(bType) {
        case Types.JDK_LIST:
            listB = new java.util.ArrayList();
            collB = new ListToListRW(listB);
            break;
        case Types.JDK_SET:
            setB = new java.util.HashSet();
            collB = new SetToSetRW(setB);
            break;
        default:
            throw new IllegalStateException("bType: "+bType);
        }
    }

    /** Returns whether 'collA' and 'collB' are equal.  Reports errors
     * to 'test' if they are not. */
    public boolean compareColls() {
        // compare the lists
        if(collA.size() != collB.size()) {
            test.error("Size differs: collA("+collA.size()+") collB("+collB.size()+")");
            return false;
        }

        int i = 0;
        IteratorRO itrB = collB.iteratorRO();
        for(IteratorRO itrA=collA.iteratorRO(); itrA.hasNext(); ) {
            Object elemA = itrA.next();
            Object elemB = itrB.next();
            if(!Util.equals(elemA, elemB)) {
                test.error("Element at index "+i+" differs:"
                           + " collA:"+collA+" collB:"+collB);
                return false;
            }
            i++;
        }
        return true;
    }

    public static CollectionRW newColl(int collType) {
	switch(collType) {
	case Types.WRAPPER_LIST:
	    return new WrappedListRW(new GapListRW(2));
	case Types.GAP_LIST:
	    return new GapListRW();
	case Types.SYNCH_LIST:
	    return new SynchronizedListRW(new GapListRW(2));
	case Types.JDK_LIST:
	    return new ListToListRW(new java.util.ArrayList(2));

	case Types.HASH_SET:
	    return new HashSetRW();
	case Types.ARRAY_HASH_SET:
	    return new ArrayHashSetRW();
	case Types.WRAPPER_SET:
	    return new WrappedSetRW(new HashSetRW());
	case Types.SYNCH_SET:
	    return new SynchronizedSetRW(new HashSetRW());
	case Types.JDK_SET:
	    return new SetToSetRW(new java.util.HashSet());

        default:
            throw new IllegalArgumentException("no such type: " + collType);
	}
    }

    public interface Test {
        public void testColl();
        public void error(String message);
        public void push(String subTestName);
        public void pop();
    }
}
