
package com.kataba.coll.test;

import com.kataba.coll.*;

public class MinListRW
    extends AbstractListRW
{
    /** @see CollectionRO#size() */
    public int size() {
        return 0;
    }

    /** @see ListRO#get(int) */
    public Object get(int index) {
        return null;
    }

    /** @see ListRW#add(int,Object) */
    public void add(int index, Object element) {
    }

    /** @see ListRW#remove(int) */
    public Object remove(int index) {
        return null;
    }
}
