
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;


/**
 * Tests the default implementation of the ListIteratorRW interface.
 *<p>
 * The following read-write methods of the ListIterator interface are tested.
 *      public void add(Object object);
 *      public void set(Object object);
 *
 * @author Ray Vander Veen
 */
public class TestListIteratorRW
    extends CollectionTest
{
    /** constructs a TestListIteratorRW instance with command-line arguments
     *@param args command line arguments
     */
    public TestListIteratorRW(String [] args) {
        super(args);
    }
    
    protected void runTests() {        
        testingNotice("ListIteratorRW");

        runTest(new TestEmptyList());
        runTest(new TestSetMethod());
        runTest(new TestAddMethod());
        //runTest(new TestListIteratorRWAgainstStandardJavaListIterator());


        // TODO:  Test all error conditions.  Make sure correct exceptions are thrown.
        // TODO:  Test set() and add() methods against standard Java ListIterator.
        
    }

    /** mainline */
    public static void main(String [] args) {

        TestListIteratorRW tiro = new TestListIteratorRW(args);

        tiro.runTests();
        tiro.summary();
        
    }

    class TestEmptyList extends TestCase {
        
        public TestEmptyList() {
            super("TestListIteratorRW.TestEmptyList");
        }
        
        /** @see TestCase.run */
        public void run() {
            
            startmsg("testing ListIteratorRW on empty list.");
            
            GapListRW list = createList();
            ListIteratorRW i = list.listIteratorRW();

            if (i.hasNext()) {
                error("ListIteratorRW.hasNext() => true on empty list");
            } else {
                ok("ListIteratorRW.hasNext() => false on empty list");
            }
                
            i.add(e());

            if (i.hasNext()) {
                ok("ListIteratorRW.hasNext() => true after adding to empty list");
            } else {
                error("ListIteratorRW.hasNext() => false after adding to empty list");
            }

            endmsg();
        }
    }

    class TestSetMethod extends TestCase {
        
        public TestSetMethod() {
            super("TestListIteratorRW.TestSetMethod");
        }
        
        /** @see TestCase.run */
        public void run() {

            startmsg("testing ListIteratorRW's set() method");

            int count = 20;
            GapListRW list = createList(SEQUENTIAL_LIST, 20);
            ListIteratorRW it = list.listIteratorRW();
            int i;
            
            // change all elements in the list to have the value 10
            while (it.hasNext()) {
                it.next();
                it.set(e(10));
            }
            
            // the list should still have 20 elements in it
            int size = list.size();
            
            if (size != count) {
                error("ListIteratorRW.set() changed the number of elements in the list.");
            } else {
                ok("ListIteratorRW.set() didn't change the number of elements.");
            }

            // make sure all elements in the list have the value 10
            Integer intTen = new Integer(10);
            it = list.listIteratorRW();
            int numOk = 0;
            
            while(it.hasNext()) {
                if (! it.next().equals(intTen)) {
                    error("ListIteratorRW.set() did not set all values correctly.");
                } else {
                    numOk++;
                }
            }
            
            if (numOk == count) {
                ok("ListIteratorRW.set() correctly set all values.");
            }

            // make sure IllegalStateException is thrown if set() is called before a call
            // to next() has been made on the element to be set
            GapListRW list2 = createList(SEQUENTIAL_LIST, 2);
            ListIteratorRW irw = list2.listIteratorRW();
            
            try {
                irw.set(e());
                error("ListIteratorRW.set() didn't throw IllegalStateException when next() " + 
                        "not called prior to calling set().");
            } catch (IllegalStateException e) {
                ok("ListIteratorRW.set() threw IllegalStateException when next() not called first");
            }
            
            // make sure IllegalStateException is thrown if set() is called before a call
            // to next() is made after a call to remove().
            try {
                
                if (irw.hasNext()) {
                    irw.next();     // call next()...
                    irw.add(e());   // but call add() before calling set; set() should throw exception
                    irw.set(e());
                    
                    error("ListIteratorRW.set() didn't throw IllegalStateException when next() " + 
                            "not called after add(), and before calling set().");                
                }
            } catch (IllegalStateException e) {
                ok("ListIteratorRW.set() threw IllegalStateException when next() not called " +
                    " after a call to add().");
                    
            }

            // make sure IllegalStateException is thrown if set() is called before a call
            // to next() is made after a call to remove().
            try {
                if (irw.hasNext()) {
                    irw.next();     // call next()...
                    irw.remove();   // but call remove() before calling set; set() should throw exception
                    irw.set(e());

                    error("ListIteratorRW.set() didn't throw IllegalStateException when next() " + 
                            "not called after remove(), and before calling set().");                
                }
            } catch (IllegalStateException e) {
                ok("ListIteratorRW.set() threw IllegalStateException when next() not called " +
                        " first after a call to remove().");
            }
            
            endmsg();
        }

        
        
    }

    class TestAddMethod extends TestCase {
        
        public TestAddMethod() {
            super("TestListIteratorRW.TestAddMethod");
        }

        /** @see TestCase.run */
        public void run() {

            testAddOnEmptyList();
            testAddOnManyElementList();
            //testAddOnOneElementList();
            ensureNextSequencePreserved();
        }

        private void ensureNextSequencePreserved() {
            GapListRW list = createList(SEQUENTIAL_LIST, 5);
            ListIteratorRW iter = list.listIteratorRW();
            
            startmsg("testing ListIteratorRW.add() to make sure seqence of next() elements preserved.");
            
            // create two vectors:  one is a straight copy of the gap list
            // the other is created by iterating over the gaplist with 
            // interspersed calls to add(). The resulting two vectors should
            // be equal.
            
            java.util.Collection collection = (java.util.Collection)list;
            Vector vector1 = new Vector(collection);
            Vector vector2 = new Vector();

            while (iter.hasNext()) {
                vector2.addElement(iter.next());
                iter.add(e());
            }

            if (getVerbose()) {
                printList(vector1, "TestListIteratorRW$TestAddMethod.ensureNextSequencePreserved");
            }

            if (vector1.equals(vector2)) {
                ok("two lists are equal after straight copy of collection and iteration " +
                    "with next(), interspersed with calls to add().");
            } else {
                error("two lists are equal after straight copy of collection and iteration " +
                    "with next(), interspersed with calls to add().");
            }
            
            endmsg();
        }

        private void testAddOnEmptyList() {

            startmsg("testing ListIteratorRW.add(); add to empty list");

            int count = 5;
            GapListRW list = createList(SEQUENTIAL_LIST, count);
            ListIteratorRW i = list.listIteratorRW();
            
            i.add(e());

            // make sure hasNext() returns false and hasPrevious() returns true
            if (i.hasPrevious()) {
                ok("hasPrevious() returned true after add to empty list.");
            } else {
                error("hasPrevious() returned false after add to empty list");
            }
                
            endmsg();
        }

        private void testAddOnOneElementList() {
            startmsg("testing ListIteratorRW.add() on one-element list");
            
            endmsg();
            
        }
        
        private void testAddOnManyElementList() {
            
            startmsg("testing ListIteratorRW.add(); add to many-element list");
            
            int size = 20;
            int mid = 10;
            GapListRW list = createList(SEQUENTIAL_LIST, size);
            ListIteratorRW i = list.listIteratorRW();
            
            // skip to the middle of the list so we can do an add in the middle
            // of the list
            for (int j = 0; j < 10; ++j) {
                i.next();    
            }

            // grab the next() element for future comparison
            Object oldNext = i.next();
            Object newElement = e();

            if (getVerbose()) {
                echo("list before add()");
                printList(list);
            }

            i.add(newElement);

            if (getVerbose()) {
                echo("list after add()");
                printList(list);
            }

            // sanity check; if this doesn't work we're in big trouble
            if (list.size() == size + 1) {
                ok("add() increased list size by 1.");
            } else {
                error("add() did not increase list size by 1.");
            }

            // now previous() should return us the element that we added
            Object previous = i.previous();

            if (getVerbose()) {
                echo("prevIndex=" + i.previousIndex());
                echo("nextIndex=" + i.nextIndex());
            }

            if (previous != newElement) {
                error("ListIteratorRW.add() caused wrong previous() value to be returned.");
                if (getVerbose()) {
                    echo("prev=" + oldNext + ",newElement=" + newElement);
                }
            } else {
                ok("ListIteratorRW.add() maintained integrity of previous().");
            }
            
            endmsg();
        }
    }

    class TestListIteratorRWAgainstStandardJavaListIterator extends TestCase {
        
        private KJListIteratorPair listPair;
        private ListIteratorRWWrapper wrapper;
        
        public TestListIteratorRWAgainstStandardJavaListIterator() {
            super("TestListIteratorRW.TestListIteratorRWAgainstStandardJavaListIterator");
        }

        private ListIteratorRWWrapper createLists() {
            return createLists(0);            
        }

        private ListIteratorRWWrapper createLists(int count) {
            listPair = TestUtil.createListIteratorInfo(count);
            wrapper = new ListIteratorRWWrapper(listPair);                                    
            
            return wrapper;
        }

        private void testAddToEmptyList() {
            ListIteratorRWWrapper wrapper = createLists();
            
            if (getVerbose()) {
                echo("** test add to empty list");
            }
            
            // make sure add() works on empty list
            wrapper.setHint("empty list");
            wrapper.add(e());
            
            try {
                
                Object next = wrapper.next();
                
                if (verbose()) {
                    echo("wrapper.next() => " + next + " after add()");
                }
                
            } catch (Exception e) {
                
            }
                

        }

        private void testAddToNonEmptyList() {
            
            ListIteratorRWWrapper wrapper = createLists(5);
            
            if (getVerbose()) {
                echo ("\nTEST CASE - testAddToNonEmptyList()");
                CollectionTest.printList(listPair.kList);
                echo("");
            }

            // make sure add() works on non empty list
            wrapper.setHint("non-empty list");
            wrapper.add(e());

            if (getVerbose()) {
                CollectionTest.printList(listPair.kList);
            }

            Object next = wrapper.next();
            if (verbose()) {
                echo("wrapper.next() => " + next + " after add()");
            }

            // make sure next() and previous() return the same result
            // after calling add() somewhere in the middle of the list
            next = wrapper.next();
            next = wrapper.next();
            
            
        }

        private void testHasNextOnEmptyList() {
            ListIteratorRWWrapper wrapper = createLists();
            wrapper.setHint("empty list");
            wrapper.hasNext();
        }

        private void testHasNextOnNonEmptyList() {
            ListIteratorRWWrapper wrapper = createLists(5);
            wrapper.setHint("non-empty list(5)");
            wrapper.hasNext();
        }

        private void testHasPreviousOnEmptyList() {
            ListIteratorRWWrapper wrapper = createLists();
            wrapper.setHint("empty list");
            wrapper.hasPrevious();
        }

        private void testHasPreviousOnNonEmptyList() {
            ListIteratorRWWrapper wrapper = createLists(5);
            wrapper.setHint("non-empty list(5)");
            wrapper.hasPrevious();
        }

        private void testPreviousIndexOnEmptyList() {
            ListIteratorRWWrapper wrapper = createLists();
            wrapper.setHint("empty list");
            wrapper.previousIndex();
        }

        private void testPreviousIndexOnNonEmptyList() {
            ListIteratorRWWrapper wrapper = createLists(5);
            wrapper.setHint("non-empty list(5)");
            wrapper.hasPrevious();
        }

        /** @see TestCase.run */
        public void run() {

            testAddToEmptyList();
            testAddToNonEmptyList();
            testHasNextOnEmptyList();
            testHasNextOnNonEmptyList();
            testHasPreviousOnEmptyList();
            testHasPreviousOnNonEmptyList();
            testPreviousIndexOnEmptyList();
            testPreviousIndexOnNonEmptyList();
        }
    }

    // inner class that wraps two ListIteratorRW objects and it implements
    // ListIteratorRW.  It ensures that both interfaces behave in the same
    // manner for all of the methods in the iterface.
    class ListIteratorRWWrapper extends TestInterfaceWrapper implements ListIterator {

        // a kataba iterator over the list
        private java.util.ListIterator kataba;
        
        // a java iterator over the list
        private java.util.ListIterator java;
        
        // the list being iterated by the java iterator
        private java.util.List jList;

        // the list being iterated by the kataba iterator
        private java.util.List kList;

        // hint for output
        private String hint;
                
        public ListIteratorRWWrapper(KJListIteratorPair info) {
            this(info.ki, info.ji, info.kList, info.jList);
        }
        
        /** constructs a ListIteratorRWWrapper */
        public ListIteratorRWWrapper(java.util.ListIterator katabaIterator, java.util.ListIterator javaIterator
                                    , java.util.List _kList, java.util.List _jList) {
            kataba = katabaIterator;
            java = javaIterator;
            kList = _kList;
            jList = _jList;
        
        }
        
        private void setHint(String _hint) {
            hint = _hint;
        }
        
        private String hint() {
            return " (" + hint + ") ";
        }
        

        public boolean hasNext() {
            boolean k = kataba.hasNext();
            boolean j = java.hasNext();
            
            if (k != j) {
                error("ListIteratorRWWrapper: kataba.hasNext() != java.hasNext() (" + 
                            k + "," + j + ")" + hint());
            } else {
                ok("ListIteratorRWWrapper: kataba.hasNext() == java.hasNext()" + hint());
            }

            return k;
        }

        public Object next() {

            Object kEx = null;
            Object jEx = null;

            boolean javaThrewNoSuchElementException = false;
            boolean katabaThrewNoSuchElementException = false;

            Object kNext = null;
            Object jNext = null;

            try {
                kNext = kataba.next();
            } catch (NoSuchElementException e) {
                katabaThrewNoSuchElementException = true;
            }
            
            try {
                jNext = java.next();
            } catch (NoSuchElementException e) {
                javaThrewNoSuchElementException = true;
            }
            
            if (javaThrewNoSuchElementException != katabaThrewNoSuchElementException) {
                error("Exceptions not the same: (kataba=" + katabaThrewNoSuchElementException +
                        ",java=" + javaThrewNoSuchElementException);
            } else {
                ok("Both Java and Kataba threw NoSuchElementException on next()");                
                
                if (! kNext.equals(jNext)) {
                    error("ListIteratorRWWrapper: kataba.next() != java.next() (" + kNext + "," + jNext + ")");
                } else {
                    ok("ListIteratorRWWrapper: kataba.next() == java.next()" + hint());
                    
                }
            }
            
            return kNext;
        }
    
        public boolean hasPrevious() {
            boolean k = kataba.hasPrevious();
            boolean j = java.hasPrevious();
            
            if (k != j) {
                error("ListIteratorRWWrapper: kataba.hasPrevious() != java.hasPrevious() (" + k + "," 
                        + j + ")" + hint());                
            } else {
                ok("ListIteratorRWWrapper: kataba.hasPrevious() == java.hasPrevious()" + hint());
            }
            
            return k;
        }

        public int nextIndex() {
            int k = kataba.nextIndex();
            int j = java.nextIndex();
            if (k != j) {
                error("ListIteratorRWWrapper: kataba.nextIndex() != java.nextIndex() (" + kataba.nextIndex() + "," 
                        + java.nextIndex() + ")");                
            } else {
                ok("ListIteratorRWWrapper: kataba.nextIndex() == java.nextIndex()");
            }        
            
            return k;
        }
        
        public int previousIndex() {
            int k = kataba.previousIndex();
            int j = java.previousIndex();
            if (k != j) {
                error("ListIteratorRWWrapper: kataba.previousIndex() != java.previousIndex() (" + k + "," + j + ")");                
            } else {
                ok("ListIteratorRWWrapper: kataba.previousIndex() == java.previousIndex()");
            }
            
            return k;
        }
                
        public Object previous() {
            Object k = kataba.previous();
            Object j = java.previous();
            
            if (! k.equals(j)) {
                error("ListIteratorRWWrapper: kataba.previous() != java.previous() (" +
                    k + "," + j + ")");
            } else {
                ok("ListIteratorRWWrapper: kataba.previous() == java.previous()");
            }
            
            return k;
        }
        
        public void add(Object o) {
            if (getVerbose()) {
                echo("ListIteratorRWWrapper.add(" + o + ")");
            }
        
            // add the same element to both lists and make sure the resultant
            // lists are equal
            kataba.add(o);
            java.add(o);
            
            if (kList.equals(kList)) {
                ok("ListIteratorRWWrapper: kataba.add() <=> java.add()" + hint());
            } else {
                error("ListIteratorRWWrapper: kataba.add() ! <=> java.add()" + hint());
                if (getVerbose()) {
                    echo("kataba list after add():");
                    printList(kList);
                    echo("java list after add():");
                    printList(jList);
                }
            }
        }

        public void set(Object o) {
                        
        }

        public void remove() {
            
        }

    }


}


