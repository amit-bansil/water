
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** An EVTest for the com.kataba.coll.ListCursorRW class
 *  For each method in the class, an expected-value test 
 *  method and an expected-exception test method is generated.
 *
 * @author com.kataba.util.EVTest_Gen
 */
public abstract class EVTest_ListCursorRW
    extends EVTest
{

    protected ListCursorRW _modelToTest;
    protected Exception exception;

    /** Constructs */
    public EVTest_ListCursorRW(String _name) {
        super(_name);
    }

    public void add(int a, Object b) {
        add(a, b, (Exception)null);
    }

    public void add(int a, Object b, Exception expectedException) {
        String test = "add("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.add(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void remove(int a) {
        remove(a, (Exception)null);
    }

    public void remove(int a, Exception expectedException) {
        String test = "remove("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.remove(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void set(int a, Object b) {
        set(a, b, (Exception)null);
    }

    public void set(int a, Object b, Exception expectedException) {
        String test = "set("+a+','+b+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.set(a, b);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public Object get(int a, Object expectedValue) {
        String test = "get("+a+','+ expectedValue + ")";

        Object ret = _modelToTest.get(a);

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object get(int a, Exception expectedException) {
        String test = "get("+a+',' + expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.get(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int size(int expectedValue) {
        String test = "size("+ expectedValue + ")";

        int ret = _modelToTest.size();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int size(Exception expectedException) {
        String test = "size("+ expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.size();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public int index(int expectedValue) {
        String test = "index("+ expectedValue + ")";

        int ret = _modelToTest.index();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public int index(Exception expectedException) {
        String test = "index("+ expectedException + ")";
        int ret = -1;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.index();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void setIndex(int a) {
        setIndex(a, (Exception)null);
    }

    public void setIndex(int a, Exception expectedException) {
        String test = "setIndex("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.setIndex(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public boolean canGet(int a, boolean expectedValue) {
        String test = "canGet("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.canGet(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean canGet(int a, Exception expectedException) {
        String test = "canGet("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.canGet(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean canMove(int a, boolean expectedValue) {
        String test = "canMove("+a+','+ expectedValue + ")";

        boolean ret = _modelToTest.canMove(a);

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean canMove(int a, Exception expectedException) {
        String test = "canMove("+a+',' + expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.canMove(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public void move(int a) {
        move(a, (Exception)null);
    }

    public void move(int a, Exception expectedException) {
        String test = "move("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.move(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public void moveCrop(int a) {
        moveCrop(a, (Exception)null);
    }

    public void moveCrop(int a, Exception expectedException) {
        String test = "moveCrop("+a+',' + expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.moveCrop(a);
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public Object lock(Object expectedValue) {
        String test = "lock("+ expectedValue + ")";

        Object ret = _modelToTest.lock();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object lock(Exception expectedException) {
        String test = "lock("+ expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.lock();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }
}
