
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** A DiffTest for the com.kataba.coll.ListIteratorRO class
 *
 * @author com.kataba.util.DiffTest_Gen
 */
public abstract class DiffTest_ListIteratorRO
    extends DiffTest
    implements ListIteratorRO
{
    protected ListIteratorRO modelA;
    protected ListIteratorRO modelB;

    /** Constructs */
    public DiffTest_ListIteratorRO(String _name) {
        super(_name);
    }

    public int previousIndex() {
        String test = "previousIndex("+')';
        preMethodTest("previousIndex");

        int modelARet = 0;
        try {
            modelARet = modelA.previousIndex();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.previousIndex();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object previous() {
        String test = "previous("+')';
        preMethodTest("previous");

        Object modelARet = null;
        try {
            modelARet = modelA.previous();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.previous();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public int nextIndex() {
        String test = "nextIndex("+')';
        preMethodTest("nextIndex");

        int modelARet = 0;
        try {
            modelARet = modelA.nextIndex();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        int modelBRet = 0;
        try {
            modelBRet = modelB.nextIndex();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean hasPrevious() {
        String test = "hasPrevious("+')';
        preMethodTest("hasPrevious");

        boolean modelARet = false;
        try {
            modelARet = modelA.hasPrevious();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.hasPrevious();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object next() {
        String test = "next("+')';
        preMethodTest("next");

        Object modelARet = null;
        try {
            modelARet = modelA.next();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.next();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public boolean hasNext() {
        String test = "hasNext("+')';
        preMethodTest("hasNext");

        boolean modelARet = false;
        try {
            modelARet = modelA.hasNext();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        boolean modelBRet = false;
        try {
            modelBRet = modelB.hasNext();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(modelARet == modelBRet)
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }

    public Object lock() {
        String test = "lock("+')';
        preMethodTest("lock");

        Object modelARet = null;
        try {
            modelARet = modelA.lock();
        } catch(Exception ex) {
            modelAEx = ex;
        }

        Object modelBRet = null;
        try {
            modelBRet = modelB.lock();
        } catch(Exception ex) {
            modelBEx = ex;
        }

        boolean notDone = postMethodTest(test);
        if(notDone) {
            if(Util.equals(modelARet, modelBRet))
                ok(test, Util.toString(modelARet));
            else {
                error(test, "Non-matching results:"
                      + " modelA("+Util.toString(modelARet)+")"
                      + " modelB("+Util.toString(modelBRet)+")");
            }
        }

        return modelARet;
    }
}
