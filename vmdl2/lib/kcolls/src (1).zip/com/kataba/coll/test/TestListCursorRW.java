package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;


/** Tests various implementations of ListCursorRW
 *
 * @author Chris Thiessen
 */
class TestListCursorRW
    extends TestSuite
{
    /** Testing mainline */
    public static void main(String[] args) {
	new TestListCursorRW().start(args);
    }

    /** Constructs */
    public TestListCursorRW() {
        super("lcrw");
        addTest(new EVTest());
    }

    private static class EVTest
        extends EVTest_ListCursorRW
        implements CollTestData.Test
    {
        protected CollTestData data;

        public EVTest() {
            super("ev");
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);
        }

        /** @see EVTest.test() */
        public void test() {
            // Only test the collection types that are applicable to listIteratorRO
            data.runTestAgainstListImplementations();
        }
        
        protected void resetData(int collectionSize) {
            resetE();   // resets the 'lastElement' variable
            data.reset();
            data.collA.addAll(coll(collectionSize));

            if(data.collA instanceof ListRO)
                _modelToTest = ((ListRW)data.collA).listCursorRW();
            else
                Out.ln("FOOBAR! Can't create a listCursorRW");
        }

        /** @see CollTestData.Test#testColl */
        public void testColl() {
            // ListCursorRO.size()
            push("ListCursorRO.size()");
            resetData(0);
            size(0);
            resetData(1);
            size(1);
            resetData(100);
            size(100);
            pop();


            // ListCursorRO.index()
            push("ListCursorRO.index()");
            resetData(0);
            index(0);
            resetData(2);
            index(0);
            move(1);
            index(1);
            move(1);
            index(2);
            move(1, new IndexOutOfBoundsException());
            move(-1);
            index(1);
            move(-1);
            index(0);
            move(-1, new IndexOutOfBoundsException());
            index(0);
            move(0);
            index(0);
            move(3, new IndexOutOfBoundsException());
            index(0);
            move(1);
            index(1);
            pop();


            // ListCursorRO.setIndex(int)
            push("ListCursorRO.setIndex(int)");
            resetData(0);
            setIndex(0);
            index(0);
            setIndex(-1, new IndexOutOfBoundsException());
            index(0);
            setIndex(1, new IndexOutOfBoundsException());
            index(0);

            resetData(3);
            setIndex(0);
            index(0);
            move(-1, new IndexOutOfBoundsException());
            index(0);
            move(1);
            index(1);

            setIndex(2);
            index(2);
            move(1);
            index(3);

            setIndex(3);
            index(3);
            setIndex(-1, new IndexOutOfBoundsException());
            index(3);
            setIndex(4, new IndexOutOfBoundsException());
            index(3);
            pop();


            // ListCursorRO.canGet(int)
            push("ListCursorRO.canGet(int)");
            resetData(0);
            canGet(0, false);
            canGet(1, false);
            canGet(-1, false);

            resetData(3);

            canGet(0, true);
            canGet(1, true);
            canGet(-1, false);

            setIndex(1);
            canGet(0, true);
            canGet(1, true);
            canGet(-1, true);

            setIndex(2);
            canGet(0, true);
            canGet(1, false);
            canGet(-1, true);

            setIndex(3);
            canGet(0, false);
            canGet(1, false);
            canGet(-1, true);
            pop();


            // ListCursorRO.get(int)
            push("ListCursorRO.get(int)");
            resetData(0);
            get(0, new IndexOutOfBoundsException());
            get(1, new IndexOutOfBoundsException());
            get(-1, new IndexOutOfBoundsException());

            resetData(3);

            get(0, e(0));
            get(1, e(1));
            get(-1, new IndexOutOfBoundsException());

            setIndex(1);
            get(0, e(1));
            get(1, e(2));
            get(-1, e(0));

            setIndex(2);
            get(0, e(2));
            get(1, new IndexOutOfBoundsException());
            get(-1, e(1));

            setIndex(3);
            get(0, new IndexOutOfBoundsException());
            get(1, new IndexOutOfBoundsException());
            get(-1, e(2));
            pop();


            // ListCursorRO.canMove(int)
            push("ListCursorRO.canMove(int)");
            resetData(0);
            canMove(0, true);
            canMove(1, false);
            canMove(-1, false);

            resetData(3);

            canMove(1, true);
            canMove(-1, false);

            setIndex(1);
            canMove(1, true);
            canMove(-1, true);

            setIndex(2);
            canMove(1, true);
            canMove(-1, true);

            setIndex(3);
            canMove(1, false);
            canMove(-1, true);
            pop();


            // ListCursorRO.move(int)
            push("ListCursorRO.move(int)");
            resetData(0);
            move(0);
            index(0);
            move(1, new IndexOutOfBoundsException());
            move(-1, new IndexOutOfBoundsException());
            index(0);

            resetData(3);

            move(0);
            index(0);
            move(1);
            index(1);
            move(-1);
            index(0);

            setIndex(1);
            move(0);
            index(1);
            move(1);
            index(2);
            move(-1);
            index(1);

            setIndex(2);
            move(0);
            index(2);
            move(1);
            index(3);
            move(-1);
            index(2);

            setIndex(3);
            move(0);
            index(3);
            move(1, new IndexOutOfBoundsException());
            move(-1);
            index(2);
            pop();


            // ListCursorRO.moveCrop(int)
            push("ListCursorRO.moveCrop(int)");
            resetData(0);
            moveCrop(0);
            index(0);
            moveCrop(1);
            index(0);
            moveCrop(-1);
            index(0);

            resetData(3);

            moveCrop(0);
            index(0);
            moveCrop(1);
            index(1);
            moveCrop(-1);
            index(0);

            setIndex(1);
            moveCrop(0);
            index(1);
            moveCrop(1);
            index(2);
            moveCrop(-1);
            index(1);

            setIndex(2);
            moveCrop(0);
            index(2);
            moveCrop(1);
            index(3);
            moveCrop(-1);
            index(2);

            setIndex(3);
            moveCrop(0);
            index(3);
            moveCrop(1);
            moveCrop(-1);
            index(2);
            pop();


            // ListCursorRW.add(int,Object)
            push("ListCursorRW.add(int,Object)");
            resetData(0);
            add(-1, null, new IndexOutOfBoundsException());
            add(1, null, new IndexOutOfBoundsException());
            add(0, e(1));
            size(1);
            index(0);
            get(0, e(1));

            resetData(1);
            add(-1, null, new IndexOutOfBoundsException());
            add(1, e(4));
            size(2);
            index(0);
            get(1, e(4));

            add(0, e(4));
            size(3);
            index(0);
            get(0, e(4));

            resetData(2);
            setIndex(1);
            add(0, e(2));
            size(3);
            index(1);
            get(0, e(2));

            add(-1, e(3));
            size(4);
            index(1);
            get(-1, e(3));

            add(1, e(4));
            size(5);
            index(1);
            get(1, e(4));

            pop();


            // ListCursorRW.remove(int)
            push("ListCursorRW.remove(int)");

            resetData(0);
            remove(0, new IndexOutOfBoundsException());

            resetData(1);
            remove(0);
            size(0);

            resetData(1);
            setIndex(1);
            remove(-1);
            size(0);

            resetData(2);
            remove(1);
            size(1);
            get(0, e(0));

            resetData(2);
            remove(0);
            size(1);
            get(0, e(1));

            pop();


            // ListCursorRW.set(int,Object)
            push("ListCursorRW.set(int,Object)");

            resetData(0);
            set(0, e(), new IndexOutOfBoundsException());
            set(-1, e(), new IndexOutOfBoundsException());
            set(1, e(), new IndexOutOfBoundsException());

            resetData(1);
            get(0, e(0));
            set(0, e(3));
            get(0, e(3));
            setIndex(1);
            set(1, e(), new IndexOutOfBoundsException());

            resetData(3);
            setIndex(1);

            get(0, e(1));
            set(0, e(3));
            get(0, e(3));

            get(-1, e(0));
            set(-1, e(4));
            get(-1, e(4));

            get(1, e(2));
            set(1, e(5));
            get(1, e(5));

            pop();
        }
    }

}

