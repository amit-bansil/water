
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.util.*;
import java.io.*;

/** Tests various implementations of IteratorRW
 *
 * @author Chris Thiessen
 * @author Ray Vander Veen
 */
class TestListIterator
    extends TestSuite
{
    /** Starts the Test */
    public static void main(String[] args) {
        TestListIterator test = new TestListIterator();
        test.init(args);
        test.runTest();
    }

    /** Constructs */
    public TestListIterator() {
        super("listiterators");
        addTest(new TestListIteratorRO_DiffTest());
        addTest(new TestListIteratorRW_DiffTest());
        addTest(new TestListIteratorRO_EVTest());
        addTest(new TestListIteratorRW_EVTest());
    }

    private static class TestListIteratorRO_DiffTest
        extends DiffTest_ListIteratorRO
        implements CollTestData.Test
    {
        private CollTestData data;
        private int collSize = 0;
        
        public TestListIteratorRO_DiffTest() {
            super("liro-diff");
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);            
        }
        
        /** @see DiffTest.resetModels */
        protected void resetModels() {
            data.reset();

            // set up the collections
            data.collA.addAll(coll(collSize));
            data.collB.addAll((CollectionRO)data.collA);

            // grab the new model ListIteratorROs
            modelA = ((ListRO)data.collA).listIteratorRO();
            modelB = ((ListRO)data.collB).listIteratorRO();
        }
        
        /** @see DiffTest.test() */
        public void test() {
            data.runTestAgainstListImplementations();
        }

        /** @see CollTestData.Test#testColl */
        public void testColl() {

            for (int i = 0; i < 3; ++i) {
                collSize = i;
                
                push("collSize: " + collSize);
                
                push("hasNext()");
                resetModels();
                hasNext();
                hasNext();
                hasNext();
                pop();
                
                push("next()");
                resetModels();
                next();
                hasNext();
                next();
                hasNext();
                next();
                hasNext();
                next();
                pop();
            
                push("hasPrevious()");
                resetModels();                
                hasPrevious();
                next();
                hasPrevious();
                previous();
                previous();                
                hasPrevious();
                hasNext();
                hasPrevious();
                pop();
                
                push("previous()");
                resetModels();                
                previous();
                previous();
                next();
                next();
                previous();
                previous();
                previous();
                hasPrevious();
                hasNext();
                previous();
                previous();
                pop();
                
                push("nextIndex()");
                nextIndex();
                next();
                nextIndex();
                next();
                nextIndex();
                previous();
                nextIndex();
                previous();
                nextIndex();
                nextIndex();
                nextIndex();
                previous();
                next();
                next();
                nextIndex();
                pop();
                
                push("previousIndex()");
                next();
                previousIndex();
                previousIndex();
                next();
                previousIndex();
                next();
                previousIndex();
                previous();
                previousIndex();
                previous();
                previousIndex();
                next();
                previousIndex();
                next();
                previousIndex();
                next();
                previousIndex();
                previousIndex();
                previous();
                previous();
                previousIndex();
                next();
                next();
                next();
                previousIndex();
                pop();
            
                pop();
            
            }// for a bunch of collection sizes
        }
        
    
    }

    private static class TestListIteratorRW_DiffTest
        extends DiffTest_ListIteratorRW
        implements CollTestData.Test
    {
        protected CollTestData data;
        private int collSize = 0;
        
        public TestListIteratorRW_DiffTest() {
            super("lirw-diff");
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);            
        }
        
        /** @see DiffTest.resetModels */
        protected void resetModels() {
            data.reset();
            resetE();

            // set up the collections
            data.collA.addAll(coll(collSize));
            data.collB.addAll((CollectionRO)data.collA);

            // grab the new model ListIteratorROs
            modelA = ((ListRW)data.collA).listIteratorRW();
            modelB = ((ListRW)data.collB).listIteratorRW();            
        }
        
        /** @see DiffTest.test() */
        public void test() {
            data.runTestAgainstListImplementations();
        }

        /** @see CollTestData.Test#testColl */
        public void testColl() {

            for (int i = 0; i < 5; ++i) {
                collSize = i;
                
                push("collSize: " + collSize);
                
                push("add()");
                resetModels();
                add(e());
                add(e());
                add(e());
                add(e());
                previous();
                next();
                add(e());
                previous();
                add(e());
                add(e());
                next();
                previous();
                remove();
                remove();
                add(e());
                pop();
                
                push("set()");
                resetModels();
                add(e());
                add(e());
                set(e(99));
                next();
                set(e(99));
                next();
                set(e(99));
                resetModels();
                set(e(99));
                next();
                set(e(99));
                next();
                set(e(99));
                next();
                set(e(99));
                if (hasNext()) {
                    next();
                    set(e(99));
                }
                pop();
                
                resetModels();
                int m;
                for (m = 0; m < collSize; ++m) {
                    if (hasNext()) {
                        next();
                        set(e(99));
                    }
                }
                pop();
            
            }// for a bunch of collection sizes
            
            
        }
    }
        
    private static class TestListIteratorRO_EVTest
        extends EVTest_ListIteratorRO
        implements CollTestData.Test
    {
        protected CollTestData data;
        
        public TestListIteratorRO_EVTest() {
            this("liro-expvalue");
        }
        
        protected TestListIteratorRO_EVTest(String msg) {
            super(msg);
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);
        }

        /** @see EVTest.test() */
        public void test() {
            // Only test the collection types that are applicable to listIteratorRO
            data.runTestAgainstListImplementations();
        }
        
        protected void resetData(int collectionSize) {
            resetE();   // resets the 'lastElement' variable
            data.reset();
            data.collA.addAll(coll(collectionSize));

            if (data.collA instanceof ListRO) {
                _modelToTest = ((ListRO)data.collA).listIteratorRO();
            } else {
                Out.ln("FOOBAR! Can't create a listIteratoRO");
            }

        }

        /** @see CollTestData.Test#testColl */
        public void testColl() {
            resetData(0);

            push("hasNext()");
            hasNext(false);
            hasNext(false);

            resetData(1);

            hasNext(true);
            hasNext(true);            
            next(e(0));
            hasNext(false);

            pop();

            push("next()");

            Exception nsee = new NoSuchElementException();

            resetData(0);
            next(nsee);

            resetData(1);
            next(e(0));
            next(nsee);

            pop();

            push("hasPrevious()");

            resetData(0);
            hasPrevious(false);

            resetData(1);
            hasPrevious(false);
            next(e(0));
            hasPrevious(true);
            previous(e(0));
            hasPrevious(false);

            resetData(3);
            hasPrevious(false);
            next(e(0));
            next(e(1));
            next(e(2));
            hasPrevious(true);
            previous(e(2));
            hasPrevious(true);
            previous(e(1));
            previous(e(0));
            hasPrevious(false);
            
            pop();

            push("previous()");
            
            push("size 0");
            resetData(0);            
            previous(nsee);
            next(nsee);
            previous(nsee);
            pop();
            
            push("size 1");
            resetData(1);
            next(e(0));
            previous(e(0));
            previous(nsee);
            previous(nsee);
            pop();
            
            push("size 3");
            resetData(3);
            next(e(0));
            next(e(1));
            next(e(2));
            hasNext(false);
            previous(e(2));
            hasNext(true);
            next(e(2));
            previous(e(2));
            next(e(2));
            previous(e(2));
            previous(e(1));
            previous(e(0));
            hasPrevious(false);
            previous(nsee);
            pop();
            
            pop();

            push("nextIndex()");
            
            push("size 1");
            resetData(0);
            nextIndex(0);
            pop();
            
            push("size 1");
            resetData(1);
            nextIndex(0);
            next(e(0));
            nextIndex(1);   // end of list; expected value is size of list
            previous(e(0));
            nextIndex(0);
            pop();
            
            push("size 2");
            resetData(2);
            nextIndex(0);
            next(e(0));
            nextIndex(1);
            next(e(1));
            pop();
            
            pop();

            push("previousIndex()");
            
            push("size 0");
            resetData(0);
            previousIndex(-1);
            previousIndex(-1);
            next(nsee);
            previous(nsee);
            previousIndex(-1);
            pop();
            
            push("size 1");
            resetData(1);
            previousIndex(-1);
            next(e(0));
            previousIndex(0);
            previous(e(0));
            previousIndex(-1);
            pop();

            push("size 2");
            resetData(2);
            previousIndex(-1);
            next(e(0));
            next(e(1));
            previousIndex(1);
            next(nsee);
            previousIndex(1);
            previous(e(1));
            previous(e(0));
            previousIndex(-1);
            nextIndex(0);
            previousIndex(-1);
            next(e(0));
            previousIndex(0);
            pop();

            push("size 5; test all methods");
            int i;
            int count = 5;
            resetData(count);
            previousIndex(-1);
            for (i = 0; i < count; ++i) {
                nextIndex(i);
                next(e(i));
            }
            nextIndex(count);
            next(nsee);
            nextIndex(count);
            for (i = 0; i < 5; ++i) {
                previousIndex((count - 1) - i);
                previous(e((count - 1) - i));
            }
            previous(nsee);
            nextIndex(0);
            previousIndex(-1);
            pop();

            pop();
        }

    }

    /** expected-value test of ListIteratorRW */
    private static class TestListIteratorRW_EVTest
        extends EVTest_ListIteratorRW
        implements CollTestData.Test
    {
        protected CollTestData data;

        public TestListIteratorRW_EVTest() {
            super("lirw-expvalue");
            data = new CollTestData(this, CollTestData.Types.JDK_LIST);
        }

        protected void resetData(int collectionSize) {
            resetE();   // resets the 'lastElement' variable
            data.reset();
            data.collA.addAll(coll(collectionSize));

            if (data.collA instanceof ListRW) {
                _modelToTest = ((ListRW)data.collA).listIteratorRW();
            } else {
                Out.ln("FOOBAR! Can't create a listIteratoRW");
            }
        }

        /** @see EVTest.test() */
        public void test() {
            // Only test the collection types that are applicable to listIteratorRW
            data.runTestAgainstListImplementations();
        }

        public void testColl() {

            Exception nsee = new NoSuchElementException();
            Exception ise = new IllegalStateException();
            int i;

            push("add()");            
            resetData(0);
            add(e());
            next(nsee);         
            previous(e(0)); // zero was added and is the previous element; next() is unaffected
            next(e(0));
            set(e(99), null);
            previous(e(99));
            set(e(0));
            next(e(0));
            pop();

            push("set()");

            resetData(0);
            set(e(99), ise);    // IllegalStateException if we haven't called next() or previous()
            add(e());
            previous(e(0));
            set(e(99), null);   // no exception 'cause we called previous()

            resetData(5);
            for (i = 0; i < 5; ++i) {
                next(e(i));
                set(e(99));
            }
            set(e(100), null);
            set(e(100), null);
            previous(e(100));
            
            for (i = 0; i < 4; ++i) {
                previous(e(99));
            }
        
            previous(nsee);

            // test that add() does not affect the sequence of elements that would
            // be returned by a series of calls to next()
            resetData(5);
            for (i = 0; i < 5; ++i) {
                add(e(i + 10));
                next(e(i));
            }

            pop();

        }
    }

}

