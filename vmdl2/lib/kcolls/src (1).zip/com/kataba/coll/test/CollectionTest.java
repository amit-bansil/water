
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;

public abstract class CollectionTest
    extends KTestCase
{

    /** the value of the integer element last created by i() or e() */
    protected int lastElement;

    /** whether to print stack traces when exceptions are thrown */
    protected boolean printStackTraces;

    /** whether output should be verbose */
    protected boolean verboseOutput;

    protected CollectionTest() {
        this(true, false);
    }

    /** constructs a CollectionTest instance */
    protected CollectionTest(String [] args) {
        super("CollectionTest");
        for (int i = 0; i < args.length; ++i) {
            String arg = args[i];
            if (arg.equals("-ok")) {
                setPrintOks(true);
            } else if (arg.equals("-stack")) {
                setPrintStackTraces(true);
            } else if (arg.equals("-v")) {
                setVerbose(true);
            }
        }
    }

    /** Invokes the run() method on a given TestCase instance.  If this method
     *  is called and 'printStackTraces' is 'true', the stack traces will be
     *  printed for all exceptions that are thrown.
     */
    protected void runTest(TestCase test) {
        try {
            test.run();
        } catch (Exception e) {
            onException(e, test);
        }
    }

    /** This method should be invoked by subclasses when an exception occurs. */
    protected void onException(Exception e, TestCase test) {
        if (printStackTraces) {
            Out.ln();
            Out.ln();
            e.printStackTrace();
            Out.ln();
            Out.ln();
        }
        
        Out.ln();
        Out.ln("EXCEPTION: " + e + " running test " + test + ": ");
        Out.ln();
    }

    /** constructs a CollectionTest instance */
    protected CollectionTest(boolean printOks, boolean printStackTraces) {
        super("CollectionTest");
        setPrintOks(printOks);
        setPrintStackTraces(printStackTraces);
    }

    protected static final int DEFAULT_LIST_SIZE = 20;
    protected static final int EMPTY_LIST = 1 << 1;
    protected static final int SEQUENTIAL_LIST = 1 << 2;

    protected GapListRW createList() {
        return createList(EMPTY_LIST, 0);
    }

    protected GapListRW createList(int flags) {
        return createList(flags, 0);
    }

    protected GapListRW createList(int flags, int param) {
        GapListRW list = new GapListRW(0);

        if ((flags & EMPTY_LIST) != 0) {
            return list;
        }

        if ((flags & SEQUENTIAL_LIST) != 0) {
            int num = DEFAULT_LIST_SIZE;
            if (param > 0) {
                num = param;
            }
            for (int i = 0; i < num; ++i) {
                list.add(e(i));
            }        
        }

        return list;
    }

    /** sets whether to print stack traces
     *@param print whether to print stack traces
     */
    protected void setPrintStackTraces(boolean print) {
        printStackTraces = print;
    }

    /** returns whether to print stack traces when exceptions occur */
    protected boolean getPrintStackTraces() {
        return printStackTraces;
    }

    /** sets whether output should be verbose */
    protected void setVerbose(boolean verbose) {
        verboseOutput = verbose;
    }

    /** returns whether output should be verbose */
    protected boolean getVerbose() {
        return verboseOutput;
    }

    protected boolean verbose() {
        return getVerbose();
    }
    

    /** Runs all test cases within the test. */
    protected abstract void runTests();

    /** Prints a notice to stdout that a test case is being run.
     *@param name the name of the test case being run
     */
    protected void testingNotice(String name) {
        Out.ln("--------------------------------");
        Out.ln("Testing " + name + "...");
    }

    /** Echos to stdout. */    
    protected void echo(Object o) {
        Out.ln(o);        
    }
    
    public static void printList(List list, String msg) {
        String s = "printing List " + list.getClass().getName() + "...";
        
        if (msg != null) {
            s += " (" + msg + ")";
        }
        
        s += "\n";
        
        if (list != null) {
            Out.ln(s);
            int size = list.size();
            for (int i = 0; i < list.size(); ++i) {
                Out.ln("elem(" + i + ")=" + list.get(i));
            }
        }        
    }
    
    public static void printList(List list) {
        printList(list, null);
    }   
}
