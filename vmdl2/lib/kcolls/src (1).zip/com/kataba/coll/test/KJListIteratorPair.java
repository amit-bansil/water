
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.coll.wrap.*;
import com.kataba.util.*;

import java.io.*;
import java.util.*;

/** A pair of list iterators: one is a Kataba list iterator; the other is
 *  a standard Java list iterator.
 */
public class KJListIteratorPair {
    
    List kList;     // kataba list
    List jList;     // java list
    ListIterator ki;    // iterator on kataba list
    ListIterator ji;    // iterator on java list
}