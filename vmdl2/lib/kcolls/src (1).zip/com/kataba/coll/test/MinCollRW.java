
package com.kataba.coll.test;

import com.kataba.coll.*;

class MinCollRW
    extends AbstractCollectionRW
{
    public int size() {
        return 0;
    }

    public boolean add(Object element) {
        return false;
    }

    public boolean remove(Object element) {
        return false;
    }

    public void clear() {
    }

    public IteratorRW iteratorRW() {
        return null;
    }
}
