
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

/** An EVTest for the com.kataba.coll.IteratorRW class
 *  For each method in the class, an expected-value test 
 *  method and an expected-exception test method is generated.
 *
 * @author com.kataba.util.EVTest_Gen
 */
public abstract class EVTest_IteratorRW
    extends EVTest
{

    protected IteratorRW _modelToTest;
    protected Exception exception;

    /** Constructs */
    public EVTest_IteratorRW(String _name) {
        super(_name);
    }

    public void remove() {
        remove((Exception)null);
    }

    public void remove(Exception expectedException) {
        String test = "remove("+ expectedException + ")";

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            _modelToTest.remove();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
    }

    public Object next(Object expectedValue) {
        String test = "next("+ expectedValue + ")";

        Object ret = _modelToTest.next();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object next(Exception expectedException) {
        String test = "next("+ expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.next();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public boolean hasNext(boolean expectedValue) {
        String test = "hasNext("+ expectedValue + ")";

        boolean ret = _modelToTest.hasNext();

        if (ret != expectedValue) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public boolean hasNext(Exception expectedException) {
        String test = "hasNext("+ expectedException + ")";
        boolean ret = false;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.hasNext();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }

    public Object lock(Object expectedValue) {
        String test = "lock("+ expectedValue + ")";

        Object ret = _modelToTest.lock();

        if (! Util.equals(ret, expectedValue)) {
            error(test + ", expected=" + expectedValue + ",actual=" + ret);
        } else {
            ok(test + " expected == actual");
        }

        return ret;
    }

    public Object lock(Exception expectedException) {
        String test = "lock("+ expectedException + ")";
        Object ret = null;

        // note:  set exception to null before method call so that it 
        // can be checked afterwards against an expected exception.
        exception = null;

        try {
            ret = _modelToTest.lock();
        } catch(Exception ex) {
            exception = ex;
        }

        if (KTestCaseUtil.exceptionsEqual(exception, expectedException)) {
            ok(test + " exceptions equal");
        } else {
            error(test + ", exceptions !equal(exp=" + expectedException + ",act=" + exception);
        }
        return ret;
    }
}
