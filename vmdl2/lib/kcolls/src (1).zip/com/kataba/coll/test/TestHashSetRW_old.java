
package com.kataba.coll.test;

import com.kataba.coll.*;
import com.kataba.util.*;

import java.io.*;
import java.util.Hashtable;
import java.util.Random;

public class TestHashSetRW_old {
    static PrintStream ps = System.out;
    static Object present = new Object();

    public static void main(String[] args) {
	if(args.length == 0
	   || "accuracy".equals(args[0])) {
	    ps.println();
	    ps.println("Testing Accuracy");
	    testAccuracy();
	}

	if(args.length == 0
	   || "speed".equals(args[0])) {
	    ps.println();
	    ps.println("Testing Speed");
	    for(int i=0; i<1; i++)
		testSpeed();
	}

	if(args.length == 0
	   || "memory".equals(args[0])) {
	    ps.println();
	    ps.println("Test Memory");

	    ps.println("testMemory 1");
	    testMemory(Integer.parseInt(args[1]));
	    /*
	    ps.println("System.gc()");
	    sleep(1000);
	    System.gc();
	    sleep(4000);
	    //*/
	    ps.println("testMemory 2");
	    testMemory(Integer.parseInt(args[1]));
	}
    }

    public static void testAccuracy() {
	ps.println("new Set");
	HashSetRW set = new HashSetRW();
	printSetRO(set);

	ps.println("adding 1 through 40");
	for(int i=0; i<40; i++) {
	    ps.println("adding " + i);
	    set.add(new String("" + i));
	}
	//set.printEntries(ps);
	printSetRO(set);
	ps.println();

	ps.println("removing all through the iterator");
	for(IteratorRW itr=set.iteratorRW(); itr.hasNext(); ) {
	    ps.println("removing " + itr.next());
	    itr.remove();
	}
	printSetRO(set);
	ps.println();

	ps.println("adding 1 through 40");
	for(int i=0; i<40; i++) {
	    set.add(new String("" + i));
	}
	//set.printEntries(ps);
	printSetRO(set);
	ps.println();

	ps.println("removing the first two through iterator");
	boolean first = true;
	for(IteratorRW itr=set.iteratorRW(); itr.hasNext(); ) {
	    if(first) {
		ps.println("removing " + itr.next()); itr.remove();
		ps.println("removing " + itr.next()); itr.remove();
		first = false;
	    } else
		ps.print(", " + itr.next());
	}
	ps.println();
	printSetRO(set);
	ps.println();

	ps.println("adding 1 through 40");
	for(int i=0; i<40; i++) {
	    set.add(new String("" + i));
	}
	//set.printEntries(ps);
	printSetRO(set);
	ps.println();

	ps.println("removing 10 through 50");
	for(int i=10; i<50; i++)
	    set.remove(new String("" + i));
	//set.printEntries(ps);
	printSetRO(set);
	ps.println();

	ps.println("contains 10: " + set.contains("" + 10));
	ps.println("contains 3: " + set.contains("" + 3));
	ps.println("contains 30: " + set.contains("" + 30));
    }

    public static void testSpeed() {
	int perType = 1;
	Timer timer = new Timer();

        int total = 1<<20;

        Out.ln();
        Out.out("numElements");
        Out.out("\tnumIters");
        Out.out("\ttotal");
        Out.out("\tHashSetRW");
        Out.out("\tFlatHashSetRW");
        Out.out("\tjava.util.HashSet");

        Random random = new Random();

        int numElements = 0;
        for(double numElems=1; numElems<=total; numElems*=1.05) {
            if(numElements == (int)numElems)
                numElems = numElements + 1;
            numElements = (int)numElems;
            int numIters = total / numElements;

	    Object[] elements = new Object[numElements];
	    for(int i=0; i<numElements; i++)
		elements[i] = new Integer(random.nextInt());

            /*
            Out.out("waiting...");
            Util.sleep(5000);
            Out.ln("done");
            */

            for(int i=0; i<perType; i++) {
                Out.ln();

                Out.out(""+numElements);
                Out.out("\t"+numIters);
                Out.out("\t"+numElements*numIters);

                timer.reset();
                for(int j=0; j<numIters; j++)
                    testSpeed(new HashSetRW(), elements);
                Out.out("\t"+timer.elapsed());
                Util.sleep(500);

                timer.reset();
                for(int j=0; j<numIters; j++)
                    testSpeed(new ArrayHashSetRW(), elements);
                Out.out("\t"+timer.elapsed());
                Util.sleep(500);

                timer.reset();
                for(int j=0; j<numIters; j++)
                    testSpeed(new java.util.HashSet(), elements);
                Out.out("\t"+timer.elapsed());
                Util.sleep(500);
            }
        }

	/*
	ps.print("java.util.Hashtable          : ");
	timer.restart();
	for(int i=0; i<numIters; i++)
	    testSpeed(new java.util.Hashtable(), tests);
	Out.ln("" + timer.elapsed() + "ms");
	*/

    }

    public static void testSpeed(SetRW set, Object[] elements) {
	for(int i=0,ii=elements.length; i<ii; i++)
	    set.add(elements[i]);
	for(int i=elements.length-1; i>=0; i--)
            set.contains(elements[i]);
	for(int i=elements.length-1; i>=0; i--)
	    set.remove(elements[i]);
    }

    public static void testSpeed(java.util.Set set, Object[] elements) {
	for(int i=0,ii=elements.length; i<ii; i++)
	    set.add(elements[i]);
	for(int i=elements.length-1; i>=0; i--)
            set.contains(elements[i]);
	for(int i=elements.length-1; i>=0; i--)
	    set.remove(elements[i]);
    }

    public static void testSpeed(java.util.Hashtable hashtable
				 , Object[] tests) {
	for(int i=0,ii=tests.length; i<ii; i++)
	    hashtable.put(tests[i], present);
	//hashtable.clear();
	for(int i=tests.length-1; i>=0; i--)
	    hashtable.remove(tests[i]);
    }

    public static void testMemory(int test) {
	int numTests = 300000;
	Object coll;
	switch(test) {
	case 0:
	    {
		HashSetRW set = new HashSetRW();
		coll = set;
		for(int i=0; i<numTests; i++)
		    set.add(new Integer(i));
	    }
	    break;
	case 1:
	    {
		Hashtable hashtable = new Hashtable();
		Object present = new Object();
		coll = hashtable;
		for(int i=0; i<numTests; i++)
		    hashtable.put(new Integer(i), present);
	    }
	    break;
	case 2:
	    {
		java.util.HashSet set = new java.util.HashSet();
		coll = set;
		for(int i=0; i<numTests; i++)
		    set.add(new Integer(i));
	    }
	    break;
	}
	try {
	    Thread.currentThread().sleep(1000);
	} catch(Exception ex) {
	}
    }

    public static void printSetRO(SetRO set) {
	Out.ln("set.size(): " + set.size());
	boolean first = true;
	for(IteratorRO itr=set.iteratorRO(); itr.hasNext(); ) {
	    Object element = itr.next();
	    if(first)
		first = false;
	    else
		ps.print(", ");
	    ps.print(element);
	}
	Out.ln();
    }

    public static void sleep(int millis) {
	try {
	    Thread.currentThread().sleep(millis);
	} catch(Exception ex) {
	}
    }
}
