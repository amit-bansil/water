//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

import com.kataba.util.*;

/** A read-only iterator over the elements of some collection of
 * elements of type <code>Object</code>.  Clients should synchronize
 * on 'lock()' if they wish to thread-safe their access to this
 * IteratorRO.
 *
 * @author Chris Thiessen
 */
public interface IteratorRO
    extends Lockable
{
    /** Returns <code>true</code> if there is a next element.  This
     * method is mutually atomic with <code>next()</code>: if this
     * method returns <code>true</code>, the next call to
     * <code>next()</code> is guaranteed to succeed; if this method
     * returns <code>false</code>, the next call to
     * <code>next()</code> is guaranteed to fail.  Also, the return
     * value will change in successive calls only after a successful
     * call to <code>next()</code>
     */
    public boolean hasNext();

    /** Iterates to and returns the next element in the iteration.
     * This method is mutually atomic with <code>hasNext()</code>: if
     * the most recent call to <code>hasNext()</code> returned
     * <code>true</code>, a call to this method is guaranteed to
     * succeed; if it returned <code>false</code> a call to this
     * method is guaranteed to fail.
     *
     * @exception NoSuchElementException if there is no next element
     */
    public Object next();
}
