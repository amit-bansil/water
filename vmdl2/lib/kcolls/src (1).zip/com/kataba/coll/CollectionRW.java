//
// Copyright 2001 Kataba Software. All Rights Reserved.
//
// This software is the proprietary information of Kataba Software.  
// Use is subject to license terms.
//

package com.kataba.coll;

/** Represents a read-write collection of Objects.  Extends
 * <code>CollectionRO</code> with content-modification methods.
 *
 * <p>An implementations of this interface should document its rules of
 * object equivalence.
 *
 * @author Chris Thiessen
 */
public interface CollectionRW
    extends CollectionRO, java.util.Collection
{

    /** @see java.util.Collection#addAll(Collection) */
    public boolean addAll(CollectionRO collection);

    /** @see java.util.Collection#removeAll(Collection) */
    public boolean removeAll(CollectionRO collection);

    /** @see java.util.Collection#retainAll(Collection) */
    public boolean retainAll(CollectionRO collection);

    /** @see java.util.Collection#iterator */
    public IteratorRW iteratorRW();


    //
    // implements the content-modification part of java.util.Collection
    //

    /** @see java.util.Collection#add(Object) */
    public boolean add(Object object);

    /** @see java.util.Collection#addAll(Collection) */
    public boolean addAll(java.util.Collection collection);

    /** @see java.util.Collection#remove(Object) */
    public boolean remove(Object element);

    /** @see java.util.Collection#removeAll(Collection) */
    public boolean removeAll(java.util.Collection collection);

    /** @see java.util.Collection#retainAll(Collection) */
    public boolean retainAll(java.util.Collection collection);

    /** @see java.util.Collection#clear */
    public void clear();

    /** Returns iteratorRW()
     *
     * @see java.util.Collection#iterator */
    public java.util.Iterator iterator();
}
