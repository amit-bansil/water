
package com.kataba.util;

import java.io.*;

/** Printer which prints to a File */
public class Printer_File extends AbstractPrinter {
    private File file;
    private OutputStream outputStream;
    private Writer writer;
    private PrintWriter printWriter;

    public Printer_File(String filename)
        throws IOException
    {
        this(new File(filename));
    }

    public Printer_File(File _file) 
        throws IOException
    {
        file = _file;
        if(file != null) {
            outputStream = new FileOutputStream(file);
            writer = new OutputStreamWriter(outputStream);
            printWriter = new PrintWriter(writer);
        }
    }

    public void out(Object object) {
        printWriter.print(object);
    }

    public void close() {
        try {
            printWriter.flush();
            writer.flush();
            outputStream.flush();
            outputStream.close();
        } catch(IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
