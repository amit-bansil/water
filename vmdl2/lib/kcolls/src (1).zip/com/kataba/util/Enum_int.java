
package com.kataba.util;

import java.lang.reflect.*;
import com.kataba.coll.*;

/** Represents an enumeration of 'int' values.  Values are harvested
 * through reflection from all 'public static final int's in the
 * extending class.
 *
 * @author Chris Thiessen
 */
public abstract class Enum_int {
    private HashMapRW valuesByName = new HashMapRW();
    private HashMapRW namesByValue = new HashMapRW();
    private int[] values;
    private String[] names;

    /** Constructs.  Uses reflection to collect the values of all
     * 'public static final int' variables in the class. */
    protected Enum_int() {
	Class clazz = getClass();

	// grab the values through reflection
	Field[] fields = clazz.getFields();
	ListRW valueList = new GapListRW();
	for(int i=0; i<fields.length; i++) {
	    Field field = fields[i];
	    int modifiers = field.getModifiers();
	    if(field.getType() == Integer.TYPE
	       && (modifiers & Modifier.STATIC) > 0
	       && (modifiers & Modifier.FINAL) > 0) {
		try {
		    Integer value = new Integer(field.getInt(null));
		    valuesByName.put(field.getName(), value);
		    namesByValue.put(value, field.getName());
		    valueList.add(value);
		} catch(IllegalAccessException ex) {
		    throw new IllegalArgumentException(ex.getMessage());
		}
	    }
	}

	// construct the 'values' and 'names' arrays
	values = new int[valueList.size()];
	names = new String[valueList.size()];
	for(int i=0; i<values.length; i++) {
	    Integer value = (Integer)valueList.get(i);
	    values[i] = value.intValue();
	    names[i] = (String)namesByValue.get(value);
	}
    }

    /** Returns the number of values */
    public int size() {
	return values.length;
    }


    //
    // name methods
    //

    /** Returns the names */
    public String[] names() {
        return (String[])names.clone();
    }

    /** Returns the name of the specified 'value' */
    public String getName(int value) {
	return (String)namesByValue.get(IntegerPool.get(value));
    }

    /** Returns the value at the specified index (from 0 to size()-1) */
    public String nameAt(int index) {
	return names[index];
    }


    //
    // value methods
    //

    /** Returns whether the specified 'value' is a valid one in this enumeration */
    public boolean isValid(int value) {
	return namesByValue.containsKey(IntegerPool.get(value));
    }

    /** Returns the value of the specified 'name' */
    public int getValue(String name) {
	return ((Integer)valuesByName.get(name)).intValue();
    }

    /** Returns the values */
    public int[] values() {
        return (int[])values.clone();
    }

    /** Returns the value at the specified index (from 0 to size()-1) */
    public int valueAt(int index) {
	return values[index];
    }


    public String flagString(int value) {
	StringBuffer buffer = new StringBuffer();
	for(int i=0; i<values.length; i++) {
	    if((values[i] & value) != 0) {
		if(buffer.length() > 0)
		    buffer.append(", ");
		buffer.append(names[i]);
	    }
	}
	return buffer.toString();
    }
}
