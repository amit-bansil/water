
package com.kataba.util;

import com.kataba.coll.*;

/** A TestSuite is a KTestCase which is a suite of other KTestCase's.
 * All contained tests report their results through this, their
 * parent.
 *
 * @author Chris Thiessen
 */
public class TestSuite extends KTestCase {

    private ListRW testCases = new GapListRW();
    private ListRW testNamePrefixes = new GapListRW();

    /** Constructs */
    public TestSuite(String _name) {
        super(_name);
    }

    /** Extracts list of args */
    public String[] init(String[] args) {
        args = super.init(args);
        ListRW others = new GapListRW();
        for(int i=0; i<args.length; i++) {
            String arg = args[i];
            if(arg.startsWith("-"))
                others.add(arg);
            else
                testNamePrefixes.add(arg);
        }
        return (String[])others.toArray(new String[0]);
    }

    /** Prints information about the test suite to 'out', prefixing
     * each line of output with 'pre' */
    public void printOn(Printer out, String pre) {
        super.printOn(out, pre);
        for(int i=0; i<testCases.size(); i++) {
            KTestCase test = (KTestCase)testCases.get(i);
            test.printOn(out, pre+"  ");
        }
    }

    /** Adds a test case to the list */
    public void addTest(KTestCase test) {
        test.setParent(this);
        testCases.add(test);
    }

    /** Returns whether the test's full name is one of the
     * command-line-specified testNamePrefixes */
    protected boolean shouldRun(KTestCase test) {
        if(getParent() != null)
            return getParent().shouldRun(test);
        else {
            // if no prefixes, then all tests should run
            if(testNamePrefixes.size() == 0)
                return true;

            // else check for a matching prefix
            for(int i=0; i<testNamePrefixes.size(); i++) {
                String pre = (String)testNamePrefixes.get(i);
                if(test.getFullName().equals(pre)
                   || test.getFullName().startsWith(pre+"."))
                    return true;
            }
        }
        return false;
    }

    /** @see KTestCase#test() */
    protected void test() {
        for(int i=0; i<testCases.size(); i++) {
            KTestCase test = (KTestCase)testCases.get(i);
            //if(test.isEnabled())
            if(test instanceof TestSuite || shouldRun(test)) {
                if(shouldRun(test))
                    ln("Test: "+test.getFullName());
                int temp = subStackSize();
                test.test();
                if(temp != subStackSize())
                    throw new IllegalStateException("Sub-test stack leakage");
            }
        }
    }
}
