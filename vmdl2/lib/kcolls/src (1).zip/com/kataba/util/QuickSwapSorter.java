
package com.kataba.util;

/** Implements an in-place Quick-Sort for objects which implement
 * <code>SwapSortable</code>
 *
 * @author Chris Thiessen
 */
public class QuickSwapSorter
    implements SwapSorter
{
    public static QuickSwapSorter INSTANCE = new QuickSwapSorter();

    /** Sorts the specified </code>SwapSortable</code>.
     *
     * @param sortable the object of the sort
     */
    public void sort(SwapSortable sortable) {
	sortRange(sortable, 0, sortable.size()-1);
    }

    /** Sorts a range within the specified
     * </code>SwapSortable</code>.
     *
     * @param sortable the object of the sort
     * @param firstIndex the first index of the range to sort
     * @param lastIndex the last index of the range to sort
     */
    public void sortRange(SwapSortable sortable
			  , int firstIndex, int lastIndex) {
	// check the arguments
	if(sortable.size() == 0)
	    return;
	if(firstIndex > lastIndex)
	    throw new IllegalArgumentException();
	if(firstIndex < 0 || lastIndex > sortable.size() - 1)
	    throw new ArrayIndexOutOfBoundsException();

	// do the sort
	internalSortRange(sortable, firstIndex, lastIndex);
    }

    /** Does the work of sorting a range within the specified
     * </code>SwapSortable</code>.  It is separate from
     * <code>sortRange(...)</code> to avoid the overhead of
     * unnecessary argument checks when recursing.
     *
     * @param sortable the object of the sort
     * @param firstIndex the first index of the range to sort
     * @param lastIndex the last index of the range to sort
     */
    private void internalSortRange(SwapSortable sortable
				   , int firstIndex, int lastIndex) {
	// if we're sorting just one element
	if(firstIndex == lastIndex)
	    return;

	// Initialize
	int leftIndex = firstIndex;
	int rightIndex = lastIndex;
	int centerIndex = firstIndex + (lastIndex - firstIndex) / 2;

	// separate the array
	while(leftIndex <= rightIndex) {
	    // find the first element >= 'center'
	    while(leftIndex < lastIndex
		  && sortable.compare(leftIndex, centerIndex) < 0)
		leftIndex++;

	    // find the first element <= 'center'
	    while(rightIndex > firstIndex
		  && sortable.compare(rightIndex, centerIndex) > 0)
		rightIndex--;

	    // if the indices haven't crossed
	    if(leftIndex <= rightIndex) {
		// keep track of the original center value
		if(leftIndex == centerIndex)
		    centerIndex = rightIndex;
		else if(rightIndex == centerIndex)
		    centerIndex = leftIndex;

		// swap elements
		sortable.swap(leftIndex, rightIndex);

		// shift indexes
		rightIndex--;				
		leftIndex++;
	    }
	}

	// sort the two parts
	if(firstIndex < rightIndex)
	    internalSortRange(sortable, firstIndex, rightIndex);
	if(leftIndex < lastIndex)
	    internalSortRange(sortable, leftIndex, lastIndex);
    }
}
