
package com.kataba.util;

/** A pool of Integer objects, to reduce construction
 *
 * @author Chris Thiessen
 */
public class IntegerPool {
    private static int CACHE_SIZE = 200;
    private static int CACHE_OFFSET = -1;
    private static Integer[] values = new Integer[CACHE_SIZE];

    /** Static initializer */
    static {
        for(int i=0; i<CACHE_SIZE; i++)
            values[i] = new Integer(i + CACHE_OFFSET);
    }

    /** Returns the Integer value corresponding to the specified 'int' value */
    public static Integer get(int value) {
        if(value < CACHE_OFFSET
	   || value >= CACHE_SIZE + CACHE_OFFSET)
            return new Integer(value);
        return values[value - CACHE_OFFSET];
    }

}
