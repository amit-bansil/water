
package com.kataba.util;

import java.io.*;

public class Printer_PrintWriter extends AbstractPrinter {
    private PrintWriter out;

    public Printer_PrintWriter(PrintWriter _out) {
        out = _out;
    }

    /** @see Printer#out */
    public void out(Object object) {
        out.print(object);
    }
}
