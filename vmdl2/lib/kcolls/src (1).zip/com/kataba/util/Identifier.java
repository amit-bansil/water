
package com.kataba.util;

/** Externally encapsulates object equivalence. */
public interface Identifier {
    /** Returns a hashcode for the object.  The rules that it follows
     * should be the same as those that the
     * <code>Object.hashCode()</code> method follows. */
    public int hashCode(Object object);

    /** Returns whether or not the two specified objects compare as
     * equals.  This method implements the same equivalence relation
     * that the <code>Object.equals(...)</code> method does. */
    public boolean equals(Object objectA, Object objectB);
}
