
package com.kataba.util;

import java.io.*;
//import javax.servlet.jsp.*;


public interface Printer {

    //
    // line-printing methods
    //

    public void ln();
    public void ln(boolean num);
    public void ln(char num);
    public void ln(long num);
    public void ln(double num);
    public void ln(Object message);


    //
    // inline-printing methods
    //

    public void out(boolean num);
    public void out(char num);
    public void out(long num);
    public void out(double num);
    public void out(Object message);

    public void close();
}


