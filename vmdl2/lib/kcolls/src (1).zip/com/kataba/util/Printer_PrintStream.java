
package com.kataba.util;

import java.io.*;

public class Printer_PrintStream extends AbstractPrinter {
    private PrintStream dest;

    public Printer_PrintStream(PrintStream _dest) {
        dest = _dest;
    }

    public void setDest(PrintStream _dest) {
        dest = _dest;
    }

    public PrintStream getDest() {
        return dest;
    }

    /** @see Printer#out */
    public void out(Object object) {
        dest.print(object);
    }
}
