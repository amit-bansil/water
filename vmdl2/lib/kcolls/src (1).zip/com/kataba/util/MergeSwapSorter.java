
package com.kataba.util;

/** A stable merge sort of <code>SwapSortable</code>s.  Not in-place:
 * requires additional storage equivalent to an <code>int</code> array
 * with as many elements as are being sorted.
 *
 * @author Chris Thiessen
 */
public class MergeSwapSorter
    implements SwapSorter
{
    public static MergeSwapSorter INSTANCE = new MergeSwapSorter();

    /** Sorts the specified </code>SwapSortable</code>.
     *
     * @param sortable the subject of the sort
     */
    public void sort(SwapSortable sortable) {
	mergeSort(sortable, new int[sortable.size()]
		  , 0, sortable.size()-1);
    }

    /** Sorts a range within the specified
     * </code>SwapSortable</code>.
     *
     * @param sortable the subject of the sort
     * @param firstIndex the first index of the range to sort
     * @param lastIndex the last index of the range to sort
     */
    public void sortRange(SwapSortable sortable, int firstIndex
			  , int lastIndex) {
	mergeSort(sortable, new int[lastIndex-firstIndex+1]
		  , firstIndex, lastIndex);
    }

    /** Sorts a range within the specified
     * </code>SwapSortable</code>, using the specified swap
     * space for indices.
     *
     * @param sortable the subject of the sort
     * @param begin    the index of the first element of the range to be sorted
     * @param end      the index of the last element of the range to be sorted
     */
    protected void mergeSort(SwapSortable sortable, int[] indices
			     , int begin, int end) {
	if(begin < end) {
	    int mid = (begin + end + 1) / 2;
	    if(begin != mid-1)
		mergeSort(sortable, indices, begin, mid-1);
	    if(mid != end)
		mergeSort(sortable, indices, mid, end);
	    merge(sortable, indices, begin, mid, end);
	}
    }

    /** Merge two abutting sorted sequences in the specified sortable,
     * using the specified indice swap space.  Worst case is O(N), but
     * if the sequences don't overlap, nothing is done.
     *
     * @param sortable the collection to sort
     * @param indices  swap space for indice storage
     * @param begin    the index of the first element of the first sequence
     * @param middle   the index of the first element of the second sequence
     * @param end      the index of the last element of the second sequence
     */
    protected void merge(SwapSortable sortable, int[] indices
			 , int begin, int middle, int end) {
	int left = begin;
	int right = middle;
	int dest=begin;

	// if the two sequences don't overlap, don't bother merging
	if(sortable.compare(middle-1, middle) <= 0)
	    return;

	// while the left and right sequences interleave
	while(left < middle && right <= end) {
	    if(sortable.compare(left, right) <= 0)
		indices[left++ - begin] = dest++;
	    else
		indices[right++ - begin] = dest++;
	}

	// while there's remaining elements on the left
	while(left < middle)
	    indices[left++ - begin] = dest++;

	// while there's remaining elements on the right
	while(right <= end)
	    indices[right++ - begin] = dest++;

	// update the sortable
	for(int i=begin; i<=end; i++) {
	    dest = indices[i-begin];
	    if(dest != -1) {
		while(dest != i) {
		    sortable.swap(i, dest);
		    int destIndex = dest - begin;
		    dest = indices[destIndex];
		    indices[destIndex] = -1;
		}
	    }
	}
    }
}
