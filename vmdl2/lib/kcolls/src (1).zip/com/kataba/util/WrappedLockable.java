
package com.kataba.util;

/** Wraps a Lockable.  Calls to Lockable methods on instances
 * of this class are forwarded to the wrapped Lockable.  This
 * class can be used to restrict the interface of the wrapped
 * Lockable to just the Lockable interface.
 *
 * @author Chris Thiessen
 */
public class WrappedLockable
    extends WrappedObject
    implements Lockable
{

    private Lockable lockable;

    /** Constructs to wrap the specified _lockable */
    public WrappedLockable(Lockable _lockable) {
        super(_lockable);
	lockable = _lockable;
    }

    /** Returns an object you can synchronize on to atomicize multiple
     * operations on this collection. */
    public Object lock() {
	return lockable.lock();
    }
}
