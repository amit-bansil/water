
package com.kataba.util;

import com.kataba.coll.*;

/** The base class of test cases which report errors, etc.
 *
 * @author Chris Thiessen
 */
public abstract class KTestCase extends KTestCaseUtil {
    private String name;
    private TestSuite parent = null;
    private int oks = 0;
    private int errs = 0;
    private boolean printOks = false;
    private boolean verbose = false;
    private ListRW subStack = new GapListRW();
    private int subsPrinted = 0;

    /** Constructs */
    protected KTestCase(String _name) {
        name = _name;
    }

    /** Returns the name of the test case */
    public String getName() {
        return name;
    }

    /** Returns the full, qualified name of the test */
    public String getFullName() {
        if(parent == null)
            return name;
        else
            return parent.getFullName()+"."+name;
    }

    /** Returns the parent of this test case */
    public TestSuite getParent() {
        return parent;
    }

    /** Returns whether this test should run */
    protected boolean shouldRun() {
        if(parent != null)
            return parent.shouldRun(this);
        else
            return true;
    }

    /** Prints information about the test to 'out', preceding each
     * line of output with 'pre' */
    public void printOn(Printer out, String pre) {
        out.ln(pre+name);
    }

    /** Returns whether 'verbose' mode is on */
    protected boolean verbose() {
        return verbose;
    }

    /** Pushes a name onto the stack of sub-test names */
    public void push(String subTestName) {
        if(parent != null)
            parent.push(subTestName);
        else
            subStack.add(subTestName);
    }

    /** Pops a name off the stack of sub-test names */
    public void pop() {
        if(parent != null)
            parent.pop();
        else {
            subStack.remove(subStack.size()-1);
            subsPrinted = Math.min(subStack.size(), subsPrinted);
        }
    }

    /** Pops a name off the stack of sub-test names. */
    public void pop(String subTestName) {
        if(parent != null)
            parent.pop(subTestName);
        else {
            String last = (String)subStack.get(subStack.size()-1);
            if(!last.equals(subTestName))
                throw new IllegalStateException
                    ("Mismatch: subTestName='"+subTestName+"', on-stack='"+last+"'");
            pop();
        }
    }

    /** Returns the number of names on the stack of sub-test names */
    public int subStackSize() {
        if(parent != null)
            return parent.subStackSize();
        return subStack.size();
    }


    //
    // setup methods
    //

    /** Initializes with command-line 'args' and then runs the
     * tests. eg. calls 'init(args)' then 'runTests()' */
    public void start(String[] args) {
        init(args);
        runTest();
    }

    /** Parses the arguments.  Returns the unparsed arguments. */
    protected String[] init(String[] args) {
        // parse the arguments
        ListRW others = new GapListRW();
        for(int i=0; i<args.length; i++) {
            if(args[i].equals("-ok"))
                printOks = true;
            else if(args[i].equals("-v"))
                verbose = true;
            else
                others.add(args[i]);
        }
        return (String[])others.toArray(new String[0]);
    }

    /** Sets the parent of the test case.  All test results are
     * reported to the parent, if a parent is set. */
    public void setParent(TestSuite _parent) {
        parent = _parent;
    }


    //
    // test sequence methods
    //

    /** Runs the test and prints the summary */
    protected final void runTest() {
        test();
        ln();
        summary();
    }

    /** Implemented to provide the body of the test
     *
     * TODO: should be abstract
     */
    protected void test() {}


    //
    // error reporting
    //

    /** Reports an error 'message' for the specified 'method' */
    public void error(String method, String message) {
        error(method+": " + message);
    }

    /** Reports an error */
    public void error(String message) {
        if(parent != null)
            parent.error(message);
        else {
            errs++;
            for(; subsPrinted<subStack.size(); subsPrinted++)
                ln(Util.spaces(subsPrinted*2+2) + subStack.get(subsPrinted));
            ln(Util.spaces(subStack.size()*2+2)+"ERROR: "+message);
        }
    }


    /** Sets whether OKs are printed when reported */
    public void setPrintOks(boolean _printOks) {
        if(parent != null)
            parent.setPrintOks(_printOks);
        else
            printOks = _printOks;
    }

    /** Reports an ok 'message' for the specified 'method' */
    public void ok(String method, String message) {
        ok(method+": " + message);
    }

    /** Reports an ok 'message' */
    public void ok(String message) {
        if(parent != null)
            parent.ok(message);
        else {
            oks++;
            if(printOks) {
                for(; subsPrinted<subStack.size(); subsPrinted++)
                    ln(Util.spaces(subsPrinted*2+2) + subStack.get(subsPrinted));
                ln(Util.spaces(subStack.size()*2+2)+"OK: "+message);
            }
        }
    }

    /** Reports an ok 'message' */
    public void ok() {
        ok("");
    }

    /** Prints a summary of the results of the test */
    public void summary() {
        if(parent != null)
            parent.summary();
        else {
            ln("Summary");
            ln("  errors: " + errs);
            ln("  OKs: " + oks);
        }
    }


    //
    // text output
    //

    /** Out.ln() */
    public void ln() {
        if(parent != null)
            parent.ln();
        else
            Out.ln();
    }

    /** Out.ln(text) */
    public void ln(Object text) {
        if(parent != null)
            parent.ln(text);
        else
            Out.ln(text);
    }

    /** Out.out(text) */
    public void out(Object text) {
        if(parent != null)
            parent.out(text);
        else
            Out.out(text);
    }

    /** if(verbose()) Out.ln() */
    public void vln() {
        if(parent != null)
            parent.vln();
        else if(verbose)
            Out.ln();
    }

    /** if(verbose()) Out.ln(text) */
    public void vln(Object text) {
        if(parent != null)
            parent.vln(text);
        else if(verbose)
            Out.ln(text);
    }

    /** if(verbose()) Out.out(text) */
    public void vout(Object text) {
        if(parent != null)
            parent.vout(text);
        else if(verbose)
            Out.out(text);
    }
}
