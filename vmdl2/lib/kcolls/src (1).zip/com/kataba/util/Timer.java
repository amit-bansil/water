
package com.kataba.util;

import java.io.*;
import java.util.*;

/** A timer.  The timer can be restarted (set to zero), and its
 * current time checked and printed.  Timers can also report
 * intermediate times.
 *
 * @author Chris Thiessen 
 */
public class Timer {
    private PrintStream ps = System.out;
    private long startTime;

    /** Constructs and initializes the timer to <code>0</code> */
    public Timer() {
	restart();
    }
    
    /** Set the PrintStream for this timer to write on by default
     *
     * @param ps the PrintStream
     */
    public void setPrintStream(PrintStream ps) {
	this.ps = ps;
    }

    /** Resets the timer to <code>0</code>. */
    public void restart() {
	startTime = System.currentTimeMillis();
    }

    public void reset() {
	restart();
    }

    /** Prints the elapsed time since the last <code>restart()</code>
     * to <code>out</code> and returns that elapsed time in
     * milliseconds.
     *
     * @param out the PrintStream to write to
     * @return the elapsed time in milliseconds since the last
     *         <code>restart()</code>
     */
    public long elapsed(PrintStream out) {
	return elapsed(out, "Elapsed time: ");
    }

    /** Prints the elapsed time since the last <code>restart()</code>
     * to the default PrintStream, labelled with <code>label</code>
     *
     * @param the label to provide
     * @return the elapsed time in milliseconds since the last
     *		<code>restart()</code>
     */
    public long elapsed(String label) {
	return elapsed(ps, label);
    }

    /** Prints the elapsed time since the last <code>restart()</code>
     * to <code>out</code>, labelled with <code>label</code>
     *
     *
     * @param out the PrintStream to write to
     * @param the label to provide
     * @return the elapsed time in milliseconds since the last
     *		<code>restart()</code>
     */
    public long elapsed(PrintStream out, String label) {
	return elapsed(out, label, "ms");
    }

    /** Prints the elapsed time since the last <code>restart()</code>
     * to <code>out</code>, labelled with <code>label</code>
     *
     *
     * @param out the PrintStream to write to
     * @param the label to provide
     * @return the elapsed time in milliseconds since the last
     *		<code>restart()</code>
     */
    public long elapsed(PrintStream out, String label, String post) {
	long elapsedTime = elapsed();

	out.print(label);
	out.print(elapsedTime);
	out.println(post);
	return elapsedTime;
    }

    /** Returns the elapsed time since the last <code>restart()</code>,
     * in milliseconds.
     *
     * @return the elapsed time in milliseconds since the last
     *         <code>restart()</code>
     */
    public long elapsed() {
	return System.currentTimeMillis() - startTime;
    }
}
