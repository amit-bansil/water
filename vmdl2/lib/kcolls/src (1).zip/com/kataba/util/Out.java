
package com.kataba.util;

import java.io.*;

public class Out {
    public static final PrintStream out = System.out;
    public static final Printer printer = new Printer_PrintStream(out);

    public static void ln(Object message) {
	out.println(message);
    }

    public static void ln() {
	out.println();
    }

    public static void out(Object message) {
	out.print(message);
    }
}
