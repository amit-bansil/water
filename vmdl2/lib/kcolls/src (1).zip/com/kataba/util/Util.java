
package com.kataba.util;

import com.kataba.coll.*;

import java.io.*;

/** Random utility methods
 *
 * @author Chris Thiessen
 */
public class Util {
    //public static final Object PRESENT = new Object();

    private static final String SPACES
	= "                                                                                                                                                                                             ";

    public static String firstLetterUpperCase(String string) {
        return string.substring(0,1).toUpperCase() + string.substring(1);
    }

    /** Returns a String of 'numSpaces' spaces. */
    public static String spaces(int numSpaces) {
	return SPACES.substring(0, numSpaces);
    }

    /** Returns a String of 'string.length()' spaces. */
    public static String spaces(String string) {
	return spaces(string.length());
    }

    /** Returns a String of 'numSpaces-string.length()' spaces. */
    public static String fill(String string, int numSpaces) {
	numSpaces = numSpaces - string.length();
	numSpaces = (numSpaces<=0)?1:numSpaces;
	return spaces(numSpaces);
    }

    /** Returns an array of the specified size */
    public static int[] expand(int[] array) {
	int[] temp = new int[array.length*2+1];
	System.arraycopy(array, 0, temp, 0, array.length);
	return temp;
    }

    public static int[] getIntArray(ListRO list) {
	int[] array = new int[list.size()];
	for(int i=0; i<array.length; i++)
	    array[i] = ((Integer)list.get(i)).intValue();
	return array;
    }

    public static String toString(long value) {
	return ""+value;
    }

    public static String toString(double value) {
	return ""+value;
    }

    public static String toString(boolean value) {
	return ""+value;
    }

    public static String toString(Object object) {
	return ""+object;
    }

    public static String toString(Object[] array) {
	StringBuffer buf = new StringBuffer();
	buf.append("{");
	for(int i=0; i<array.length; i++) {
	    if(i != 0)
		buf.append(",");
	    buf.append(array[i]);
	}
	buf.append("}");
	return buf.toString();
    }

    public static String toString(int[] array) {
	StringBuffer buf = new StringBuffer();
	buf.append("{");
	for(int i=0; i<array.length; i++) {
	    if(i != 0)
		buf.append(",");
	    buf.append(array[i]);
	}
	buf.append("}");
	return buf.toString();
    }

    /*
    public static final void assert(boolean arg) {
	if(!arg)
	    throw new AssertionFailureException();
    }
    */

    /** Returns <code>(object==null ? 0 : object.hashCode())</code> */
    public static final int hashCode(Object object) {
        return object==null ? 0 : object.hashCode();
    }

    /** Returns <code>(a==null ? b==null : a.equals(b))</code> */
    public static final boolean equals(Object a, Object b) {
        return a==null ? b==null : a.equals(b);
    }

    public static final boolean equals(char[] a, char[] b) {
	if(a == b)
	    return true;
	if(a == null || b == null)
	    return false;
	if(a.length != b.length)
	    return false;
	for(int i=0; i<a.length; i++)
	    if(a[i] != b[i])
		return false;
	return true;
    }

    public static final boolean equals(int[] a, int[] b) {
	if(a == b)
	    return true;
	if(a == null || b == null)
	    return false;
	if(a.length != b.length)
	    return false;
	for(int i=0; i<a.length; i++)
	    if(a[i] != b[i])
		return false;
	return true;
    }

    public static final boolean equals(Object[] a, Object[] b) {
	if(a == b)
	    return true;
	if(a == null || b == null)
	    return false;
	if(a.length != b.length)
	    return false;
	for(int i=0; i<a.length; i++)
	    if(!Util.equals(a[i], b[i]))
		return false;
	return true;
    }

    /** Compares two char[] ranges.  Returns 'true' if they're the
     * same, and 'false' if they differ. */
    public static final boolean equals(char[] a, int ai, int aEnd
				       , char[] b, int bi, int bEnd) {
	if(a == b && ai == bi && aEnd == bEnd)
	    return true;
	if(a == null || b == null)
	    return false;
	if(aEnd-ai != bEnd-bi)
	    return false;
	while(ai < aEnd)
	    if(a[ai++] != b[bi++])
		return false;
	return true;
    }

    public static final String toString(Object a, String nullString) {
	if(a != null)
	    return a.toString();
	else
	    return nullString;
    }

    /** All possible chars for representing a number as a String */
    final static char[] digits = {
	'0' , '1' , '2' , '3' , '4' , '5' ,
	'6' , '7' , '8' , '9' , 'a' , 'b' ,
	'c' , 'd' , 'e' , 'f' , 'g' , 'h' ,
	'i' , 'j' , 'k' , 'l' , 'm' , 'n' ,
	'o' , 'p' , 'q' , 'r' , 's' , 't' ,
	'u' , 'v' , 'w' , 'x' , 'y' , 'z'
    };

    private static final char[] buf = new char[12];

    public static void append(StringBuffer buffer, int value) {
	synchronized(buf) {
	    boolean negative = value < 0;
	    int charPos = 12;

	    if(value == Integer.MIN_VALUE)
		buffer.append("-2147483648");

	    if(negative)
		value = -value;

	    do {
		buf[--charPos] = digits[value % 10];
		value /= 10;
	    } while(value != 0);

	    if(negative)
		buf[--charPos] = '-';

	    buffer.append(buf, charPos, (12 - charPos));
	}
    }

    public static void append(StringBuffer buffer, int value, int radix) {
        if(radix < 2 || radix > 36)
	    throw new IllegalArgumentException("Invalid radix: " + radix);

	// Use the faster version
	if(radix == 10)
	    append(buffer, value);

	char buf[] = new char[33];
	boolean negative = (value < 0);
	int charPos = 32;

	if(!negative)
	    value = -value;

	while(value <= -radix) {
	    buf[charPos--] = digits[-(value % radix)];
	    value = value / radix;
	}
	buf[charPos] = digits[-value];

	if(negative)
	    buf[--charPos] = '-';

	buffer.append(buf, charPos, (33 - charPos));
    }

    public static int intValue(String value) {
	return (new Integer(value)).intValue();
    }

    public static final char[] chars(String string) {
	return chars(string, null);
    }

    public static final char[] chars(String string, char[] nullChars) {
	if(string == null)
	    return nullChars;

	char[] chars = new char[string.length()];
	string.getChars(0, string.length(), chars, 0);
	return chars;
    }

    public static final Boolean toObject(boolean value) {
	return value
	    ?Boolean.TRUE
	    :Boolean.FALSE;
    }

    public static final boolean isEmptyOrNull(String string) {
	return string == null || string.equals("");
    }

    public static final Integer toObject(int value) {
	return new Integer(value);
    }

    public static final Long toObject(long value) {
	return new Long(value);
    }

    public static boolean sleep(long millis) {
	try {
	    Thread.currentThread().sleep(millis);
	    return true;
	} catch(InterruptedException ex) {
	    return false;
	}
    }

    public static void sort(int[] array) {
    }

    public static void printStackTrace() {
	printStackTrace(System.out);
    }

    public static void printStackTrace(PrintStream out) {
	try {
	    throw new Exception();
	} catch(Exception ex) {
	    ex.printStackTrace(out);
	}
    }

    public static boolean match(char[] a, int startA
				, char[] b, int startB
				, int length) {
	if(startA + length > a.length
	   || startB + length > b.length)
	    return false;
	int ai = startA;
	int bi = startB;
	for(int i=0; i<length; i++)
	    if(a[ai++] != b[bi++])
		return false;
	return true;
    }

    public static boolean match(String string
				, char[] array, int start, int length) {
	if(string.length() != length)
	    return false;
	for(int i=0; i<length; i++)
	    if(string.charAt(i) != array[i+start])
		return false;
	return true;
    }
}

class AssertionFailureException extends RuntimeException {
}
