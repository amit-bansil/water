
package com.kataba.util;

public class DefaultIdentifier implements Identifier {
    public static final DefaultIdentifier INSTANCE = new DefaultIdentifier();

    /** Returns a hashcode for the object.  The rules that it follows
     * should be the same as those that the
     * <code>Object.hashCode()</code> method follows. */
    public int hashCode(Object object) {
	if(object == null)
	    return 0;
	else
	    return object.hashCode();
    }

    /** Returns whether or not the two specified objects compare as
     * equals.  This method implements the same equivalence relation
     * that the <code>Object.equals(...)</code> method does, except
     * that null values should be considered equivalent. */
    public boolean equals(Object objectA, Object objectB) {
	return (objectA == objectB
		|| (objectA != null && objectA.equals(objectB)));
    }
}
