
package com.kataba.util;


/** Wraps a Object.  Calls to Object methods on instances
 * of this class are forwarded to the wrapped Object.  This
 * class can be used to restrict the interface of the wrapped
 * Object to just the Object interface.
 *
 * @author Chris Thiessen
 */
public class WrappedObject {

    private Object object;

    /** Constructs to wrap the specified _object */
    public WrappedObject(Object _object) {
	object = _object;
    }

    /** @see Object#toString */
    public String toString() {
        return object.toString();
    }

    /** @see Object#hashCode */
    public int hashCode() {
        return object.hashCode();
    }

    /** @see Object#equals */
    public boolean equals(Object _object) {
        return object.equals(object);
    }
}
