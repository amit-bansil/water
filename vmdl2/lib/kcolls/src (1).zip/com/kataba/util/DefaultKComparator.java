
package com.kataba.util;

/** A Comparator which handles comparisons of objects implementing the
 * Comparable interface
 *
 * @author Chris Thiessen */
public class DefaultKComparator
    extends DefaultIdentifier
    implements KComparator
{
    /** Returns -1 if objectA < objectB, 0 if objectA == objectB, 1 if
     * objectA > objectB */
    public int compare(Object objectA, Object objectB) {
	int mult = 1;
	if(objectA == objectB)
	    return 0;

	// swap the objects if objectA is null
	if(objectA == null) {
	    mult = -1;
	    Object temp = objectA;
	    objectA = objectB;
	    objectB = temp;
	}

	// return the comparison
	if(objectA instanceof Comparable)
	    return mult * ((Comparable)objectA).compareTo((Comparable)objectB);
	else
	    throw new RuntimeException("Object of unhandled type: "
				       + objectA.getClass().getName());
    }
}
