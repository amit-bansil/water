
package com.kataba.util;

import java.io.*;

public class Printer_OutputStream extends AbstractPrinter {
    private OutputStream out;
    private PrintStream ps;

    public Printer_OutputStream(OutputStream _out) {
        out = _out;
	ps = new PrintStream(out);
    }

    /** @see Printer#out */
    public void out(Object object) {
        ps.print(object);
    }
}
