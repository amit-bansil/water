
package com.kataba.util;

import java.io.*;

/** Presents a read-only view of a range of a int[] */
public final class ArrayRO_int {
    private final int[] array;
    private final int start;
    private final int size;

    /** Constructs to wrap the specified 'array' */
    public ArrayRO_int(int[] _array) {
	this(_array, 0, _array.length);
    }

    /** Constructs to wrap the specified range of an '_array', from
     * '_start', up to but not including '_end' */
    public ArrayRO_int(int[] _array, int _start, int end) {
	array = _array;
	start = _start;
	size = end - start;

	if(start < 0)
	    throw new IndexOutOfBoundsException
		("start:"+start+", array.length:"+array.length);
	if(start > end)
	    throw new IllegalArgumentException("start:"+start+" > end:"+end);
	if(end > array.length)
	    throw new IllegalArgumentException("end:"+end+", array.length:"+array.length);
    }

    /** Returns the number of int's available */
    public int size() {
	return size;
    }

    /** Returns the int at the specified 'index' */
    public int get(int index) {
	return array[start+index];
    }

    /** @see Object#toString */
    public String toString() {
	StringBuffer buf = new StringBuffer();
	buf.append("{");
	for(int i=0; i<size; i++) {
	    if(i!=0)
		buf.append(",");
	    buf.append(array[start+i]);
	}
	buf.append("}");
	return buf.toString();
    }
    

    /** @see Object#equals */
    public boolean equals(Object object) {
	if(object == null || !(object instanceof ArrayRO_int))
	    return false;

	ArrayRO_int temp = (ArrayRO_int)object;
	if(size != temp.size)
	    return false;
	for(int i=0; i<size; i++) {
	    if(array[i] != temp.get(i))
		return false;
	}
	return true;
    }
}

