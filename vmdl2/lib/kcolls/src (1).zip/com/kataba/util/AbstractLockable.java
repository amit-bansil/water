
package com.kataba.util;

/** Default implementation of Lockable.  'lock()' returns 'this'
 *
 * @author Chris Thiessen
 */
public class AbstractLockable implements Lockable {
    /** Returns 'this'
     *
     * @see Lockable#lock() */
    public Object lock() {
	return this;
    }
}
