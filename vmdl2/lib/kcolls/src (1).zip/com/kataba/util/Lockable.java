//
// Copyright 2001 Muffinsoft. All Rights Reserved.
//
// This software is the proprietary information of Muffinsoft.  
// Use is subject to license terms.
//

package com.kataba.util;

/** To be implemented by classes which wish to specify to clients
 * what object to synchronize on to thread-safe any operations on it.
 *
 * @author Chris Thiessen
 */
public interface Lockable {
    /** Returns the Object that should be synchronized on to
     * thread-safe any operations on it. */
    public Object lock();
}
