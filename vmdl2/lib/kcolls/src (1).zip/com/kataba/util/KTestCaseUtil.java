
package com.kataba.util;

import com.kataba.coll.*;
import java.util.*;

public abstract class KTestCaseUtil {

    //
    // test element creation
    //

    private int lastElement = 0;

    public void resetE() {
        lastElement = 0;
    }

    /** Returns the 'next' object to be used as a collection element */
    public String e() {
        return "" + (lastElement++);
    }

    public String e(int num) {
        return "" + num;
    }

    /** Returns a new Integer object with a given value.
     *
     * @param num the value of the Integer object to be returned.
     */
    protected Object i(int num) {
        return new Integer(num);
    }

    /** Returns a new Integer object with a given value. 
     *
     * @param num the value of the Integer object to be returned.
     */
    protected Object createInt(int num) {
        return i(num);
    }

    /** Returns a new String with the given integer value. */
    protected Object createIntString(int num) {
        return e(num);
    }

    public Object[] array(int num) {
        Object[] array = new Object[num];
    
        for(int i=0; i<num; i++)
            array[i] = e();
    
        return array;
    }

    public CollectionRO coll(int num) {
        return new DefaultListRO(array(num));
    }

    public CollectionRO coll(Object[] array) {
    return new DefaultListRO(array);
    }

    public CollectionRO collro(Object element) {
    return new DefaultListRO(element);
    }

    public CollectionRO collro(CollectionRO coll) {
    return new DefaultListRO(coll);
    }

    public ListRO listro(Object element) {
    return new SingleElementListRO(element);
    }

    public ListRO listro(Object a, Object b) {
    return listro(new Object[] { a, b });
    }

    public ListRO listro(Object a, Object b, Object c) {
    return listro(new Object[] { a, b, c });
    }

    public ListRO listro(Object a, Object b, Object c, Object d) {
    return listro(new Object[] { a, b, c, d });
    }

    public ListRO listro(Object a, Object b, Object c, Object d, Object e) {
    return listro(new Object[] { a, b, c, d, e });
    }

    public ListRO listro(Object[] array) {
    return new DefaultListRO(array);
    }

    public ListRO listro(ListRO list) {
    return new DefaultListRO(list);
    }

    public ListRO listro(CollectionRO coll) {
    return new DefaultListRO(coll);
    }

    public SetRO setro(Object element) {
    return new DefaultSetRO(element);
    }

    public SetRO setro(Object a, Object b) {
    return setro(new Object[] { a, b });
    }

    public SetRO setro(Object a, Object b, Object c) {
    return setro(new Object[] { a, b, c });
    }

    public SetRO setro(Object a, Object b, Object c, Object d) {
    return setro(new Object[] { a, b, c, d });
    }

    public SetRO setro(Object a, Object b, Object c, Object d, Object e) {
    return setro(new Object[] { a, b, c, d, e });
    }

    public SetRO setro(Object[] array) {
    return new DefaultSetRO(array);
    }

    public SetRO setro(SetRO list) {
    return new DefaultSetRO(list);
    }

    public SetRO setro(CollectionRO coll) {
    return new DefaultSetRO(coll);
    }

    public java.util.Collection javaCollection(Object [] objects) {
        if (objects == null) {
            return null;
        }
        
        Vector v = new Vector(objects.length);
        for (int i = 0; i < objects.length; ++i) {
            v.addElement(objects[i]);
        }
        
        return v;
            
    }

    public java.util.Collection javaCollection(int numElements) {
        Vector v = new Vector(numElements);
        
        for (int i = 0; i < numElements; ++i) {
            v.addElement(e(i));
        }
        
        return v;
    }

    /** whether to compare exception message strings when determining
     *  equivalence of two exceptions
     */
    public static final int EX_EQUAL_COMPARE_MESSAGES = 1 << 0;

    /** Returns whether two exceptions are equal. 
     *@param exA an exception
     *@param exA and exception to compare to 'exA'
     *@return 'true' if the exceptions are equal; false otherwise
     */
    public static boolean exceptionsEqual(Exception exA, Exception exB) {
        return exceptionsEqual(exA, exB, 0);
    }

    /** Returns whether two exceptions are equal. 
     *@param exA an exception
     *@param exA and exception to compare to 'exA'
     *@param flags combo of EX_EQUAL_ flags
     *@return 'true' if the exceptions are equal; false otherwise
     */
    public static boolean exceptionsEqual(Exception exA, Exception exB, int flags) {
        // check for coinciding exceptions
        if(exA == null && exB == null) {
            return true;
        } else if(exA != null && exB != null) {
            String aExName = exA.getClass().getName();
            
            if(aExName.startsWith("java.lang.")) {
                aExName = aExName.substring("java.lang.".length());
            }
            
            String aExMsg = exA.getMessage();
            
            String bExName = exB.getClass().getName();
            
            if(bExName.startsWith("java.lang.")) {
                bExName = aExName.substring("java.lang.".length());
            }
            
            String bExMsg = exB.getMessage();

            if(exA.getClass() != exB.getClass()) {
                return false;
            } else if((flags & EX_EQUAL_COMPARE_MESSAGES) != 0) {
                if (! Util.equals(exA.getMessage(), exB.getMessage())) {
                    return false;
                }
            }
            
            return true;    // same exception

        } else {
            return false;
        }
    }

}
