
package com.kataba.util;

/** An interface for accepting or rejecting objects.
 *
 * @author Chris Thiessen
 */
public interface Filter {
    /** Returns <code>true</code> if the element should be 'included',
     * and <code>false</code> if the element should be filtered
     * out.
     *
     * @param element the element to filter
     */
    public boolean match(Object element);
}
