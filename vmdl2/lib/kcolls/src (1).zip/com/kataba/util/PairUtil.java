
package com.kataba.util;

public final class PairUtil {

    private PairUtil() {
    }

    /** Appends a pair to the specified array */
    public static Object[] add(Object[] array, int length
			       , Object a, Object b) {
	// no existing array
	if(array == null) {
	    array = new Object[4];
	    array[0] = a;
	    array[1] = b;
	    return array;
	}

	// new pair
	int index = 2*length;
	if(index < array.length) {
	    array[index] = a;
	    array[index+1] = b;
	    return array;
	}

	// expand the array and add the pair
	return expand(array, a, b);
    }


    /** Removes the two Objects at the specified pair index by
     * replacing it with the last pair in the 'array', then clearing
     * that last pair. */
    public static void swapRemove(Object[] array, int length, int pair) {
	if(pair < 0 || pair >= length)
	    throw new IndexOutOfBoundsException("indexpair:" + pair
						+ " length:" + length);

	// calculate pair indexes
	int lastIndex = (length-1) * 2;
	int pairIndex = pair * 2;

	// shift last pair over removed pair
	array[pairIndex] = array[lastIndex];
	array[pairIndex+1] = array[lastIndex+1];

	// clear last pair
	array[lastIndex] = null;
	array[lastIndex+1] = null;
    }

    /** Removes the two Objects at the specified pair index and shifts
     * the following pairs left.  Returns the second pair of the pair
     * being removed */
    public static Object shiftRemove(Object[] array, int length, int pair) {
	if(pair < 0 || pair >= length)
	    throw new IndexOutOfBoundsException("pair:" + pair
						+ " length:" + length);

	// the array index of the last pair
	int lastIndex = (length-1) * 2;
	int pairIndex = pair * 2;

	// cache old b
	Object oldB = array[pairIndex+1];

	// shift the following elements over the removed pair
	for(int i=pairIndex; i<lastIndex; i+=2) {
	    array[i] = array[i+2];
	    array[i+1] = array[i+3];
	}

	// clear last pair
	array[lastIndex] = null;
	array[lastIndex+1] = null;

	return oldB;
    }

    /** Returns the pair index of the pair of Objects in 'array' where
     * the first object == 'a' (not .equals(...)) */
    public static int find(Object[] array, int length, Object a) {
	for(int i=0,ii=length*2; i<ii; i+=2) {
	    if(array[i] == a)
		return i/2;
	}
	return -1;
    }

    /** Returns the key of the specified pair */
    public static Object getA(Object[] array, int pair) {
	return array[pair*2];
    }

    public static Object getB(Object[] array, int pair) {
	return array[pair*2+1];
    }

    /** Expands the specified array and appends the specified pair */
    public static Object[] expand(Object[] array, Object a, Object b) {
	//System.out.println("array.length: " + array.length);
	//printStackTrace(System.out);

	Object[] newArray = new Object[array.length*2];
	for(int i=0; i<array.length; i++)
	    newArray[i] = array[i];
	newArray[array.length] = a;
	newArray[array.length+1] = b;
	return newArray;
    }
}

