
package com.kataba.util;

/** Handy entity comparison methods.
 *
 * @author Chris Thiessen
 */
public class CompareUtil {
    /** Returns -1 if a < b, 1 if a > b, and 0 if a == b */
    public static int compare(long a, long b) {
	if(a < b)
	    return -1;
	else if(a > b)
	    return 1;
	return 0;
    }

    /** Returns -1 if a < b, 1 if a > b, and 0 if a == b */
    public static int compare(int a, int b) {
	if(a < b)
	    return -1;
	else if(a > b)
	    return 1;
	return 0;
    }

    /** Returns -1 if a < b, 1 if a > b, and 0 if a == b */
    public static int compare(short a, short b) {
	if(a < b)
	    return -1;
	else if(a > b)
	    return 1;
	return 0;
    }

    /** Returns -1 if a < b, 1 if a > b, and 0 if a == b */
    public static int compare(char a, char b) {
	if(a < b)
	    return -1;
	else if(a > b)
	    return 1;
	return 0;
    }

    /** Returns -1 if a < b, 1 if a > b, and 0 if a == b */
    public static int compare(byte a, byte b) {
	if(a < b)
	    return -1;
	else if(a > b)
	    return 1;
	return 0;
    }

    /** Returns -1 if a < b, 1 if a > b, and 0 if a == b */
    public static int compare(double a, double b) {
	if(a < b)
	    return -1;
	else if(a > b)
	    return 1;
	return 0;
    }

    /** Returns -1 if a < b, 1 if a > b, and 0 if a == b */
    public static int compare(float a, float b) {
	if(a < b)
	    return -1;
	else if(a > b)
	    return 1;
	return 0;
    }
}
