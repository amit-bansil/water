
package com.kataba.util;

/** Abstract base class for Printers.  Only 'out(Object)' must be
 * implemented in extending classes (though more can be) */
public abstract class AbstractPrinter implements Printer {
    /** @see Printer#ln */
    public void ln() {
        ln("");
    }

    /** @see Printer#ln(boolean) */
    public void ln(boolean value) {
        ln(""+value);
    }

    /** @see Printer#ln(char) */
    public void ln(char value) {
        ln(""+value);
    }

    /** @see Printer#ln(long) */
    public void ln(long value) {
        ln(""+value);
    }

    /** @see Printer#ln(double) */
    public void ln(double value) {
        ln(""+value);
    }

    /** @see Printer#ln(Object) */
    public void ln(Object message) {
	out(message);
	out("\r\n");
    }



    /** @see Printer#out(boolean) */
    public void out(boolean value) {
        out(""+value);
    }

    /** @see Printer#out(char) */
    public void out(char value) {
        out(""+value);
    }

    /** @see Printer#out(long) */
    public void out(long value) {
        out(""+value);
    }

    /** @see Printer#out(double) */
    public void out(double value) {
        out(""+value);
    }



    /** @see Printer#close */
    public void close() {
    }
}
