
package com.kataba.util;

/** The interface to be implemented by sorters of
 * <code>SwapSortable</code>'s
 *
 * @author Chris Thiessen
 */
public interface SwapSorter {
    /** Sorts the specified </code>SortableCollection</code>.
     *
     * @param sortable the subject of the sort
     */
    public void sort(SwapSortable sortable);

    /** Sorts a range within the specified </code>SwapSortable</code>.
     *
     * @param sortable the subject of the sort
     * @param begin    the first index of the range to sort
     * @param end      the last index of the range to sort
     */
    public void sortRange(SwapSortable sortable, int begin, int end);
}
