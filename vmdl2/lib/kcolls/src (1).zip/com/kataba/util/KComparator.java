
package com.kataba.util;

/** Externally encapsulates Object equivalence and ordering */
public interface KComparator
    extends Identifier, java.util.Comparator
{
    /** Returns -1 if objectA < objectB, 0 if objectA == objectB, 1 if
     * objectA > objectB */
    public int compare(Object objectA, Object objectB);
}
