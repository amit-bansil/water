
package com.kataba.util;

/** Implement this interface when you want a collection to be sortable
 * by a <code>SwapSorter</code>.
 *
 * @author Chris Thiessen
 */
public interface SwapSortable {
    /** Swaps the element at <code>indexA</code> with the element at
     * <code>indexB</code>
     *
     * @param indexA the index of an element
     * @param indexB the index of an element
     */
    public void swap(int indexA, int indexB);

    /** Compares the element at <code>indexA</code> with the element
     * at <code>indexB</code>, returning <code>&lt;0</code> if the
     * first is smaller than the second, <code>&gt;0</code> if the
     * second is larger, and <code>0</code> if they are the same.
     *
     * @return <code>&lt;0</code> if the first is smaller than the
     *         second, <code>&gt;0</code> if the second is larger, and
     *         <code>0</code> if they are the same.
     */
    public int compare(int indexA, int indexB);

    /** Returns the number of elements in the collection
     *
     * @return the number of elements in the collection
     */
    public int size();
}
