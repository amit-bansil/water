
package com.kataba.util;

/** An interface for non-invertible transformations of objects
 *
 * @author Chris Thiessen
 */
public interface Transform {
    /** Converts an object to the destination format */
    public Object to(Object object);
}
