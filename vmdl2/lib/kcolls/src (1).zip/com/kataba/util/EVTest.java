
package com.kataba.util;

/** The base class of classes which checks the result of method
 *  calls on an interaface. Direct
 *
 *  Direct subclasses are genrated by ModelTest_Gen.
 *
 *  @author Ray Vander Veen
 */
public abstract class EVTest extends KTestCase {

    protected EVTest(String name) {
        super(name);
    }

}
