
package com.kataba.util;

public class Printer_StringBuffer extends AbstractPrinter {
    private StringBuffer out;

    public Printer_StringBuffer(StringBuffer _out) {
	out = _out;
    }

    /** @see Printer#out */
    public void out(Object object) {
        out.append(object);
    }
}
