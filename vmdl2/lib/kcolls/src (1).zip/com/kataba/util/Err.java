
package com.kataba.util;

import java.io.*;

public class Err {
    public static final PrintStream err = System.err;

    public static void ln(Object message) {
	err.println(message);
    }

    public static void ln() {
	err.println();
    }

    public static void out(Object message) {
	err.print(message);
    }
}
