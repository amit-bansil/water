
package com.kataba.util;

import java.io.*;

public class Printer_Writer extends AbstractPrinter {
    private PrintWriter out;
    private Writer writer;

    public Printer_Writer(Writer _writer) {
	writer = _writer;
	out = new PrintWriter(writer);
    }

    /** @see Printer#out */
    public void out(Object object) {
        out.print(object);
    }
}
