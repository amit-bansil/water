BUILD

METROWORKS CODEWARRIOR 7 FULL INSTALL
JAVA2SDK1.4.0

RUN

RasUMD.dll (rasumd\rasumd.mcp)
Tip32.dll (tip32\tip32.mcp)
BCP.dll (bcp\bcp.mcp)
org (bin\build_src.bat)