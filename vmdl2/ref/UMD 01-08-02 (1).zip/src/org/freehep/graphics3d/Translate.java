package org.freehep.graphics3d;

/**
 * @author Mark Donszelmann
 * @version $Id: Translate.java,v 1.1 2000/11/17 15:43:57 duns Exp $
 */

public class Translate extends Vector3 {
    
    public Translate(double x, double y, double z) {
        super(x, y, z);
    }
}
