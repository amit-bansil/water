package org.freehep.graphics3d;

/**
 * @author Mark Donszelmann
 * @version $Id: Scale.java,v 1.1 2000/11/17 15:43:56 duns Exp $
 */

public class Scale extends Vector3 {
    
    public Scale(double x, double y, double z) {
        super(x, y, z);
    }
}
