package org.cps.data;

import org.cps.core.*;


/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class Binding extends CPSComponent {
	private final Variable target,source;
	public Binding(DataRoot parent,String name,String t,String s) {
		super(parent,name);
		this.target=parent.getInput(t);
		this.source=parent.getVariable(s);
		if(source==null) throw new IllegalArgumentException("source "+s+" not found");
		if(target==null) throw new IllegalArgumentException("target "+t+" not found");
		source.addDependant(this);
		target.addDependant(this);
		source.getValueChange().addListener(new ChangeListener(){
			public final void targetChanged(){
				target.setValue(source.getValue());
			}
		});
	}
}