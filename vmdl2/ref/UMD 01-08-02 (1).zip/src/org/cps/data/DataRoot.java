package org.cps.data;

import java.io.*;
import java.util.*;
import org.cps.core.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class DataRoot extends DynamicContainer{//create dependency checker

	public DataRoot(CPSContainer parent) {
		super("Data",parent);
		registerType(Binding.class,new Object[]{new String(),new String()});
		registerType(Variable.class,new Object[]{new Float(0)});
		registerType(ExpressionVariable.class,new Object[]{new String(),new String[0]});
		registerType(InputVariable.class,new Object[]{new Float(0)});
		registerType(PropertyVariable.class,new Object[]{new String[0]});
		registerType(InputVariableProperty.class,new Object[]{new String[0]});
		registerType(CalmedVariable.class,new Object[0]);
	}
	public final void objectRemoved(CPSComponent c){
		if(!variables.containsKey(c.getName()))throw new IllegalArgumentException("name "+c.getName()+" not added");
		variables.remove(c.getName());
		if(inputs.containsKey(c.getName()))inputs.remove(c.getName());
	}
	public final void objectAdded(CPSComponent c){
		if(variables.containsKey(c.getName()))throw new IllegalArgumentException("name "+c.getName()+" added");
		if(c instanceof InputVariable) inputs.put(c.getName(),c);
		variables.put(c.getName(),c);
	}
	public final InputVariable getInput(String name){return (InputVariable)inputs.get(name);}
	public final Variable getVariable(String name){return (Variable)variables.get(name);}
	public void load(InputStream in)throws IOException{
		super.load(in);
	}
	private final Hashtable variables=new Hashtable();
	private final Hashtable inputs=new Hashtable();
}