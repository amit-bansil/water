package org.cps.data;

import org.cps.core.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class CalmedVariable extends Variable {
	private int cin=0;
	public CalmedVariable(DataRoot parent,String name,final int regSize,String target,String time) {
		super(parent,name,0);

		final Variable targetV,timeV;
		targetV=parent.getVariable(target);
		timeV=parent.getVariable(time);
		if(target==null) throw new IllegalArgumentException("target not found");
		if(time==null) throw new IllegalArgumentException("time not found");

		final float[] xa=new float[regSize],ya=new float[regSize];
		ya[cin]=targetV.getValue();
		xa[cin]=timeV.getValue();
		cin++;

		targetV.getValueChange().addListener(new ChangeListener(){
			public final void targetChanged(){
				if(cin>=regSize){
					cin=0;
					setValue(linReg(xa,ya,timeV.getValue()));
				}
				ya[cin]=targetV.getValue();
				xa[cin]=timeV.getValue();
				cin++;
			}
		});
		setValue(ya[0]);
	}
	private final float linReg(float[] xa,float[] ya,float xn){
		final int n=xa.length;
		float sx=0,sxx=0,sy=0,sxy=0;
		float x,y;
		for(int i=0;i<n;i++){
			x=xa[i];
			y=ya[i];
			sx+=x;
			sxx+=x*x;
			sy+=y;
			sxy+=x*y;
		}
		float m=(n*sxy-sx*sy)/(n*sxx-sx*sx);
		float b=(-m*sx+sy)/n;
		return m*xn+b;
	}
}