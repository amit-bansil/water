package org.cps.data;
import org.cps.core.*;
import org.nfunk.jep.JEP;
import java.util.*;
import org.cps.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class ExpressionVariable extends Variable{
	private final JEP jep;

	public ExpressionVariable(DataRoot parent,String name,String expression,final String[] vs) {
		super(parent,name,0);
		if(expression==null||expression.length()==0) throw new IllegalArgumentException("expression must be set");

		final Variable[] variables=new Variable[vs.length];
		for(int i=0;i<vs.length;i++){
			variables[i]=(Variable)parent.getVariable(vs[i]);
			if(variables[i]==null) throw new IllegalArgumentException("variable "+vs[i]+" not found");
		}

		jep=new JEP();
		jep.addStandardConstants();
		jep.addStandardFunctions();

		for(int i=0;i<variables.length;i++){
			final int n=i;
			final String mappedName="v"+n;
			expression=CPSText.replace(expression,variables[i].getName(),mappedName);
			jep.addVariable(mappedName,variables[n].getValue());
			variables[i].getValueChange().addListener(new ChangeListener(){
				public final void targetChanged(){
					jep.addVariable(mappedName,variables[n].getValue());
					setValue((float)jep.getValue());
				}
			});
		}
		jep.parseExpression(expression);
		setValue((float)jep.getValue());
		if(jep.hasError()) throw new IllegalArgumentException("Equation Invalid:"+jep.getErrorInfo());
		for(int i=0;i<variables.length;i++) variables[i].addDependant(this);
	}
}