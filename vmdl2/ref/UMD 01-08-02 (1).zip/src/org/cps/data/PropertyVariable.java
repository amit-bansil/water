package org.cps.data;

import org.cps.core.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class PropertyVariable extends Variable {
	private final Property p;
	public PropertyVariable(CPSContainer parent,String name,String[] path) {
		super(parent,name,0);
		p=(Property)getCore().getEventQueue().getCommandable(path);
		p.addDependant(this);
		p.getChange().addListener(new ChangeListener(){
			public final void targetChanged(){
				setValue(((Float)ObjectProperty.convert(p.getObjectValue(),
						Number.class)).floatValue());
			}
		});
		setValue(((Float)ObjectProperty.convert(p.getObjectValue(),
						Number.class)).floatValue());
	}
}