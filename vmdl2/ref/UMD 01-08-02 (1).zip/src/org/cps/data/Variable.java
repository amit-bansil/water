package org.cps.data;
import org.cps.core.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class Variable extends CPSComponent{
	private float value;
	private final ChangeSupport valueChange=new ChangeSupport();

	public Variable(CPSContainer parent,String name,float initial) {
		super(parent,name);
		if(name==null||name.length()==0) throw new IllegalArgumentException("name must be specified");
		this.value=initial;
	}
	public final float getValue(){return value;}
	public final ChangeSupport getValueChange(){return valueChange;}

	protected void setValue(float v){
		if(value!=v){ value=v; valueChange.setChanged();}
	}
}