package org.cps;

import java.io.*;
import java.util.*;
import java.util.zip.*;
import org.cps.core.*;

/**
 * A persistent application configuration. A properties file is created in user.home
 * named [TITLE_SHORT].dat i.e. UMD.dat from which properties are read on startup,
 * and saved to on close (notified by a call to finish).
 * @author Amit Bansil
 * @version 1.0
 */
public final class CPSConfiguration {
	public static final String LOCATION="location";
	public static final String SIZE="size";
	public static final void save(String key,String value,Object v){
		save(key+"_"+value,v);
	}
	public static final Object load(String root,String key,Object v){
		return load(root+"_"+key,v);
	}
	public static final int loadIntProperty(String name,int defaultValue){
		return((Number)CPSConfiguration.load(name,new Integer(defaultValue))).intValue();
	}
	/**
	 * Returns the value a a system property that is expected to be either 'true'
	 * or 'false'. 'default' can also be specified in which case default value will
	 * be used.
	 * @param propertyName Name of the property, it will be appended to 'CPS_'.
	 * @param defaultValue  Whether the parameter should be assumed to be true or false
	 * if it is not specified or 'default' is specified.
	 * @return The system properties value.
	 */
	public static final boolean getBooleanSystemProperty(String propertyName,boolean defaultValue){
		String s=System.getProperty(CPS.FRAMEWORK_NAME+"_"+propertyName,"default");
		if(s.equals("true")) return true;
		else if(s.equals("false")) return false;
		else if(s.equals("default")) return defaultValue;
		else{
			CPSErrors.warning(
				"Unexpected value for system property '"+propertyName+"':"+s+"\n"+
				"Use either 'true', 'false', or 'default'."+"\n"+
				"The default value "+defaultValue+" will be substituted.");
			return true;
		}
	}
	private static final Hashtable props;
	private static final File propsFile;
	//short name of application ie UMD
	static{
		propsFile=new File(System.getProperty("user.home"),CPSApplicationDescription.TITLE_SHORT+".dat");

		Hashtable temp=new Hashtable();
		Throwable error=null;
		if(propsFile.exists()){
			ObjectInputStream oi=null;
			try{
				oi=new ObjectInputStream(
					new GZIPInputStream(new BufferedInputStream(
					new FileInputStream(propsFile))));

				temp=(Hashtable)oi.readObject();
			}catch(Throwable e){
				error=e;
			}finally{
				try{
					if(oi!=null) oi.close();
				}catch(IOException e){
					CPSErrors.warning("failed to close properties file",e);
				}
			}
		}
		if(error==null)props=temp;
		else{
			props=new Hashtable();
			CPSErrors.warning("property file reading failed:delete umd.dat!",error);
		}
	}
	/**
	 * Saves the current properties.
	 */
	public static void finish(){
		try{
			propsFile.delete();
			//propsFile.createNewFile(); not needed?

			ObjectOutputStream oo=new ObjectOutputStream(
				new GZIPOutputStream(new BufferedOutputStream(
				new FileOutputStream(propsFile) )));

			oo.writeObject(props);

			oo.flush();
			oo.close();
		}catch(Exception e){
			CPSErrors.warning("property file writing failed",e);
		}
	}
	/**
	 * Sets a key to some value.
	 * @param key The key to be used to lookup the value.
	 * @param value The value to be stored under the key.
	 */
	public static void save(Object key,Object value){
		props.put(key,value);
	}
	/**
	 * Saves a key with a certain value assuming no value is already assigned to
	 * that key.
	 * @param key The key to be used to lookup the value.
	 * @param def The value to be stored under the key.
	 */
	public static void saveDefault(Object key,Object def){
		if(!props.containsKey(key)) props.put(key,def);
	}
	/**
	 * Loads the value associated with a key.
	 * @param key The key to lookup.
	 * @return The associated value or <code>null</code> if not found.
	 */
	public static Object load(Object key){
		return props.get(key);
	}
	/**
	 * Loads the value associated with a key unless the key is not found in which
	 * case the key will be assigned the value def and def will be returned.
	 * @param key The key to lookup.
	 * @param def The default value of that key.
	 * @return The key's value or def if the key is not found.
	 */
	public static Object load(Object key,Object def){
		if(!props.containsKey(key))
			props.put(key,def);
		return props.get(key);
	}
}