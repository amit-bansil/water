package org.cps;

import java.awt.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import org.cps.core.*;
import org.freehep.util.ScientificFormat;
import org.cps.util.*;
import java.lang.reflect.*;
/**
 * Text handling macros.
 * The functions used for internationalization of stringsare also here.
 * The translations of keys are loaded from the properties file 'text'.
 * @author Amit Bansil
 * @version 0.0a
 */

public final class CPSText {

	public static final String TITLE="title";
	public static final String LABEL="label";
	private static final Hashtable text;
	public static final String trans(String value,String key){
		return trans(value+" "+key);
	}
	static{
		ResourceBundle t;
		text=new Hashtable(500,.25f);
		try{
			t=CPSResources.getProperties("text");
			Enumeration e=t.getKeys();
			String k;
			while(e.hasMoreElements()){
				k=(String)e.nextElement();
				if(CPS.isDebug()) if(text.contains(k))
					throw new IllegalArgumentException("duplicate definition: "+k);
				String v=t.getString(k);
				text.put(k.replace('_',' '),v);
			}
		}catch(IOException e){
			CPSErrors.ioException("failed to load text,application will exit",e);
			System.exit(-1);
		}catch(MissingResourceException e){
			CPSErrors.internalException("failed to find text,application will exit",e);
			System.exit(-1);
		}
	}
	/**
	 * Checks if a key can be translated.
	 * @param key the key.
	 * @return true if it can.
	 */
	public static final boolean contains(String key){
		return text.get(key)!=null;
	}
	/**
	 * Translate a key. If the key cannot be tranlsated it is returned and
	 * a "key not found" warning is register.
	 * @param key The key to be translated.
	 * @return Translation or the key.
	 */
	public static final String trans(final String key){
		final String ret;
		ret=(String)text.get(key);
		if(ret==null){
			CPSErrors.warning("key not found "+key);
			return key;
		}
		return ret;
	}
	public static final Icon emptyIcon=new Icon(){
		public int getIconHeight(){
			return 16;
		}
		public int getIconWidth(){
			return 16;
		}
		public void paintIcon(Component c, Graphics g, int x, int y){
		}
	};
	/**
	 * creates a menu item translating the name, and setting its mnomic and accelerator
	 * to [name].monic and [name].accel respectivly. If those keys are unspecified
	 * those fields of the menuitem are unset.
	 * @param name The base name.
	 * @return A JMenuItem.
	 */
	public static final JMenuItem createMenuItem(String name){
		final JMenuItem m=new JMenuItem(trans(name));
		m.setIcon(emptyIcon);
		if(contains(name+".monic")) m.setMnemonic(trans(name+".monic").charAt(0));
		if(contains(name+".accel")) m.setAccelerator(
			KeyStroke.getKeyStroke( trans(name+".accel") ));
		return m;
	}
	/**
	 * creates a menu, translating the name and giving it an empty icon to
	 * fix layout problems.
	 * @param name Menu's base name.
	 * @return A JMenu.
	 */
	public static final JMenu createMenu(String name){
		final JMenu m=new JMenu(CPSText.trans(name));
		m.setIcon(emptyIcon);
		return m;
	}
	private static final char[] escapesVs=new char[]{' ','\\','"','n','r','f','t'};
	private static final char[] escapesCs=new char[]{' ','\\','"','\n','\r','\f','\t'};
	private static final Object OPEN_ARRAY=new Object(),CLOSE_ARRAY=new Object();
	public static final String outputList(Object[] sa){//optimize

		StringBuffer ret=new StringBuffer();
		for(int i=0;i<sa.length;i++){
			final Object a=sa[i];
			if(a.getClass().isArray()){
				ret.append("{ ");
				Object[] o=new Object[Array.getLength(a)];
				for(int x=0;x<o.length;x++)o[x]=Array.get(a,x);
				ret.append(outputList(o));
				ret.append(" } ");
			}else{
				String s=outputToken(a.toString());
				if(s.length()==0) s="\" \"";
				if(s.equals("{")||s.equals("}")) s="\"s\"";
				ret.append(s);
				ret.append(' ');
			}
		}
		if(sa.length!=0) ret.setLength(ret.length()-1);
		return ret.toString();
	}
	private static final String outputToken(String s){//optimize
		for(int j=0;j<escapesCs.length;j++){
			if(s.indexOf(escapesCs[j])!=-1){
				for(int k=1;k<escapesVs.length;k++){
					s=replace(s,escapesCs[k],"\\"+escapesVs[k]);
				}
				return '"'+s+'"';
			}
		}
		return s;
	}
	public static final Object[] inputList(String s){//ditto
		//tokenize
		final char[] sa=s.toCharArray();
		StringBuffer current=new StringBuffer();
		CPSVector tokens=new CPSVector();
		boolean inToken=false;
		for(int i=0;i<sa.length;i++){
			if(inToken){
				boolean r=false;
				for(;i<sa.length;i++){
					for(int k=0;k<escapesVs.length;k++){
						if(sa[i]==escapesCs[k]){
							r=true; break;
						}
					}
					if(r) break;
					current.append(sa[i]);
				}
				tokens.add(current.toString());
				current=new StringBuffer();
				inToken=false;
				continue;
			}
			if(sa[i]=='"'){
				if(i==sa.length-1) throw new IllegalArgumentException("unclosed quote");
				i++;
				for(;i<sa.length;i++){
					if(sa[i]=='\\'){//append corrected
						if(i==sa.length-1) throw new IllegalArgumentException("illegal escape");
						i++;
						for(int k=0;true;k++){
							if(sa[i]==escapesVs[k]){
								current.append(escapesCs[k]);
								break;
							}
							if(k==escapesVs.length-1) throw new IllegalArgumentException("illegal escape");
						}
						continue;
					}
					if(sa[i]=='"'){
						break;
					}
					current.append(sa[i]);
				}
				tokens.add(current.toString());
				current=new StringBuffer();
				continue;
			}
			if(sa[i]=='{'){
				tokens.add(OPEN_ARRAY);
				continue;
			}else if(sa[i]=='}'){
				tokens.add(CLOSE_ARRAY);
				continue;
			}
			boolean r=false;
			for(int k=0;k<escapesVs.length;k++){
				if(sa[i]==escapesCs[k]){r=true; break;}
			}
			if(!r){ inToken=true; i--; }
		}

		final Object[] o=(Object[])tokens.createArray(Object.class);
		return combineArrays(o,0,o.length);
	}
	private static final Object[] combineArrays(Object[] o,int off,int len){//optimize
		CPSVector ret=new CPSVector();
		Object x;
		for(int i=off;i<off+len;i++){
			x=o[i];
			if(x==OPEN_ARRAY){
				int n=1,s=i;
				while(n!=0){
					i++;
					if(i==len+off)throw new IllegalArgumentException("expected }");
					x=o[i];
					if(x==OPEN_ARRAY) n++;
					else if(x==CLOSE_ARRAY) n--;
				}
				x=combineArrays(o,s+1,(i-s)-1);
			}else if(x==CLOSE_ARRAY){
				throw new IllegalArgumentException("unexpected }");
			}
			ret.add(x);
		}
		return ret.createArray(Object.class);
	}
	/**
	 * Formats a string array into a single string array suitable for output.
	 * @param s The string array.
	 * @return A single string.
	 */
	public static final String listToString(String[] s){
		return listToString(s,true);
	}
	public static final String listToString(String[] s,boolean showAnd){//use below
		if(s.length==0) throw new IllegalArgumentException("String array must contain some elements");
		else if(s.length==1) return s[0];
		final String and=showAnd?trans("and"):",";
		if(s.length==2) return s[0]+" "+and+" "+s[1];
		else{
			String ret=null;
			for(int i=0;i<s.length-1;i++) ret+=s[i]+", ";
			return ret+and+" "+s[s.length-1];
		}
	}
	public static final String listToString(Object[] s,char sep){//optimize
		String ret=new String();
		for(int i=0;i<s.length-1;i++) ret+=s[i].toString()+sep;
		if(s.length!=0) ret+=s[s.length-1];
		return ret;
	}
	public static final String listToString(String[] s,char sep){//optimize
		String ret=new String();
		for(int i=0;i<s.length-1;i++) ret+=s[i]+sep;
		if(s.length!=0) ret+=s[s.length-1];
		return ret;
	}
	//converts a number if milleseconds into an approximate string
	private static final long[] timeCs=new long[]{1,1000,60,60,24,365,1000};
	private static final String[] timeNs=new String[]{
		"millesecond",
		"second",
		"minute",
		"hour",
		"day",
		"year",
		"millenium"};
	private static final String[] timeNsp=new String[]{
		"milleseconds",
		"seconds",
		"minutes",
		"hours",
		"days",
		"years",
		"millenia"};

	/**
	 * Formats a number of millesconds into a time string.
	 * For example 6100 would become '6 minutes'. It is a very appoximate display
	 * truncated to two words. This is suitable for telling the user the time remaining for an operation.
	 * Should not display over ten years. 0 will return '<1 millesecond'.
	 *
	 * @param time Num of milliseconds.
	 * @return A string.
	 */
	 public static final String timeToString(long time){
		return timeToString(time,1);
	}

	/**
	 * Formates a number of milliseconds as a time string cuttingoff as less than
	 * long milliseconds. For example if the cutoff is 1000 times less than 1000 will
	 * displasy '<1 second'.
	 * @param time Time.
	 * @param cut Cutoff.
	 * @return A string.
	 */
	//to do return full time string
	public static final String timeToString(long time,long cut){
		if(time<cut) return "< "+timeToString(cut);
		for(int i=0;i<timeNs.length;i++){
			time=time/timeCs[i];
			if(time==1) return "1 "+CPSText.trans(timeNs[i]);
			else if(time<timeCs[i+1]) return time+" "+CPSText.trans(timeNsp[i]);
		}
		return ">"+timeCs[timeNsp.length]+" "+CPSText.trans(timeNsp[timeNsp.length-1]);
		/*if(time<cut) return "< "+timeToString(cut,-1);
		int i=0;
		long c=1;
		for(;i<timeCs.length;i++){
			c*=timeCs[i];
			if(c>cut){i--; c/=timeCs[i]; break;}
		}
		if(i==timeCs.length) throw new IllegalArgumentException("cutoff["+cut+"] overflow,>="+c);
		if(Math.round((double)time/(double)c)==1) return 1+CPSText.trans(timeNs[i]);

		int v;
		for(int j=timeCs.length-1;i>=0;j--){
			v=(int)Math.round((double)time/(double)c);
			ret=":"+v+ret;
			time-=v*c;

		}*/
	}
	//ACME routines
	/**
	 * Fills a string with spaces to give it minWidth characters. This will
	 * right justify a fixed width font.
	 * @param s The string.
	 * @param minWidth Min number of characters in the string.
	 * @return The string with spaces appended to the right.
	 */
	public static final String rightJustify(final String s,final int minWidth){
		final int len = s.length();
		if ( len >= minWidth )
			return s;
		final int fillWidth = minWidth - len;
		final StringBuffer fill = new StringBuffer( fillWidth );
		for ( int i = 0; i < fillWidth; ++i )
			fill.append( ' ' );

		return fill + s;
	}

	/**
	 * This set of functions outputs a number with a fixed number of significant figures.
	 * @param d double to round
	 * @param sigFigs @ of sigfigs
	 * @return formatted string.
	 */
	public static final String numToString(final double d,final int sigFigs){

		return numToString((float)d,sigFigs);
	}
	private static final String UNDETERMINED_CHAR='\u00D8'+"",INFINITY_CHAR='\u221E'+"";
	private static final ScientificFormat formatter=new ScientificFormat(4,3,false);
	public static final String numToString(final float f,final int sigFigs){
		formatter.setSigDigits(sigFigs);
		if(f==0){return formatter.format(0);}//optimize this case
		else if(Float.isNaN(f)) return UNDETERMINED_CHAR;
		else if(Float.isInfinite(f)){
			if(f==Float.NEGATIVE_INFINITY) return "-"+INFINITY_CHAR;
			else return INFINITY_CHAR;
		}else{
			return formatter.format(f);
		}
	}
	public static final String decimalRound(final double v,final int coef){//lots of potential for optimizing
		if(coef<=0) throw new IllegalArgumentException("coef<="+0);

		final long wholePart=(long)Math.floor(v);
		final int fractPart=(int)Math.round((v-wholePart)*Math.pow(10,coef));
		StringBuffer fractString=new StringBuffer(Integer.toString(fractPart));
		int l=fractString.length();
		fractString.setLength(coef);
		for(int i=l;i<coef;i++) fractString.setCharAt(i,'0');
		return Long.toString(wholePart)+"."+fractString;
	}
	/**
	 * StringTokenizer Delimeters to parse an array.
	 * @return "\t ," or tab, comma, and space.
	 */
	public static final String getArrayDelimiters(){
		return "\t ,";
	}
	/**
	 * Whitespace characters as defined by StringTokenizer.
	 * @return " \t\n\r\f"
	 */
	public static final String getWhitespace(){
		return " \t\n\r\f";
	}
	public static final String[] listToArray(String s){
		return listToArray(s,-1);
	}
	public static final String[] listToArray(String s,int count){
		return listToArray(s,count,count);
	}
	public static final String[] listToArray(String s,int min,int max){
			String[] ret=seperate(s,getArrayDelimiters());
			if(min!=-1&&ret.length<min) throw new IllegalArgumentException("too few parameters");
			if(max!=-1&&ret.length>max) throw new IllegalArgumentException("too many parameters");
			return ret;
	}
	public static final String[] seperate(final String s,final String delimeters){//todo allow quote escapse
		final StringTokenizer st=new StringTokenizer(s,delimeters,false);
		final String[] ret=new String[st.countTokens()];
		int i=0;
		while(st.hasMoreTokens()){ ret[i]=st.nextToken(); i++;}
		return ret;
	}
	public static final String replace(String target,String v0,final String v1){
		StringBuffer sb=new StringBuffer(target);
		int i=sb.indexOf(v0);
		while(i!=-1){
			sb.delete(i,i+v0.length());
			sb.insert(i,v1);
			i=sb.indexOf(v0,i+v1.length());
		}
		return sb.toString();
	}
	public static final String replace(String target,final char v0,final String v1){
		StringBuffer sb=new StringBuffer(target);
		if(v1.length()==0) return target;
		final char v11=v1.charAt(0);
		final int v13=v1.length()-1;
		final String v12= v13!=0?v1.substring(1):null;
		for(int i=0;i<sb.length();i++){
			if(sb.charAt(i)==v0){
				sb.setCharAt(i,v11);
				if(v12!=null) sb=sb.insert(i,v12);
				i+=v13;
			}
		}
		return sb.toString();
	}
}