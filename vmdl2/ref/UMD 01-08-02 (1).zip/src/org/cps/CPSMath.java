package org.cps;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public final class CPSMath {
	public static final float fit(float f,float max,float min){
		return Math.min(Math.max(f,min),max);
	}


	/*converts the dimensions of a cube into front and rear facing lines*/
/*
	static final int[][] lines=new int[][]{{0,1},{1,3},{3,2},{2,0},{4,5},{5,7},{7,6},{6,4},{0,4},{1,5},{3,7},{2,6}};
	static final int[][] faces=new int[][]{{0,1,3,2},{4,5,7,6},{2,0,4,6},{0,4,5,1},{1,5,7,3},{2,6,7,3}};

	static final int[][] connections=new int[][]{{1,2,4},{0,5,3},{0,3,6},{1,2,7},{0,6,5},{1,4,7},{2,4,7},{3,5,6}};

	//front facing lines can be determined based on three facts-
	//a line is in front when it is a member of a face that is in front
	//a face is in front when it touches the front most point
	//and the point diagonal from the front point on that face

	/*public static void getCube(){
		int points[][]=new int[8][3];
		boolean faceFront[]=new boolean[6];
		for(int i=0;i<faceFront.length;i++) faceFront[i]=false;
		for(int i=0;i<4;i++)

	}*/
}