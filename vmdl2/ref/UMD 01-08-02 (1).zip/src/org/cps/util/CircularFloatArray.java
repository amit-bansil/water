package org.cps.util;

import org.cps.CPSErrors;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class CircularFloatArray {
	private final float[] internal;
	private final int size;
	private int offset,length,end;
	private boolean full;

	public CircularFloatArray(int length) {this(new float[length],0,0);}
	public CircularFloatArray(float[] f,int offset,int length){//passed array must be straight
		internal=f;
		offset=offset;
		end=length-offset;
		size=f.length;
		this.length=length;
		full=false;
	}
	public final void add(float f){
		if(end>=size){ end=0; full=true; }
		internal[end]=f;
		end++;
		length++;
		if(full) offset++;
	}
	public final void add(float[] f){add(f,0,f.length);}
	public final void add(final float[] f,int offset,int length){
		for(int i=offset;i<length;i++) add(f[i]); //optimize
	}

	public final int getOffset(){return offset;}
	public final int getLength(){return length;}
	public final int getSize(){return size;}
	public final void getAll(float[] f){
		System.arraycopy(internal,end,f,0,internal.length-end);
		System.arraycopy(internal,0,f,internal.length-end,end);
	}
	public final float get(int o){
		if(o<offset) throw new ArrayIndexOutOfBoundsException("index<=first valid index["+offset+"]");
		o=end-(length-o);
		if(o>=end) throw new ArrayIndexOutOfBoundsException("index["+o+"]>=length["+length+"]");
		if(o<0) o+=size;
		return internal[o];
	}
	public final void get(int offset, int length,float[] f){
		for(int i=offset;i<length;i++) f[i]=get(i);
	}
	public final void get(int offset,float[] f){get(offset,f.length);}
	public final float[] get(int offset, int length){
		final float[] f=new float[length];
		get(offset,length,f);
		return f;
	}
	public String toString(){
		return super.toString()+
				"[data="+internal+
				",offset="+offset+
				",length="+length+
				",end="+end+
				",full="+full+"]";
	}
	//test
	public static final void main(String[] args){
		final CircularFloatArray test1=new CircularFloatArray(7);
	}
}