package org.cps.util;

import java.util.Enumeration;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public final class ArrayEnumeration implements Enumeration {
	private final Object[] a;
	private int n=-1;
	private final int l;
    public ArrayEnumeration(Object[] a) {
		l=a.length;
		this.a=a;
    }
    public final boolean hasMoreElements() {
        return (n+1<l);
    }
    public final Object nextElement() {
		n++;
		return a[n];

    }
}