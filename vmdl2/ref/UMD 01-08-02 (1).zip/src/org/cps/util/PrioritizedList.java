package org.cps.util;

/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */

public class PrioritizedList {
    float[] priorities=new float[0];
    Object[] objects=new Object[0];

    public PrioritizedList() {
    }
	public boolean contains(Object o){
		for(int i=0;i<objects.length;i++){
			if(objects[i].equals(o)) return true;
		}
		return false;
	}
    public void add(Object o,float priority){
        int next=0;
        for(int i=0;i<priorities.length;i++){
            if(priorities[i]>priority) break;
            next++;
        }
        Object[] temp=new Object[objects.length+1];
        System.arraycopy(objects,0,temp,0,next);
        temp[next]=o;
        System.arraycopy(objects,next,temp,next+1,objects.length-next);
        objects=temp;

        float[] temp2=new float[priorities.length+1];
        System.arraycopy(priorities,0,temp2,0,next);
        temp2[next]=priority;
        System.arraycopy(priorities,next,temp2,next+1,priorities.length-next);
        priorities=temp2;
    }
    public void remove(Object o){
        for(int i=0;i<objects.length;i++){
            if(objects[i]==o){
                Object[] temp=new Object[objects.length-1];
                if(i!=0) System.arraycopy(objects,0,temp,0,i);
                if(objects.length-1!=i) System.arraycopy(objects,
                    i+1,temp,i,(objects.length-i)-1);
                objects=temp;

                float[] temp2=new float[priorities.length-1];
                if(i!=0) System.arraycopy(priorities,0,temp2,0,i);
                if(priorities.length-1!=i) System.arraycopy(priorities,
                    i+1,temp2,i,(priorities.length-i)-1);
                priorities=temp2;
                return;
            }
        }
    }
    public Object[] getObjects(){
        return objects;
    }
}