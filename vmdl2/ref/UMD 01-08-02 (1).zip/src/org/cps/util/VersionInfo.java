package org.cps.util;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */

public class VersionInfo {

  public VersionInfo() {
  }
  private String name;
  private java.util.Date date;
  private int major;
  private String description;
  private int micro;
  private int minor;
  private String[] author;
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  public void setDate(java.util.Date date) {
    this.date = date;
  }
  public java.util.Date getDate() {
    return date;
  }
  public void setMajor(int major) {
    this.major = major;
  }
  public int getMajor() {
    return major;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  public String getDescription() {
    return description;
  }
  public void setAuthors(String[] author) {
    this.author = author;
  }
  public String[] getAuthors() {
    return author;
  }
  public void setMinor(int minor) {
    this.minor = minor;
  }
  public int getMinor() {
    return minor;
  }
  public void setMicro(int micro) {
    this.micro = micro;
  }
  public int getMicro() {
    return micro;
  }
  public String getVersionNumberString(){
	return "v"+getMajor()+"."+getMinor()+"."+getMicro();
  }
}