package org.cps.util;

import java.util.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class ReverseHashtable extends Hashtable {

    public ReverseHashtable(Hashtable table) {
		super(table.size());
		Enumeration e=table.keys();
		Object k;
		while(e.hasMoreElements()){
			k=e.nextElement();
			put(table.get(k),k);
		}
    }
}