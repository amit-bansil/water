package org.cps.util;

import java.util.*;


/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class CPSVector implements Cloneable{

	protected transient int modCount = 0;

	public CPSVector search(Class type){
		final CPSVector ret=new CPSVector();
		final int length=elementCount;
		for(int i=0;i<length;i++){
			if(type.isInstance(elementData[i])) ret.add(elementData[i]);
		}
		return ret;
	}

	public void copyInto(Object anArray[]) {
		System.arraycopy(elementData, 0, anArray, 0, elementCount);
	}
	public void fill(Object[] array){
		System.arraycopy(elementData,0,array,0,size());
	}
	public void addArray(Object[] o){
		for(int i=0;i<o.length;i++) add(o[i]);
	}
	public Object[] createArray(Class type){
		Object[] ret=(Object[])java.lang.reflect.Array.newInstance(type, elementCount);
		fill(ret);
		return ret;
	}
	public Object[] createArray(){
		Object[] ret=new Object[elementCount];
		fill(ret);
		return ret;
	}

	private Object elementData[];
	private int elementCount;
	private int capacityIncrement;

	public CPSVector(int initialCapacity, int capacityIncrement) {
		super();
		if (initialCapacity < 0){
			throw new IllegalArgumentException("Illegal Capacity: "+
					initialCapacity);
		}
		this.elementData = new Object[initialCapacity];
		this.capacityIncrement = capacityIncrement;
	}

	public CPSVector(int initialCapacity) {
		this(initialCapacity, 0);
	}

	public CPSVector() {
		this(10);
	}

	public void trimToSize() {
		modCount++;
		int oldCapacity = elementData.length;
		if (elementCount < oldCapacity) {
			Object oldData[] = elementData;
			elementData = new Object[elementCount];
			System.arraycopy(oldData, 0, elementData, 0, elementCount);
		}
	}

	public void ensureCapacity(int minCapacity) {
		modCount++;
		ensureCapacityHelper(minCapacity);
	}

	private void ensureCapacityHelper(int minCapacity) {
		int oldCapacity = elementData.length;
		if (minCapacity > oldCapacity) {
			Object oldData[] = elementData;
			int newCapacity = (capacityIncrement > 0) ?
					 (oldCapacity + capacityIncrement) : (oldCapacity * 2);
			if (newCapacity < minCapacity) {
				newCapacity = minCapacity;
			}
			elementData = new Object[newCapacity];
			System.arraycopy(oldData, 0, elementData, 0, elementCount);
		}
	}

	public void setSize(int newSize) {
		modCount++;
		if (newSize > elementCount) {
			ensureCapacityHelper(newSize);
		} else {
			for (int i = newSize ; i < elementCount ; i++) {
				elementData[i] = null;
			}
		}
		elementCount = newSize;
	}

	public int capacity() {
		return elementData.length;
	}

	public int size() {
		return elementCount;
	}

	public boolean isEmpty() {
		return elementCount == 0;
	}

	public Enumeration elements() {
		return new Enumeration() {
			int count = 0;

			public boolean hasMoreElements() {
				return count < elementCount;
			}

			public Object nextElement() {
				if (count < elementCount) {
					return elementData[count++];
				}

				throw new NoSuchElementException("Vector Enumeration");
			}
		};
	}

	public boolean contains(Object elem) {
		return indexOf(elem, 0) >= 0;
	}

	public int indexOf(Object elem) {
		return indexOf(elem, 0);
	}

	public int indexOf(Object elem, int index) {
		if (elem == null) {
			for (int i = index ; i < elementCount ; i++)
	   if (elementData[i]==null)
		return i;
		} else {
			for (int i = index ; i < elementCount ; i++)
	   if (elem.equals(elementData[i]))
		return i;
		}
		return -1;
	}

	public int lastIndexOf(Object elem) {
		return lastIndexOf(elem, elementCount-1);
	}

	public int lastIndexOf(Object elem, int index) {
		if (index >= elementCount){
			throw new IndexOutOfBoundsException(index + " >= "+ elementCount);
		}
		if (elem == null) {
			for (int i = index; i >= 0; i--)
	   if (elementData[i]==null)
		return i;
		} else {
			for (int i = index; i >= 0; i--)
	   if (elem.equals(elementData[i]))
		return i;
		}
		return -1;
	}

	public Object elementAt(int index) {
		if (index >= elementCount) {
			throw new ArrayIndexOutOfBoundsException(index + " >= " + elementCount);
		}
		try {
			return elementData[index];
		} catch (ArrayIndexOutOfBoundsException e) {
			throw new ArrayIndexOutOfBoundsException(index + " < 0");
		}
	}


	public Object firstElement() {
		if (elementCount == 0) {
			throw new NoSuchElementException();
		}
		return elementData[0];
	}

	public Object lastElement() {
		if (elementCount == 0) {
			throw new NoSuchElementException();
		}
		return elementData[elementCount - 1];
	}

	public void setElementAt(Object obj, int index) {
		if (index >= elementCount) {
			throw new ArrayIndexOutOfBoundsException(index + " >= " +
					elementCount);
		}
		modCount++;
		elementData[index] = obj;
	}

	public void removeElementAt(int index) {
		modCount++;
		if (index >= elementCount) {
			throw new ArrayIndexOutOfBoundsException(index + " >= " +
					elementCount);
		}
		else if (index < 0) {
			throw new ArrayIndexOutOfBoundsException(index);
		}
		int j = elementCount - index - 1;
		if (j > 0) {
			System.arraycopy(elementData, index + 1, elementData, index, j);
		}
		elementCount--;
		elementData[elementCount] = null; /* to let gc do its work */
	}

	public void insertElementAt(Object obj, int index) {
		modCount++;
		if (index >= elementCount + 1) {
			throw new ArrayIndexOutOfBoundsException(index
					+ " > " + elementCount);
		}
		ensureCapacityHelper(elementCount + 1);
		System.arraycopy(elementData, index, elementData, index + 1, elementCount - index);
		elementData[index] = obj;
		elementCount++;
	}

	public void addElement(Object obj) {
		modCount++;
		ensureCapacityHelper(elementCount + 1);
		elementData[elementCount++] = obj;
	}

	public boolean removeElement(Object obj) {
		modCount++;
		int i = indexOf(obj);
		if (i >= 0) {
			removeElementAt(i);
			return true;
		}
		return false;
	}

	public void removeAllElements() {
		modCount++;
		// Let gc do its work
		for (int i = 0; i < elementCount; i++){
			elementData[i] = null;
		}
		elementCount = 0;
	}

	public Object clone() {

		CPSVector v = null;
		try {
			v = (CPSVector)super.clone();
			v.elementData = new Object[elementCount];
			System.arraycopy(elementData, 0, v.elementData, 0, elementCount);
			v.modCount = 0;
		}
		catch (CloneNotSupportedException ex) {
			throw new InternalError();
		}

		return v;
	}

	public Object[] toArray() {
		Object[] result = new Object[elementCount];
		System.arraycopy(elementData, 0, result, 0, elementCount);
		return result;
	}

	public Object[] toArray(Object a[]) {
		if (a.length < elementCount){
			a = (Object[])java.lang.reflect.Array.newInstance(
					a.getClass().getComponentType(), elementCount);
		}
		System.arraycopy(elementData, 0, a, 0, elementCount);

		if (a.length > elementCount){
			a[elementCount] = null;
		}
		return a;
	}

	public Object get(int index) {
		if (index >= elementCount){
			throw new ArrayIndexOutOfBoundsException(index);
		}
		return elementData[index];
	}

	public Object set(int index, Object element) {
		modCount++;
		if (index >= elementCount){
			throw new ArrayIndexOutOfBoundsException(index);
		}
		Object oldValue = elementData[index];
		elementData[index] = element;
		return oldValue;
	}

	public void add(Object o) {
		addElement(o);
	}

	public boolean remove(Object o) {
		return removeElement(o);
	}
	public void add(int index, Object element) {
		insertElementAt(element, index);
	}

	public Object remove(int index) {
		modCount++;
		if (index >= elementCount){
			throw new ArrayIndexOutOfBoundsException(index);
		}
		Object oldValue = elementData[index];

		int numMoved = elementCount - index - 1;
		if (numMoved > 0)
	  System.arraycopy(elementData, index+1, elementData, index,
					   numMoved);
		elementData[--elementCount] = null; // Let gc do its work

		return oldValue;
	}

	public void clear() {
		removeAllElements();
	}

	protected void removeRange(int fromIndex, int toIndex) {
		modCount++;
		int numMoved = elementCount - toIndex;
		System.arraycopy(elementData, toIndex, elementData, fromIndex,
						 numMoved);

		// Let gc do its work
		int newElementCount = elementCount - (toIndex-fromIndex);
		while (elementCount != newElementCount){
			elementData[--elementCount] = null;
		}
    }
}