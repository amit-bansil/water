package org.cps.util;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public final class CachedVector extends CPSVector {
	private final Class type;
	private int currentMod=-1;
	private Object[] cachedArray;
    public CachedVector(Class type) {
		this.type=type;
	}
	public CachedVector(int initialCapacity,int capacityIncrement,Class type) {
		super(initialCapacity,capacityIncrement);
		this.type=type;
	}
    public Object[] getCachedArray(){
		if(modCount!=currentMod){
			currentMod=modCount;
			cachedArray=createArray(type);
		}
		return cachedArray;
	}
}