package org.cps;

import java.io.*;
import javax.swing.*;

/**
 * Application wide error handler.
 * @author Amit Bansil
 * @version 1.0
 */
public final class CPSErrors {
	private static PrintStream originalSystemErrStream,originalSystemOutStream;
	/**
	 * Whether or not streams have been redericted. The <code>System.err</code>
	 * and <code>System.out</code> streams have been redirected to the files
	 * errors.txt and out.txt, respectivly if this flag is true. It is determined
	 * by the system parameter 'CPS_redirectStreams'
	 */
	public static final boolean redirect;
	static{
		if(CPSConfiguration.getBooleanSystemProperty("redirectStreams",false)){
			redirect=true;

			originalSystemOutStream=System.out; originalSystemErrStream=System.err;
			try{System.setErr(new PrintStream(new FileOutputStream("errors.txt")));
			}catch(Exception e){ internalException("The error stream could not be setup",e); }
			try{System.setOut(new PrintStream(new FileOutputStream("out.txt")));
			}catch(Exception e){ internalException("The ouput stream could not be setup",e); }
		}else redirect=false;
	}
	public static void record(Throwable t){
		t.printStackTrace();
	}
	public static void record(String s){
		System.err.println(s);
	}
	public static void unknownError(Throwable t){
		unknownError(t,new String());
	}
	public static void unknownError(Throwable t,String s){
		System.err.println(s);
		t.printStackTrace();
		throw new UnknownError();
	}
	/**
	 * Flushes and closes the redirected streams.
	 */
	public static void finish(){
		//remove empty files
		if(redirect){
			try{
				PrintStream out=System.out,err=System.err;
				System.setOut(originalSystemOutStream); System.setErr(originalSystemErrStream);
				out.close(); err.close();//avoid closing current output streams
				File outF=new File("out.txt"),errF=new File("errors.txt");
				if(outF.length()==0) outF.delete();
				if(errF.length()==0) errF.delete();
			}catch(Exception e){
				internalException("failed to close empty files",e);
			}
		}
	}

	/**
	 * Signals an internal exception. The user is notified and the application
	 * may terminate.
	 * <code>UnknownError</code> will be used as the exception.
	 * Caused by a bug.
	 */
	public static void internalException(){
		internalException("",new UnknownError());
	}
	/**
	 * Signals an internal exception. The user is notified and the application
	 * may terminate.
	 * @param e An exception associated with the bug.
	 */
	public static void internalException(Throwable e){
		internalException(CPSText.trans("internal exception message"),e);
	}
	/**
	 * Signals an internal exception. The user will be informed of it,
	 * it will be recoreded and if
	 * debugging is turned off the application will exit.
	 * @param description A description of the excption.
	 * @param e The associated exception.
	 */
	public static void internalException(String description,Throwable e){
		System.err.println(description);
		if(e!=null) e.printStackTrace();
		JOptionPane.showMessageDialog(null,description,
		CPSText.trans("internal exception title"), JOptionPane.ERROR_MESSAGE);


		if(!CPS.isDebug()) escape();
	}
	/**
	 * A graceful quick exit.
	 * Errors will be recorded but the user left uninformed.
	 */
	public static void escape(){
		try{
			CPS.finish();
		}catch(Exception e){
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 * Records and notifies the user of an IO exception.
	 * @param description The circumstances that may have caused the exception.
	 * @param e The associated exception.
	 */
	public static void ioException(String description,Throwable e){
		System.err.println(description);
		ioException(e);
	}
	/**
	 * Records a suspicious exception. The user is not notified and the program
	 * does not exit.
	 * @param e The exception.
	 */
	public static void warning(Throwable e){
		e.printStackTrace();
	}
	/**
	 * Recordes a suspicious condition. The user is not notified and the program
	 * does not exit.
	 * @param description A description of the exception.
	 */
	public static void warning(String description){
		System.err.println("Warning:"+description);
	}
	/**
	 * Recordes a suspicious condition. The user is not notified and the program
	 * does not exit.
	 * @param description A description of the exception.
	 * @param e  The exception.
	 */
	public static void warning(String description,Throwable e){
		JOptionPane.showMessageDialog(null,description,CPSText.trans("warning title"), JOptionPane.WARNING_MESSAGE);
		e.printStackTrace();
	}
	/**
	 * Records and notifies the user of an IOException.
	 * @param e The exception.
	 */
	public static void ioException(Throwable e){
		e.printStackTrace();
		JOptionPane.showMessageDialog(null,"An error occured while accessing the disk",
		CPSText.trans("IOError title"), JOptionPane.ERROR_MESSAGE);
	}
	/**
	 * Records and notifies the user of an error in the simulation. The simulation
	 * should reset itself after this.
	 * @param e The exception.
	 */
	public static final int SIMULATION_ERROR_RESET=0;
	public static final int SIMULATION_ERROR_PAUSE=1;
	public static int simulationException(Throwable e){
		e.printStackTrace();
		Object[] options = {
			CPSText.trans("SimError reset"),CPSText.trans("SimError pause")};
		return JOptionPane.showOptionDialog(null, CPSText.trans("SimError message")
			,CPSText.trans("SimError title"),
			JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
			null, options, options[1]);
	}
}