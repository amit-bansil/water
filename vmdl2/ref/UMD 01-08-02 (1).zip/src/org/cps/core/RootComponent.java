package org.cps.core;
import org.cps.util.*;
import java.util.Hashtable;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class RootComponent extends CPSContainer {
    public RootComponent(CPSCore core) {
		super(core);
	}
	private final CPSVector components=new CPSVector();

	private final CachedVector gcListeners=new CachedVector(CachedVector.class);
	private final CachedVector gcClasses=new CachedVector(Class.class);
	public final void addGlobalListener(Class type,CPSContainerListener l){
		CachedVector v;
		int n=gcClasses.indexOf(type);
		if(n!=-1){//optimize
			v=(CachedVector)gcListeners.get(n);
		}else{
			v=new CachedVector(CPSContainerListener.class);
			gcClasses.add(type);
			gcListeners.add(v);
		}
		v.add(l);
	}
	public final void removeGlobalListener(Class type,CPSContainerListener l){
		int n=gcClasses.indexOf(type);
		CachedVector v=(CachedVector)gcListeners.get(n);
		v.remove(l);
		if(v.size()==0){
			gcListeners.remove(n);
			gcClasses.remove(n);
		}
	}
	public final CPSVector globalSearch(Class type){return components.search(type);}
	public final void register(final CPSComponent c){
		getCore().getKernel().threadCheck(true);
		components.add(c);
		Class[] types=(Class[])gcClasses.getCachedArray();
		for(int i=0;i<types.length;i++){
			if(types[i].isInstance(c)){
				CachedVector v=(CachedVector)gcListeners.get(i);
				CPSContainerListener[] cv=(CPSContainerListener[])v.getCachedArray();
				for(int j=0;j<cv.length;j++) cv[j].componentAdded(c);
			}
		}
	}
	public final void unregister(final CPSComponent c){
		getCore().getKernel().threadCheck(true);
		components.remove(c);
		Class[] types=(Class[])gcClasses.getCachedArray();
		for(int i=0;i<types.length;i++){
			if(types[i].isInstance(c)){
				CachedVector v=(CachedVector)gcListeners.get(i);
				CPSContainerListener[] cv=(CPSContainerListener[])v.getCachedArray();
				for(int j=0;j<cv.length;j++) cv[j].componentRemoved(c);
			}
		}
	}
}