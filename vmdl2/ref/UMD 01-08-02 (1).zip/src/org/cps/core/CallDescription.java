package org.cps.core;

import org.cps.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class CallDescription{
	private final String name;
	private final String[] path;
	private final Object[] parameters;
	private final long time;
	public CallDescription(CallDescription c) {
		this(c.name,c.path,c.parameters,c.time);
	}
	public CallDescription(String name,Commandable c) {
		this(name,((CPSComponent)c).getPath(),new Object[0]);
	}
	public CallDescription(String name,String[] path) {
		this(name,path,new Object[0]);
	}
	public CallDescription(String name,Commandable c,Object[] parameters) {
		this(name,((CPSComponent)c).getPath(),parameters);
	}
	public CallDescription(String name,String[] path,Object[] parameters) {
		this(name,path,parameters,System.currentTimeMillis());
	}
	private CallDescription(String name,String[] path,Object[] parameters,long time) {
		this.name=name;
		this.path=(String[])path.clone();
		this.parameters=(Object[])parameters.clone();
		this.time=time;
	}
	public final long getTime(){return time;}
	public final String getName(){return name;}
	public final String[] getPath(){return (String[])path.clone();}
	public final Object[] getParameters(){return (Object[])parameters.clone();}
	public final boolean equals(Object o){
		if(o instanceof CallDescription) return equals((CallDescription)o);
		else return false;
	}
	public final boolean equals(CallDescription x){
		if(!x.name.equals(name))return false;
		if(x.path.length!=path.length) return false;
		if(x.parameters.length!=parameters.length) return false;
		for(int i=0;i<path.length;i++) if(!path[i].equals(x.path[i])) return false;
		for(int i=0;i<parameters.length;i++) if(!parameters[i].equals(x.parameters[i])) return false;
		return true;
	}
	public final String toString(){
		return CPSText.listToString(path,'.')+'.'
			+name+"("+CPSText.listToString(parameters,',')+")"+"@"+time;
	}
	public void called(Throwable e,Object ret){
		if(e!=null) CPSErrors.record(e);
	}
}