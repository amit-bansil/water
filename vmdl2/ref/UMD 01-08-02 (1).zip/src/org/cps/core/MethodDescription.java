package org.cps.core;

import java.lang.reflect.*;

/**
 * Title:        Universal Molecular Dynamics
 * Description:  Universal Interface for Molecular Dynamics Simulations
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.1a
 */

public final class MethodDescription {
	private final String name,description;
	private final String[] parameterDescriptions;
	private final Method method;
	private final Object[] defaults;

	public MethodDescription(Method method,String name,String description,
							 String[] parameterDescriptions,Object[] defaults){
		this.method=method;
		this.name=name;
		this.description=description;
		this.defaults=(Object[])defaults.clone();
		this.parameterDescriptions=(String[])parameterDescriptions.clone();
	}
	public final String getName(){return name;}
	public final String getDescription(){return description;}
	public final String[] getParameterDescriptions(){return (String[])parameterDescriptions.clone();}
	public final Object[] getDefaults(){return (Object[])defaults.clone();}
	public final Method getMethod(){return method;}
}