package org.cps.core;
/**
 * Title:        Universal Molecular Dynamics
 * Description:  Universal Interface for Molecular Dynamics Simulations
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.1a
 */
import org.cps.io.*;
import java.util.*;
import org.cps.util.*;
import java.io.*;
import org.cps.*;
import org.cps.io.util.*;
import java.lang.reflect.*;

public class DataModel extends CPSContainer  implements Commandable,ConfigurationManager.Configurable{
	private final FileDescription desc;
	public DataModel(CPSContainer c,final String name) {
		super(c,name);
		desc=new FileDescription(name,c.getPath(),"txt");
	}
	private final ChangeListener cl=new ChangeListener(){
		public final void targetChanged(){
			getChange().setChanged();
		}
	};
	final void addProperty_int(Property p){
		if(properties.containsKey(p.getName())){
			throw new IllegalArgumentException("property "+p.getName()+" already registered");
		}
		p.getChange().addListener(cl);
		properties.put(p.getName(),p);
	}
	final void removeProperty_int(Property p){
		if(!properties.containsKey(p.getName())){
			throw new IllegalArgumentException("property "+p.getName()+" not registered");
		}
		p.getChange().removeListener(cl);
		properties.remove(p.getName());
	}
	//change support,see property for how to rewritethis,use a bitfield,concatenate multiple events,delayed processing
	private final ChangeSupport change=new ChangeSupport(){
		public final void setChanged(){
			if(isEditing()) return;
			doUpdate();
			super.setChanged();
			reset();
		}
	};
	public final ChangeSupport getChange(){return change;}
	private boolean editing=false;
	protected final boolean isEditing(){return editing;}
	protected final void setEditing(boolean v){editing=v;}
	protected void doUpdate(){}
	protected void reset(){}
	//properties
	private final Hashtable properties=new Hashtable();
	public final boolean containsProperty(String name){
		return getProperty(name)!=null;
	}
	public final Property getProperty(String name){
		return (Property)properties.get(name);
	}

	//convenience methods
	public final void call(String name){
		getCore().getEventQueue().callNowSafe(new CallDescription(name,this));
	}
	public final void call(String name,Object[] parameters){
		getCore().getEventQueue().callNowSafe(new CallDescription(name,this,parameters));
	}
	//io
	public final FileDescription getDescription(){
		return desc;
	}

	public final void save(OutputStream out)throws IOException{//optimize
		PrintWriter pw=new PrintWriter(out);
		final Enumeration p=properties.keys();
		while(p.hasMoreElements()){
			Object k=p.nextElement();
			pw.println(CPSText.outputList(new Object[]{
				k,((Property)properties.get(k)).getObjectValue()}));
		}
		pw.flush();
	}
	public final void load(InputStream in)throws IOException{
		new ScriptReader(){
			public final void read(final String x)throws Throwable{
				final Object[] o=CPSText.inputList(x);
				if(o.length!=2) throw new IllegalArgumentException(
						"requires two parameters,property and value");
				if(!(o[0] instanceof String)) throw new IllegalArgumentException(
						"first parameter must be string specifying parameter");
				final Property p=getProperty((String)o[0]);
				p.setObjectValue(o[1]);
			}
		}.run(in);
	}
}