package org.cps.core;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */


public class IntProperty extends Property{
	protected int v;
	public IntProperty(DataModel parent,String name,int v){
		super(parent,name);
		this.v=v;
	}

	public void setIntValue(int f){if(v==f)return; v=f; setChanged();}
	public final int getIntValue(){return v;}

	public final Class getType(){return Integer.class;}//not Float.TYPE or float.class
	public final Object getObjectValue(){return new Integer(v);}
	public final void setObjectValue(Object o){
		setIntValue(
				((Integer)ObjectProperty.convert(o,Integer.class)).intValue()
				);
	}
	public static class Bound extends IntProperty{
		private final int max,min;
		public final int getMax(){return max;}
		public final int getMin(){return min;}
		public Bound(DataModel parent,String name,int v,int max,int min){
			super(parent,name,v);
			this.max=max;
			this.min=min;
		}
		public final void setIntValue(int f){
			if(v==f)return;
			if(f>max) throw new IllegalArgumentException("value to big, "+f+" > "+max);
			if(f<min) throw new IllegalArgumentException("value to small, "+f+" < "+min);
			super.setIntValue(f);
		}
	}
}