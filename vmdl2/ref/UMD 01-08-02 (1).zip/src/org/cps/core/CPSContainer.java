package org.cps.core;
/**
 * Title:        Universal Molecular Dynamics
 * Description:  Universal Interface for Molecular Dynamics Simulations
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.1a
 */
import org.cps.*;
import org.cps.util.*;
public abstract class CPSContainer extends CPSComponent{
	private final CachedVector children=new CachedVector(CPSComponent.class);

	protected CPSContainer(CPSCore c){
		super(c);
	}
	protected CPSContainer(CPSContainer parent){
		super(parent);
	}
	protected CPSContainer(CPSContainer parent,String name){
		super(parent,name);
	}

	public final CPSComponent createChild(String s)throws Exception{
		return createChild(Class.forName(s,true,getCore().getIO().getClassLoader()));
	}
	public final CPSComponent createChild(Class c)throws Exception{
		return (CPSComponent)c.getConstructor(STANDARD_CONSTRUCTOR).newInstance(new Object[]{this});
	}

	//internal called by CPSComponent's contructor
	public void add(CPSComponent c){
		children.add(c);
		if(listeners!=null)
			for(int i=0;i<listeners.size();i++)
				noteComponentAdded(
					((CPSContainerListener)listeners.elementAt(i)),c);
	}

	//internal called by CPSComponent
	public void remove(CPSComponent c){
		children.remove(c);
		if(listeners!=null)
			for(int i=0;i<listeners.size();i++)
				noteComponentRemoved(
					((CPSContainerListener)listeners.elementAt(i)),c,this);
	}
	protected final void noteComponentAdded(CPSContainerListener lis,CPSComponent comp){
		lis.componentAdded(comp);
	}
	protected final void noteComponentRemoved(CPSContainerListener lis,CPSComponent comp,CPSContainer par){
		lis.componentRemoved(comp);
	}
	protected final void finishDependancies(){
		super.finishDependancies();
		CPSComponent[] c=(CPSComponent[])children.getCachedArray();
		for(int i=0;i<c.length;i++) c[i].finish();
	}
	public final CPSComponent[] getChildren(){
		return  (CPSComponent[])children.getCachedArray();
	}
	public final Object[] getChildren(Class type){
		return children.createArray(type);
	}
	public final CPSVector search(Class type){
		return children.search(type);
	}
	public final int getIndex(CPSComponent c){
		return children.indexOf(c);
	}
	public final CPSComponent get(int index){
		return (CPSComponent)children.get(index);
	}

	private CPSVector listeners;
	public final void addContainerListener(final CPSContainerListener l){
		if(listeners==null) listeners=new CPSVector();
		listeners.add(l);
	}
	public final void removeContainerListener(final CPSContainerListener l){
		listeners.remove(l);
		if(listeners.isEmpty()) listeners=null;
	}

}