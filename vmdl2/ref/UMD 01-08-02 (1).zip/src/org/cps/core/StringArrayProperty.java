package org.cps.core;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class StringArrayProperty extends Property {
	private String[] a;
    public StringArrayProperty(DataModel parent,String name,String[] initial) {
		super(parent,name);
		a=(String[])initial.clone();
	}
    public void setObjectValue(Object o) {
        setStringArrayValue((String[])ObjectProperty.convert(o,String[].class));
    }
	public void setStringArrayValue(String[] o){
		if(a.equals(o)) return;
		if(a.length==o.length) System.arraycopy(o,0,a,0,a.length);
		else a=(String[])o.clone();
		setChanged();
	}
	public String[] getStringArrayValue(){
		return (String[])a.clone();
	}
    public Class getType() {return String[].class; }
    public Object getObjectValue() {return getStringArrayValue();}
	public final void bindContains(final StringProperty p){//will leak if used across datamodels
		p.getChange().addListener(new ChangeListener(){
			public final void targetChanged(){
				final String s=p.getStringValue();
				for(int i=0;i<a.length;i++) if(a[i].equals(s))return;
				throw new IllegalArgumentException("unexpected value");
			}
		});

	}
}