package org.cps.core;
import org.cps.util.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */
import org.cps.*;
public final class Kernel {
	//state
	private int state;
	public static final int INITIALIZING=0,RUNNING=1,SHUTTING_DOWN=2,SHUTDOWN=3;
	public final int getState(){return state;}
	public final boolean isRunning(){return state==RUNNING;}
	public final boolean isShuttingDown(){return state==SHUTTING_DOWN;}
	public final boolean isInitializing(){return state==INITIALIZING;}
	public final boolean isShutDown(){return state==SHUTDOWN;}
	//kernelrate
	private int kernelRate;
	public static final float DEFAULT_FPS_LIMIT=16.0f;
	public final float getFPSLimit(){
		return (1f/((float)kernelRate))*1000f;
	}
	public final void setFPSLimit(float fps){
		kernelRate=(int)(1000f/fps);
	}
	//priority
	public static final int DEFAULT_PRIORITY=Thread.NORM_PRIORITY;
	public final void setPriority(int p){
		thread.setPriority(p);
	}
	public final int getPriority(){
		return thread.getPriority();
	}
	//constructor
	private final CPSCore core;
	public Kernel(CPSCore core){ this(core,DEFAULT_FPS_LIMIT,DEFAULT_PRIORITY); }
	public Kernel(CPSCore core,float rate,int priority){
		this.core=core;
		state=INITIALIZING;
		setFPSLimit(rate);
		setPriority(priority);
	}

	//prevents deadlocks
	public final void threadCheck(){
		threadCheck(false);
	}
	public final boolean isEventThread(){return Thread.currentThread().equals(thread);}
	public final void threadCheck(boolean isKernel){
		if(!CPS.isDebug()) return;
		if(isKernel){
			if(isInitializing()) return;
			if(!Thread.currentThread().equals(thread)){
				throw new IllegalThreadStateException("must be called from internal thread");
			}
		}else{
			if(Thread.currentThread().equals(thread)){
				throw new IllegalThreadStateException("CPSThread cannot wait upon itself");
			}
		}
	}
	//state control
	public void start(){
		if(!isInitializing()) throw new IllegalStateException("CPSThread already started");
		thread.start();
	}

	private boolean finishRunning=false;
	public final void finish(){
		if(!isRunning()&&!isInitializing()) throw new IllegalStateException("CPSThread already shuttingdown|shutdown");
		finishRunning=true;
	}
	//continuous update
	private final CachedVector cUpdates=new CachedVector(30,10,Runnable.class);
	public void startRunning(Runnable c){
		cUpdates.add(c);
	}
	public void stopRunning(Runnable c){
		cUpdates.remove(c);
	}
	//pending
	private final CPSVector pending=new CPSVector(30,10);

	public final void runLater(Runnable r){
		pending.add(r);
	}
	private static final class SimpleNowRunnable implements Runnable{
		public final Runnable r;
		public SimpleNowRunnable(Runnable r){
			this.r=r;
		}
		public void run(){
			r.run();
			wait=false;
			synchronized(monitor){
				monitor.notify();
			}
		}
		public boolean wait=true;
		public Object monitor=new Object();
	}
	public final void runNow(Runnable r){
		threadCheck(false);
		core.getUI().startWaiting();
		SimpleNowRunnable n=new SimpleNowRunnable(r);
		pending.add(n);
		while(n.wait){
			try{
				synchronized(n.monitor){
					n.monitor.wait();
				}
			}catch(Exception e){
				CPSErrors.record(e);
			}
		}
		core.getUI().stopWaiting();
	}
	private static final class NowRunnable implements Runnable{
		public final CPSRunnable r;
		public NowRunnable(CPSRunnable r){
			this.r=r;
		}
		public void run(){
			try{
				ret=r.run();
			}catch(Exception e){
				ex=e;
			}
			wait=false;
			synchronized(monitor){
				monitor.notify();
			}
		}
		public Object ret;
		public Exception ex=null;
		public boolean wait=true;
		public Object monitor=new Object();
	}
	public final Object runNow(CPSRunnable r)throws Exception{
		if(isEventThread()){ return r.run();}
		core.getUI().startWaiting();
		NowRunnable n=new NowRunnable(r);
		pending.add(n);
		while(n.wait){
			try{
				synchronized(n.monitor){
					n.monitor.wait();
				}
			}catch(Exception e){
				CPSErrors.record(e);
			}
		}
		core.getUI().stopWaiting();
		if(n.ex!=null) throw n.ex;
		return n.ret;
	}
	//shutdown
	private final CPSVector shutdown=new CPSVector();
	public final void addShutdownHook(Runnable r){
		shutdown.add(r);
	}
	//thread
	private long time,extra;
	private final Thread thread=new Thread(){
		public void run(){
			try{
			state=RUNNING;
			thread.setPriority(Thread.NORM_PRIORITY+1);
			Runnable[] continuousArray;
			int gcmod=0;
			while(!finishRunning){

				time=System.currentTimeMillis();

				//gcmod++;
				//if(gcmod>100){ gcmod=0; System.gc(); }

				synchronized(cUpdates){
					continuousArray=(Runnable[])cUpdates.getCachedArray();

				}
				for (int i = continuousArray.length-1; i >= 0; i--) {
					try{
						continuousArray[i].run();//for not just do this backward later prioritize
					}catch(Exception e){
						CPSErrors.internalException(e);
					}
				}
				Runnable[] pendingArray=null;
				synchronized(pending){
					pendingArray=(Runnable[])pending.createArray(Runnable.class);
					pending.clear();
				}
				for (int i = 0; i < pendingArray.length; i++) {
					try{
						pendingArray[i].run();
					}catch(Exception e){
						CPSErrors.internalException(e);
					}
				}

				try{
					extra=kernelRate-(System.currentTimeMillis()-time);
					if(extra>minSleep){
						//extra=kernelRate-(System.currentTimeMillis()-time);
						thread.sleep(extra);
					}else thread.sleep(minSleep);
				}catch(InterruptedException e){
					CPSErrors.record(e);
				}
			}
			}catch(Throwable t){
				CPSErrors.internalException(t);
			}
			pending.clear();

			state=SHUTTING_DOWN;
			Runnable[] shutdownArray=(Runnable[])shutdown.createArray(Runnable.class);
			for (int i = shutdownArray.length-1; i <= 0; i--) {
				shutdownArray[i].run();
			}
			state=SHUTDOWN;
			cUpdates.clear();
			shutdown.clear();
		}
	};
	private static final long minSleep=3;
	public final boolean hasTimeRemaining(){
		long f= kernelRate-(System.currentTimeMillis()-time);
		return f>0;
	}


}