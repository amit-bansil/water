package org.cps.core;
/**
 * Title:        Universal Molecular Dynamics
 * Description:  Universal Interface for Molecular Dynamics Simulations
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.1a
 */
import org.cps.*;
import org.cps.util.*;
import java.util.*;
import org.cps.io.*;
import org.cps.io.util.*;
import org.cps.umd.io.*;
import org.cps.ui.*;

public class CPSCore{
	//io
	private final IOManager io;
	public final IOManager getIO(){ return io; }
	//gui
	private final ComponentHandle ui;
	public final boolean isUIInitialized(){return ui.get()!=null;}
	public final CPSUI getUI(){
		if(!isUIInitialized()) throw new IllegalStateException("The user interface is not you initialized");
		return (CPSUI)ui.get();
	}
	//eventqueue
	private final EventQueue events;
	public final EventQueue getEventQueue(){
		return events;
	}
	//cps thread
	private final Kernel kernel;
	public final Kernel getKernel(){
		return kernel;
	}
	//root
	private final RootComponent root;
	public final RootComponent getRootComponent(){
		return root;
	}
	//core
	public CPSCore(){

		kernel=new Kernel(this);
		kernel.addShutdownHook(shutdownHook);

		root=new RootComponent(this);

		events=new EventQueue(this);

		io=new IOManager(this);

		ui=new ComponentHandle(root,CPSUI.class);
	}
	private final Runnable shutdownHook=new Runnable(){
		public void run(){
			shutdown();
		}
	};
	private final void shutdown(){
		io.finish();
		root.finish();
		CPS.finish();
		System.exit(0);
	}
}