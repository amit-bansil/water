package org.cps.core;

import java.lang.reflect.*;
import org.cps.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

//?? is (new byte[]{2,1,3,1}).eqauls(new byte[]{2,1,3,1}) ?? if not setValue must be fixed ;
//perhaps step through arrays rather than just using equals
public final class ObjectProperty extends Property{

	private static final Class[] EMPTY_CONSTRUCTOR=new Class[0];
	private static final Object[] EMPTY_PARAMETER=new Object[0];

	public ObjectProperty(DataModel parent,String name,Object initialValue) {
		this(parent,name,initialValue.getClass(),initialValue);
	}
	public ObjectProperty(DataModel parent,String name,Class type,Object initialValue) {
		super(parent,name);
		this.type=type;
		try {
			clone=type.getMethod("clone",EMPTY_CONSTRUCTOR);
		}catch (NoSuchMethodException ex) {
			CPSErrors.record(ex);
			throw new UnknownError("type does not contain clone?!");
		}
		setObjectValue(initialValue);
	}

	private Object value;
	private final Class type;
	private final Method clone;
	public Class getType(){return type;}
	public final Object getObjectValue(){
		try {
			return clone.invoke(value,EMPTY_PARAMETER);
		}
		catch (IllegalAccessException ex) {
			CPSErrors.record(ex);
			throw new UnknownError("clone not public");
		}catch (InvocationTargetException ex) {
			CPSErrors.record(ex);
			throw new UnknownError("clone failed");
		}
	}
	public final void setObjectValue(Object v){
		if(value.equals(v)) return;
		try {
			value=clone.invoke(convert(v,type),EMPTY_PARAMETER);
		}
		catch (IllegalAccessException ex) {
			CPSErrors.record(ex);
			throw new UnknownError("clone not public");
		}catch (InvocationTargetException ex) {
			CPSErrors.record(ex);
			throw new UnknownError("clone failed");
		}
	}

	private static final Class[] PARSE_CONSTRUCTOR=new Class[]{String.class};
	private static final Object parseArray(Object array,Class arrayType){//optimize
		if(array==null) return null;
		else if(!array.getClass().isArray()){
			Object ret=Array.newInstance(arrayType,1);
			Array.set(ret,0,array);
			return ret;
		}else{
			final int l=Array.getLength(array);
			final Object ret=Array.newInstance(arrayType,l);
			for(int i=0;i<l;i++){
				final Object o=Array.get(array,i);
				if(o==null){
					continue;//??let it be
				}else{
					Array.set(ret,i,convert(o,arrayType));
				}
			}
			return ret;
		}
	}
	private static final char[] PRIMITIVES=new char[]{'F','I','B','Z','C','D','J','S','V'};
	private static final Class[] WRAPPERS=new Class[]{
		Float.class,Integer.class,Boolean.class,Byte.class,Character.class,Double.class,
		Long.class,Short.class,Void.class};
	//the best way to fix this would be to create a
	//hashtable of fast parsers,step through the newType's supperclasses till
	//you find a match
	public static final Object convert(Object p,Class newType){//OPTIMIZE!!
		if(newType.isPrimitive()){//perhaps we could just make a hastable and in thisway remap even non primitve classes
			char n=newType.getName().toUpperCase().charAt(0);
			for(int i=0;i<PRIMITIVES.length;i++){
				if(PRIMITIVES[i]==n){
					newType=WRAPPERS[i];
					break;
				}
			}
		}
		if(newType.isAssignableFrom(p.getClass())){
			return p;
		}else if(String.class.equals(newType)){//string is final
			return p.toString();
		}else if(newType.isArray()){
			return parseArray(p,newType.getComponentType());
		}else{
			try {
				Constructor c=newType.getConstructor(PARSE_CONSTRUCTOR);
				try {
					return c.newInstance(new Object[]{p.toString()});//optimize
				}catch (Exception e) {
					throw new IllegalArgumentException("could not convert parameter "+p+" to "+newType);
				}
			}
			catch(NoSuchMethodException ex) {
				throw new InternalError("type "+newType+" not parseable");
			}
		}
	}
}