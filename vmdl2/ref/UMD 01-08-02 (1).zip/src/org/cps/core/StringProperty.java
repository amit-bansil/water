package org.cps.core;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class StringProperty extends Property {
	private String value;
    public StringProperty(DataModel parent,String name,String initial) {
		super(parent,name);
		value=initial;
    }
    public void setObjectValue(Object o) {
		if(value.equals(o)) return;
        value=o.toString();
		setChanged();
    }
    public Class getType() {return String.class; }
    public Object getObjectValue() {
       return value;
    }
	public String getStringValue(){return value;}
	public void setStringValue(String v){setObjectValue(v);}
}