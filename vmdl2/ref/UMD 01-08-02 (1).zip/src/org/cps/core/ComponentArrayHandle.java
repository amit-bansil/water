package org.cps.core;
import org.cps.util.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class ComponentArrayHandle implements CPSContainerListener {
	private final CPSContainer target;
	private final CachedVector ret;
	private final Class type;
	public final Object[] get(){return ret.getCachedArray();}
	public ComponentArrayHandle(CPSContainer target,Class type) {
		this.target=target;
		this.type=type;
		ret=new CachedVector(type);
		ret.addArray(target.search(type).toArray());
		target.addContainerListener(this);
	}
	public final void componentAdded(CPSComponent c){
		if(type.isInstance(c)){
			ret.add(c);
		}
	}
	public final void componentRemoved(CPSComponent c){
		if(type.isInstance(c)){
			ret.remove(c);
		}
	}
}