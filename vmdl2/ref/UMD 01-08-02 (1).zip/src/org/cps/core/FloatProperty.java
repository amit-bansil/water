package org.cps.core;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class FloatProperty extends Property{
	protected float v;
	public FloatProperty(DataModel parent,String name,float v){
		super(parent,name);
		this.v=v;
	}

	public void setFloatValue(float f){if(v==f)return; v=f; setChanged();}
	public final float getFloatValue(){return v;}

	public final Class getType(){return Float.class;}//not Float.TYPE or float.class
	public final Object getObjectValue(){return new Float(v);}
	public final void setObjectValue(Object o){
		setFloatValue(
				((Float)ObjectProperty.convert(o,Float.class)).floatValue()
				);
	}
	public static final class Bound extends FloatProperty{
		private final float max,min;
		public final float getMax(){return max;}
		public final float getMin(){return min;}
		public Bound(DataModel parent,String name,float v,float max,float min){
			super(parent,name,v);
			this.max=max;
			this.min=min;
		}
		public final void setFloatValue(float f){
			if(v==f)return;
			if(f>max) throw new IllegalArgumentException("value to big, "+f+" > "+max);
			if(f<min) throw new IllegalArgumentException("value to small, "+f+" < "+min);
			super.setFloatValue(f);
		}
	}
}