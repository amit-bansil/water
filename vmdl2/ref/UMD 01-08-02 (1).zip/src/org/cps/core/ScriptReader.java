package org.cps.core;

import java.io.*;
import org.cps.util.*;
import org.cps.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public abstract class ScriptReader {

	public ScriptReader(){}
	public final void run(InputStream in)throws IOException{
		LineNumberReader reader=null;
		try{
			reader=new LineNumberReader(new BufferedReader(new InputStreamReader(in)));
			String x=reader.readLine();

			CPSVector errors=new CPSVector(),errorDescs=new CPSVector();
			while(x!=null){
				try{
					read(x);
					x=null;
					x=reader.readLine();
				}catch(Throwable e){
					errors.add(e);
					errorDescs.add("error@line #"+reader.getLineNumber()+" "+x);
					x=reader.readLine();
				}
			}
			reader.close();
			reader=null;
			in=null;
			if(errors.size()!=0){
				CPSErrors.warning("This script contains errors");
				CPSErrors.record("The following errors were found in this script:");
				Object[] errorsA=errors.createArray();
				Object[] errorDA=errorDescs.createArray();
				for(int i=0;i<errorsA.length;i++){
					CPSErrors.record((String)errorDA[i]);
					CPSErrors.record((Throwable)errorsA[i]);
				}
			}
		}finally{
			if(reader!=null) reader.close();
			else if(in!=null) in.close();
		}
	}
	protected abstract void read(String s)throws Throwable;
}