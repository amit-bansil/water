package org.cps.core;

import java.lang.reflect.*;
import org.cps.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public abstract class Property extends CPSComponent implements Commandable{
	public abstract Class getType();
	public abstract Object getObjectValue();
	public abstract void setObjectValue(Object o);
	//later move change support to enclosing datamodel and allow differed event processing
	private final ChangeSupport change=new ChangeSupport();
	public final ChangeSupport getChange(){return change;}

	public Property(DataModel parent,String name){
		super(parent,name);
		parent.addProperty_int(this);
	}
	public final void finish(){
		((DataModel)getParent()).removeProperty_int(this);
		super.finish();
	}
	protected final void setChanged(){
		change.setChanged();
	}

	private boolean readOnly=false;
	public final void set(Object o){
		if(!getCore().getKernel().isEventThread()){
			getCore().getEventQueue().callNowSafe(new CallDescription(SET,this,new Object[]{o}));
		}else{
			if(readOnly){
				throw new IllegalArgumentException("property "+getName()+" is readonly");
			}
			setObjectValue(o);
		}
	}
	public final Object get(){//should this be synced or performed on the event queue??
		return getObjectValue();
	}

	public static final String SET="set",GET="get";
	static{
		MethodRegistry.registerMethod(Property.class,SET,"sets a property's value",
							  "the property's new value",null,Object.class);
		MethodRegistry.registerMethod(Property.class,GET,"gets a property's value");
	}
	public static void classFinalize() throws Throwable {
		MethodRegistry.unregisterMethod(SET);
		MethodRegistry.unregisterMethod(GET);
	}
	public final void setReadOnly(boolean v){readOnly=v;}
	public final boolean isReadOnly(){return readOnly;}
}
