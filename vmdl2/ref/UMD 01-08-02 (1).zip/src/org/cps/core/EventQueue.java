package org.cps.core;
import org.cps.util.*;
import java.util.*;
import org.cps.*;
import java.lang.reflect.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public final class EventQueue {//to do implement repeated call caching,loging
	//command registry

	private final Hashtable paths=new Hashtable(100,.25f);//optimize
	private static final char PATH_SEP=':';
	public boolean containsPath(String[] path){
		return paths.containsKey(CPSText.listToString(path,PATH_SEP));
	}
	public final Commandable getCommandable(String[] path){
		return (Commandable)paths.get(CPSText.listToString(path,PATH_SEP));
	}
	//
	private final Runnable runner=new Runnable(){
		public final void run(){
			step();
		}
	};
	final CPSCore core;
	public EventQueue(CPSCore core) {
		this.core=core;
		core.getKernel().startRunning(runner);
		core.getRootComponent().addGlobalListener(Commandable.class,new CPSContainerListener(){
			public final void componentAdded(CPSComponent c){
				final String[] path=(c.getPath());
				for(int i=0;i<path.length;i++) if(path[i].indexOf(PATH_SEP)!=-1){
					throw new IllegalArgumentException("illegal path:"+path[i]+
					", paths cannot contain '"+PATH_SEP+"' characters");
				}
				String s=CPSText.listToString(path,PATH_SEP);
				if(paths.contains(s))throw new IllegalArgumentException("path "+s+" already registered");
				paths.put(s,c);
			}
			public final void componentRemoved(CPSComponent c){
				String s=CPSText.listToString(c.getPath(),PATH_SEP);
				if(!paths.containsKey(s)) throw new IllegalArgumentException("path "+s+" not registered");
				paths.remove(s);
			}
		});
	}
	public static final Object[] convertParameters(final Class[] pc,final Object[] mp,Object[] def){
		Object[] p=new Object[pc.length];
		if(mp.length>p.length){
			new IllegalArgumentException("too many parameters("+mp.length+">"+p.length+")");
		}
		for(int i=0;i<mp.length;i++){
			if(mp[i]==null){
				p[i]=def[i];
			}else{
				p[i]=ObjectProperty.convert(mp[i],pc[i]);//optimize
			}
		}
		if(mp.length<p.length){
			for(int n=mp.length;n<p.length;n++){
				p[n]=def[n];
			}
		}
		return p;
	}
	private final void runCall(CallDescription x){//optimize
		Object ret=null;
		Throwable e=null;
		final Object target=getCommandable(x.getPath());
		try{
			if(target==null){
				throw new IllegalArgumentException(
						"target "+CPSText.listToString(x.getPath(),'.')+" not registered");
			}
			final MethodDescription md=MethodRegistry.getMethod(x.getName());
			if(md==null) throw new IllegalArgumentException("method "+x.getName()+" not found");
			final Method m=md.getMethod();

			final Object[] p=convertParameters(m.getParameterTypes(),x.getParameters(),md.getDefaults());

			if(!m.getDeclaringClass().isAssignableFrom(target.getClass())){
				throw new IllegalArgumentException("method "+x.getName()+
						" not callable against "+CPSText.listToString(x.getPath(),'.'));
			}

			try {
				ret=m.invoke(target,p);
			}
			catch (IllegalAccessException ex) {
				throw new InternalError("method not callable,not accessible:"+ex.toString());
			}catch (IllegalArgumentException ex) {
				throw new UnknownError("parameters incorrectly parsed,not accessible:"+ex.toString());
			}catch (InvocationTargetException ex) {
				CPSErrors.record(ex);
				throw ex.getTargetException();
			}
		}catch(Throwable ex){
			e=ex;
		}finally{
			x.called(e,ret);
		}
	}
	//call
	private final CPSVector calls=new CPSVector(30,10);
	private final CPSVector callDescs=new CPSVector(30,10);
	public final void call(final CallDescription x){
		if(!core.getKernel().isEventThread()){
			synchronized(calls){
				calls.add(x);
			}
		}else{
			runCall(x);
		}
	}
	//step
	private final void step(){
		core.getKernel().threadCheck(true);

		final CallDescription[] callsArray;
		synchronized(calls){
			if(calls.isEmpty()) return;
			callsArray=
					(CallDescription[])calls.createArray(CallDescription.class);
			calls.clear();
		}
		for (int i = 0; i < callsArray.length; i++) {
			try{
				runCall(callsArray[i]);
			}catch(Exception e){
				CPSErrors.internalException("An error occured while processing the command "+callsArray[i],e);
			}
		}
	}
	//call extended
	private static final class NowCallDescription extends CallDescription{
		private final CallDescription c;
		public NowCallDescription(CallDescription c){
			super(c);
			this.c=c;
		}
		public void called(Throwable e,Object ret){
			c.called(e,ret);
			ex=e;
			this.ret=ret;

			wait=false;
			synchronized(monitor){
				monitor.notify();
			}
		}
		public Throwable ex=null;
		public Object ret=null;
		public boolean wait=true;
		public Object monitor=new Object();
	}
	public final Object callNowSafe(CallDescription c){
		try{
			return callNow(c);
		}catch(Throwable e){
			CPSErrors.unknownError(e);
			throw new UnknownError("unreachable code");
		}
	}
	public final Object callNow(CallDescription c)throws Throwable{
		core.getUI().startWaiting();
		final NowCallDescription n=new NowCallDescription(c);
		call( n);
		while(n.wait){
			try{
				synchronized(n.monitor){
					n.monitor.wait();
				}
			}catch(Exception e){
				CPSErrors.record(e);
			}
		}
		core.getUI().stopWaiting();
		if(n.ex!=null) throw n.ex;
		return n.ret;
	}
}