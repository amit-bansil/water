package org.cps.core;

/**
 * Title:        Universal Molecular Dynamics
 * Description:  Universal Interface for Molecular Dynamics Simulations
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.1a
 */

public interface CPSContainerListener {
	public void componentAdded(CPSComponent target);
	public void componentRemoved(CPSComponent target);
}