package org.cps.core;
import org.cps.util.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class ComponentHandle implements CPSContainerListener {
	private final CPSContainer target;
	private CPSComponent ret=null;
	private final Class type;
	public final CPSComponent get(){return ret;}
    public ComponentHandle(CPSContainer target,Class type) {
		this.target=target;
		this.type=type;
		CPSVector results=target.search(type);
		if(results.size()>1) throw new IllegalStateException("a handle allows only one instance of type");
		else if(results.size()!=0) ret=(CPSComponent)results.firstElement();
		target.addContainerListener(this);
    }
	public final void componentAdded(CPSComponent c){
		if(type.isInstance(c)){
			if(ret!=null) throw new IllegalStateException("a handle allows only one instance of type");
			ret=c;
		}
	}
	public final void componentRemoved(CPSComponent c){
		if(type.isInstance(c)){
			if(ret==null){
				throw new InternalError("unadded component cannot be removed");
			}
			ret=null;
		}
	}
}