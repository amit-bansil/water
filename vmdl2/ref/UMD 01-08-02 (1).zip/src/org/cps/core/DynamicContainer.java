package org.cps.core;

import java.util.*;
import java.lang.reflect.*;
import org.cps.*;
import org.cps.io.*;
import java.io.*;
import org.cps.util.*;
import org.cps.io.ConfigurationManager;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public abstract class DynamicContainer extends CPSContainer implements ConfigurationManager.Configurable,Commandable{
	static{
		MethodRegistry.registerMethod(DynamicContainer.class,"add","add a child",
		   new String[]{"type","name","parameters"},
		   new Object[]{new String(),new String(),new Object[0]},
		   new Class[]{String.class,String.class,Object[].class});
		MethodRegistry.registerMethod(DynamicContainer.class,"remove","remove a child",
									  "child's name",new String(),String.class);

	}
	public static void classFinalize() throws Throwable {
		MethodRegistry.unregisterMethod("add");
		MethodRegistry.unregisterMethod("remove");
	}

	public FileDescription getDescription(){
		return desc;
	}
	private final FileDescription desc;
	public void load(InputStream in)throws IOException{
		removeAll();
		new ScriptReader(){
			public final void read(String x)throws Throwable{
				final Object[] o=CPSText.inputList(x);
				if(o.length<2)throw new IllegalArgumentException("expected type&name");
				if(o.length>3)throw new IllegalArgumentException("too many parameters");
				if(!(o[0] instanceof String))throw new IllegalArgumentException("expected string type first");
				if(!(o[1] instanceof String))throw new IllegalArgumentException("expected string name second");
				final Object[] p;
				if(o.length==2) p=new Object[0];
				else if(o[2] instanceof Object[]) p=(Object[])o[2];
				else p=new Object[]{o[2]};
				add((String)o[0],(String)o[1],p);
			}
		}.run(in);
	}
	public final void save(OutputStream out)throws IOException{
		final Object[][] o=(Object[][])log.createArray(Object[].class);
		final PrintWriter pw=new PrintWriter(out);
		for(int i=0;i<o.length;i++) pw.println(CPSText.outputList(o[i]));
		pw.flush();
	}
	public DynamicContainer(String name,CPSContainer parent) {
		super(parent,name);
		desc=new FileDescription(name,getParent().getPath(),"txt");
	}
	public final void registerType(String name,Constructor type,Object[] defs){
		if(childrenTypes.containsKey(name))throw new IllegalArgumentException(
				"name "+name+" already registered");
		childrenTypes.put(name,type);
		defaults.put(name,defs);
	}
	public final void registerType(Class c,Object[] d){
		Constructor x=c.getConstructors()[0];
		registerType(x.getName().substring(x.getName().lastIndexOf('.')+1),x,d);
	}
	public final void unregisterType(String name){
		if(!childrenTypes.containsKey(name))throw new IllegalArgumentException(
				"name "+name+" !registered");
		childrenTypes.remove(name);
		defaults.remove(name);
	}

	public abstract void objectAdded(CPSComponent c);
	public abstract void objectRemoved(CPSComponent c);

	private final Hashtable children=new Hashtable(),defaults=new Hashtable();
	private final Hashtable childrenTypes=new Hashtable();
	private final CPSVector log=new CPSVector();private final Hashtable logNames=new Hashtable();
	public final void add(String type,String name,Object[] paa)throws Throwable{
		if(name.length()==0)throw new IllegalArgumentException("must specify name");
		if(!childrenTypes.containsKey(type))throw new IllegalArgumentException("unknown type "+type);
		Object[] parameters=new Object[paa.length+2];
		parameters[0]=this;parameters[1]=name;
		System.arraycopy(paa,0,parameters,2,paa.length);
		final Constructor c=(Constructor)childrenTypes.get(type);
		Object[] da=(Object[])defaults.get(type);
		Object[] d=new Object[da.length+2];
		System.arraycopy(da,0,d,2,da.length);
		final Object[] p=EventQueue.convertParameters(c.getParameterTypes(),
				parameters,d);
		try {
			final CPSComponent o=(CPSComponent)c.newInstance(p);
			children.put(name,o);
			final Object l=new Object[]{type,name,paa.clone()};
			log.add(l);
			logNames.put(name,l);
			objectAdded(o);
		}
		catch (InvocationTargetException ex) {
			CPSErrors.record(ex);
			throw ex.getTargetException();
		}catch (IllegalAccessException ex) {
			CPSErrors.record(ex);
			throw new UnknownError("Can't access contructor for type "+type);
		}catch (InstantiationException ex) {
			CPSErrors.record(ex);
			throw new UnknownError("Can't invoke contructor for type "+type);
		}
	}
	public final void removeAll(){
		Enumeration names=children.keys();
		while(names.hasMoreElements()) remove((String)names.nextElement());
	}
	public final void remove(String name){
		if(name.length()==0)throw new IllegalArgumentException("must specify name");
		if(!children.containsKey(name)) throw new IllegalArgumentException("component "+name+" not found");
		CPSComponent c=(CPSComponent)children.get(name);
		objectRemoved(c);
		log.remove(logNames.get(name));
		logNames.remove(name);
		c.finish();
	}
}