package org.cps.core;

import java.util.*;
import org.cps.*;
import java.lang.reflect.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public abstract class MethodRegistry {
	//registry-intheory we can register/unregister methods statically however this may leak since
	//those classes will then never be unloaded and hence never unregistered-see JLangSpec 12.8
	//solution-explictly unregister methods to allow class finalization,or use weakrefrences,however
	//this won't work in 1.1

	private static final Hashtable methods=new Hashtable(100,.25f);//optimize

	public static final void registerMethod(MethodDescription method){
		if(methods.containsKey(method.getName())) throw new IllegalArgumentException("method already registered");
		methods.put(method.getName(),method);
	}
	public static final void unregisterMethod(MethodDescription method){
		unregisterMethod(method.getName());
	}
	public static final void unregisterMethod(String name){
		if(!methods.containsKey(name)) throw new IllegalArgumentException("method not registered");
		methods.remove(name);
	}
	public static boolean containsMethod(String name){
		return methods.containsKey(name);
	}
	public static MethodDescription getMethod(String name){
		return (MethodDescription)methods.get(name);
	}
	public static final void registerMethod(Class type,String name,String description){
		registerMethod(type,name,description,new String[0],new Object[0],new Class[0]);
	}
	public static final void registerMethod(Class type,String name,String description,Class parameter){
		registerMethod(type,name,description,null,null,parameter);
	}
	public static final void registerMethod(Class type,String name,String description,
										String parameterDescription,Object def,
										Class parameter){
		registerMethod(type,name,description,new String[]{parameterDescription},
					   new Object[]{def},new Class[]{parameter});
	}
	public static final void registerMethod(Class type,String name,String description,
										String[] parameterDescriptions,Object[] defaults,Class[] parameters){
		try {
			Method m=type.getMethod(name,parameters);
			registerMethod(new MethodDescription(
					m,name,description,parameterDescriptions,defaults));
		}
		catch (NoSuchMethodException ex) {
			throw new IllegalArgumentException(name+" not found");
		}

	}
}