package org.cps.core;

/**
 * Title:        Universal Molecular Dynamics
 * Description:  Universal Interface for Molecular Dynamics Simulations
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.1a
 */

import org.cps.*;
import org.cps.util.*;
public abstract class CPSComponent{
	public static final Class[] STANDARD_CONSTRUCTOR=new Class[]{CPSContainer.class};

	private final CPSContainer parent;
	private final CPSCore core;
	private CPSVector dependants=null;
	private CPSVector dependOns=null;
	protected CPSComponent(CPSContainer parent) {
		this(parent,null);
	}
	private final String name;
	public final String getName(){
		if(!isNamed()) throw new IllegalStateException("this component is not named");
		return name;
	}
	public final boolean isNamed(){return name!=null;}

	protected CPSComponent(CPSContainer parent,String name) {
		this.parent=parent;
		this.name=name;
		parent.add(this);
		core=parent.getCore();
		core.getRootComponent().register(this);
	}
	protected CPSComponent(CPSCore core){//used by roots
		if(CPS.isDebug()&&!(this instanceof RootComponent)){
			throw new IllegalArgumentException("only root components can use this constructor");
		}
		this.core=core;
		this.name=null;

		parent=null;
	}

	public final String[] getPath(){//optimize
		String[] path;
		CPSComponent t=this;
		CPSComponent root=getCore().getRootComponent();
		while(true){
			if(t==root){path=new String[0]; break;}
			t=t.getParent();
			if(t.isNamed()){
				path=t.getPath();
				break;
			}
		}
		if(isNamed()){
			String[] ret=new String[path.length+1];
			System.arraycopy(path,0,ret,0,path.length);
			ret[ret.length-1]=getName();
			return ret;
		}else return path;
	}

	//dispose of this component,
	//called to remove a componet from its parent
	//and any component it depends upon as well as
	//finish any components that depend on this component
	protected void finishDependancies(){
		if(dependants!=null){
			final CPSComponent[] c=(CPSComponent[])dependants.createArray(CPSComponent.class);
			for(int i=0;i<c.length;i++) c[i].finish();
		}
		if(dependOns!=null){
			CPSComponent[] temp=new CPSComponent[dependOns.size()];
			dependOns.fill(temp);
			for(int i=0;i<temp.length;i++)
				temp[i].removeDependant(this);
		}
	}
	public void finish(){
		finishDependancies();
		core.getRootComponent().unregister(this);
		if(parent!=null) parent.remove(this);
	}
	//a dependant is a class that will be finished when the class it dependsOn is finished
	public void addDependant(final CPSComponent dependant){
		if(dependants==null) dependants=new CPSVector();
		dependants.add(dependant);
		dependant.addDependOn(this);
	}
	public void removeDependant(final CPSComponent dependant){
		dependants.remove(dependant);
		dependant.removeDependOns(this);
		if(dependants.isEmpty()) dependants=null;
	}
	//internal, should only be called by add dependant
	private final void addDependOn(final CPSComponent dependOn){
		if(dependOns==null) dependOns=new CPSVector();
		dependOns.add(dependOn);
	}
	//internal, should only be called by remove dependant
	private void removeDependOns(final CPSComponent dependOn){
		dependOns.remove(dependOn);
		if(dependOns.isEmpty()) dependOns=null;
	}

	public final CPSContainer getParent(){
		return parent;
	}
	public final CPSCore getCore(){
		return core;
	}
}