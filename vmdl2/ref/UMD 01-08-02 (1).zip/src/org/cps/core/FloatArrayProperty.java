package org.cps.core;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */


public class FloatArrayProperty extends Property{
	protected float[] v;
	public FloatArrayProperty(DataModel parent,String name,float[] v){
		super(parent,name);
		this.v=(float[])v.clone();
	}
	public final Class getType(){return float[].class;}//not Float.TYPE or float.class
	public final float[] getFloatArrayValue(){return (float[])v.clone();}
	public final void setFloatArrayValue(final float[] n){
		if(v.length==n.length){
			for(int i=0;true;i++){if(i==v.length) return; if(v[i]!=n[i]) break; }
			System.arraycopy(n,0,v,0,n.length);
		}else this.v=(float[])n.clone();
		setChanged();
	}
	public final Object getObjectValue(){return v.clone();}
	public final void setObjectValue(Object o){
		setFloatArrayValue(((float[])ObjectProperty.convert(o,float[].class)));
	}
	public static class A2D extends FloatArrayProperty{
		protected A2D(DataModel parent,String name,float[] f){
			super(parent,name,f);
		}
		public A2D(DataModel parent,String name,float x,float y){
			this(parent,name,new float[]{x,y});
		}
		public final float getXValue(){return v[0];}
		public final float getYValue(){return v[1];}
		public final void setXValue(float x){if(v[0]==x)return; v[0]=x; setChanged();}
		public final void setYValue(float y){if(v[1]==y)return; v[1]=y; setChanged();}
	}
	public static final class A3D extends FloatArrayProperty.A2D{
		public A3D(DataModel parent,String name,float x,float y,float z){
			super(parent,name,new float[]{x,y,z});
		}
		public final float getZValue(){return v[2];}
		public final void setZValue(float z){if(v[2]==z)return; v[2]=z; setChanged();}
	}
}