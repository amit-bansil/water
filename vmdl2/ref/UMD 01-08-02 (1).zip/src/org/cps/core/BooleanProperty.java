package org.cps.core;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */


public final class BooleanProperty extends Property{
	private boolean v;
	public BooleanProperty(DataModel parent,String name,boolean v){
		super(parent,name);
		this.v=v;
	}
	public void setBooleanValue(boolean f){if(v==f)return; v=f; setChanged();}
	public boolean getBooleanValue(){return v;}

	public Class getType(){return Integer.class;}//not Float.TYPE or float.class
	public Object getObjectValue(){return new Boolean(v);}
	public void setObjectValue(Object o){
		setBooleanValue(
			((Boolean)ObjectProperty.convert(o,Boolean.class)).booleanValue()
		);
	}
}