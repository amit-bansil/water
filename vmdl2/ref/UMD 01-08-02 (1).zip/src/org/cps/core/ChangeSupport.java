package org.cps.core;
import org.cps.util.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class ChangeSupport {
	public ChangeSupport(){
	}
	private CachedVector changeListeners=null;
	public void addListener(ChangeListener c){
		if(changeListeners==null) changeListeners=new CachedVector(ChangeListener.class);
		changeListeners.add(c);
	}
	public void removeListener(ChangeListener c){
		changeListeners.remove(c);
		if(changeListeners.isEmpty()) changeListeners=null;
	}
	public void setChanged(){
		if(changeListeners!=null){
			ChangeListener[] changeListenersArray=
					(ChangeListener[])changeListeners.getCachedArray();
			for (int i = 0; i < changeListenersArray.length; i++) {
				changeListenersArray[i].targetChanged();
			}
		}
	}
}