package org.cps.io;
import java.io.*;
import org.cps.CPSErrors;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class TempFile {
	private final File internal;
	private final IOException e;
	private InputStream in;
	private OutputStream out;

	public TempFile(FileDescription d) {
		IOException e=null; File internal=null;
		final String name=d.getName()+"_"+(int)(Math.random()*100)+"."+d.getType();
		try{
			for(int i=0;i<99;i++){
				internal=new File(i+name).getAbsoluteFile();
				if(!internal.exists()) break;
				internal=null;
				if(i==99)
					throw new IOException("could not create temp file:directory overflow");

			}
		}catch(IOException ex){
			e=ex;
		}
		this.e=e;
		this.internal=internal;
	}
	public final void write(File f)throws IOException{//overwrites
		FileOutputStream out=new FileOutputStream(f,false);
		write(out);
	}
	public final void read(InputStream in)throws IOException{//optimize
		check();
		FileIO.copy(in,getOut());
		close();
	}
	public final void write(OutputStream out)throws IOException{//optimize
		check();
		FileIO.copy(getIn(),out);
		close();
	}
	public String getPath() throws IOException{
		check();
		return internal.getAbsolutePath();
	}
	public OutputStream getOut()throws IOException{
		check();
		out=new FileOutputStream(internal);
		return out;
	}
	public InputStream getIn()throws IOException{
		check();
		in=new FileInputStream(internal);
		return in;
	}
	public final File getFile()throws IOException{
		check();
		return internal;
	}
	public final void check()throws IOException{
		if(in!=null||out!=null) throw new IllegalStateException(this+" open");
		if(e!=null){ throw e; }
	}
	public final void delete(){
		try{
			check();
			if(internal!=null&&internal.exists()&&!internal.delete()){
				CPSErrors.warning("Couldn't delete "+this);
			}
		}catch(Exception e){
			CPSErrors.ioException("couldn't delete "+this,e);
		}
	}
	public final void close()throws IOException{
		if(in!=null) in.close();
		if(out!=null) out.close();
		in=null; out=null;
	}
	public final String toString(){
		return "temp file@"+
				(internal==null?"unknown":internal.getAbsolutePath());
	}
	protected void finalize()throws Throwable{
		delete();
		super.finalize();
	}
}