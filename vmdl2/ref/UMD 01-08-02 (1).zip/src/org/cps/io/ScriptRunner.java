package org.cps.io;
import java.io.*;
import org.cps.core.*;
import org.cps.*;
import org.cps.io.util.*;
import com.Ostermiller.util.*;
import org.cps.util.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class ScriptRunner extends CPSComponent implements Commandable,ConfigurationManager.Configurable{
	public static final String CREATE="create",LOAD_DEFAULT="loadDefaults";

	static{
		MethodRegistry.registerMethod(ScriptRunner.class,CREATE,
									  "create a CPSComponent dependant on this ScriptRunner",
									  "the components class type",null,String.class);
		MethodRegistry.registerMethod(ScriptRunner.class,LOAD_DEFAULT,
									  "load the data from this file");
	}
	public static void classFinalize() throws Throwable {
		MethodRegistry.unregisterMethod(CREATE);
		MethodRegistry.unregisterMethod(LOAD_DEFAULT);
	}
	public final void loadDefaults(){//would really screw things up if gui called this directly,optimize
		final CPSVector c=getCore().getRootComponent().globalSearch(CustomSaveable.class);
		final CPSContainerListener gl=new CPSContainerListener(){
			public final void componentAdded(CPSComponent o){
				c.add(o);
			}
			public final void componentRemoved(CPSComponent o){
				if(c.contains(o)) c.remove(o);
			}
		};
		getCore().getRootComponent().addGlobalListener(CustomSaveable.class,gl);
		while(!c.isEmpty()){
			final CustomSaveable a=(CustomSaveable)c.elementAt(0);
			c.remove(0);
			if(a==this)continue;
			final FileDescription f=a.getDescription();
			try{
				if(getCore().getIO().contains(f)) a.load(getCore().getIO().findData(f));
			}catch(Exception e){
				CPSErrors.ioException("error reading "+f.getFullName(),e);
			}
		}
		getCore().getRootComponent().removeGlobalListener(CustomSaveable.class,gl);
	}
	public final void create(String name)throws Exception{
		if(name==null) throw new IllegalArgumentException("create missing type class name");
		addDependant(getCore().getRootComponent().createChild(name));
	}
	private static final String LOAD_SCRIPT="Starter";

	public ScriptRunner(CPSContainer parent)throws IOException{
		this(parent,LOAD_SCRIPT);//shoudld be seperate class
	}

	private final FileDescription desc;
	public final FileDescription getDescription(){return desc;}
	protected ScriptRunner(CPSContainer parent,String name)throws IOException {
		this(parent,name,null);
	}
	private ScriptRunner(CPSContainer parent,String name,InputStream in)throws IOException {
		super(parent,name);

		desc=new FileDescription(name,parent.getPath(),FileIO.TEXT_FORMAT);

		if(in==null){
			in=parent.getCore().getIO().findData(desc);
		}
		if(in!=null)_load(in);
		else if(CPS.isDebug()) CPSErrors.warning(LOAD_SCRIPT+" not found");
	}
	public final void load(final InputStream in)throws IOException{
		if(!loaded) _load(in);
		else{
			final CPSContainer parent=getParent();
			finish();
			new ScriptRunner(parent,getName(),in);
		}
	}
	private boolean loaded=false;

	private final CPSVector script=new CPSVector();
	private final void _load(final InputStream in)throws IOException{
		loaded=true;

		final EventQueue queue=getCore().getEventQueue();

		new ScriptReader(){
			protected final void read(String x)throws Throwable{
				script.add(x);
				execute(queue,x);
			}
		}.run(in);
	}
	public static final void execute(EventQueue queue,String x)throws Throwable{
		final Object[] s=CPSText.inputList(x);

		if(s.length<2) throw new IllegalArgumentException(
				"too few parameters-must specify path and name");

		Object[] param;
		if(s.length==1)  param=new String[0];
		if(!(s[0] instanceof String)) throw new IllegalArgumentException(
				"expected path first,not array");
		if(!(s[1] instanceof String)) throw new IllegalArgumentException(
				"expected target second,not array");
		else{
			param=new Object[s.length-2];
			System.arraycopy(s,2,param,0,param.length);
		}
		queue.callNow(new CallDescription((String)s[1],CPSText.seperate((String)s[0],"."),param));
	}
	public final void save(OutputStream os)throws IOException{
		String[] s=(String[])script.createArray(String.class);
		PrintWriter pw=new PrintWriter(new BufferedWriter(new OutputStreamWriter(os)));
		for(int i=0;i<s.length;i++) pw.println(s[i]);
		pw.flush();
	}
}