package org.cps.io;
import java.io.*;
import org.cps.CPSText;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public final class FileDescription{
	public static final char DEFAULT_TYPE_SEP='.';
	public static final char DEFAULT_PATH_SEP=':';

	private final String externalName; private final String[] path;
	private final long mod;
	private final long size;
	private final String type;
	public final boolean sizeValid(){return size!=-1;}
	public final boolean modifiedValid(){return mod!=-1;}

	public final String toString(){return "FileDesription "+getFullName();}

	public static final String getInternalName(String name,String path[],String type, char pathSep){
		return getInternalName(name,path,type,pathSep,DEFAULT_TYPE_SEP);
	}
	public static final String getInternalName(String name,String path[],String type, char pathSep,char typeSep){
		StringBuffer ret=new StringBuffer();
		for(int i=0;i<path.length;i++){ ret.append(path[i]); ret.append(pathSep); }
		ret.append(name);
		ret.append(typeSep);
		ret.append(type);
		return ret.toString();
	}
	public FileDescription(String name,String type){
		this(name,new String[0],type);
	}
	public FileDescription(String name,String path,String type){
		this(name,new String[]{path},type);
	}
	public FileDescription(String name,String[] path,String type){
		this(name,path,type,-1,-1);
	}
	public FileDescription(String internalName,char pathSep){
		this(internalName,pathSep,DEFAULT_TYPE_SEP,-1,-1);
	}
	public FileDescription(String internalName,char pathSep,char typeSep){
		this(internalName,pathSep,typeSep,-1,-1);
	}
	public FileDescription(String internalName,char pathSep,char typeSep,long mod,long size){
		this(internalName.substring(
				internalName.lastIndexOf(pathSep)+1,internalName.lastIndexOf(typeSep)),
			CPSText.seperate(internalName.substring(0,internalName.lastIndexOf(pathSep)),pathSep+""),
			internalName.substring(
				internalName.lastIndexOf(internalName.lastIndexOf(typeSep)+1)),
				mod,size);
	}
	public FileDescription(String name,String[] path,String type,long mod,long size){
		this.mod=mod;
		this.size=size;
		this.path=path;
		this.externalName=name;
		this.type=type;
	}
	public final String[] getPath(){return path;}
	public final String getFullName(){
		return CPSText.listToString(path,DEFAULT_PATH_SEP)+DEFAULT_PATH_SEP+getName()+
				DEFAULT_TYPE_SEP+DEFAULT_TYPE_SEP;
	}
	public final String getName(){return externalName;}
	public final long getSize(){return size;}
	public final long getModified(){return mod;}
	public final String getType(){return type;}
}