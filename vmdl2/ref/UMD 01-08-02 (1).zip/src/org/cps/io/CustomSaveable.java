package org.cps.io;
import org.cps.io.util.*;
import org.cps.core.*;
import java.io.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */

public interface CustomSaveable{
	public void save(OutputStream out)throws java.io.IOException;
	public void load(InputStream d)throws java.io.IOException;
	public FileDescription getDescription();
}