package org.cps.io;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */
import org.cps.*;
import org.cps.core.*;
import java.io.*;
import org.cps.io.util.*;
import org.cps.ui.*;
import org.cps.util.*;
import org.cps.umd.io.*;
public class IOManager{
	private final FileIO io;
	private final CPSCore core;
	public IOManager(CPSCore core) {
		this.core=core;
		io=new FileIO(core);
		CPSResources.registerExtension("startUMD.bat","umd32.ico",io.getExtension());
	}
	public InputStream findData(FileDescription d)throws IOException{
		return io.findData(d);
	}
	public FileDescription findDescription(String name,String[] path,String type)throws IOException{
		return io.findDescription(name,path,type);
	}
	public boolean contains(FileDescription d)throws IOException{
		return io.findData(d)!=null;
	}
	public boolean isLoaded(){
		return io.isLoaded();
	}
	public final ClassLoader getClassLoader(){
		return io.getClassLoader();
	}

	private final ChangeSupport loadChange=new ChangeSupport();
	public ChangeSupport getLoadChange(){return loadChange;}

	public void reload(){
		core.getKernel().runNow(new Runnable(){
			public void run(){
				try{
					io.reload();
				}catch(Exception e){
					CPSErrors.ioException(e);
				}
				loadChange.setChanged();
			}
		});
	}
	public void load(){
		core.getKernel().runLater(new Runnable(){
			public void run(){
				try{
					File f=(File)core.getUI().prompt(
							new PromptDescription.FileOpenPrompt(CPSText.trans("open dialog"),io.getFilter()));
					if(f!=null) io.load(f);
				}catch(Exception e){
					CPSErrors.ioException("The file was not loaded, check type",e);
				}
				loadChange.setChanged();
			}
		});
	}
	public void load(final File f){
		core.getKernel().runNow(new Runnable(){
			public void run(){
				try{
					if(f!=null) io.load(f);
				}catch(Exception e){
					CPSErrors.ioException("The file was not loaded, check type",e);
				}
				loadChange.setChanged();
			}
		});
	}

	/** @todo implement save as */
	public void saveAs(){
		core.getKernel().runLater(new Runnable(){
			public void run(){
				try{
					File f=(File)core.getUI().prompt(new PromptDescription.FileSavePrompt(
	                        CPSText.trans("save config"),io.getExtension(),io.getFilter()));
					if(f!=null) io.save(f);
				}catch(Exception e){
					CPSErrors.ioException(e);
				}
			}
		});
	}
	public void save(){
		core.getKernel().runLater(new Runnable(){
			public void run(){
				try{
					io.save();
				}catch(Exception e){
					CPSErrors.ioException(e);
				}
			}
		});
	}
	public void saveMovie(){
		core.getKernel().runLater(new Runnable(){
			public void run(){
				try{
					File f=(File)core.getUI().prompt(new PromptDescription.FileSavePrompt(
							io.getExtension(),
	                        CPSText.trans("save movie"),io.getFilter()));
					if(f!=null) io.saveMovie(f);
				}catch(Exception e){
					CPSErrors.ioException(e);
				}
			}
		});
	}
	/*public void quickClose(){
		io.close();
		loadChanged();
	}*/
	public void close(){
		core.getKernel().runNow(new Runnable(){
			public void run(){
				try{
					io.close();
				}catch(Exception e){
					CPSErrors.ioException(e);
				}
				loadChange.setChanged();
			}
		});
	}
	public void finish(){
		io.finish();
	}
}