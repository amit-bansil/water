package org.cps.io;

import org.cps.core.*;

import org.cps.gui.*;
import java.io.*;
import org.cps.*;
import java.util.*;
import org.cps.util.*;
import org.cps.io.util.*;
import org.cps.umd.io.*;
import java.util.zip.*;
import java.util.HashSet;
/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */

public final class FileIO{
	public static final int COPY_BUFFER_SIZE=CPSConfiguration.loadIntProperty(
			"Copy Buffer Size",1024);
	public static final int COMPRESSION_LEVEL=CPSConfiguration.loadIntProperty(
			"Compression Level",9);
	public static final String TEXT_FORMAT="txt";

	public final ClassLoader getClassLoader(){//todo write zipfile classloader
		return ClassLoader.getSystemClassLoader();
	}
	private final CPSCore core;
	private ScriptRunner runner;
	private ZipFile file;
	private File cur;
	//name

	private static final char zipPathSep='/';
	private static final char zipTypeSep='.';
	private final String resolveName(String name,String[] path,String type){
		return FileDescription.getInternalName(name,path,type,zipPathSep,zipTypeSep);
	}
	//filter
	private static final String EXTENSION=".cps";
	public final String getExtension(){return EXTENSION;}
	private static final FilenameFilter filter=new FilenameFilter(){
		public boolean accept(File dir,String name){
			if(name.endsWith(EXTENSION)) return true;
			else return false;
		}
	};
	public final FilenameFilter getFilter(){return filter;}

	public FileIO(CPSCore core) {
		this.core=core;
	}

	public final void saveMovie(File f){
		throw new IllegalArgumentException("Unsupported Operation");
	}
	public InputStream findData(FileDescription d)throws IOException{
		if(!isLoaded()) throw new IllegalStateException("!loaded");
		final String n=resolveName(d.getName(),d.getPath(),d.getType());
		final ZipEntry ze=file.getEntry(n);
		if(ze==null) return null;
		else return file.getInputStream(ze);
	}
	public FileDescription findDescription(String name,String[] path,String type)throws IOException{
		if(!isLoaded()) throw new IllegalStateException("!loaded");
		final String n=resolveName(name,path,type);
		final ZipEntry ze=file.getEntry(n);
		if(ze==null) return null;
		else return new FileDescription(n,zipPathSep,zipTypeSep,
										ze.getTime(),ze.getSize());
	}
	public boolean isLoaded(){ return file!=null; }
	public void save()throws IOException{
		TempFile t=new TempFile(new FileDescription("Save","cps"));
		try{
			save(t.getFile());
			file.close();
			file=null;
			cur.delete();
			t.write(cur);
			file=new ZipFile(cur);
		}finally{
			t.delete();
		}
	}
	public void save(File f)throws IOException{
		if(!f.getName().endsWith(EXTENSION)) f=new File(f.getAbsolutePath(),f.getName()+EXTENSION);
		if(f.exists()) f.delete();
		ZipOutputStream out=new ZipOutputStream(new FileOutputStream(f));
		out.setLevel(COMPRESSION_LEVEL);
		CustomSaveable[] saveables=(CustomSaveable[])core.getRootComponent()
							.globalSearch(CustomSaveable.class).createArray(CustomSaveable.class);
		Hashtable savedFiles=null;
		FileDescription desc;
		ZipEntry ze;
		String name;
		if(CPS.isDebug()){
			savedFiles=new Hashtable();
		}
		for(int i=0;i<saveables.length;i++){
			desc=saveables[i].getDescription();
			name=resolveName(desc.getName(),desc.getPath(),desc.getType());
			if(savedFiles!=null){
				if(savedFiles.containsKey(name)) throw new IOException("Can't save:the name "+name+" is repeated");
				savedFiles.put(name,new Object());
			}
			ze=new ZipEntry(name);
			if(desc.modifiedValid()) ze.setTime(desc.getModified());
			out.putNextEntry(ze);

			saveables[i].save(out);
		}
		out.flush();
		out.close();
		file.close();
		file=null;
		file=new ZipFile(f);
	}
	public void load(final File f)throws IOException{
		close();
		cur=f;
		file=new ZipFile(f);

		runner=new ScriptRunner(core.getRootComponent());
	}

	public void close()throws IOException{
		if(!isLoaded()) return;
		file.close();
		file=null;
		cur=null;
		runner.finish();
		runner=null;
	}
	public void reload()throws IOException{
		runner.finish();
		runner=new ScriptRunner(core.getRootComponent());
	}
	public void finish(){
		try{
			close();
		}catch(IOException e){
			CPSErrors.ioException("could not close file",e);
		}
	}

	private static final byte[] copyBuffer=new byte[COPY_BUFFER_SIZE];
	public static final void copy(final InputStream in,final OutputStream out)throws IOException{
		copy(in,out,-1);
	}
	public static final void copy(final InputStream in,final OutputStream out,final long lenL)throws IOException{
	synchronized(copyBuffer){
		final int len=(int)lenL;
		if((long)len!=lenL) throw new IllegalArgumentException("File Length must be less than "+Integer.MAX_VALUE+" bytes");
		final int lenb=(int)Math.floor((double)len/(double)copyBuffer.length)*copyBuffer.length;
		if(len>0){
			for(int i=copyBuffer.length;i<=lenb;i+=copyBuffer.length){
				int n=0,c;
				while(n<copyBuffer.length){
					c=in.read(copyBuffer,n,copyBuffer.length-n);
					out.write(copyBuffer,n,c);
					n+=c;
				}
			}
			int k;
			for(int i=0;i<len-lenb;){
				k=in.read(copyBuffer,i,(len-lenb)-i);
				out.write(copyBuffer,i,k);
				i+=k;
			}
		}else{
			int k=0;
			while(true){
				for(int i=0;i<copyBuffer.length;){
					k=in.read(copyBuffer,i,copyBuffer.length-i);
					if(k==-1) break;
					out.write(copyBuffer,i,k);
					i+=k;
				}
				if(k==-1) break;
			}
		}
	}}
}