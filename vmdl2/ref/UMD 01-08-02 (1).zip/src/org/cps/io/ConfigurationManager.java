package org.cps.io;

import org.cps.core.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
*/
import java.io.*;
import org.cps.*;

public class ConfigurationManager extends CPSContainer{

	public static interface Configurable extends CustomSaveable{}

	public ConfigurationManager(RootComponent parent) {
		super(parent);
	}
	public final void importF(final Configurable b,final File f){
		getCore().getKernel().runNow(new Runnable(){
			public final void run(){
				try{
					b.load(new FileInputStream(f));
				}catch(IOException ex){
					CPSErrors.ioException("Unable to import configuration",ex);
				}
			}
		});
	}
	public final void exportF(final Configurable b,final File f){
		getCore().getKernel().runNow(new Runnable(){
			public final void run(){
				try{
					b.save(new FileOutputStream(f));
				}catch(IOException ex){
					CPSErrors.ioException("Unable to export configuration",ex);
				}
			}
		});
	}
	public final void editF(final Configurable b){
		getCore().getKernel().runNow(new Runnable(){
			public final void run(){
				TempFile f=new TempFile(b.getDescription());
				try{
					try{
						b.save(f.getOut());
					}catch(IOException ex){
						CPSErrors.ioException("Unable to export configuration for editing",ex);
						return;
					}finally{
						f.close();
					}
					final Process p;
					try{
						p=Runtime.getRuntime().exec("notepad "+f.getPath());
					}catch(IOException ex){
						CPSErrors.ioException("Unable to start editor",ex);
						return;
					}
					try{
						p.waitFor();
					}catch(InterruptedException ex){
						CPSErrors.record(ex);
						return;
					}

					try{
						b.load(f.getIn());
					}catch(IOException ex){
						CPSErrors.ioException("Unable to import edited configuration",ex);
						return;
					}finally{
						f.close();
					}
				}catch(IOException e){
					CPSErrors.ioException("An unexpected io error occurred",e);
				}finally{
					f.delete();
				}
			}
		});
	}
	/*
	public final void memorize(Configurable b){

	}
	public final void forget(Configurable b){

	}*/
}
