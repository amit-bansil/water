package org.cps.ui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class ProgressDescription {
	private final String title,description;
	private final ProgressListener l;
	private final float endTime;
	private final int wait;
	public static final int DEFAULT_WAIT=100;

	public ProgressDescription(String title,ProgressListener l,float endTime){
		this(title,l,endTime,null,DEFAULT_WAIT);
	}
    public ProgressDescription(String title,ProgressListener l,float endTime,String description,
							   int wait) {
		this.l=l;
		this.title=title;
		this.description=description;
		this.wait=wait;
		this.endTime=endTime;
    }
	public final String getTitle(){return title;}
	public final String getDescription(){return description;}
	public final ProgressListener getListener(){return l;}
	public final double getEndTime(){return endTime;}
	public final int getWait(){return wait;}
}