package org.cps.ui.gui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */
import java.awt.*;
import javax.swing.*;
import org.cps.*;
import org.cps.core.*;
import org.cps.umd.core.*;
import org.cps.ui.*;
public abstract class CPSMenu extends CPSComponent {
	private final JMenu menu;
	public CPSMenu(CPSGUI gui,float priority,String name) {
		super( gui );

		menu=new JMenu(name);
		((CPSGUI)getParent()).addMenu(menu,priority);
	}
	public void finish(){
		((CPSGUI)getParent()).removeMenu(menu);
		super.finish();
	}
	protected final JMenu getMenu(){ return menu; }

}