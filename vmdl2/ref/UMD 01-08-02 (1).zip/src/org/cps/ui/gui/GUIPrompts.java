package org.cps.ui.gui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */
import org.cps.*;
import org.cps.ui.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import org.cps.ui.gui.util.CPSGUIToolkit;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class GUIPrompts {
	private final CPSFrame frame;
	private final Hashtable prompts=new Hashtable();
    public GUIPrompts(final CPSFrame frame) {
		this.frame=frame;
		prompts.put(PromptDescription.FileSavePrompt.class,new Prompt(){
			public final Object prompt(final PromptDescription p){
				final PromptDescription.FileSavePrompt fp=(PromptDescription.FileSavePrompt)p;
				FileDialog chooser=new FileDialog(frame.getParent(),p.getPrompt(),FileDialog.SAVE);
				chooser.setDirectory(CPSResources.getIORoot().getAbsolutePath());
				chooser.setFilenameFilter(fp.getFilter());
				chooser.setVisible(true);
				if(chooser.getFile()==null) return null;
				final String n=chooser.getFile();
				if(n==null) return null;
				else if(n.endsWith(fp.getExtension())){
					return new File(chooser.getDirectory(),n);
				}else{
					return new File(chooser.getDirectory(),n+fp.getExtension());
				}
			}
		});
		prompts.put(PromptDescription.FileOpenPrompt.class,new Prompt(){
			public final Object prompt(final PromptDescription p){
				final PromptDescription.FileOpenPrompt fp=(PromptDescription.FileOpenPrompt)p;
				final CPSFileChooser c=new CPSFileChooser(fp.getFilter(),frame,p.getPrompt());
				return c.getUserSelection();
			}
		});
		prompts.put(PromptDescription.NumberPrompt.class,new Prompt(){
			public final Object prompt(final PromptDescription p){
				final PromptDescription.NumberPrompt np=(PromptDescription.NumberPrompt)p;
				try{
					return new Float(
							PromptDialog.promptFloat(np.getTitle(),np.getPrompt(),
							np.getMin(),np.getMax(),np.getDefault(),frame));
				}catch(InvalidInputException e){
					return null;
				}
			}
		});
		prompts.put(PromptDescription.StringPrompt.class,new Prompt(){
			public final Object prompt(final PromptDescription p){
				final PromptDescription.StringPrompt np=(PromptDescription.StringPrompt)p;
				return JOptionPane.showInputDialog(
					frame.getParent(),
					np.getPrompt(), np.getTitle(),
					JOptionPane.INFORMATION_MESSAGE, null,
					null,new String());
			}
		});
		prompts.put(PromptDescription.ListPrompt.class,new Prompt(){
			public final Object prompt(final PromptDescription p){
				final PromptDescription.ListPrompt lp=(PromptDescription.ListPrompt)p;
				final JDialog d=new JDialog(frame.getParent(),lp.getTitle(),true);
				final JList list=new JList(lp.getChoices());
				final JButton ok=new JButton(CPSText.trans("prompt ok"));
				final JButton cancel=new JButton(CPSText.trans("prompt cancel"));
				ok.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						d.setVisible(false);
					}
				});
				d.addWindowListener(new WindowAdapter() {
					public void windowClosing(WindowEvent e) {
						cancel.setEnabled(false);
					}
				});
				ok.setEnabled(false);
				cancel.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						cancel.setEnabled(false);
						d.setVisible(false);
					}
				});
				list.addListSelectionListener(new ListSelectionListener(){
					public void valueChanged(ListSelectionEvent e){
						ok.setEnabled(true);
					}
				});
				CPSGUIToolkit.layoutDialog(d,lp.getPrompt(),list,null,ok,cancel);
				d.pack();
				CPSGUIToolkit.centerComponent(d,frame.getParent());
				d.setVisible(true);
				d.dispose();
				if(!cancel.isEnabled()) return null;
				else return list.getSelectedValue();
			}
		});
    }
	public Object prompt(PromptDescription p){
		if(CPS.isDebug()&&!prompts.containsKey(p.getClass())){
			throw new IllegalArgumentException("unrecognized prompt type:"+p);
		}
		return ((Prompt)prompts.get(p.getClass())).prompt(p);
	}
	private static abstract class Prompt{
		public abstract Object prompt(PromptDescription p);
	}
}