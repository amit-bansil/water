package org.cps.ui.gui.util;

/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import org.cps.*;
import org.cps.gui.util.*;

public final class CPSGUIToolkit {
	private static final ShadowBorder shadowBorder=new ShadowBorder(4);
	public static final ShadowBorder getShadowBorder(){return shadowBorder;}
	private static final HeaderBorder headerBorder=new HeaderBorder();
	public static final HeaderBorder getHeaderBorder(){return headerBorder;}

	public static void layoutDialog(JDialog d,String prompt,Component main,JButton more,JButton ok,JButton cancel) {
		((JPanel)d.getContentPane()).setBorder(BorderFactory.createEmptyBorder(6,12,11,11));
		d.getContentPane().setLayout(new BoxLayout(d.getContentPane(),BoxLayout.Y_AXIS));
		JPanel instructions=new JPanel(new BorderLayout());
		JLabel label=new JLabel(prompt);
		instructions.add(label,BorderLayout.WEST);
		instructions.setMaximumSize(new Dimension(
			Integer.MAX_VALUE,label.getMaximumSize().height));
		d.getContentPane().add(instructions);
		d.getContentPane().add( Box.createRigidArea(new Dimension(3,3)) );
		JScrollPane pane=new JScrollPane(main);
		pane.setMaximumSize(new Dimension(Integer.MAX_VALUE,Integer.MAX_VALUE));
		d.getContentPane().add(pane);

		JPanel base=new JPanel(); base.setLayout(new BoxLayout(base,BoxLayout.X_AXIS));
		if(more!=null) base.add(more);
		base.add( Box.createHorizontalGlue() );
		base.add( Box.createRigidArea(new Dimension(12,0)) );
		base.add(cancel);
		base.add( Box.createRigidArea(new Dimension(3,3)) );
		base.add(ok);

		d.getContentPane().add(Box.createRigidArea(new Dimension(11,11)));
		d.getContentPane().add(base);
	}
	public static final void centerComponent(Component c){
		c.setLocation(c.getToolkit().getScreenSize().width/2-c.getSize().width/2,
			c.getToolkit().getScreenSize().height/2-c.getSize().height/2);
	}
	public static final void centerComponent(Component c,Component parent){
			c.setLocation(parent.getLocation().x+parent.getSize().width/2-c.getSize().width/2,
				parent.getLocation().y+parent.getSize().height/2-c.getSize().height/2);
	}
	public static final void initialize(){
		setComponentsMixed(true);
		try{
			javax.swing.LookAndFeel alloyLnF = new com.incors.plaf.alloy.AlloyLookAndFeel();
			javax.swing.UIManager.setLookAndFeel(alloyLnF);
		}catch(UnsupportedLookAndFeelException e){
			CPSErrors.record(e);
		}
	}
	/** @todo use full screen splash screen when loading in full screen mode, add a flag for full screen mode,
	 *  save that flag */
	 //convenience for common use
	private static SplashScreen curSplash;
	public static final void setLoading(boolean v){
		if(v){
			if(curSplash==null) curSplash=new SplashScreen(CPSText.trans("splash loading"));
		}else{
			if(curSplash!=null){
				curSplash.dispose();
				curSplash=null;
			}
		}
	}
	public static final void setEnabled(final Component set,final boolean v){
		set.setEnabled(v);
		if(set instanceof Container){
			final Component[] c=((Container)set).getComponents();
			for(int i=0;i<c.length;i++){
				if(!(c[i] instanceof JLabel)) setEnabled(c[i],v);
			}
		}
	}
	public static final void deepClose(Component c){
		if(c instanceof Container){
			final Component[] ca=((Container)c).getComponents();
			for(int i=0;i<ca.length;i++)deepClose(ca[i]);
		}
		c.getParent().remove(c);
	}
	//if mixed allow for heavyweight components
	public static final void setComponentsMixed(boolean v){
		ToolTipManager.sharedInstance().setLightWeightPopupEnabled(!v);
		JPopupMenu.setDefaultLightWeightPopupEnabled(!v);
	}
	public static final void lockSize(JComponent c){
		c.setSize(c.getPreferredSize());
		c.setMaximumSize(c.getPreferredSize());
		c.setMinimumSize(c.getPreferredSize());
	}
	public static final void lockYSize(JComponent c){
		c.setSize(new Dimension(c.getSize().width,c.getPreferredSize().height));
		c.setMaximumSize(new Dimension(c.getMaximumSize().width,c.getPreferredSize().height));
		c.setMinimumSize(new Dimension(c.getMinimumSize().width,c.getPreferredSize().height));
	}
	public static final Box leftAlign(Component c){
		Box ret=Box.createHorizontalBox();
		ret.add(c);
		ret.add(Box.createHorizontalGlue());
		return ret;
	}
}