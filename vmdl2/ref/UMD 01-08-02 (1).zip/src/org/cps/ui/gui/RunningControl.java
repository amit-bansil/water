package org.cps.ui.gui;

import javax.swing.*;
import org.cps.*;
import java.awt.event.*;
import org.cps.umd.simulation.*;
import org.cps.core.*;
import java.awt.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class RunningControl extends GUIComponent{

	public RunningControl(final DataGUI data,String name) {
		super(data,name,Box.createHorizontalBox());
		final JButton start=new JButton("Start",CPSResources.getImageIcon("Play16"));
		final JButton stop=new JButton("Stop",CPSResources.getImageIcon("Pause16"));
		final TimeData d=data.getSimulation().getTimeData();
		start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.getProperty(d.RUNNING).set(new Boolean(true));
			}
		});
		stop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				d.getProperty(d.RUNNING).set(new Boolean(false));
			}
		});
		data.bind(new ChangeListener(){
			public final void targetChanged(){
				final boolean v=((Boolean)d.getProperty(d.RUNNING).get()).booleanValue();
				if(v){
					stop.setEnabled(true);
					if(start.hasFocus()) stop.grabFocus();
					start.setEnabled(false);
				}
				else{
					start.setEnabled(true);
					boolean gf=stop.hasFocus();
					start.requestFocusInWindow();
					stop.setEnabled(false);
					start.requestFocusInWindow();
				}
			}
		},d.getProperty(d.RUNNING).getChange());

		Box cont=(Box)getComponent();
		cont.add(start);
		cont.add(Box.createRigidArea(new Dimension(3,3)));
		cont.add(Box.createHorizontalGlue());
		cont.add(stop);
	}
}