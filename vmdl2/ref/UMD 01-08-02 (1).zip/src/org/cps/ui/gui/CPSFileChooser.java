package org.cps.ui.gui;

/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import org.cps.*;
import org.cps.gui.*;
import javax.swing.event.*;
import org.cps.gui.util.*;
import org.cps.ui.gui.util.CPSGUIToolkit;

public class CPSFileChooser extends CPSDialog{
	private final FilenameFilter filter;
	private final CPSFrame frame;
	private final String name;
	public CPSFileChooser(FilenameFilter f,CPSFrame frame,String name){
		super(name,frame);

		this.name=name;
		this.filter=f;
		this.files=CPSResources.findFiles(filter);
		this.frame=frame;

		final String[] fss=new String[files.length];
		int n;
		for(int i=0;i<fss.length;i++){
			n=files[i].getName().indexOf('.');
			if(n!=-1) fss[i]=files[i].getName().substring(0,n);
		}
		list=new JList(fss);
		ok=new JButton(CPSText.trans("open file dialog")); ok.setEnabled(false);
		cancel=new JButton(CPSText.trans("cancel file dialog"));
		more=new JButton(CPSText.trans("more file dialog"));

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				selection=null;
				setVisible(false);
			}
		});

		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selection=files[list.getSelectedIndex()];
				setVisible(false);
			}
		});
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				selection=null;
				setVisible(false);
			}
		});
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selection=null;
				setVisible(false);
			}
		});

		list.addMouseListener(new MouseAdapter() {
			 public void mouseClicked(MouseEvent e) {
				 if (e.getClickCount() == 2) {
					 int index = list.locationToIndex(e.getPoint());
					 if(index!=-1){
						selection=files[index];
						setVisible(false);
					 }
				}
			 }
		});

		more.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selection=fileOpenDialog();
				if(selection.exists()) setVisible(false);
			}
		});
		list.addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent e){
				ok.setEnabled(true);
			}
		});

		//layout
		CPSGUIToolkit.layoutDialog(this,CPSText.trans("file list"),list,more,ok,cancel);

		pack();
	}
	private final JList list;
	private final JButton ok,cancel,more;
	private File selection;
	private final File[] files;
	private final File fileOpenDialog(){
		FileDialog chooser=new FileDialog(frame.getParent(),name,FileDialog.LOAD);
		chooser.setDirectory(CPSResources.getIORoot().getAbsolutePath());
		chooser.setFilenameFilter(filter);
		chooser.setVisible(true);
		return new File(chooser.getDirectory()+chooser.getFile());
	}
	public File getUserSelection(){
		setVisible(true);

		return selection;
	}
}