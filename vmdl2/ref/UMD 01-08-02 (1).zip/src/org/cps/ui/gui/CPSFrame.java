package org.cps.ui.gui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import org.cps.*;
/** @todo allow full screen mode to run multiple applications at once side by side,
 *  take advantage of full screen awt drawing */
public class CPSFrame {
	private static final String WIN_LOCATION="Window Location";
	private static final String WIN_SIZE="Window Size";

	static{
		CPSConfiguration.saveDefault(WIN_LOCATION,new Point(0,0));
		CPSConfiguration.saveDefault(WIN_SIZE,new Dimension(600,400));
	}
	private JFrame frame=null;
	private JWindow window=null;
	private JInternalFrame internalFrame=null;
	private Container contentHolder=null;
	private JFrame tempFrame=null;

	public CPSFrame() {
		fullScreen=false;
		if(fullScreen) initWindow();
		else initFrame();
	}
	private final void initFrame(){
		frame=new JFrame();

		frame.setIconImage(CPSResources.getImage("UMD"));
		frame.setLocation((Point)CPSConfiguration.load(WIN_LOCATION));
		frame.setSize((Dimension)CPSConfiguration.load(WIN_SIZE));
		//frame.setDefaultCloseOperation(frame.DO_NOTHING_ON_CLOSE);
		frame.setTitle(title);
		frame.setCursor(cursor);
		if(windowCloseListener!=null) frame.addWindowListener(frameL);
		if(mb!=null) frame.setJMenuBar(mb);

		contentHolder=frame.getContentPane();
		contentHolder.setLayout(new BorderLayout(0,0));
		if(content!=null) contentHolder.add(content);

		frame.setVisible(true);
	}
	private final void initWindow(){
		window=new JWindow();
		tempFrame=new JFrame();
		window.setLocation(0,0);
		window.setSize(window.getToolkit().getScreenSize());
		final JDesktopPane desktop=new JDesktopPane();
		window.setContentPane(desktop);
		desktop.setBackground(Color.green);
		internalFrame=new JInternalFrame(title,false,true,false,false);
		internalFrame.setBackground(Color.orange);
		desktop.add(internalFrame);
		try{
			internalFrame.setMaximum(true);
		}catch(java.beans.PropertyVetoException e){
			CPSErrors.warning("could not maximize main frame",e);
		}
		internalFrame.setDefaultCloseOperation(internalFrame.DO_NOTHING_ON_CLOSE);
		internalFrame.setCursor(cursor);
		if(windowCloseListener!=null) internalFrame.addInternalFrameListener(intFrameL);
		if(mb!=null) internalFrame.setJMenuBar(mb);

		contentHolder=internalFrame.getContentPane();
		contentHolder.setLayout(new BorderLayout(0,0));
		if(content!=null) contentHolder.add(content);

		internalFrame.setVisible(true);
		window.setVisible(true);
	}
	private final void killFrame(){
		CPSConfiguration.save(WIN_LOCATION,frame.getLocation());
		CPSConfiguration.save(WIN_SIZE,frame.getSize());
		frame.setJMenuBar(null);
		contentHolder.removeAll();
		contentHolder=null;
		frame.dispose();
		if(windowCloseListener!=null)frame.removeWindowListener(frameL);
		frame=null;
	}
	private final void killWindow(){
		tempFrame.dispose();
		tempFrame=null;
		window.getContentPane().removeAll();
		internalFrame.setJMenuBar(null);
		internalFrame=null;
		contentHolder.removeAll();
		contentHolder=null;
		window.dispose();
		if(windowCloseListener!=null)internalFrame.removeInternalFrameListener(intFrameL);

		window.dispose();
		window=null;
	}
	public Frame getParent(){
		if(frame!=null) return frame;
		else return tempFrame;
	}

	private boolean fullScreen;
	/** @todo make fullscreen work right now the window taskbar gets in the way and internal frame decorations are ugly*/

	public final void finish(){
		if(frame!=null) killFrame();
		else if(window!=null) killWindow();
	}
	public void setFullScreen(boolean v){//only can be set
		throw new IllegalArgumentException("not yet working, see todo");
		/*if(fullScreen==v) return;
		fullScreen=v;
		finish();
		if(fullScreen) initWindow();
		else initFrame();*/
	}
	private String title=new String();
	private Cursor cursor=Cursor.getDefaultCursor();
	private ActionListener windowCloseListener=null;

	private final WindowListener frameL=new WindowAdapter() {
		public void windowClosing(WindowEvent e) {
			windowCloseListener.actionPerformed(null);
		}
	};
	private final InternalFrameListener intFrameL=new InternalFrameAdapter() {
		public void internalFrameOpened(InternalFrameEvent e) {
			windowCloseListener.actionPerformed(null);
		}
	};

	private JMenuBar mb=null;
	private Container content;

	public void setTitle(String s){
		if(s==null) s=new String();
		title=s;
		if(window!=null) internalFrame.setTitle(s);
		else if(frame!=null) frame.setTitle(s);
	}
	public void setCursor(Cursor c){
		if(c==null) c=Cursor.getDefaultCursor();
		cursor=c;
		if(window!=null) internalFrame.setCursor(c);
		else if(frame!=null) frame.setCursor(c);
	}

	public void setWindowClosingListener(ActionListener l){
		if(windowCloseListener!=null){
			if(window!=null) internalFrame.removeInternalFrameListener(intFrameL);
			else if(frame!=null) frame.removeWindowListener(frameL);
		}
		windowCloseListener=l;
		if(windowCloseListener!=null){
			if(window!=null) internalFrame.addInternalFrameListener(intFrameL);
			else if(frame!=null) frame.addWindowListener(frameL);
		}
	}
	public void setJMenuBar(JMenuBar m){
		if(mb!=null){
			if(window!=null) internalFrame.setJMenuBar(null);
			else if(frame!=null) frame.setJMenuBar(null);
		}
		mb=m;
		if(mb!=null){
			if(window!=null) internalFrame.setJMenuBar(mb);
			else if(frame!=null) frame.setJMenuBar(mb);
		}
	}
	public Container getContentPane(){
		return content;
	}
	public void setContentPane(Container c){
		contentHolder.removeAll();
		content=c;
		if(content!=null) contentHolder.add(content);
	}
	public void centerComponent(Component c){
		c.setLocation((getParent().getLocation().x+getParent().getSize().width/2)-c.getSize().width/2,
			(getParent().getLocation().y+getParent().getSize().height/2)-c.getSize().height/2);
	}
}