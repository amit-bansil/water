package org.cps.ui.gui.util;

import javax.swing.border.Border;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class HeaderBorder implements Border {

    public HeaderBorder() {
    }
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
		g.setColor(c.getBackground());
		height-=1; width-=1;
		g.drawLine(x+width,y,x+width,y+height);

		g.setColor(c.getBackground().brighter());
        g.drawLine(x,y,x+width,y);
		g.drawLine(x,y,x,y+height);
		g.setColor(c.getBackground().darker());
		g.drawLine(x,y+height,x+width,y+height);
    }
	private static final Insets insets=new Insets(1,1,1,1);
    public Insets getBorderInsets(Component c) {
        return insets;
    }
    public boolean isBorderOpaque() {
        return true;
    }
}