package org.cps.ui.gui;
import org.cps.ui.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */
import org.cps.*;
import javax.swing.*;
import java.awt.event.*;
public class CPSProgressMonitor implements ActionListener{
	private ProgressMonitor pm;
	private final Timer t;
	private final double start;
	private final double scale;
	private static final int RATE=500;
	private final ProgressListener target;
	private final long startTime;
	private final double endTime,range;
	private final Object title;
	private final CPSFrame frame;
	public CPSProgressMonitor(Object title,double endTime,int wait,
			ProgressListener target,CPSFrame frame) {
		startTime=System.currentTimeMillis();
		start=target.getProgress();
		range=endTime-start;

		this.target=target;
		this.endTime=endTime;
		this.title=title;
		if(range<1000) scale=(((double)Integer.MAX_VALUE)/10000d);
		else if(range>10000) scale=1d/10d;
		else if(range>100000) scale=1d/100d;
		else if(range>1000000) scale=1d/1000d;
		else if(range>10000000) scale=1d/10000d;
		else scale=1;

		this.frame=frame;

		t=new Timer(RATE,this);
		t.setRepeats(true);
		t.setCoalesce(true);
		t.setInitialDelay(wait);
		t.start();
	}
	private boolean done=false;
	private Object monitor=new Object();
	public void actionPerformed(ActionEvent e){
		synchronized(monitor){
			if(done) return;
			if(pm==null){
				pm=new ProgressMonitor(frame.getParent(),title,
					CPSText.trans("calculating time"),0,(int)(range*scale));
				pm.setMillisToPopup(0);
				pm.setMillisToDecideToPopup(0);
			}
				if(pm.isCanceled()) target.cancel();
				pm.setProgress((((int)(((double)target.getProgress()-(double)start)*scale)))+1);
				pm.setNote(CPSText.timeToString(
					(long) ( ( ((double)System.currentTimeMillis()-(double)startTime)/
					(target.getProgress()-start) )*(endTime-target.getProgress())),RATE*2)
					+" "+CPSText.trans("time remaining")+".");

		}
	}
	public void done(){
		synchronized(monitor){
			t.stop();
			done=true;
			if(pm!=null) pm.close();
			else pm=null;
		}
	}
}