package org.cps.ui.gui;

import org.cps.core.*;
import org.cps.data.*;
import javax.swing.*;
import org.cps.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class NumberOutput extends GUIComponent {
	public NumberOutput(DataGUI gui,String name,String target,String title,
						String units,String pre,int sig){//fix order
		super(gui,name,title==null?new String():title,Box.createHorizontalBox());
		if(target==null) target=new String();
		if(units==null) units=new String();
		if(pre==null) pre=new String();
		final String preAppend=pre;
		if(sig==0) sig=3;
		final int sigFigs=sig;

		final Variable v=(Variable)gui.getDataRoot().getVariable(target);
		if(v==null) throw new IllegalArgumentException("vairable "+target+" not found");
		final JLabel m=new JLabel();
		gui.bind(new ChangeListener(){
			public final void targetChanged(){
				if(sigFigs>0) m.setText(preAppend+CPSText.numToString(v.getValue(),sigFigs));
				else m.setText(preAppend+CPSText.decimalRound(v.getValue(),-sigFigs));
			}
		},v.getValueChange());
		Box b=(Box)getComponent();
		b.add(m);
		if(units!=null&&units.length()!=0) b.add(new JLabel(units));
	}
}