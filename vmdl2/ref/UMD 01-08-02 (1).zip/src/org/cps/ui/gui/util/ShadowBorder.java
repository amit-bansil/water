package org.cps.ui.gui.util;

import javax.swing.border.Border;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class ShadowBorder implements Border {

    public ShadowBorder(int n) {this.n=n; insets=new Insets(n,n,n,n); }
	private final int n;
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {

		x+=n-1;y+=n-1; height-=2*n;width-=2*n; height+=1; width+=1;

		g.setColor(c.getBackground().darker());
		g.drawLine(x+1,y+height,x+width,y+height);
		g.drawLine(x+width,y+1,x+width,y+height);
		g.drawLine(x+1,y+height+1,x+width+1,y+height+1);
		g.drawLine(x+width+1,y+1,x+width+1,y+height+1);

		g.drawRect(x,y,width-1,height-1);
    }
	private final Insets insets;
    public Insets getBorderInsets(Component c) {
        return insets;
    }
    public boolean isBorderOpaque() {
        return false;
    }
}