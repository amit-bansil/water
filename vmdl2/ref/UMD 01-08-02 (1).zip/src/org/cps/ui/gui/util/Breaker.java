package org.cps.ui.gui.util;

import java.awt.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public final class Breaker extends Component {
	private static final Dimension max=new Dimension(Short.MAX_VALUE,Short.MAX_VALUE),zero=new Dimension(0,0);
	public final Dimension getPreferredSize(){return zero;}
	public final Dimension getMinimumSize(){return zero;}
	public final Dimension getMaximumSize(){return max;}
	public final void paint(Graphics g){
		final int x=getSize().width,y=(getSize().height/2)+3;
		g.setColor(getBackground().darker());
		g.drawLine(0,y-2,x-2,y-2);
		g.setColor(getBackground().brighter());
		g.drawLine(1,y-1,x-1,y-1);
	}
    public Breaker() {
    }
}