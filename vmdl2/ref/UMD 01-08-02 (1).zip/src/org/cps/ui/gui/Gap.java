package org.cps.ui.gui;

import java.awt.*;
import javax.swing.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class Gap extends GUIComponent{
	public Gap(DataGUI gui,String name,int size){super(gui,name,Box.createRigidArea(new Dimension(size,size)));}
}