package org.cps.ui.gui;

import java.awt.*;
import java.lang.reflect.*;
import org.cps.core.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public abstract class GUIComponent extends CPSComponent{
	public GUIComponent(DataGUI gui,String name) {
		this(gui,name,null,null);
	}
	public GUIComponent(DataGUI gui,String name,String title) {
		this(gui,name,title,null);
	}
	public GUIComponent(DataGUI gui,String name,Component c) {
		this(gui,name,null,c);
	}
	public GUIComponent(DataGUI gui,String name,String title,Component c) {
		super(gui,name);
		this.title=title;
		this.c=c;
	}
	private final String title;
	protected final void setComponent(Component c){}
	private final Component c;
	public String getTitle(){return title;}
	public Component getComponent(){return c;}
}