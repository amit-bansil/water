package org.cps.ui.gui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */
import java.awt.event.*;
import javax.swing.*;
import org.cps.*;
import org.cps.core.*;
import org.cps.io.*;

public class FileMenu extends CPSMenu{
	private final IOManager iom;
	public static final int FILE_MENU_PRIORITY=0;
	private final JMenuItem save,close,reset,saveMovie,saveAs;
	public FileMenu(CPSGUI gui,IOManager io) {
		super(gui,FILE_MENU_PRIORITY,CPSText.trans("file menu title"));
		iom=io;

		final JMenuItem exit=(CPSText.createMenuItem("quit item"));
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getCore().getKernel().finish();
			}
		});
		exit.setIcon(CPSResources.getImageIcon("Exit16.gif"));

		close=(CPSText.createMenuItem("close item"));
		close.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iom.close();
			}
		});

		reset=(CPSText.createMenuItem("reload item"));
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iom.reload();
			}
		});
		reset.setIcon(CPSResources.getImageIcon("Reload16.gif"));
		final JMenuItem load=(CPSText.createMenuItem("load item"));
		load.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iom.load();
			}
		});
		load.setIcon(CPSResources.getImageIcon("Open16.gif"));

		saveMovie=(CPSText.createMenuItem("saveMovie item"));
		saveMovie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iom.saveMovie();
			}
		});
		saveMovie.setIcon(CPSResources.getImageIcon("Movie16.gif"));

		save=new JMenuItem("Save");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iom.save();
			}
		});
		save.setIcon(CPSResources.getImageIcon("Save16.gif"));

		saveAs=new JMenuItem("Save As...");
		saveAs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iom.saveAs();
			}
		});
		saveAs.setIcon(CPSResources.getImageIcon("SaveAs16.gif"));

		close.setIcon(CPSResources.getImageIcon("Close16.gif"));
		setLoaded(iom.isLoaded());
		iom.getLoadChange().addListener(loadListener);
		getMenu().add(load);
		getMenu().add(save);
		getMenu().add(saveAs);
		//getMenu().add(saveMovie); untested
		getMenu().add(reset);
		getMenu().add(close);
		getMenu().addSeparator();
		getMenu().add(exit);
	}
	private final ChangeListener loadListener=new ChangeListener(){
		public final void targetChanged(){
			if(actLoaded==iom.isLoaded())return;
			setLoaded(iom.isLoaded());
		}
	};

	public void componentAdded(CPSComponent c){
		setLoaded(true);
	}
	public void componentRemoved(CPSContainer c,CPSComponent l){
		setLoaded(false);
	}
	private boolean actLoaded;
	private final void setLoaded(boolean v){
		actLoaded=v;
		save.setEnabled(v);
		saveAs.setEnabled(v);
		saveMovie.setEnabled(v);
		close.setEnabled(v);
		reset.setEnabled(v);
	}
	public void finish(){
		iom.getLoadChange().removeListener(loadListener);
		super.finish();
	}
}