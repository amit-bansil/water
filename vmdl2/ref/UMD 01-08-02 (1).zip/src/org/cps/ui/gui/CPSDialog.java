package org.cps.ui.gui;

/**
 * Title:        Universal Molecular Dynamics
 * Description:  Universal Interface for Molecular Dynamics Simulations
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.1a
 */
import javax.swing.*;
import org.cps.core.*;
import org.cps.*;

public abstract class CPSDialog extends JDialog{
	private final CPSFrame frame;
	public CPSDialog(String name,CPSFrame frame) {
		super(frame.getParent(),name,true);
		this.frame=frame;
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	}
	public void pack(){
		super.pack();
		frame.centerComponent(this);
	}
}