package org.cps.ui.gui.util;
import org.cps.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import org.cps.gui.*;

public class SliderGroupEx extends JSlider{
	private final JLabel name, value;
	private double conversion=1;
	private final int sigFigs;

	public SliderGroupEx(String nme, String tip,final int figs){
		super();
		this.name=new JLabel(nme);
		this.sigFigs=figs;
		setToolTipText(tip);
		value=new JLabel("--");

		CPSGUIToolkit.lockSize(value);
		value.setForeground (java.awt.Color.black);
		addChangeListener(new ChangeListener(){
			public void stateChanged(ChangeEvent e) {
				value.setText(CPSText.numToString(getRealValue(),sigFigs));
			}
		});
		addPropertyChangeListener("enabled",new PropertyChangeListener(){
			public void propertyChange(PropertyChangeEvent evt){
				name.setEnabled(isEnabled());
				value.setEnabled(isEnabled());
			}
		});

	}
	public SliderGroupEx(String name,String tip,double max,double min,double conv,final int sigFigs){
		this(name,tip,sigFigs);
		setConversion(conv);
		setRealMaximum(max);
		setRealMinimum(min);
	}
	public void setLabel(String l){
		name.setText(l);
	}

	public void setRealValue(double v){
		super.setValue((int)(v*conversion));
		value.setText(CPSText.numToString(v,sigFigs));
	}
	public double getRealValue(){
		double x=((double)getValue())/conversion;
		if(x<min) x=min;
		else if(x>max) x=max;
		return x;
	}
	double max,min;
	public void setRealMaximum(double v){
		max=v;
		super.setMaximum((int)(v*conversion));
	}
	public void setRealMinimum(double v){
		min=v;
		super.setMinimum((int)(v*conversion));
	}
	public double getConversion(){
		return conversion;
	}
	public void setConversion(double v){
		conversion=v;
	}
	public JPanel getPanel(){
		JPanel sliderPanel= new JPanel();
		sliderPanel.setLayout(new GridBagLayout());
		GridBagConstraints gridBagConstraints2 = new java.awt.GridBagConstraints ();
		gridBagConstraints2.gridx = 0;
		gridBagConstraints2.gridy = 1;
		gridBagConstraints2.gridwidth = 2;
		gridBagConstraints2.fill = java.awt.GridBagConstraints.HORIZONTAL;
		gridBagConstraints2.anchor = java.awt.GridBagConstraints.NORTHEAST;
		gridBagConstraints2.weightx = 1.0;
		gridBagConstraints2.weighty = 1.0;
		sliderPanel.add(this, gridBagConstraints2);

		gridBagConstraints2 = new java.awt.GridBagConstraints ();
		gridBagConstraints2.gridx = 0;
		gridBagConstraints2.gridy = 0;
		gridBagConstraints2.insets = new java.awt.Insets (0, 6, 0, 6);
		gridBagConstraints2.weightx = 0.0;
		gridBagConstraints2.anchor = java.awt.GridBagConstraints.NORTHWEST;
		sliderPanel.add (name, gridBagConstraints2);

		gridBagConstraints2 = new java.awt.GridBagConstraints ();
		gridBagConstraints2.gridx =1;
		gridBagConstraints2.gridy = 0;
		gridBagConstraints2.weightx = 1.0;
		gridBagConstraints2.fill = java.awt.GridBagConstraints.NONE;
		gridBagConstraints2.insets = new java.awt.Insets (0, 6, 0, 12);
		gridBagConstraints2.anchor = java.awt.GridBagConstraints.NORTHEAST;
		sliderPanel.add (value, gridBagConstraints2);

		return sliderPanel;
	}
}