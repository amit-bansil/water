package org.cps.ui.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import org.cps.*;
import org.cps.core.*;
import org.cps.core.ChangeListener;
import org.cps.ui.*;

import org.cps.ui.gui.util.*;
import org.cps.umd.simulation.*;
import org.cps.util.*;
import java.util.Hashtable;
import org.cps.io.*;
import java.io.*;
import org.cps.data.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public final class DataGUI extends DynamicContainer{
	private final Box layout;
	private final ListContainer data;
	private final CPSGUI gui;
	private final UMDSimulation sim;
	public UMDSimulation getSimulation(){return sim;}
	private final PanelDescription panelDesc;
	private final DataRoot dataRoot;
	public DataGUI(final UMDSimulation sim,CPSGUI gui,DataRoot dataRoot) {
		super("Controls",sim);
		this.dataRoot=dataRoot;

		layout=Box.createVerticalBox();
		this.gui=gui;
		this.sim=sim;
		data=new ListContainer();

		layout.add(data);

		panelDesc=new PanelDescription(PanelDescription.TYPE_PRIMARY_CONTROL,layout);
		gui.addPanel(panelDesc);
		registerType(RunningControl.class,new Object[0]);
		registerType(Separator.class,new Object[]{new Integer(0)});
		registerType(NumberOutput.class,new Object[]{new String(),new String(),
				new String(),new String(),new Integer(4)});
		registerType(NumberInput.class,new Object[]{new String(),new String(),
				new String(),new Float(Float.MAX_VALUE),new Float(Float.MIN_VALUE),new float[]{0}});
		registerType(Gap.class,new Object[]{new Integer(6)});
		registerType(VariableGraph.class,new Object[0]);
	}
	public DataRoot getDataRoot(){return dataRoot;}

	public final void objectAdded(CPSComponent cx){
		String name=((GUIComponent)cx).getTitle();
		Component c=((GUIComponent)cx).getComponent();
		if(c==null){
			throw new IllegalArgumentException("must specify component");
		}else if(name==null){
			data.addComponent(c);
		}else{
			data.addComponent(name,c);
		}
	}
	public final void objectRemoved(CPSComponent cx){
		String name=((GUIComponent)cx).getTitle();
		Component c=((GUIComponent)cx).getComponent();
		data.removeComponent(c,name);
	}
	public final void finish(){
		gui.removePanel(panelDesc);
		unbindAll();
		super.finish();
	}

	private final void updateRunning(boolean v){}

	private final CPSVector changeLs=new CPSVector();
	private final CPSVector changeSups=new CPSVector();
	public void bind(ChangeListener l,ChangeSupport s){
		changeLs.add(l);
		changeSups.add(s);
		s.addListener(l);
		l.targetChanged();
	}
	private void unbindAll(){
		final ChangeSupport[] sups=(ChangeSupport[])changeSups.createArray(ChangeSupport.class);
		final ChangeListener[] ls=(ChangeListener[])changeLs.createArray(ChangeListener.class);
		for(int i=0;i<sups.length;i++) sups[i].removeListener(ls[i]);
	}
	public final void doFocus(){
		Component[] comps=data.getComponents();
		for(int i=0;i<comps.length;i++){
			if(comps[i] instanceof AbstractButton&&comps[i].isFocusable()){
				((AbstractButton)comps[i]).grabFocus();
			}
		}
	}

	static{
		MethodRegistry.registerMethod(DataGUI.class,"relayout","refresh the layout after changes have been made");
	}
	public static void classFinalize() throws Throwable {
		MethodRegistry.unregisterMethod("relayout");
	}
	public final void relayout(){
		layout.validate();
	}

	public void load(InputStream in)throws IOException{
		super.load(in);
		relayout();
	}
	private static final class ListContainer extends Container{
		public ListContainer(){
			setLayout(new GridBagLayout());
			lgbc.gridx=0;lgbc.anchor=lgbc.SOUTHWEST; lgbc.fill=lgbc.NONE;
			lgbc.gridheight=lgbc.gridwidth=1; lgbc.weightx=lgbc.weighty=0;
			lgbc.ipadx=lgbc.ipady=0; lgbc.insets=new Insets(0,0,0,3);
			vgbc.gridx=1;vgbc.anchor=vgbc.SOUTHEAST; vgbc.fill=vgbc.NONE;
			vgbc.gridheight=vgbc.gridwidth=1; vgbc.weightx=1; vgbc.weighty=0;
			vgbc.ipadx=vgbc.ipady=0; vgbc.insets=new Insets(0,3,0,0);
			vgbc.gridy=lgbc.gridy=y;
			cgbc.gridx=0;cgbc.anchor=cgbc.CENTER; cgbc.fill=cgbc.BOTH;
			cgbc.gridheight=1;cgbc.gridwidth=2; cgbc.weightx=1; cgbc.weighty=0;
			cgbc.ipadx=cgbc.ipady=0; cgbc.insets=new Insets(0,0,0,0);
		}
		private final GridBagConstraints lgbc=new GridBagConstraints();
		private final GridBagConstraints vgbc=new GridBagConstraints();
		private final GridBagConstraints cgbc=new GridBagConstraints();
		private int y=0;
		public final void addComponent(Component c){
			cgbc.gridy=y;
			add(c,cgbc);
			y++;
		}
		public final void addComponent(String name,Component v){
			lgbc.gridy=vgbc.gridy=y;
			JLabel n=new JLabel(name);
			names.put(name,n);
			add(n,lgbc);
			add(v,vgbc);
			y++;
		}
		private final Hashtable names=new Hashtable();
		public final void removeComponent(Component c,String name){
			if(name!=null){
				remove((JLabel)names.get(name));
				names.remove(name);
			}
			remove(c);
		}
	}
}