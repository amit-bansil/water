package org.cps.ui.gui.util;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import org.cps.ui.gui.DataGUI;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class CSpinnerNumberEditor extends JSpinner.NumberEditor {

    public CSpinnerNumberEditor(JSpinner spinner,final DataGUI gui) {
		super(spinner,"#######0.########");
		final JTextField f=getTextField();
		f.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount()==2) f.selectAll();

			}
		});
		f.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.getCaret().setVisible(false);
				gui.doFocus();
				f.setForeground(Color.black);
			}
		});

    }
}