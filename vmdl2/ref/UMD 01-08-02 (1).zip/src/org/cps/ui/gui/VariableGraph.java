package org.cps.ui.gui;

import java.awt.*;
import ptolemy.plot.*;
import org.cps.data.*;
import org.cps.core.*;
import org.cps.umd.simulation.*;
import org.cps.util.*;
import javax.swing.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class VariableGraph extends GUIComponent {
	private int curBuf=0;
	private double lastRescale=0,lastRedraw=0,yMin=Double.MAX_VALUE,yMax=Double.MIN_VALUE;
	private double lastMax=Double.NaN,lastMin=Double.NaN,lastT=Double.NaN;
	public VariableGraph(DataGUI gui,String name,String time,String[] targets,String[] legend, final float len,
						 final float rescale,final float redraw,String title,String yTitle,String xTitle,boolean yLog,
						 final double yMax0,final double yMin0,int xSize,int ySize){
		super(gui,name,new JPanel(new BorderLayout()));

		if(yMax0>yMin0){
			yMin=yMin0;
			yMax=yMax0;
		}

		final Variable[] v=new Variable[targets.length];
		for(int i=0;i<v.length;i++){
			v[i]=gui.getDataRoot().getVariable(targets[i]);
			if(v[i]==null) throw new IllegalArgumentException("variable "+targets[i]+" not found");
		}

		final Variable t=gui.getDataRoot().getVariable(time);
		if(t==null) throw new IllegalArgumentException("variable "+time+" not found");
		final Plot plot=new Plot();

		if(xSize>0&&ySize>0) plot.setSize(new Dimension(xSize,ySize));
		if(title!=null&&title.length()!=0) plot.setTitle(title);
		if(xTitle!=null&&xTitle.length()!=0) plot.setXLabel(xTitle);
		if(yTitle!=null&&yTitle.length()!=0) plot.setYLabel(yTitle);

		//plot.setXPersistence(len);
		plot.setConnected(true);
		plot.setMarksStyle("none");

		plot.setGrid(true);
		plot.setXRange(0,len);
		plot.setYLog(yLog);
		//plot.setWrap(true);
		plot.setBackground(Color.LIGHT_GRAY);
		final UMDSimulation sim=gui.getSimulation();

		final CPSVector tBuf=new CPSVector();
		final CPSVector[] vBuf=new CPSVector[v.length];
		for(int i=0;i<vBuf.length;i++)vBuf[i]=new CPSVector();

		final float[] lastYs=new float[vBuf.length];
		for(int i=0;i<lastYs.length;i++) lastYs[i]=Float.NaN;

		gui.getSimulation().getChange().addListener(new ChangeListener(){
			public final void targetChanged(){
				double ta=t.getValue(),te=sim.getTimeData().getElapsedTime();
				if(lastT!=ta){
					lastT=ta;
					tBuf.add(new Float(ta));
					for(int i=0;i<vBuf.length;i++){
						vBuf[i].add(new Float(v[i].getValue()));
					}
				}
				if(te>=lastRedraw+redraw){
					lastRedraw=te;
					if(!tBuf.isEmpty()){
						final Float[][] vBufa=new Float[vBuf.length][tBuf.size()];
						final Float[] tBufa=new Float[tBuf.size()];
						tBuf.fill(tBufa); tBuf.clear();
						for(int i=0;i<vBufa.length;i++){
							vBuf[i].fill(vBufa[i]); vBuf[i].clear();
						}
						for(int i=0;i<tBufa.length;i++){
							float x=tBufa[i].floatValue();
							for(int n=0;n<vBufa.length;n++){
								float y=vBufa[n][i].floatValue();
								if(y!=lastYs[n]){
									lastYs[n]=y;
									if(y>yMax) yMax=y;
									if(y<yMin) yMin=y;
									plot.addPoint(n,x,y,true);
								}
							}
						}
					}
				}
				if(te>=lastRescale+rescale){
					lastRescale=te;

					if(lastMax!=yMax||lastMin!=yMin){
						plot.setYRange(yMin,yMax);
						lastMax=yMax;
						lastMin=yMin;
						plot.repaint();
					}
				}
			}
		});

		if(legend!=null){
			for(int i=0;i<legend.length;i++){
				plot.addLegend(i,legend[i]);
			}
		}
		((JPanel)getComponent()).add(plot);
	}
}