package org.cps.ui.gui;

import java.awt.*;
import org.cps.core.*;
import javax.swing.*;
import org.cps.ui.gui.util.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class Separator extends GUIComponent {
	public Separator(DataGUI gui,String name,String title){
		super(gui,name,Box.createHorizontalBox());
		Box c=(Box)getComponent();
		final JLabel l=new JLabel(title);
		final Font f=UIManager.getFont("Label.font");
		//todo:use a ui and do this right
		l.setFont(new Font(f.getName(),Font.BOLD,f.getSize()));
		c.add(l);
		c.add(Box.createRigidArea(new Dimension(3,3)));
		c.add(new Breaker());
	}
}