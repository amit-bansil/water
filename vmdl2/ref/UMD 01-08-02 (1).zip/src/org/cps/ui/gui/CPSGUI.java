package org.cps.ui.gui;

/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */
import org.cps.ui.*;
import org.cps.core.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import org.cps.util.*;
import org.cps.*;
import org.cps.data.gui.*;

public final class CPSGUI extends CPSContainer implements CPSUI{
	private CPSFrame frame;
	//prompts
	private final GUIPrompts prompts;
	public Object prompt(PromptDescription p){
		return prompts.prompt(p);
	}
	//message
	public void message(String title,String message){
		JOptionPane.showMessageDialog(frame.getParent(),message,title,JOptionPane.INFORMATION_MESSAGE);
	}
	//redraw
	public void redraw(){
		frame.getParent().setVisible(true);
		frame.getParent().repaint();
	}
	//cursors
	private int waitState=0;
	public void stopWaiting(){
		if(waitState<1) throw new IllegalArgumentException("cannot stop waiting before starting");
		waitState--;
		if(waitState==0) frame.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}
	public void startWaiting(){
		waitState++;
		frame.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
	}
	//progress
	private ProgressDescription description=null;
	private CPSProgressMonitor currentMonitor=null;
	public void addProgressMonitor(ProgressDescription description){
		if(this.description!=null){
			throw new IllegalStateException("This implementation only supports "+
					"one progress monitor at a time [current="
	                +this.description+",new="+description);
		}
		this.description=description;
		currentMonitor=new CPSProgressMonitor(description.getTitle(),
				description.getEndTime(),description.getWait(),
				description.getListener(),frame);
	}
	public void removeProgressMonitor(ProgressDescription description){
		if(this.description!=description){
			throw new IllegalArgumentException("cannot remove progress monitor "
					+description+"because is has not been added, current="+
	                this.description);
		}
		this.description=null;
		currentMonitor.done();
		currentMonitor=null;
	}
	//panel
	public void addPanel(PanelDescription desc){
		final Component c=desc.getPanel();
		switch(desc.getType()){
			case PanelDescription.TYPE_MAIN:
				setMain(c);
				break;
			case PanelDescription.TYPE_PRIMARY_CONTROL:
				addControlPanel(c,desc.getPriority());
				break;
			case PanelDescription.TYPE_MINOR_CONTROL:
				setBottomControl(c);
				break;
			default:
				throw new IllegalArgumentException("type "+desc.getType()+" not supported");//unsupported op not avail 1.1
		}
	}
	public void removePanel(PanelDescription desc){
		final Component c=desc.getPanel();
		switch(desc.getType()){
			case PanelDescription.TYPE_MAIN:
				removeMain();
				break;
			case PanelDescription.TYPE_PRIMARY_CONTROL:
				removeControlPanel(c);
				break;
			case PanelDescription.TYPE_MINOR_CONTROL:
				removeBottomControl();
				break;
			default:
				throw new IllegalArgumentException("type "+desc.getType()+" not supported");//unsupported op not avail 1.1
		}
	}
	//visible
	public void setVisible(boolean v){
		frame.getParent().setVisible(v);
	}
	public final void finish(){
		frame.setWindowClosingListener(null);
		frame.setJMenuBar(null);
		frame.getContentPane().remove(containerHolder);

		frame.finish();
		super.finish();
	}
	public CPSFrame getFrame(){
		return frame;
	}
	public CPSGUI(final CPSCore parent) {
		super(parent.getRootComponent());

		frame=new CPSFrame();
		frame.setTitle(CPSApplicationDescription.TITLE);

		frame.setWindowClosingListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				getCore().getKernel().finish();
			}
		});
		bar=new JMenuBar();
		bar.setVisible(false);
		frame.setJMenuBar(bar);

		prompts=new GUIPrompts(frame);
		containerHolder.setBorder(BorderFactory.createEmptyBorder(12,12,12,2));
		containerHolder.setLayout(new BorderLayout(0,0));
		containerHolder.setVisible(false);

		mainHolder.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
		mainHolder.setLayout(new BorderLayout(0,0));
		mainHolder.setVisible(false);

		JPanel c=new JPanel(new BorderLayout(0,0));
		c.add(containerHolder,BorderLayout.WEST);
		c.add(mainHolder,BorderLayout.CENTER);

		frame.setContentPane(c);
	}
	private final JMenuBar bar;
	private final PrioritizedList menus=new PrioritizedList()
									 ,controlPanels=new PrioritizedList();
	private Component bottom=null;
	private final JPanel containerHolder=new JPanel(),mainHolder=new JPanel();
	private Component main;
	private final Box containerSubHolder=Box.createVerticalBox();
	private void addControlPanel(Component c,float priority){//for now only supports one component!
		if(controlPanels.getObjects().length==0&&bottom==null){
			containerHolder.setVisible(true);
		}
		controlPanels.add(c,priority);
		Object[] temp=controlPanels.getObjects();
		containerHolder.removeAll();
		containerSubHolder.removeAll();
		containerHolder.add((Component)temp[0],BorderLayout.NORTH);//quick hack since we always have only one component
		for(int i=1;i<temp.length;i++){
			containerSubHolder.add(Box.createRigidArea(new Dimension(6,6)));
			containerSubHolder.add((Component)temp[i]);
		}
		containerHolder.add(containerSubHolder,BorderLayout.CENTER);
		//containerHolder.add(Box.createVerticalGlue(),BorderLayout.CENTER);
		if(bottom!=null)containerHolder.add(bottom,BorderLayout.SOUTH);
		containerSubHolder.setVisible(true);
		frame.getParent().validate();
	}
	private void removeBottomControl(){
		if(bottom==null){
			throw new IllegalStateException("cannot remove nonadded bottom control");
		}
		containerHolder.remove(bottom);
		bottom=null;
		if(controlPanels.getObjects().length==0)
			containerHolder.setVisible(false);
	}
	private void setBottomControl(Component c){
		if(bottom!=null){
			throw new IllegalStateException("cannot have multiple bottom controls");
		}
		if(controlPanels.getObjects().length==0)
			containerHolder.setVisible(true);
		bottom=c;
		containerHolder.add(bottom,BorderLayout.SOUTH);
	}

	private void removeControlPanel(Component c){
		if(CPS.isDebug()&&!controlPanels.contains(c)){
			throw new IllegalArgumentException("cannot remove unadded control");
		}
		containerSubHolder.remove(c);
		controlPanels.remove(c);
		if(controlPanels.getObjects().length==0&&bottom==null)
			containerHolder.setVisible(false);
	}

	public void addMenu(JMenu m,float priority){
		if(menus.getObjects().length==0)
			bar.setVisible(true);

		menus.add(m,priority);
		Object[] temp=menus.getObjects();
		bar.removeAll();
		for(int i=0;i<temp.length;i++)
			bar.add((JMenu)temp[i]);
	}
	public void removeMenu(JMenu m){
		if(CPS.isDebug()&&!menus.contains(m)){
			throw new IllegalArgumentException("cannot remove menu "+m+
					"because it has not yet been added");
		}
		bar.remove(m);
		menus.remove(m);
		if(menus.getObjects().length==0)
			bar.setVisible(false);
	}
	private void setMain(Component c){
		if(main!=null){
			throw new IllegalStateException("only one main panel is allowed at a time");
		}
		main=c;
		mainHolder.add(main);
		mainHolder.setVisible(true);
	}
	private void removeMain(){
		if(main==null){
			throw new IllegalStateException("no main panel to remove");
		}
		mainHolder.remove(main);
		main=null;
		mainHolder.setVisible(false);
	}
}