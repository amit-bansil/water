package org.cps.ui.gui.util;

import javax.swing.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

import java.util.*;
import java.io.Serializable;
//lost of potential for optimizing this class...
public class SpinnerFloatArrayModel extends SpinnerNumberModel implements Serializable
{
	private static final float calcMax(float[] values){
		float ret=Float.MIN_VALUE;
		for(int i=0;i<values.length;i++) if(values[i]>ret) ret=values[i];
		return ret;
	}
	private static final float calcMin(float[] values){
		float ret=Float.MAX_VALUE;
		for(int i=0;i<values.length;i++) if(values[i]<ret) ret=values[i];
		return ret;
	}
	private static final float calcDelta(float[] values){
		return (calcMax(values)-calcMin(values))/values.length;
	}
	public void setMinimum(Comparable minimum){throw new IllegalArgumentException("op not supported");}
	public void setMaximum(Comparable minimum){throw new IllegalArgumentException("op not supported");}
	public void setStepSize(Number stepSize){throw new IllegalArgumentException("op not supported");}
	public Number getNumber() {return (Number)getValue();}

	private final float[] values;
	private final int len;
	private final int determineCur(){
		final float value=getNumber().floatValue();
		for(int i=0;i<values.length;i++)if(value<=values[i]) return i;
		return values.length-1;
	}
	public SpinnerFloatArrayModel(float[] values,float value) {
		this(values,value,calcMax(values),calcMin(values));
	}
	public SpinnerFloatArrayModel(float[] values,float value,float max,float min) {
		super(value,min,max,calcDelta(values));
		len=values.length;
		this.values=(float[])values.clone();
		Arrays.sort(this.values);
		determineCur();
	}

	public Object getNextValue() {

		int cur=determineCur();
		if(values[cur]==getNumber().floatValue()){cur++; if(cur>=len) return null;}
		return new Float(values[cur]);
	}
	public Object getPreviousValue() {
		int cur=determineCur();
		cur--;
		if(cur<0) return null;
		else return new Float(values[cur]);
	}
}
