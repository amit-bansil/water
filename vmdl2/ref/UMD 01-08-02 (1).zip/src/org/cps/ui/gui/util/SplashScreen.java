package org.cps.ui.gui.util;
import java.awt.*;
/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */
import javax.swing.*;
import org.cps.*;
import org.cps.gui.*;


public final class SplashScreen extends JWindow{

	private final Image splash;
	private String state;
	private String stateLine2;
	private String stateLine3;
	private static final int BASE=13;
	private static final Color borderColor=new Color(84,107,161);
	private static final Font stateFont=new Font("Sans Serif",Font.PLAIN,10);
	boolean justText=false;
	public SplashScreen(String text){
		splash = CPSResources.getImage(CPSApplicationDescription.TITLE_SHORT+"_splash");

		int w=splash.getWidth(this),h=splash.getHeight(this);
		setSize(w,h+(BASE-1));

		state=text;

		CPSGUIToolkit.centerComponent(this);

		setVisible(true);
	}

	public void update(Graphics g){
		paint(g);
	}
	public void paint(Graphics g){
		if(!justText)
		g.drawImage(splash,0,0,this);
		justText=false;
		int width=getSize().width;
		int height=getSize().height;
	/*try{
		Graphics2D g2d=(Graphics2D)g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
	}catch(ClassCastException e){
	}*///not 1.1 safe

		g.setFont(stateFont);
		g.setColor(borderColor);
		g.drawLine(0,0,0,height);
		g.drawLine(0,0,width,0);
		g.drawLine(width-1,0,width-1,height);
		g.drawLine(1,1,1,height-1);
		g.drawLine(1,1,width-1,1);
		g.drawLine(width-2,1,width-2,height-1);
		g.fillRect(0,height-BASE,width,BASE);
		g.setColor(Color.black);
		g.drawString(state,2,height-4);

	}
}