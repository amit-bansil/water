package org.cps.ui.gui;
import org.cps.*;
import javax.swing.*;

public final class PromptDialog{
	public static final float forceFloat(
			String title,String prompt,float def,CPSFrame frame){
		return forceFloat(
				prompt,title,Float.NEGATIVE_INFINITY,Float.POSITIVE_INFINITY,
			def,frame);
	}
	public static final float forceFloat(String title,String prompt,
			float min,float max,float def,CPSFrame frame){
		while(true){
			try{
				float ret=promptFloat(title,prompt,min,max,def,frame);
				if(Float.isNaN(ret)) return def;
				else return ret;
			}catch(InvalidInputException e){
			}
		}
	}
	public static final float promptFloat(String title,String prompt,float min,
			float max,float def,CPSFrame frame)throws InvalidInputException{
		if(CPS.isDebug()){
			if(min>max) throw new IllegalStateException("min>max");
			if(def>max) throw new IllegalStateException("default>max");
			if(def<min) throw new IllegalStateException("default<min");
		}

		float ret=promptFloat(title,prompt,def,frame);
		if(ret>max||ret<min){
			JOptionPane.showMessageDialog(frame.getParent(),
				CPSText.trans("input outofbounds")+" "+max+" "+CPSText.trans("and")+" "+min+".",
				CPSText.trans("input error"),JOptionPane.WARNING_MESSAGE);
			throw new InvalidInputException();
		}else return ret;
	}
	//use Float.NaN to specify no initial value
	//returns Float.NaN to specify canceling
	public static final float promptFloat(String title,String prompt,float initial,CPSFrame frame)throws InvalidInputException{
		try{
			Object initialObj=Float.toString(initial);
			if(Float.isNaN(initial)) initialObj=new String();
			Object ret=JOptionPane.showInputDialog(
					frame.getParent(),
					prompt, title,
					JOptionPane.INFORMATION_MESSAGE, null,
					null,initialObj);
				if(ret==null) return Float.NaN;
				else return Float.parseFloat((String)ret);
			}catch(NumberFormatException e){
			JOptionPane.showMessageDialog(frame.getParent(),
				CPSText.trans("invalid input"),
				CPSText.trans("input error"),JOptionPane.WARNING_MESSAGE);
			throw new InvalidInputException();
		}
	}
}