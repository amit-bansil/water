package org.cps.ui.gui;

import org.cps.data.*;
import org.cps.ui.gui.util.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import org.cps.core.ChangeListener;
import java.awt.Dimension;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class NumberInput extends GUIComponent{

	public NumberInput(DataGUI parent,String name,String target,String title,String units,float max,float min,float[] presets){//name units target max [presets] min
		super(parent,name,title,Box.createHorizontalBox());
		final InputVariable v=(InputVariable)parent.getDataRoot().getInput(target);
		final JSpinner s=new JSpinner();
		float curV=v.getValue();
		s.setModel(new SpinnerFloatArrayModel(presets,curV,max,min));
		s.setEditor(new CSpinnerNumberEditor(s,parent));
		parent.bind(new ChangeListener(){
			public final void targetChanged(){
				s.setValue(new Double(v.getValue()));
			}
		},v.getValueChange());
		s.addChangeListener(new javax.swing.event.ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				v.changeValue(((Number)s.getValue()).floatValue());
			}
		});
		s.setValue(new Float(curV));

		v.changeValue(curV);

		((JSpinner.DefaultEditor)s.getEditor()).getTextField().setColumns(5);

		Box b=(Box)getComponent();
		b.add(s);
		b.add(Box.createRigidArea(new Dimension(2,2)));
		b.add(new JLabel(units));
	}
}