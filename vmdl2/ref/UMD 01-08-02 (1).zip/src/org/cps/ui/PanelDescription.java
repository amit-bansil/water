package org.cps.ui;
import java.awt.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class PanelDescription {

	public static final int TYPE_MAIN=1,TYPE_SECONDARY_CONTROL=2,TYPE_PRIMARY_CONTROL=3,
	TYPE_FREE=3,TYPE_MAIN_CONTROL=4,TYPE_FREE_CONTROL=5,TYPE_MINOR_CONTROL=6;

	private final String title,descirption;
	private final int type,priority;
	private final Component panel;
	public PanelDescription(int type, Component panel) {
		this(type,null,null,0,panel);
	}
	public PanelDescription(int type,String title,String descirption,int priority,
							 Component panel) {
		this.type=type;
		this.panel=panel;
		this.title=title;
		this.descirption=descirption;
		this.priority=priority;
	}
	public final Component getPanel(){return panel;}
	public final int getType(){return type;}
	public final int getPriority(){return priority;}
	public final String getTitle(){return title;}
	public final String getDescirption(){return descirption;}
}