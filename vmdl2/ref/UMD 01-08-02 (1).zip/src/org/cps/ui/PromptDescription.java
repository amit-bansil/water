package org.cps.ui;
import java.io.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class PromptDescription {
	private final String prompt;
	public final String getPrompt(){return prompt;}

    public PromptDescription(String prompt) {
		this.prompt=prompt;
    }
	public static class FileOpenPrompt extends PromptDescription{
		private final FilenameFilter filter;
		public FileOpenPrompt(String prompt,FilenameFilter filter){
			super(prompt);
			this.filter=filter;
		}
		public final FilenameFilter getFilter(){return filter;}
	}
	public static final class FileSavePrompt extends FileOpenPrompt{
		private final String extension;
		public FileSavePrompt(String prompt,String extension,FilenameFilter filter){
			super(prompt,filter);
			this.extension=extension;
		}
		public final String getExtension(){return extension;}
	}
	public static class StringPrompt extends PromptDescription{
		private final String title;
		public StringPrompt(String prompt,String title){
			super(prompt);
			this.title=title;
		}
		public String getTitle(){return title;}
	}
	public static final class ListPrompt extends StringPrompt{
		private final String[] choices;
		public ListPrompt(String[] choices,String prompt,String title){
			super(prompt,title);
			this.choices=choices;
		}
		public String[] getChoices(){
			return choices;
		}
	}
	public static final class NumberPrompt extends StringPrompt{

		private final float def,max,min;
		public NumberPrompt(String prompt,String title){
			this(prompt,title,Float.POSITIVE_INFINITY,Float.NEGATIVE_INFINITY);
		}
		public NumberPrompt(String prompt,String title,float max,float min){
			this(prompt,title,max,min,Float.NaN);
		}
		public NumberPrompt(String prompt,String title,float max,float min,float def){
			super(prompt,title); this.def=def;this.max=max;this.min=min;
		}

		public float getMax(){return max;}
		public float getMin(){return min;}
		public float getDefault(){return def;}
	}
}