package org.cps.ui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public interface CPSUI {
	public Object prompt(PromptDescription description);
	public void message(String title,String message);
	public void redraw();
	public void startWaiting();
	public void stopWaiting();
	public void addProgressMonitor(ProgressDescription description);
	public void removeProgressMonitor(ProgressDescription description);
	public void addPanel(PanelDescription panel);
	public void removePanel(PanelDescription panel);
	public void setVisible(boolean v);
}