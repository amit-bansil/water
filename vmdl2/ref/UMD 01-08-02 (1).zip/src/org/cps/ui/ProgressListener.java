package org.cps.ui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */

public interface ProgressListener {
	public double getProgress();
	public void cancel();
}