/**
 * Center For Polymer Studies static utility class.
 */
package org.cps;

/**
 * Application wide constants.
 * @author Amit Bansil
 * @version 1.0
 */

public final class CPS {
	/**
	 * The package name. a convenience field to avoid making RMI calls.
	 */
	public static final String PACKAGE_NAME="org.cps";
	/**
	 * The name for the framework. Always "CPS", short for Center for Polymer Studies".
	 */
	public static final String FRAMEWORK_NAME="CPS";

	/**
	 * Initialises CPS services.
	 */
	public static final void initialize(){
	}

	/**
	 * Finishes CPS services.
	 */
	public static final void finish(){//remember order!
		CPSConfiguration.finish();
		CPSErrors.finish();
	}

	private static final boolean debug=CPSConfiguration.getBooleanSystemProperty("isDebug",true);
	/**
	 * Flag to turn debugging on or off.
	 * By default on, set by the system parameter CPS_isDebug.
	 * Returns a constant.
	 * Disabling debugging will improve performance, but errors may not be reported.
	 * @return whether or not to debug
	 */
	public static final boolean isDebug(){
		return debug;
	}

}