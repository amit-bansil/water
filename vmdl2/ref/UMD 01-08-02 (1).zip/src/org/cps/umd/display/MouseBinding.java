package org.cps.umd.display;

import org.cps.core.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import org.cps.*;
import java.io.*;
import org.cps.umd.core.*;
import org.cps.util.*;
import org.cps.umd.display.Binding.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public final class MouseBinding extends DataModel{
	private Binding binding;
	private boolean pressed=false;
	private int ax,ay,mx,my;
	private CPSVector pressedComponents=new CPSVector();
	private boolean running=false;
	private final UMDDisplay display;
	private final MouseListener mouseListener=new MouseAdapter() {
		public void mousePressed(MouseEvent e) {
			if(binding==null||pressed||display.getCamera()==null) return;
			running=true;
			ax=e.getX(); ay=e.getY();
			mx=0; my=0;
			synchronized(display.getCamera()){
				binding.anchor();
			}
			pressed=true;
			((Component)e.getSource()).setCursor(binding.getActiveCursor());
			pressedComponents.add(e.getSource());
		}
		public void mouseReleased(MouseEvent e) {
			if(binding==null||!pressed) return;
			running=false;
			mx=ax-e.getX();
			my=ay-e.getY();
			((Component)e.getSource()).setCursor(binding.getNormalCursor());
			pressedComponents.remove(e.getSource());
			if(pressedComponents.isEmpty()) pressed=false;
		}
	};
	private final MouseMotionListener mouseMotionListener=new MouseMotionAdapter(){
		public void mouseDragged(MouseEvent e) {
			if(binding==null||!pressed) return;
			mx=ax-e.getX();
			my=ay-e.getY();
		}
	};

	public final void update(){
		if(running){
			synchronized(display.getCamera()){
				binding.move(mx,my);
			}
		}
	}


	public final void finish(){
		running=false;

		target.removeMouseListener(mouseListener);
		target.removeMouseMotionListener(mouseMotionListener);
		super.finish();
	}

	private final StringProperty mode;
	private final StringArrayProperty modes;

	private final Component target;
	public static final String MODE="mode",MODES="modes";
	public MouseBinding(UMDDisplay display,Component target) {
		super(display,"MouseBinding");
		this.display=display;
		final Hashtable table=new Hashtable();
		table.put("Pan",new PanBinding(display));
		table.put("Scale",new ScaleBinding(display));
		table.put("None",new EmptyBinding(display));
		table.put("Rotate",new RotateBinding(display));

		mode=new StringProperty(this,MODE,"Rotate");
		binding=new RotateBinding(display);

		modes=new StringArrayProperty(this,MODES,new String[]{"Pan","Scale","None","Rotate"});
		modes.setReadOnly(true);
		modes.bindContains(mode);

		this.target=target;

		target.addMouseListener(mouseListener);
		target.addMouseMotionListener(mouseMotionListener);
		target.setCursor(binding.getNormalCursor());

		mode.getChange().addListener(new ChangeListener(){
			public void targetChanged(){
				binding=(Binding)table.get(mode.getStringValue());
				MouseBinding.this.target.setCursor(binding.getNormalCursor());

				if(pressed){
					MouseBinding.this.target.setCursor(binding.getActiveCursor());
				}
			}
		});
	}
}