package org.cps.umd.display;

import org.cps.core.*;
import java.io.*;
import org.cps.*;
import org.cps.umd.core.*;
import java.awt.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public abstract class CameraData extends DataModel {
	protected abstract int getDimensions();

	private float sWidth,sHeight;
	protected float getViewScale(){
		if(sWidth/sHeight>actRatio){
			return sHeight/eHeight;
		}else{
			return sWidth/eWidth;
		}

	}
	protected float getWidth(){return sWidth;}
	protected float getHeight(){return sHeight;}
	protected float getViewTranslateX(){
		return sWidth/2f+pan.getXValue();
	}
	protected float getViewTranslateY(){
		return sHeight/2f+pan.getYValue();
	}
	//aspectratio
	private float eWidth,eHeight;
	private float actRatio;

	private boolean prepared=false;
	private boolean spinning=false;
	private final UMDDisplay display;
	protected final FloatProperty.Bound scale;
	protected final FloatProperty internalScale;
	protected final FloatArrayProperty.A3D translation;
	protected final FloatArrayProperty.A2D aspectRatio;
	protected final FloatArrayProperty.A2D pan;
	protected final FloatArrayProperty.A2D rotation;
	protected final FloatArrayProperty.A2D spin;
	protected final IntProperty zMax,zMin;

	public static final String SCALE="scale",INTERNAL_SCALE="internalScale",
	ASPECT_RATIO="aspectRatio",PAN="pan",ROTATION="rotation",TRANSLATION="translation",
	SPIN="spin";
	public static final float MAX_SCALE=1600.0f,MIN_SCALE=1.0f;
	protected CameraData(UMDDisplay display,float defaultInternalScale) {
		super(display,"Camera Data");
		this.display=display;
		prepared=false;
		scale=new FloatProperty.Bound(this,SCALE,100.0f,MAX_SCALE,MIN_SCALE);
		internalScale=new FloatProperty(this,INTERNAL_SCALE,defaultInternalScale);
		translation=new FloatArrayProperty.A3D(this,TRANSLATION,0,0,0);
		eWidth=300; eHeight=300;
		actRatio=eWidth/eHeight;
		aspectRatio=new FloatArrayProperty.A2D(this,ASPECT_RATIO,eWidth,eHeight);

		zMax=new IntProperty(this,"zMax",Integer.MAX_VALUE);
		zMin=new IntProperty(this,"zMin",Integer.MIN_VALUE);

		pan=new FloatArrayProperty.A2D(this,PAN,0,0);
		rotation=new FloatArrayProperty.A2D(this,ROTATION,0.0f,0.0f);
		spin=new FloatArrayProperty.A2D(this,SPIN,0,0);
		spin.getChange().addListener(new ChangeListener(){
			public final void targetChanged(){
				float[] s=spin.getFloatArrayValue();
				boolean spun=false;
				for(int i=0;i<s.length;i++) if(s[0]!=0){ spun=true; break;}
				spinning=spun;
			}
		});
		getChange().addListener(new ChangeListener(){
			public final void targetChanged(){
				prepared=false;
			}
		});

	}

	public final void setSize(Dimension size){
		//synchronized(this){
			if(size.width!=sWidth||size.height!=sHeight){
				sWidth=size.width;
				sHeight=size.height;
			}
			getChange().setChanged();
		//}
	}
	public final void checkSpin(){
		if(spinning){
			boolean spun=false;
			float[] s=spin.getFloatArrayValue();
			for(int i=0;i<s.length;i++) if(s[0]!=0){ spun=true; break;}
			if(spun){
				prepared=false;
				float[] r=rotation.getFloatArrayValue();
				for(int i=0;i<r.length;i++) r[i]+=s[i];
				rotation.setFloatArrayValue(r);
			}
		}
	}
	public final boolean isPrepared(){return prepared;}
	private int zMinv=Integer.MAX_VALUE,zMaxv=Integer.MIN_VALUE;
	public int getZMin(){return zMinv;}
	public int getZMax(){return zMaxv;}

	public final void prepare(){
		if(!prepared){
			//synchronized(this){
			zMaxv=zMax.getIntValue();
			zMinv=zMin.getIntValue();
			eWidth=aspectRatio.getXValue();
			eHeight=aspectRatio.getYValue();
			actRatio=eWidth/eHeight;
			doPrepare();
			prepared=true;
			//}
		}
	}
	protected abstract void doPrepare();
	public abstract void transform(final float x,final float y,final float z,final int[] result);
	public abstract void transform(final float[] in,final int length,final int dstOff,
								final int[] xo,final int[] yo,final int[] zo,
								final float[] radii,final int[] scaledRadii);
}