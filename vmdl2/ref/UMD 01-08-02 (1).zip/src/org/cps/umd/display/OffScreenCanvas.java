package org.cps.umd.display;
import java.awt.*;
import java.awt.event.*;
import org.cps.CPSErrors;
import javax.swing.*;
/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */

public class OffScreenCanvas extends Canvas{
	private Image backbuffer;
	private Graphics backGraphics;
	private int curWidth,curHeight;
	private boolean needsResize,needsRedraw;
	public OffScreenCanvas() {
		backbuffer=null;
		needsResize=true;
		needsRedraw=true;

		addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				needsResize=true;
			}
		});
	}
	public void update(final Graphics g){
		paint(g);
	}
	public void paint(final Graphics g){
		final Dimension size=getSize();
		if(backbuffer!=null){
			g.drawImage(backbuffer,
				(size.width-curWidth)/2,
				(size.height-curHeight)/2,
				curWidth,curHeight,null);
		}else{g.setColor(getBackground()); g.fillRect(0,0,size.width,size.height);}
	}
	public void doRepaint(){
		Graphics g=getGraphics();
		paint(g);
		//repaint();
		g.dispose();
	}
	public boolean resizeOffscreen(){
		final int width=getSize().width,height=getSize().height;
		needsResize=false;
		needsRedraw=true;
		if(backbuffer!=null){
			backbuffer.flush();
			backGraphics.dispose();
		}
		backbuffer=null;
		curWidth=width;
		curHeight=height;
		try{
			backbuffer=getGraphicsConfiguration().createCompatibleVolatileImage(width,height,new ImageCapabilities(true));
			//not avail in 1.1 so just
		//	backbuffer=createImage(width,height);
		}catch(AWTException e){
			CPSErrors.unknownError(e);
		}
		backGraphics=backbuffer.getGraphics();
		return true;
	}

	public Graphics getOffGraphics(){
		return backGraphics;
	}
	public boolean needsRedraw(){
		return needsRedraw;
	}
	public boolean isDrawable(){
		return isVisible();
	}
	public void noteRedrawn(){
		needsRedraw=false;
	}
	public boolean needsResize(){
		return needsResize;
	}
	public void finish(){
		if(backbuffer==null) return;
		backbuffer.flush();
		backbuffer=null;
		backGraphics.dispose();
		needsResize=true;
		needsRedraw=true;
		repaint();
	}
}