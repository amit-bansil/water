package org.cps.umd.gui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import org.cps.*;
import org.cps.io.*;
import org.cps.core.*;
import org.cps.ui.gui.*;
import org.cps.umd.simulation.*;
import java.io.*;
import java.util.Hashtable;

public final class ConfigurationMenu extends CPSMenu{//move to CPS
	private final JMenu load,save,edit;
	private final JMenuItem call;
	public static final int CONFIG_MENU_PRIORITY=TimeMenu.TIME_MENU_PRIORITY+1;
	private final ConfigurationManager manager;
	private final ChangeListener ccl;
	public ConfigurationMenu(final CPSGUI gui,final ConfigurationManager m) {
		super(gui,CONFIG_MENU_PRIORITY,"Configuration");
		m.addDependant(this);
		this.manager=m;
		final JMenu menu=getMenu();
		ccl=new ChangeListener(){
			public final void targetChanged(){
				menu.setVisible(getCore().getIO().isLoaded());
			}
		};
		ccl.targetChanged();
		getCore().getIO().getLoadChange().addListener(ccl);

		call=new JMenuItem("Call");
		call.setAccelerator(KeyStroke.getKeyStroke("control ENTER"));
		call.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
					ScriptRunner.execute(getCore().getEventQueue(),
							JOptionPane.showInputDialog(gui.getFrame().getParent(),
							"Enter Command:","Call",JOptionPane.QUESTION_MESSAGE));
				}catch(Throwable ex){
					CPSErrors.record(ex);
				}
			}
		});
		call.setIcon(CPSText.emptyIcon);
		load=new JMenu("Import");
		save=new JMenu("Export");
		edit=new JMenu("Edit...");
		edit.setIcon(CPSResources.getImageIcon("edit"));
		load.setIcon(CPSResources.getImageIcon("import"));
		save.setIcon(CPSResources.getImageIcon("export"));

		ConfigurationManager.Configurable[] ca=(ConfigurationManager.Configurable[])
					getCore().getRootComponent().globalSearch(
					ConfigurationManager.Configurable.class).createArray(
					ConfigurationManager.Configurable.class);
		for(int i=0;i<ca.length;i++){
			configurableAdded(ca[i]);
		}
		cl=new CPSContainerListener(){
			public final void componentAdded(final CPSComponent c){
				getCore().getKernel().runLater(new Runnable(){public final void run(){
				configurableAdded((ConfigurationManager.Configurable)c);
				}});
			}
			public final void componentRemoved(CPSComponent c){//should this be delayed too????
				configurableRemoved((ConfigurationManager.Configurable)c);
			}
		};
		getCore().getRootComponent().addGlobalListener(
				ConfigurationManager.Configurable.class,cl);
		menu.add(load);
		menu.add(save);
		menu.add(edit);
		menu.add(call);
	}
	private final CPSContainerListener cl;
	public final void finish(){
		getCore().getIO().getLoadChange().removeListener(ccl);
		getCore().getRootComponent().removeGlobalListener(
				ConfigurationManager.Configurable.class,
				cl);
		super.finish();
	}
	private final Hashtable items=new Hashtable();
	private final void configurableAdded(final ConfigurationManager.Configurable v){

		final CPSGUI gui=(CPSGUI)getCore().getUI();
		JMenuItem load=new JMenuItem(v.getDescription().getName());
		JMenuItem save=new JMenuItem(v.getDescription().getName());
		JMenuItem edit=new JMenuItem(v.getDescription().getName());
		load.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FileDialog fd=new FileDialog(gui.getFrame().getParent(),
						"Import Configuration",FileDialog.LOAD);
				fd.show();
				if(fd.getFile()==null) return;
				manager.importF(v,new File(fd.getDirectory(),fd.getFile()));
			}
		});
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FileDialog fd=new FileDialog(gui.getFrame().getParent(),
						"Export Configuration",FileDialog.SAVE);
				fd.show();
				if(fd.getFile()==null) return;
				manager.exportF(v,new File(fd.getDirectory(),fd.getFile()));
			}
		});
		edit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				manager.editF(v);
			}
		});
		this.load.add(load);
		this.save.add(save);
		this.edit.add(edit);
		items.put(v,new JMenuItem[]{load,save,edit});
	}
	private final void configurableRemoved(ConfigurationManager.Configurable v){
		JMenuItem[] m=(JMenuItem[])items.get(v);
		load.remove(m[0]);
		save.remove(m[1]);
		edit.remove(m[2]);
	}
}