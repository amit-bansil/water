package org.cps.umd.gui;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.0a
 */
import java.awt.event.*;
import javax.swing.*;
import org.cps.*;
import org.cps.core.*;
import org.cps.ui.gui.*;
import org.cps.umd.simulation.*;

public final class TimeMenu extends CPSMenu{
	private final TimeData timeData;
	private final JMenuItem start,stop,step,bigStep;
	private final JMenu frameRates;
	private final JRadioButtonMenuItem otherFrameRate;
	public static final int TIME_MENU_PRIORITY=FileMenu.FILE_MENU_PRIORITY+1;
	public TimeMenu(CPSGUI gui,TimeData time) {
		super(gui,TIME_MENU_PRIORITY,CPSText.trans("time menu"));
		final JMenu menu=getMenu();
		timeData=time;
		time.addDependant(this);

		start=(CPSText.createMenuItem("start item"));
		stop=(CPSText.createMenuItem("stop item"));
		step=(CPSText.createMenuItem("step item"));
		bigStep=(CPSText.createMenuItem("bigStep item"));

		frameRates=CPSText.createMenu(("frameRate menu"));
		otherFrameRate=new JRadioButtonMenuItem(CPSText.trans("custom stepSize"));
		otherFrameRate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timeData.promptTimeStep();
			}
		});
		start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timeData.getProperty(timeData.RUNNING).set(new Boolean(true));
			}
		});
		start.setIcon(CPSResources.getImageIcon("Play16.gif"));

		stop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timeData.getProperty(timeData.RUNNING).set(new Boolean(false));
			}
		});
		stop.setIcon(CPSResources.getImageIcon("Pause16.gif"));
		step.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timeData.call(timeData.STEP,new Object[]{timeData.getProperty(timeData.TIME_STEP).get()});
			}
		});
		step.setIcon(CPSResources.getImageIcon("StepForward16.gif"));
		bigStep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timeData.call(timeData.PROMPT_STEP);
			}
		});
		menu.add(start);
		menu.add(stop);
		menu.add(step);
		menu.addSeparator();
		menu.add(frameRates);
		menu.add(bigStep);

		updateRunning();
		updateFrameRates();
		timeData.getProperty(timeData.RUNNING).getChange().addListener(runningListener);
		timeData.getProperty(timeData.FRAME_RATES).getChange().addListener(frameRatesListener);
		timeData.getProperty(timeData.TIME_STEP).getChange().addListener(timeStepListener);
	}
	public final void finish(){
		timeData.getProperty(timeData.RUNNING).getChange().removeListener(runningListener);
		timeData.getProperty(timeData.FRAME_RATES).getChange().removeListener(frameRatesListener);
		timeData.getProperty(timeData.TIME_STEP).getChange().removeListener(timeStepListener);
		super.finish();
	}
	private final ChangeListener runningListener=new ChangeListener(){
		public final void targetChanged(){
			updateRunning();
		}
	};
	private final ChangeListener frameRatesListener=new ChangeListener(){
		public final void targetChanged(){
			updateFrameRates();
		}
	};
	private final ChangeListener timeStepListener=new ChangeListener(){
		public final void targetChanged(){
			updateRate();
		}
	};

	private void updateRunning(){
		final boolean r=((Boolean)timeData.getProperty(timeData.RUNNING).get()).booleanValue();
		start.setEnabled(!r);
		stop.setEnabled(r);
		step.setEnabled(!r);
		bigStep.setEnabled(!r);
	}
	private float currentTimeStep;
	private float[] currentTimeSteps=new float[0];
	private final void updateFrameRates(){
		frameRates.removeAll();
		currentTimeStep=Float.NaN;
		final float[] timeSteps=(float[])timeData.getProperty(timeData.FRAME_RATES).get();
		currentTimeSteps=new float[timeSteps.length];
		System.arraycopy(timeSteps,0,currentTimeSteps,0,timeSteps.length);
		ButtonGroup b=new ButtonGroup();
		for(int i=0;i<timeSteps.length;i++){
			JRadioButtonMenuItem m=new JRadioButtonMenuItem(Float.toString(timeSteps[i]));
			m.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try{
						timeData.getProperty(timeData.TIME_STEP).set(new Float(
								((JRadioButtonMenuItem)e.getSource()).getText()));
					}catch(NumberFormatException ex){
						CPSErrors.internalException("Unexpected error parsing frame rate",ex);
					}
				}
			});
			b.add(m);
			frameRates.add(m);
		}
		frameRates.addSeparator();
		b.add(otherFrameRate);
		frameRates.add(otherFrameRate);

		updateRate();
	}
	private final void updateRate(){
		currentTimeStep=((Float)timeData.getProperty(timeData.TIME_STEP).get()).floatValue();
		for(int i=0;i<currentTimeSteps.length;i++){
			if(currentTimeSteps[i]==currentTimeStep){
				((JRadioButtonMenuItem)frameRates.getMenuComponent(i)).setSelected(true);
				return;
			}
		}
		otherFrameRate.setSelected(true);
	}
}