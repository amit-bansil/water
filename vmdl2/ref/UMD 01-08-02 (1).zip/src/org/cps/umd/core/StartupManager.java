package org.cps.umd.core;

import java.io.*;
import org.cps.*;
import org.cps.ui.gui.util.*;
import org.cps.io.*;
import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
/**
 * Initializes the application from the commandline.
 * @todo create a class that loads the startup manager using rmi to
 * force one virtual machine/provide shell behavior, remember to cascade new windows
 * @author Amit Bansil
 * @version 1.0
 */
public final class StartupManager extends UnicastRemoteObject implements RemoteStartup{
	public static final String RMI_NAME="StartupManager";

	/**
	 * The entry point from the commandline.
	 * It initialies CPS framework, shows a splash screen, loads UMD, opens a file,
	 * and shows the GUI.
	 *
	 * @param args An initial file to load.
	 * If length==0 or null the user will prompted to open a file.
	 * Otherwise, all the arguments will be concatenated together with spaces
	 * inbetween them to form a single file name which will be opened.
	 */
	public static final void main(String[] args){
		try{
			try{
				if((RemoteStartup)Naming.lookup(RMI_NAME)==null){
					throw new IllegalStateException();
				}
			}catch(Exception e){
				LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
				Naming.rebind(RMI_NAME,new StartupManager());
			}
			((RemoteStartup)Naming.lookup(RMI_NAME)).init(args);
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	private final long createdOn;
	public StartupManager()throws RemoteException{
		createdOn=System.currentTimeMillis();
	}
	public final String toString(){
		return super.toString()+" "+createdOn;
	}
	private boolean initialized=false;
	private transient UMDCore core;
	public final synchronized void init(String[] args){
		if(initialized){postLoad(args); core.getUI().setVisible(true); return;}
		CPS.initialize();

		CPSGUIToolkit.initialize();//needed for gui app
		CPSGUIToolkit.setLoading(true);
		try{
			core=new UMDCore();

			postLoad(args);

			CPSGUIToolkit.setLoading(false);
			core.getUI().setVisible(true);
			initialized=true;
		}catch(Exception e){
			CPSErrors.internalException("Application creation failure",e);
			initialized=false;
			CPSErrors.escape();
		}
	}
	private final void postLoad(String[] args){
		if(args==null||args.length==0) core.getIO().load();
		else{
			String name=args[0];
			for(int i=1;i<args.length;i++) name+=" "+args[i];
			core.getIO().load(new File(args[0]));
		}
	}
}