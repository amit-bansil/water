package org.cps.umd.core;

/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */
 /** @todo optimize loading by not calling finish when the same display/simulation is reloaded*/
import org.cps.core.*;
import org.cps.ui.gui.*;
import org.cps.umd.display.*;
import org.cps.umd.simulation.*;
import org.cps.io.*;
import org.cps.umd.gui.ConfigurationMenu;

public final class UMDCore extends CPSCore{//put this into CPSGUI
	public final CPSGUI getGUI(){return (CPSGUI)getUI();}
	public UMDCore(){
		display=new ComponentHandle(getRootComponent(),UMDDisplay.class);
		simulation=new ComponentHandle(getRootComponent(),UMDSimulation.class);
		new CPSGUI(this);
		new UMDDisplay(this.getRootComponent());
		new FileMenu(getGUI(),getIO());
		new ConfigurationMenu(getGUI(),new ConfigurationManager(getRootComponent()));//move to io
		getKernel().start();
	}
	private final ComponentHandle display,simulation;
	public UMDDisplay getDisplay(){
		return (UMDDisplay)display.get();
	}
	public UMDSimulation getSimulation(){
		return (UMDSimulation)simulation.get();
	}
}