package org.cps.umd.simulation;

/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */
import java.io.*;
import org.cps.*;
import org.cps.core.*;
import org.cps.data.*;
import org.cps.data.gui.*;
import org.cps.io.*;
import org.cps.ui.*;
import org.cps.ui.gui.*;
import org.cps.umd.core.*;
import org.cps.umd.display.*;
import org.cps.umd.gui.*;
import org.cps.data.*;
import org.cps.io.FileDescription;

public abstract class UMDSimulation extends CPSContainer implements ConfigurationManager.Configurable{
	public final FileDescription getFileDescription(){
		return desc;
	}
	private final FileDescription desc;

	protected UMDSimulation(CPSContainer parent)throws IOException{
		super(parent,"Simulation");

		data=new DataRoot(this);

		desc=new FileDescription("Simulation","bcp");

		displayData=new SimulationDisplayData();
		parameterData=new SimulationParameterData(data);
		inputParameterData=new SimulationInputParameterData(this,data);
		typeData=new SimulationTypeData();

		link(displayData,parameterData,inputParameterData,typeData);
	}
	private boolean firstLoad=true;//todo,make this unneccessary
	private final void checkFirstLoad(){
		if(!firstLoad)return;
		firstLoad=false;
		time=new TimeData(this);

		final CPSGUI gui=((UMDCore)getCore()).getGUI();
		new TimeMenu(gui,time);

		final UMDDisplay display=((UMDCore)getCore()).getDisplay();
		if(displayData.is3D()){
			addDependant((new Camera3D(display,.5f)));
			box=new BoxDrawer3D(display);
		}else if(displayData.is2D()){
			addDependant((new Camera2D(display,.5f)));
			box=new BoxDrawer2D(display);
		}else throw new UnknownError("not 2d or 3d???");
		new FastDrawer(display,this);

		addDependant(box);
		displayData.setBox(box);

		new DataGUI(this,gui,data);
	}
	private DataRoot data;
	//data
	private final SimulationDisplayData displayData;
	public final SimulationDisplayData getDisplayData(){
		return displayData;
	}
	private final SimulationParameterData parameterData;
	public final SimulationParameterData getParameterData(){
		return parameterData;
	}
	private final SimulationInputParameterData inputParameterData;
	public final SimulationInputParameterData getInputParameterData(){
		return inputParameterData;
	}
	private final SimulationTypeData typeData;
	public final SimulationTypeData getTypeData(){
		return typeData;
	}
	private TimeData time;
	public final TimeData getTimeData(){
		return time;
	}

	//initial state
	private BoxDrawer box;
	//control
	private boolean abort;
	public final void step(final float stepSize)throws SimulationException{
		abort=false;

		final float startTime=(float)getCurrentTime();
		setChanged(calculateStep(stepSize));

		String s=processMessages();
		if(s!=null) throw new SimulationException(s);

		if(abort&&(getCurrentTime()-startTime!=stepSize)){
			getCore().getUI().message(CPSText.trans("time advance abort"),
									  CPSText.numToString(getCurrentTime()-startTime,5)
									  +" "+CPSText.trans("time executed"));
		}
		if(changed){
			getChange().setChanged();
		}
	}
	//change support
	private final ChangeSupport change=new ChangeSupport();
	public final ChangeSupport getChange(){return change;}

	//change
	private final SimulationFlags flags=new SimulationFlags();
	private boolean changed=false;
	private final void setChanged(int flagsInt){
		flags.setFlag(flagsInt);
		changed=false;
		if(!flags.isChanged()) return;

		displayData.setChangeFlag(flags);
		inputParameterData.setChangeFlag(flags);
		parameterData.setChangeFlag(flags);
		typeData.setChangeFlag(flags);

		changed=true;
	}
	protected final void reset(){
		changed=false;
		displayData.reset();
		typeData.reset();
	}
	//progress
	private final ProgressListener progressListener=new ProgressListener(){
		public final double getProgress(){
			return getInstantTime();
		}
		public final void cancel(){
			abort=true;
			abort();
		}
	};
	public ProgressListener getProgressListener(){
		return progressListener;
	}
	//finish
	public final void finish(){
		if(open) close();
		unlink();
		super.finish();
	}
	private boolean open=false;

	public final void load(InputStream in)throws IOException{
		if(open) close();
		TempFile f=new TempFile(CONFIG);
		try{
			f.read(in);
			setChanged( load((String)f.getPath()) );
			open=true;

			String s=processMessages();
			if(s!=null) throw new IOException(s);

			if(changed){
				getChange().setChanged();
			}
		}finally{
			f.delete();
		}
		checkFirstLoad();
	}
	private static final FileDescription CONFIG=new FileDescription("Simulation Configuration",
			new String[]{"Simulation"},"bcp");
	public final FileDescription getDescription(){return CONFIG;}
	public final void save(OutputStream d)throws IOException{
		if(!open) throw new IllegalStateException("no file open");

		TempFile f=new TempFile(CONFIG);
		try{
			save(f.getPath());

			String s=processMessages();
			if(s!=null) throw new IOException(s);

			f.write(d);
		}finally{
			f.delete();
		}

	}
	private final String processMessages(){
		if(_msgString!=null) getCore().getUI().message("Simulation message",_msgString);

		if(_errorString!=null){
			String e=_errorString;
			_errorString=null;
			return e;
		}else return null;
	}
	//remove this funciton
	public final void callExt(final int f,final double[] values){
		try{
			getCore().getKernel().runNow(new CPSRunnable(){
				public final Object run()throws Exception{
					setChanged(call(f,values));//use file stream in 1.1

					String s=processMessages();
					if(s!=null) throw new IllegalArgumentException(s);
					return null;
				}
			});
		}catch(IllegalArgumentException e){
			throw e;
		}catch(Exception e){
			CPSErrors.unknownError(e);
		}
	}
	//hooks
	protected abstract int call(int fnum,double[] value);
	protected abstract void close();
	protected abstract void save(String name);
	protected abstract int load(String name);
	protected abstract void abort();
	protected abstract void unlink();
	protected abstract int calculateStep(float time);
	protected abstract void link(SimulationDisplayData displayData,
			  SimulationParameterData parameterData,
			  SimulationInputParameterData inputParameterData,SimulationTypeData typeData);
	protected abstract float getInstantTime();

	protected double _curTime=0;
	protected String _errorString=null;
	protected String _msgString=null;
	public final double getCurrentTime(){
		return _curTime;
	}
}