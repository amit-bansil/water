package org.cps.umd.simulation;
import org.cps.util.*;
import org.cps.core.*;
import org.cps.data.*;
/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */
import org.cps.*;
import java.util.StringTokenizer;

public class SimulationParameterData{

	//these are public for native access only
	public String[] parameterNames;
	public double[] parameterValues;
	public String[] parameterGroups;
	private InputVariable[] outputs;
	private final DataRoot data;
	public SimulationParameterData(DataRoot data) {
		this.data=data;
	}

	public void setChangeFlag(SimulationFlags flag){
		if(flag.isParameterDataChanged()){
			if(outputs!=null) for(int i=0;i<outputs.length;i++){
				data.objectRemoved(outputs[i]);
				outputs[i].finish();
			}
			outputs=new InputVariable[parameterNames.length];
			for(int i=0;i<outputs.length;i++){
				outputs[i]=new InputVariable(data,parameterGroups[i]+
				"."+parameterNames[i],(float)parameterValues[i]);
				data.objectAdded(outputs[i]);
			}
		}else if(flag.isParameterValuesChanged()){
			for(int i=0;i<outputs.length;i++){
				outputs[i].changeValue((float)parameterValues[i]);
			}
		}
	}
}