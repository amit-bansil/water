package org.cps.umd.simulation;
import org.cps.core.*;
import org.cps.data.*;
/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */

public class SimulationInputParameterData {
	public String[] parameterNames,parameterGroups,inputParameterNames;
	public int[] parameterCounts;
	public double[] parameterValues;//add change flag,mods
	private final DataRoot dataRoot;
	private final UMDSimulation sim;
	public SimulationInputParameterData(UMDSimulation sim,DataRoot data) {
		this.dataRoot=data;
		this.sim=sim;
	}
	private InputVariable[] inputs;
	public void setChangeFlag(SimulationFlags flag){//fix
		if(flag.isInputParameterDataChanged()){
			if(inputs!=null) for(int i=0;i<inputs.length;i++){
				dataRoot.objectRemoved(inputs[i]);
				inputs[i].finish();
			}
			inputs=new InputVariable[inputParameterNames.length];
			int j=0;
			for(int i=0;i<parameterNames.length;i++){
				final int ns=j;
				for(int m=0;m<parameterCounts[i];m++){
					inputs[j]=new InputVariable(dataRoot,parameterGroups[i]+"."+
					parameterNames[i]+"."+inputParameterNames[j],
						  (float)parameterValues[j]);
					dataRoot.objectAdded(inputs[j]);
					final int ni=i,nj=j,nm=m;

					inputs[ni].getValueChange().addListener(new ChangeListener(){
						public final void targetChanged(){//???
							double[] p=new double[parameterCounts[ni]];
							for(int k=0;k<p.length;k++) p[k]=parameterValues[ns+k];
							p[nm]=inputs[ni].getValue();
							sim.callExt(ni,p);
						}
					});
					j++;
				}
			}
		}else if(flag.isParameterValuesChanged()){
			for(int i=0;i<inputs.length;i++){
				inputs[i].changeValue((float)parameterValues[i]);
			}
		}
	}
}