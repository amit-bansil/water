package org.cps.umd.simulation;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public abstract class SimulationDefaults {

	//step data
	public static final float getMaxStep(){return 10E7f;}
	public static final float getMinStep(){return 0;}
	public static final float getDefaultStepSize(){return 2;}
	public static final float[] getDefaultStepSizes(){
			return new float[]{.01f,.1f,.5f,1f,2f,10f,100f};}
}