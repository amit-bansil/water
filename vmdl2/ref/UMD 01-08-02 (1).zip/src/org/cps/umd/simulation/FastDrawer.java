package org.cps.umd.simulation;

import org.cps.umd.display.*;
import org.cps.core.*;
import java.awt.*;
import org.cps.*;

/**
 * <p>Title: Universal Molecular Dynamics</p>
 * <p>Description: A Universal Interface for Molecular Dynamics Simulations</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Boston University</p>
 * @author Amit Bansil
 * @version 0.1a
 */

public class FastDrawer extends DataModel implements Drawer {
	boolean needsInit;
	boolean changed,positionsChanged,bondsChanged,radiiChanged,colorsChanged;
	private final SimulationDisplayData displayData;
	private final SimulationTypeData typeData;
	private final UMDSimulation sim;
	private int realBScanSize;
	private final BooleanProperty colorByKE,forceTypeColors,forceRadii,colorByNumber;
	private final FloatProperty spectrumMax,spectrumMin,hMax,hMin;
	private final FloatArrayProperty colorsA,radiiA;

	public FastDrawer(UMDDisplay display,UMDSimulation sim) {
		super(display,"Drawer");
		sim.addDependant(this);
		needsInit=true;

		colorByKE=new BooleanProperty(this,"colorByKE",false);
		forceTypeColors=new BooleanProperty(this,"Force Colors",false);
		forceRadii=new BooleanProperty(this,"Force Radii",false);
		spectrumMin=new FloatProperty(this,"spectrumMin",-1);
		spectrumMax=new FloatProperty(this,"spectrumMax",1);
		colorsA=new FloatArrayProperty(this,"typeColors",new float[0]);
		radiiA=new FloatArrayProperty(this,"typeRadii",new float[0]);
		colorByNumber=new BooleanProperty(this,"colorBy#",false);
		hMax=new FloatProperty(this,"Max Hue",1);
		hMin=new FloatProperty(this,"Min Hue",0);

		displayData=sim.getDisplayData();
		typeData=sim.getTypeData();
		this.sim=sim;
		getChange().addListener(new ChangeListener(){
			public final void targetChanged(){
				internalUpdate(true);
			}
		});

		sim.getChange().addListener(cl);
		positions=displayData.getPositions();
		types=typeData.getAtomTypes();
		internalUpdate(true);

		realBScanSize=displayData.getBScanSize();
		changed=positionsChanged=bondsChanged=radiiChanged=colorsChanged=true;
	}
	private boolean doInternalUpdate=false;
	public final void finish(){
		sim.getChange().removeListener(cl);
		super.finish();
	}
	private final ChangeListener cl=new ChangeListener(){
		public final void targetChanged(){
			internalUpdate(false);
		}
	};
	private final void doNothing(int o){//needs some code to prevent inlining to nothing?
		o++;
		o=(int)Math.sqrt(o*21);
	}
	public static final float SCALE_FACTOR=.25f,UNSCALE_FACTOR=.5f;

	private final void internalUpdate(boolean reMapTypes){
		doInternalUpdate=false;
		if(typeData.isAtomTypesChanged()){
			reMapTypes=true; types=typeData.getAtomTypes();
		}
		if(typeData.isTypeDescsChanged()) reMapTypes=true;
		if(displayData.isPositionsChanged()){
			positions=displayData.getPositions();
			changed=positionsChanged=true;
		}
		if(count!=displayData.getAtomCount()){
			count=displayData.getAtomCount();
			if(count>size||count/UNSCALE_FACTOR>size) size=(int)(count*(1+SCALE_FACTOR));
			changed=positionsChanged=true;
			if(count>types.length) reMapTypes=true;
		}
		if(displayData.isBondsChanged()){
			changed=bondsChanged=true;
		}
		if(displayData.isBScanSizeChanged()){
			changed=bondsChanged=true;
			realBScanSize=displayData.getBScanSize();
		}
		if(reMapTypes){
			createSpectrum();
			final int typeCount=typeData.getAtomTypeCount();
			int[] typeColorsxxx=new int[typeCount];
			int n=0,cxx;
			float[] c=typeData.getAtomTypeColors();
			final float[] caa=colorsA.getFloatArrayValue();
			if(forceTypeColors.getBooleanValue()){
				if(caa.length==c.length) c=caa;
				else if(caa.length<c.length){
					System.arraycopy(caa,0,c,0,caa.length);
					colorsA.setFloatArrayValue(c);
				}
			}
			//System.out.println("starting typeColors{");

			for(int i=0;i<typeCount;i++,n+=3){
				cxx=0xff000000|
							  ((int)(c[n+0]*255))<<16|
							  ((int)(c[n+1]*255))<< 8|
							  ((int)(c[n+2]*255))<< 0;
				typeColorsxxx[i]=cxx;
				//the line of code below should do absolutly nothing.
				//however without it some simulations (for example bonding) [perhaphs because of reaction?? causing typeRemap events]
				//will set some of its typeColors to 0 [black] and draw wrong
				doNothing(typeColorsxxx[i]);
				//System.out.println("["+new java.awt.Color(typeColors[i])+"]");// why does this nooed to be done in two statements???
			}
			this.typeColors=typeColorsxxx;
			//System.out.println("}done typeColors");
			types=typeData.getAtomTypes();
			float[] typeRadii=typeData.getAtomTypeRadii();
			final float[] raa=radiiA.getFloatArrayValue();
			if(forceRadii.getBooleanValue()){
				if(raa.length==typeRadii.length) typeRadii=raa;
				else if(raa.length<typeRadii.length){
					System.arraycopy(raa,0,typeRadii,0,raa.length);
					radiiA.setFloatArrayValue(typeRadii);
				}
			}
			if(radii.length!=types.length) radii=new float[types.length];
			for(int i=0;i<types.length;i++)radii[i]=typeRadii[types[i]];

			changed=true;
			radiiChanged=colorsChanged=true;
		}
	}
	public boolean needsRedraw(){return changed;}
	public boolean needsInit(){return needsInit;}

	int offset,bScanSize;

	public void init(int offset,int bScanSize){
		this.offset=offset;
		this.bScanSize=bScanSize;
		needsInit=false;
		changed=positionsChanged=bondsChanged=radiiChanged=colorsChanged=true;
	}
	public void offsetChanged(int offset){
		this.offset=offset;
		changed=positionsChanged=bondsChanged=radiiChanged=colorsChanged=true;
	}
	public void positionsAndRadiiLost(){
		changed=positionsChanged=radiiChanged=true;
	}
	public void colorsLost(){
		changed=colorsChanged=true;
	}
	public void bondsLost(){
		changed=positionsChanged=bondsChanged=radiiChanged=colorsChanged=true;
	}
	public void bScanSizeChanged(int scanSize){
		bScanSize=scanSize;
		changed=bondsChanged=true;
	}
	private float[] positions=new float[0];
	private float[] radii=new float[0];
	private int[] types=new int[0];
	private int[] typeColors=new int[0];

	private int count,size;
	private static final int[] SPECTRUM=new int[32];
	private void createSpectrum(){
		for(int i=0;i<SPECTRUM.length;i++)
			SPECTRUM[i]=Color.HSBtoRGB( hueChange((float)i/(SPECTRUM.length-1f)) ,1,1);
	}
	private final float hueChange(float i){
		return (i*(hMax.getFloatValue()-hMin.getFloatValue()))+hMin.getFloatValue();
	}
	public int redraw(CameraData camera,int[] xa,int[] ya,int[] za,int[] oR,int[] colors,int[] bonds){
		if(!changed) throw new IllegalStateException("attempt to update unchanged drawer");
		boolean doKE=false;
		if(positionsChanged||radiiChanged){
			camera.transform(positions,count,offset,xa,ya,za,radii,oR);
			if(colorByKE.getBooleanValue())doKE=colorByKE.getBooleanValue();
		}
		//System.out.println("STARTING COLORS[off="+offset+",count="+count+"]{");
		if(colorsChanged&&!colorByKE.getBooleanValue()&&!colorByNumber.getBooleanValue()){
			for(int i=0;i<count;i++){
				colors[i+offset]=typeColors[types[i]];
				//System.out.print("["+types[i]+"]");
			}/*not sure if this should be count*/
		}else doKE=colorByKE.getBooleanValue()||colorByNumber.getBooleanValue();
		if(doKE){
			final int l=SPECTRUM.length;
			final float off=-spectrumMin.getFloatValue();
			final float s=(1/(spectrumMax.getFloatValue()-spectrumMin.getFloatValue()))*l;
			final float[] v=displayData.getVelocties();
			int n=0;

			for(int i=0;i<count;i++){

				if(colorByNumber.getBooleanValue()){
					colors[i+offset]=
							SPECTRUM[(int)CPSMath.fit(0,l-1,((float)i/(float)count)*l)];
				}else{
					float vaa=v[n]*v[n]+v[n+1]*v[n+1]+v[n+2]*v[n+2];
					colors[i+offset]=
							SPECTRUM[(int)CPSMath.fit(0,l-1,(vaa+off)*s)];
				}
				n+=3;
			}
		}
		//System.out.println("}FINISHED COLORS");
		if(bondsChanged){//todo: real bonds support
			final int[] realBonds=displayData.getBonds();
			if(bScanSize==realBScanSize){
				System.arraycopy(realBonds,0,bonds,offset,count);
			}
			final int t=count*realBScanSize;
			int j=0,l;
			for(int i=0;i<t;i+=realBScanSize){
				int n=0;
				while(true){
					if(n>=realBScanSize){
						bonds[j+n]=-1;
						break;
					}
					l=realBonds[n+i];
					bonds[j+n]=l;
					if(l==-1) break;
					n++;
				}
				j+=bScanSize;
			}
		}
		changed=positionsChanged=bondsChanged=radiiChanged=colorsChanged=false;
		return count;
	}
	public int getMinBScanSize(){
		return realBScanSize;
	}
	public int getSize(){
		return size;
	}
}