package org.cps.umd.simulation;

/**
 * Title:        Universal Molecular Dynamics
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      Boston University
 * @author Amit Bansil
 * @version 0.0a
 */

public class SimulationException extends Exception {

	public SimulationException(String exception) {
		super(exception);
	}
}