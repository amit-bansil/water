package org.cps;

import java.text.*;
import java.util.*;

/**
 * Describes the current application.
 * This version is localized for Universal Molecular Dynamics.
 * It describes the source code version.
 * @author Amit Bansil
 * @version 1.0umd
 */

public final class CPSApplicationDescription {
	public static final String
		TITLE="Universal Molecular Dynamics",
		TITLE_SHORT="UMD";
	/**
	 * The version of the source code NOT the application release.
	 */
	public static final int
		VERSION_MAJOR=0,
		VERSION_MINOR=1,
		VERSION_MICRO=0;
	public static final String[]
		AUTHORS=new String[]{"Amit Bansil","Sergey Buldyrev"};
	public static final String
		DESCRIPTION="universal interface for molecular dynamics simulations";
	/**
	 * The date the source code was last modified on.
	 */
	public static final Date VERSION_DATE;
	static{
		Date temp;
		try{
			temp=new java.text.SimpleDateFormat("MM:DD:yy").parse("07:04:02",new ParsePosition(0));
			if(temp==null) throw new ParseException("failed to parse date",0);
		}catch(ParseException e){
			CPSErrors.internalException("malformed source modification date, Jan 1,1970 will be used",e);
			temp=new Date(0);
		}
		VERSION_DATE=temp;
	}
	public static final String
		ORGINIZATION="Center For Polymer Studies, Boston University";
	public static final String
		PACKAGE_NAME=CPS.PACKAGE_NAME+".umd";
	/**
	 * Describes the application version
	 * @return ShortName+Version+VersionDate
	 */
	public static final String getString(){
		return TITLE_SHORT+" "+VERSION_MAJOR+"."+VERSION_MINOR+"."+VERSION_MICRO+" "+VERSION_DATE.toString();
	}
}