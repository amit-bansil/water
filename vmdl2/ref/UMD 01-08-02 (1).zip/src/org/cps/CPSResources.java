package org.cps;

import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import org.cps.util.*;
/**
 * Methods for accessing external data files. This prevents classes from directly
 * accessing the underling filesystem to allow applets etc. to work properly from
 * the same codebase. Files are serached for in the packages locale specific resource dir
 * then the common resources dir. The directories may not contain common files.
 * @todo allow switching of language directory
 * @author Amit Bansil
 * @version 0.0a
 */
public final class CPSResources {
	private static final char sep='/';
	private static final String configDir="configurations"+File.separator;
	private static final String imageDir=sep+"images"+sep,resourcesDir=sep+"resources";
	private static final String commonDir=sep+"common"+sep;
	public static final void readByteData(String name,final byte[] data){
		try{
			BufferedInputStream bin=new BufferedInputStream(CPSResources.getStream(name));
			int ret=bin.read(data);
			if(ret!=data.length) throw new IOException(name+" corrupted, read: "+ret);
		}catch(IOException e){
			CPSErrors.internalException("Support file "+name+"couldn't be loaded, rendering may be incorrect",e);
		}
	}
	private static final String[] searchDirs=new String[2];
	static{
		searchDirs[1]=CPSApplicationDescription.PACKAGE_NAME.replace('.',sep)+resourcesDir
			   +sep+CPSConfiguration.load("language","eng")+sep;
		searchDirs[0]=CPSApplicationDescription.PACKAGE_NAME.replace('.',sep)+resourcesDir
			   +commonDir;
	}

	/**
	 * Finds a property file.
	 * @param name The base name of the property file (.properties is appended).
	 * @return A property Resource bundle. May be null(?).
	 * @throws IOException If the property resource bundle cannot be loaded.
	 */
	public static final PropertyResourceBundle getProperties(String name)throws IOException{
		name+=".properties";
		InputStream is;
		String s;
		for(int i=searchDirs.length-1;i>=0;i--){
			s=searchDirs[i]+name;
			is=ClassLoader.getSystemResourceAsStream(s);
			if(is!=null){
				checkConflict(s);
				return new PropertyResourceBundle(is);
			}
		}
		throw new MissingResourceException("Properties file could not be found","resources",name);
	}
	//Prevents duplicate files in diffrent search dirs
	private static final void checkConflict(String s){//s should have already been validated so a null pointer won't happen
		if(!CPS.isDebug()) return;
  /*try{ //getSystemResources not avail1.1
   Enumeration e=ClassLoader.getSystemResources(s);
   e.nextElement();
   if(e.hasMoreElements()) CPSErrors.warning("multiple resources for "+s+" unpredictable results are possible");
  }catch(IOException e){
   CPSErrors.warning("unexpected io exception",e);
  }*/

	}

	public static final String IOROOT_KEY="IORoot";
	static{
		CPSConfiguration.saveDefault(IOROOT_KEY,new File(System.getProperty("user.dir")));
	}
	/**
	 * dWhere user should find/save files. Determined by IORoot.
	 * @todo make an editor for this property
	 * @return A file.
	 */
	public static final File getIORoot(){
		return (File)CPSConfiguration.load(IOROOT_KEY);
	}

	private static final String[] imageExtensions=new String[]{"",".gif",".jpg",".jpeg"};
	/**
	 * Gets an image an wraps it in an ImageIcon class.
	 * @param name the base name of the image. The image dir of each search dir
	 * is searched, and if it is not found .gif, .jpg, and .jpeg extensions are tried.
	 * no extension should be specified unless the image is <I>always</i> of the same format
	 * @return the image icon
	 */
	public static final ImageIcon getImageIcon(final String name){
		URL u;
		String s;
		for(int i=0;i<imageExtensions.length;i++){
			for(int j=0;j<searchDirs.length;j++){
				s=searchDirs[j]+imageDir+name+imageExtensions[i];
				u=ClassLoader.getSystemResource(s);
				if(u!=null){
					checkConflict(s);
					return new ImageIcon(u);
				}
			}
		}
		throw new MissingResourceException("Image "+name+" could not be found","resources",name);
	}
	/**
	 * Gets an image icon an extracts the image, a blocking call.
	 * @param name Name of the image to find.
	 * @return An image.
	 */
	public static final Image getImage(final String name){
		return getImageIcon(name).getImage();
	}
	public static final InputStream getStream(final String name){
		InputStream in;
		String s;
		for(int j=0;j<searchDirs.length;j++){
			s=searchDirs[j]+name;
			in=ClassLoader.getSystemResourceAsStream(s);
			if(in!=null){
				return in;
			}
		}

		throw new MissingResourceException("Resource "+name+" could not be found","resources",name);
	}
	/** @todo create a library, include the ablity to 'scan' jar files */
	//returns all either files or input streams
	public static final File[] listFiles(final File f) {//copied from File 1.2 for 1.1 support
		String[] ss = f.list();
		if (ss == null) return null;
		int n = ss.length;
		File[] fs = new File[n];
		for (int i = 0; i < n; i++) {
			fs[i] = new File(f.getPath(), ss[i]);//getPath instead of path
		}
		return fs;
	}
	public static final File getParentFile(File f) {//same as above
		String p = f.getParent();
		if (p == null) return null;
		return new File(p/*, f.getPrefixLength()*/);//prefix length lost,may cause problems
	}
	public static final File[] findFiles(FilenameFilter f){
		String cp=System.getProperty("java.class.path");
		if(cp==null) cp=".";
		else cp+=File.pathSeparator+".";

		final StringTokenizer rootNames=new StringTokenizer(
				cp,File.pathSeparator,false);
		final CPSVector roots=new CPSVector();

		File root;
		while(rootNames.hasMoreElements()){
			String next=rootNames.nextToken();
			if(next.endsWith(".jar")||next.endsWith(".zip")){
			}else{
				root=new File(next+File.separator+configDir);
				if(root.exists()){
					File[] files=listFiles(root);
					for(int i=0;i<files.length;i++){
						if(files[i].isDirectory()||
						   f.accept(getParentFile(files[i]),files[i].getName()) ){
						if(!roots.contains(files[i]))roots.add(files[i]);
						}
					}
				}
			}
		}
		final Object[] oa=roots.toArray();
		final File[] fa=new File[oa.length];
		for(int i=0;i<fa.length;i++)fa[i]=(File)oa[i];

		return fa;
	}
	private static final File findFile(String name){
		final URL l=ClassLoader.getSystemResource(name);
		if(l==null) return null;
		else return new File(l.getFile());
	}
	//todo write macos version
	public static final void registerExtension(String lnkName,String icoName,String ext){
		registerExtension(lnkName,icoName,ext,"file");
	}
	public static final void registerExtension(String lnkName,String icoName,String ext,String name){
		if(ext.startsWith(".")) ext=ext.substring(1);

		final File lnk=findFile(lnkName);
		if(lnk==null) throw new IllegalArgumentException("shell file "+icoName+" not found");
		if((lnk.getAbsolutePath()+icoName).equals(CPSConfiguration.load("extLnk:"+ext,""))){
			return;
		}
		CPSConfiguration.save("extLnk:"+ext,lnk.getAbsolutePath()+icoName);

		final File ico=findFile(icoName);
		if(ico==null) throw new IllegalArgumentException("ico file "+icoName+"not found");
		final String fName=CPSApplicationDescription.TITLE_SHORT+"."+name;
		String icoPath=ico.getAbsolutePath();
		String lnkPath=lnk.getAbsolutePath();

		icoPath=CPSText.replace(icoPath,'\\',"\\\\");
		lnkPath=CPSText.replace(lnkPath,'\\',"\\\\");
		final File reg=new File("reg_"+ext+".reg");
		try{
			PrintWriter pw=new PrintWriter(new BufferedOutputStream(new FileOutputStream(reg)));
			pw.println("Windows Registry Editor Version 5.00");
			pw.println();
			pw.println("[HKEY_CLASSES_ROOT\\."+ext+"]");
			pw.println("@=\""+fName+"\"");
			pw.println("Content Type\"=\"application/x-"+name+"\"");
			pw.println();
			pw.println("[HKEY_CLASSES_ROOT\\"+fName+"]");
			pw.println("\"EditFlags\"=dword:00000000");
			pw.println("\"BrowserFlags\"=dword:00000008");
			pw.println();
			pw.println("[HKEY_CLASSES_ROOT\\"+fName+"\\DefaultIcon]");
			pw.println("@=\""+icoPath+"\"");
			pw.println();
			pw.println("[HKEY_CLASSES_ROOT\\"+fName+"\\shell]");
			pw.println("@=\"open\"");
			pw.println();
			pw.println("[HKEY_CLASSES_ROOT\\"+fName+"\\shell\\open]");
			pw.println();
			pw.println("[HKEY_CLASSES_ROOT\\"+fName+"\\shell\\open\\command]");
			pw.println("@=\""+lnkPath+" \\\"%1\\\"\"");

			pw.flush();
			pw.close();

			System.out.println("registering type "+ext+" successfully registered");

			Runtime.getRuntime().exec("regedit -s"+reg.getName());

			System.out.println("File type "+ext+" successfully registered");
		}catch(IOException e){
			CPSErrors.ioException("Could not register file extension "+ext,e);
		}

	}
}