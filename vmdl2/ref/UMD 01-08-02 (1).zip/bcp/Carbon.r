/*
 *  Carbon launch resource for OS X
 *  � 1997-2000 Metrowerks Corp.
 *
 *  Questions and comments to:
 *       <mailto:support@metrowerks.com>
 *       <http://www.metrowerks.com/>
*/

/*----------------------------carb � Carbon on OS X launch information --------------------------*/
type 'carb' {
};


resource 'carb'(0) {
};