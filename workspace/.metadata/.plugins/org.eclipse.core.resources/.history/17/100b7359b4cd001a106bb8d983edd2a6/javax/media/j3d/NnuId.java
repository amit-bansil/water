/*
 * $RCSfile: NnuId.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:55:22 $
 * $State: Exp $
 */

package javax.media.j3d;

/**
 * Defines a "not necessarily unique ID"
 */

interface NnuId {
    
    abstract int equal(NnuId obj);

    abstract int getId();
    
}
