/*
 * $RCSfile: ObjectUpdate.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:55:26 $
 * $State: Exp $
 */

package javax.media.j3d;

/*
 * A Object Update interface.  Any object that can be put in the ObjectUpdate list
 * must implement this interface.
 */

interface ObjectUpdate {

    /**
     * The actual update function.
     */
    abstract void updateObject();
}
