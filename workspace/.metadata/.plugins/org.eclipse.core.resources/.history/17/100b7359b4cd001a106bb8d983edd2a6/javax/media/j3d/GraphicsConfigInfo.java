/*
 * $RCSfile: GraphicsConfigInfo.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:54:13 $
 * $State: Exp $
 */

package javax.media.j3d;

class GraphicsConfigInfo {
    private int reqStencilSize = 0;
    private long fbConfig = 0L;

    int getRequestedStencilSize() {
	return reqStencilSize;
    }

    void setRequestedStencilSize(int reqSS) {
	reqStencilSize = reqSS;
    }
    
    long getFBConfig() {
	return fbConfig;
    }
    
    void setFBConfig(long fbC) {
	fbConfig = fbC;
    }

}
