/*
 * $RCSfile: IllegalRenderingStateException.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:54:18 $
 * $State: Exp $
 */

package javax.media.j3d;

/**
 * Indicates an illegal state for rendering.  This exception is currently
 * unused.
 */
public class IllegalRenderingStateException extends IllegalStateException {

    /**
     * Create the exception object with default values.
     */
    public IllegalRenderingStateException(){
    }

    /**
     * Create the exception object that outputs message.
     * @param str the message string to be output.
     */
    public IllegalRenderingStateException(String str){
	super(str);
    }

}
