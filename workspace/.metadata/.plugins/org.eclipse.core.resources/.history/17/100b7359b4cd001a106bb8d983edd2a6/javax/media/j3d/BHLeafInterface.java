/*
 * $RCSfile: BHLeafInterface.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:53:08 $
 * $State: Exp $
 */

package javax.media.j3d;

interface BHLeafInterface {
    
    abstract BoundingBox computeBoundingHull();

    abstract boolean isEnable();

    abstract boolean isEnable(int visibilityPolicy);
    
    // Can't use getLocale, it is used by BranchGroupRetained
    abstract Locale getLocale2();
    
}
