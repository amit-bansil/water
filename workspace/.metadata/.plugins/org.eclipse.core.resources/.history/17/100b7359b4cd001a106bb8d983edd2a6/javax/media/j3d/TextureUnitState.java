/*
 * $RCSfile: TextureUnitState.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.4 $
 * $Date: 2006/01/05 03:56:11 $
 * $State: Exp $
 */

package javax.media.j3d;

import java.util.Hashtable;

/**
 * The TextureUnitState object defines all texture mapping state for a
 * single texture unit.  An appearance object contains an array of
 * texture unit state objects to define the state for multiple texture
 * mapping units.  The texture unit state consists of the
 * following:
 *
 * <p>
 * <ul>
 * <li>Texture - defines the texture image and filtering
 * parameters used when texture mapping is enabled. These attributes
 * are defined in a Texture object.</li><p>
 *
 * <li>Texture attributes - defines the attributes that apply to
 * texture mapping, such as the texture mode, texture transform,
 * blend color, and perspective correction mode. These attributes
 * are defined in a TextureAttributes object.</li><p>
 *
 * <li>Texture coordinate generation - defines the attributes
 * that apply to texture coordinate generation, such as whether
 * texture coordinate generation is enabled, coordinate format
 * (2D or 3D coordinates), coordinate generation mode (object
 * linear, eye linear, or spherical reflection mapping), and the
 * R, S, and T coordinate plane equations. These attributes
 * are defined in a TexCoordGeneration object.</li><p>
 * </ul>
 *
 * @see Appearance
 * @see Texture
 * @see TextureAttributes
 * @see TexCoordGeneration
 *
 * @since Java 3D 1.2
 */
public class TextureUnitState extends NodeComponent {

    /**
     * Specifies that this TextureUnitState object allows reading its
     * texture, texture attribute, or texture coordinate generation
     * component information.
     */
    public static final int ALLOW_STATE_READ =
	CapabilityBits.TEXTURE_UNIT_STATE_ALLOW_STATE_READ;

    /**
     * Specifies that this TextureUnitState object allows writing its
     * texture, texture attribute, or texture coordinate generation
     * component information.
     */
    public static final int ALLOW_STATE_WRITE =
	CapabilityBits.TEXTURE_UNIT_STATE_ALLOW_STATE_WRITE;

   // Array for setting default read capabilities
    private static final int[] readCapabilities = {
        ALLOW_STATE_READ
    };
    
    /**
     * Constructs a TextureUnitState component object using defaults for all
     * state variables. All component object references are initialized
     * to null.
     */
    public TextureUnitState() {
	// Just use default values
        // set default read capabilities
        setDefaultReadCapabilities(readCapabilities);
    }

    /**
     * Constructs a TextureUnitState component object using the specified
     * component objects.
     *
     * @param texture object that specifies the desired texture
     * map and texture parameters
     * @param textureAttributes object that specifies the desired
     * texture attributes
     * @param texCoordGeneration object that specifies the texture coordinate
     * generation parameters
     */
    public TextureUnitState(Texture texture,
			     TextureAttributes textureAttributes,
			     TexCoordGeneration texCoordGeneration) {
        // set default read capabilities
        setDefaultReadCapabilities(readCapabilities);

	((TextureUnitStateRetained)this.retained).initTexture(texture);
	((TextureUnitStateRetained)this.retained).initTextureAttributes(
							textureAttributes);
	((TextureUnitStateRetained)this.retained).initTexCoordGeneration(
							texCoordGeneration);
    }

    /**
     * Creates the retained mode TextureUnitStateRetained object that this
     * TextureUnitState component object will point to.
     */
    void createRetained() {
	this.retained = new TextureUnitStateRetained();
	this.retained.setSource(this);
    }

    /**
     * Sets the texture, texture attributes, and texture coordinate
     * generation components in this TextureUnitState object to the
     * specified component objects.
     *
     * @param texture object that specifies the desired texture
     * map and texture parameters
     * @param textureAttributes object that specifies the desired
     * texture attributes
     * @param texCoordGeneration object that specifies the texture coordinate
     * generation parameters
     */
    public void set(Texture texture,
		    TextureAttributes textureAttributes,
		    TexCoordGeneration texCoordGeneration) {

	if (isLiveOrCompiled())
	    if (!this.getCapability(ALLOW_STATE_WRITE))
		throw new CapabilityNotSetException(J3dI18N.getString("TextureUnitState0"));

	((TextureUnitStateRetained)this.retained).setTextureUnitState(
				texture, textureAttributes, texCoordGeneration);
    }

    /**
     * Sets the texture object to the specified object.
     * Setting it to null disables texture mapping for the
     * texture unit corresponding to this TextureUnitState object.
     * @param texture object that specifies the desired texture
     * map and texture parameters
     * @exception CapabilityNotSetException if appropriate capability is
     * not set and this object is part of live or compiled scene graph
     */
    public void setTexture(Texture texture) {
	if (isLiveOrCompiled())
	    if (!this.getCapability(ALLOW_STATE_WRITE))
		throw new CapabilityNotSetException(J3dI18N.getString("TextureUnitState0"));

	((TextureUnitStateRetained)this.retained).setTexture(texture);
    }

    /**
     * Retrieves the current texture object.
     * @return the texture object
     * @exception CapabilityNotSetException if appropriate capability is
     * not set and this object is part of live or compiled scene graph
     */
    public Texture getTexture() {
	if (isLiveOrCompiled())
	    if (!this.getCapability(ALLOW_STATE_READ))
		throw new CapabilityNotSetException(J3dI18N.getString("TextureUnitState1"));

	return ((TextureUnitStateRetained)this.retained).getTexture();
    }

    /**
     * Sets the textureAttributes object to the specified object.
     * Setting it to null will result in default attribute usage for the.
     * texture unit corresponding to this TextureUnitState object.
     * @param textureAttributes object that specifies the desired
     * texture attributes
     * @exception CapabilityNotSetException if appropriate capability is
     * not set and this object is part of live or compiled scene graph
     */
    public void setTextureAttributes(TextureAttributes textureAttributes) {
	if (isLiveOrCompiled())
	    if (!this.getCapability(ALLOW_STATE_WRITE))
		throw new CapabilityNotSetException(J3dI18N.getString("TextureUnitState2"));

	((TextureUnitStateRetained)this.retained).setTextureAttributes(textureAttributes);
    }

    /**
     * Retrieves the current textureAttributes object.
     * @return the textureAttributes object
     * @exception CapabilityNotSetException if appropriate capability is
     * not set and this object is part of live or compiled scene graph
     */
    public TextureAttributes getTextureAttributes() {
	if (isLiveOrCompiled())
	    if (!this.getCapability(ALLOW_STATE_READ))
		throw new CapabilityNotSetException(J3dI18N.getString("TextureUnitState3"));

	return ((TextureUnitStateRetained)this.retained).getTextureAttributes();
    }

    /**
     * Sets the texCoordGeneration object to the specified object.
     * Setting it to null disables texture coordinate generation for the
     * texture unit corresponding to this TextureUnitState object.
     * @param texCoordGeneration object that specifies the texture coordinate
     * generation parameters
     * @exception CapabilityNotSetException if appropriate capability is
     * not set and this object is part of live or compiled scene graph
     */
    public void setTexCoordGeneration(TexCoordGeneration texCoordGeneration) {
	if (isLiveOrCompiled())
	    if (!this.getCapability(ALLOW_STATE_WRITE))
		throw new CapabilityNotSetException(J3dI18N.getString("TextureUnitState4"));

	((TextureUnitStateRetained)this.retained).setTexCoordGeneration(texCoordGeneration);
    }

    /**
     * Retrieves the current texCoordGeneration object.
     * @return the texCoordGeneration object
     * @exception CapabilityNotSetException if appropriate capability is
     * not set and this object is part of live or compiled scene graph
     */
    public TexCoordGeneration getTexCoordGeneration() {
	if (isLiveOrCompiled())
	    if (!this.getCapability(ALLOW_STATE_READ))
		throw new CapabilityNotSetException(J3dI18N.getString("TextureUnitState5"));

	return ((TextureUnitStateRetained)this.retained).getTexCoordGeneration();
    }


    /**
     * @deprecated replaced with cloneNodeComponent(boolean forceDuplicate)
     */
    public NodeComponent cloneNodeComponent() {
        TextureUnitState ts = new TextureUnitState();
        ts.duplicateNodeComponent(this);
        return ts;
    }

    /**
     * NOTE: Applications should <i>not</i> call this method directly.
     * It should only be called by the cloneNode method.
     *
     * @deprecated replaced with duplicateNodeComponent(
     *  NodeComponent originalNodeComponent, boolean forceDuplicate)
     */
    public void duplicateNodeComponent(NodeComponent originalNodeComponent) {
	checkDuplicateNodeComponent(originalNodeComponent);
    }

    /**
     * Copies all TextureUnitState information from
     * <code>originalNodeComponent</code> into
     * the current node.  This method is called from the
     * <code>cloneNode</code> method which is, in turn, called by the
     * <code>cloneTree</code> method.<P>
     *
     * @param originalNodeComponent the original node to duplicate.
     * @param forceDuplicate when set to <code>true</code>, causes the
     *  <code>duplicateOnCloneTree</code> flag to be ignored.  When
     *  <code>false</code>, the value of each node's
     *  <code>duplicateOnCloneTree</code> variable determines whether
     *  NodeComponent data is duplicated or copied.
     *
     * @exception RestrictedAccessException if this object is part of a live
     *  or compiled scenegraph.
     *
     * @see Node#cloneTree
     * @see NodeComponent#setDuplicateOnCloneTree
     */
    void duplicateAttributes(NodeComponent originalNodeComponent,
			     boolean forceDuplicate) {
	super.duplicateAttributes(originalNodeComponent, forceDuplicate);

	Hashtable hashtable = originalNodeComponent.nodeHashtable;

	TextureUnitStateRetained app = (TextureUnitStateRetained) originalNodeComponent.retained;

	TextureUnitStateRetained rt = (TextureUnitStateRetained) retained;

	rt.setTexture((Texture) getNodeComponent(app.getTexture(),
						 forceDuplicate,
						 hashtable));

	rt.setTextureAttributes((TextureAttributes) getNodeComponent(
						app.getTextureAttributes(),
						forceDuplicate,
						hashtable));

	rt.setTexCoordGeneration((TexCoordGeneration) getNodeComponent(
						app.getTexCoordGeneration(),
						forceDuplicate,
						hashtable));
    }

    /**
     *  This function is called from getNodeComponent() to see if any of
     *  the sub-NodeComponents  duplicateOnCloneTree flag is true.
     *  If it is the case, current NodeComponent needs to
     *  duplicate also even though current duplicateOnCloneTree flag is false.
     *  This should be overwrite by NodeComponent which contains sub-NodeComponent.
     */
    boolean duplicateChild() {
	if (getDuplicateOnCloneTree())
	    return true;

	TextureUnitStateRetained rt = (TextureUnitStateRetained) retained;

	NodeComponent nc = rt.getTexture();
	if ((nc != null) && nc.duplicateChild())
	    return true;

	nc = rt.getTextureAttributes();
	if ((nc != null) && nc.getDuplicateOnCloneTree())
	    return true;

	nc = rt.getTexCoordGeneration();
	if ((nc != null) && nc.getDuplicateOnCloneTree())
	    return true;

	return false;
    }
}
