/*
 * $RCSfile: NodeComponentUpdate.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:55:24 $
 * $State: Exp $
 */

package javax.media.j3d;

/**
 * A Node Component Update interface.  Any object that can be put in the 
 * node component updateCheck list must implement this interface.
 */

interface NodeComponentUpdate {

    /**
     * The actual update function.
     */
    abstract void updateNodeComponentCheck();
}
