/*
 * $RCSfile: NodeData.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.4 $
 * $Date: 2006/01/05 03:55:24 $
 * $State: Exp $
 */

package javax.media.j3d;


class NodeData {
    // per path node data
    // XXXX: replace per path mirror objects with node data
    // XXXX: move other basic node's data here
    SwitchState switchState = null;
}
