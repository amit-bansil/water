/*
 * $RCSfile: RenderMethod.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:55:44 $
 * $State: Exp $
 */

package javax.media.j3d;

/**
 * The RenderMethod interface is used to create various ways to render
 * different geometries.
 */

interface RenderMethod {

    /**
     * The actual rendering code for this RenderMethod
     */
    abstract boolean render(RenderMolecule rm, Canvas3D cv, int pass, 
			 RenderAtomListInfo ra, int dirtyBits);
}
