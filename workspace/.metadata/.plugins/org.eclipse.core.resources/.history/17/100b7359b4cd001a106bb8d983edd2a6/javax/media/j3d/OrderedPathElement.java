/*
 * $RCSfile: OrderedPathElement.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:55:29 $
 * $State: Exp $
 */

package javax.media.j3d;

import java.util.ArrayList;

class OrderedPathElement extends Object {
    OrderedGroupRetained orderedGroup;
    Integer childId;

    OrderedPathElement(OrderedGroupRetained og, Integer orderedId) {
        orderedGroup = og;
        childId = orderedId;
    }
}
