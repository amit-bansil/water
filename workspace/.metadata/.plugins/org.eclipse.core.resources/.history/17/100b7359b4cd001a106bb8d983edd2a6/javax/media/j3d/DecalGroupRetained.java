/*
 * $RCSfile: DecalGroupRetained.java,v $
 *
 * Copyright (c) 2006 Sun Microsystems, Inc. All rights reserved.
 *
 * Use is subject to license terms.
 *
 * $Revision: 1.3 $
 * $Date: 2006/01/05 03:53:37 $
 * $State: Exp $
 */

package javax.media.j3d;

class DecalGroupRetained extends OrderedGroupRetained {

    DecalGroupRetained() {
        this.nodeType = NodeRetained.DECALGROUP;
    }
}
